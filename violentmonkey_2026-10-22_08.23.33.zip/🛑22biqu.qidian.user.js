// ==UserScript==
// @name 🛑22biqu.qidian
// @namespace   ScriptCat
// @description css字体大小 内容屏蔽  id # class .
// @version      220505.21
// @author       You
// @license MIT
// @run-at       document-end


// @include       *22biqu.*
// @include      *.qidian.com*

// @exclude   *sina*

// @grant       none

// ==/UserScript==

/*body > [href^="固定/批量匹配"]{}无^固定指定
body > embed[id][src]{display:none !important}


m.xsbiquge.la###chaptercontent > p:nth-of-type(1)

www.sudugu.com##a[href="/xianxia/"]


*/


!(function() {
    'use strict';

    // 通过CSS预先隐藏元素，避免闪烁
    var css = `
#content,
#cContent,
.content,
.container,
#mycontent,
div#htmlContent,
DIV#chaptercontent,
DIV.chapter-content,
#txt,DIV.txt,DIV.con,
DIV.txtnav,
DIV.articlecontent,
DIV#novelcontent,
div#nr1,
DIV#Lab_Contents,
DIV#neirong1{background:#fff;color:#000;font-size:23px;line-height: 38px;text-indent: 0em;padding-left: 6px;padding-right:4px;!important;}

DIV.addbook{display:none!important;}
LI.visible-sm.visible-xs{display:none!important;}

P.Readpage{max-height: 20px;text-align:center;}

p.Readpage:nth-child(4){display:none !important}

DIV[style='position:fixed;']{display:none !important}



A[href^='javascript']{display:none !important}





DIV.setbox,DIV.setli{display:none!important;}
FOOTER{display:none!important;}
.iconhome{float:right;}
.iconback, .iconhome{margin-top:3px; font-size:12px; text-align:center; color:#fff; line-height:40px; width:40px; height:40px;}
.channelHeader2 .iconhome{margin-top:-44px;}
.iconback img, .iconhome img{width:40px; height:40px; font-size:12px; text-align:center; line-height:40px;}

{background:#fff;color:#000;font-size:23px;padding-left: 26px;padding-right:24px}

P.cp{background:#fff;color:#000;font-size:23px;line-height: 38px;text-indent: 0em;!important;}

屏蔽{display:none !important}

//qidian


DIV.y-popup{display:none !important}
.pl-22px{display:none !important}
.justify-center.items-center.flex.z-5.inset-0.fixed{display:none !important}
.bg-on-image-white-70.z-4.inset-0.fixed{display:none !important}
.bottom-48px{display:none !important}
NAV.flex.bg-inherit.h-44px.pr-16px.justify-between.text-s-gray-500.fixed.top-0.w-full.items-center.z-5{display:none !important}



    `;
    var style = document.createElement('style');
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);



})();

