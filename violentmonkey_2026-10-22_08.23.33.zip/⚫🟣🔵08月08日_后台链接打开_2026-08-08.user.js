// ==UserScript==
// @name    ⚫🟣🔵08月08日_后台链接打开_2026-08-08
// @namespace    http://tampermonkey.net/
// @version      4.1
// @description  点击悬浮球为当前网站切换并保存「关闭 / 前台新标签 / 后台静默」模式，自动按域名记忆。支持设置延迟打开时间（0-30秒），防止批量打开导致浏览器卡顿；内置操作日志记录每次拦截行为。点击齿轮打开设置面板，可统一管理所有网站配置、全局默认值、延迟设置与日志。支持拖拽与边缘磁吸，位置自动记忆。适用于需要为不同网站批量设置不同打开方式的场景。
// @author       You
// @match        *://*/*
// @grant        GM_openInTab
// @grant        GM_registerMenuCommand
// @run-at       document-end
// @downloadURL https://update.greasyfork2.org/scripts/591424/08%E6%9C%8808%E6%97%A5_%E5%90%8E%E5%8F%B0%E9%93%BE%E6%8E%A5%E6%89%93%E5%BC%80_2026-08-08.user.js
// @updateURL https://update.greasyfork2.org/scripts/591424/08%E6%9C%8808%E6%97%A5_%E5%90%8E%E5%8F%B0%E9%93%BE%E6%8E%A5%E6%89%93%E5%BC%80_2026-08-08.meta.js
// ==/UserScript==

(function() {
    'use strict';

    // ==================== 功能说明 ====================
    // 本脚本为网页链接提供三种打开方式（关闭/前台/后台），并按网站域名自动记忆偏好。
    // 点击悬浮球即可为当前网站保存专属模式；点击右上角齿轮进入设置面板，可统一管理所有网站配置、
    // 设置全局默认模式、调整延迟打开秒数（0-30秒，缓解批量打开造成的浏览器压力），并查看操作日志。
    // 悬浮球支持拖拽与边缘磁吸，位置自动保存。适用于批量查阅搜索结果、论坛列表、资讯聚合等场景。
    // ==================== 配置区 ====================
    const MODES = [
        { key: 'off',    label: '⚫',    color: '#3a3a3a00', desc: '链接正常打开' },
        { key: 'front',  label: '🟣',    color: '#1e88e500', desc: '新标签页前台打开' },
        { key: 'back',   label: '🔵',    color: '#43a04700', desc: '静默后台打开' }
    ];

    const SETTINGS_KEY = 'bgOpenSettings_v41';
    let settings = {
        defaultMode: 0,      // 新网站默认
        domains: {},         // 各网站专属配置
        delaySeconds: 0,     // 延迟秒数
        logs: []             // 操作日志
    };

    // ==================== 工具函数 ====================
    function getDomain() {
        return location.hostname.replace(/^www\./, '');
    }

    function loadSettings() {
        try {
            const raw = localStorage.getItem(SETTINGS_KEY);
            if (raw) {
                const parsed = JSON.parse(raw);
                settings = Object.assign(settings, parsed);
                if (!Array.isArray(settings.logs)) settings.logs = [];
            }
        } catch(e) {}
    }

    function saveSettings() {
        try {
            localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
        } catch(e) {}
    }

    function getEffectiveMode() {
        const domain = getDomain();
        if (settings.domains[domain] !== undefined) {
            return settings.domains[domain];
        }
        return settings.defaultMode;
    }

    function getModeByIndex(idx) {
        return MODES[idx] || MODES[0];
    }

    function addLog(domain, url, mode, delay) {
        settings.logs.unshift({
            time: new Date().toISOString(),
            domain,
            url: url.length > 200 ? url.slice(0, 200) + '…' : url,
            mode,
            delay
        });
        if (settings.logs.length > 200) {
            settings.logs = settings.logs.slice(0, 200);
        }
        saveSettings();
        // 面板若打开，实时刷新
        const listEl = document.getElementById('bgosLogList');
        if (listEl && panel.style.display === 'flex') {
            renderLogs();
        }
    }

    // ==================== 创建悬浮球 ====================
    const ball = document.createElement('div');
    ball.id = 'bgOpenBall';
    ball.innerHTML = `
        <div id="ballInner" style="
            width: 15px; height: 15px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            flex-direction: column;
            box-shadow: 0 4px 6px rgba(0,0,0,0.45);
            cursor: pointer; transition: all 0.25s ease;
            color: #fff; font-size: 8px; font-weight: 700;
            line-height: 1.2; user-select: none; touch-action: none;
            background: #3a3a3a; position: relative;
        ">
            <span id="ballMode">关闭</span>
            <span id="ballSub" style="font-size:9px;opacity:0.85;">点击切换</span>
            <div id="bgosGear" style="
                position: absolute; top: 0px; right: 0px;
                width: 0px; height: 0px; background: rgba(255,255,255,0.95);
                color: #222; border-radius: 50%; font-size: 0px;
                display: flex; align-items: center; justify-content: center;
                box-shadow: 0 2px 6px rgba(0,0,0,0);
                cursor: pointer; z-index: 2; font-weight: 700;
            " title="打开设置">⚙</div>
        </div>
    `;
    ball.style.cssText = `
        position: fixed; z-index: 2147483647;
        width: 14px; height: 14px;
        cursor: pointer; touch-action: none;
    `;
//Dtotn.id="Dtotnyd";

//Dtotn.innerHTML="";//右下♥♥♥♥

//Dtotn.setAttribute("style","font-size:5px !important;color:#27618D;width:15px !important;height:60vh !important;line-height:50vh !important;text-align:center !important;background-color:rgba(250,250,250,0);box-shadow:inset 0px 0px 2px rgba(39,97,141,0.5);position:fixed !important;bottom:7vh !important;right:-20px !important;z-index:9999999999 !important;border-radius:10px 10px 10px 10px");

var Dtotnyd1, Dtotnyd2;

    document.addEventListener("touchstart",

    function(e) {

        Dtotnyd1 = e.changedTouches[0].clientY

    });

    document.addEventListener("touchmove",

    function(e) {

       Dtotnyd2 = e.changedTouches[0].clientY;

        if (Dtotnyd2 - Dtotnyd1 > 0) {

            document.getElementById("bgOpenBall").style.display = "none"

        } else {

            document.getElementById("bgOpenBall").style.display = "block"

        }

    });/*none♥block*/







    document.body.appendChild(ball);

    const ballInner = document.getElementById('ballInner');
    const ballMode  = document.getElementById('ballMode');
    const ballSub   = document.getElementById('ballSub');
    const gearBtn   = document.getElementById('bgosGear');

    gearBtn.addEventListener('mousedown', e => e.stopPropagation());
    gearBtn.addEventListener('touchstart', e => e.stopPropagation(), { passive: false });
    gearBtn.addEventListener('click', e => {
        e.stopPropagation();
        openSettings();
    });

    // ==================== 创建设置面板 ====================
    const panel = document.createElement('div');
    panel.id = 'bgosPanel';
    panel.style.cssText = `
        position: fixed; inset: 0; z-index: 2147483646;
        display: none; align-items: center; justify-content: center;
        font-family: system-ui, -apple-system, sans-serif;
    `;
    panel.innerHTML = `
        <div id="bgosMask" style="
            position: absolute; inset: 0;
            background: rgba(0,0,0,0.55);
            opacity: 0; transition: opacity 0.25s ease;
        "></div>
        <div id="bgosCard" style="
            position: relative; width: 380px; max-width: 92vw;
            background: #1e1e1e; color: #eee;
            border-radius: 16px; padding: 20px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.6);
            transform: scale(0.92); opacity: 0;
            transition: all 0.3s cubic-bezier(0.25,0.8,0.25,1);
            border: 1px solid rgba(255,255,255,0.08);
            max-height: 85vh; overflow-y: auto;
        ">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
                <h3 style="margin:0; font-size:16px; font-weight:600;">打开方式设置</h3>
                <button id="bgosClose" style="
                    background: rgba(255,255,255,0.1); border: none;
                    color: #fff; width: 28px; height: 28px;
                    border-radius: 50%; cursor: pointer;
                    font-size: 16px; line-height: 1;
                ">×</button>
            </div>

            <div style="margin-bottom:14px;">
                <div style="font-size:12px; color:#888; margin-bottom:4px;">当前网站</div>
                <div id="bgosCurDomain" style="font-size:14px; font-weight:500; color:#fff; word-break:break-all;"></div>
                <div style="margin-top:6px; display:flex; align-items:center; gap:8px;">
                    <span style="font-size:12px; color:#888;">当前模式：</span>
                    <span id="bgosCurBadge" style="
                        display:inline-block; padding: 2px 10px;
                        border-radius: 12px; font-size: 12px; font-weight: 600;
                        background: #3a3a3a; color: #fff;
                    ">关闭</span>
                </div>
            </div>

            <div style="margin-bottom:18px;">
                <div style="font-size:12px; color:#888; margin-bottom:6px;">全局默认模式（新网站自动使用）</div>
                <select id="bgosDefaultSelect" style="
                    width: 100%; padding: 8px 10px; border-radius: 8px;
                    background: #2a2a2a; color: #eee; border: 1px solid rgba(255,255,255,0.1);
                    font-size: 13px; outline: none; cursor: pointer;
                ">
                    <option value="0">关闭（链接正常打开）</option>
                    <option value="1">前台（新标签页前台打开）</option>
                    <option value="2">后台（静默后台打开）</option>
                </select>
            </div>

            <div style="margin-bottom:18px;">
                <div style="font-size:12px; color:#888; margin-bottom:6px;">延迟打开（缓解浏览器压力）</div>
                <div style="display:flex; align-items:center; gap:12px;">
                    <input type="range" id="bgosDelayRange" min="0" max="30" step="1" style="
                        flex:1; accent-color:#1e88e5; height:4px;
                    ">
                    <span id="bgosDelayValue" style="
                        font-size:13px; color:#fff; min-width:44px; text-align:right; font-weight:600;
                    ">0秒</span>
                </div>
                <div style="font-size:11px; color:#666; margin-top:4px;">批量打开时建议设为 1~5 秒，0 秒表示立即打开</div>
            </div>

            <div style="margin-bottom:14px;">
                <div style="font-size:12px; color:#888; margin-bottom:6px;">已保存的网站</div>
                <div id="bgosList" style="
                    max-height: 160px; overflow-y: auto;
                    border-radius: 8px; background: #252525;
                    border: 1px solid rgba(255,255,255,0.06);
                ">
                    <div style="padding: 12px; text-align: center; color: #666; font-size: 12px;">暂无专属配置</div>
                </div>
            </div>

            <div style="margin-bottom:8px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                    <div style="font-size:12px; color:#888;">操作日志（最近50条）</div>
                    <button id="bgosClearLog" style="
                        background: rgba(255,100,100,0.15); color: #ff8a8a;
                        border: none; border-radius: 6px; padding: 3px 10px;
                        font-size: 11px; cursor: pointer;
                    ">清空日志</button>
                </div>
                <div id="bgosLogList" style="
                    max-height: 140px; overflow-y: auto;
                    border-radius: 8px; background: #252525;
                    border: 1px solid rgba(255,255,255,0.06);
                ">
                    <div style="padding: 10px; text-align: center; color: #666; font-size: 12px;">暂无记录</div>
                </div>
            </div>

            <div style="font-size:11px; color:#666; margin-top:10px; line-height:1.5;">
                提示：点击悬浮球即可为当前网站保存专属模式，在此统一管理。
            </div>
        </div>
    `;
    document.body.appendChild(panel);

    const bgosMask = document.getElementById('bgosMask');
    const bgosCard = document.getElementById('bgosCard');
    const bgosClose = document.getElementById('bgosClose');

    function openSettings() {
        panel.style.display = 'flex';
        panel.offsetHeight;
        bgosMask.style.opacity = '1';
        bgosCard.style.opacity = '1';
        bgosCard.style.transform = 'scale(1)';
        renderSettings();
    }

    function closeSettings() {
        bgosMask.style.opacity = '0';
        bgosCard.style.opacity = '0';
        bgosCard.style.transform = 'scale(0.92)';
        setTimeout(() => {
            panel.style.display = 'none';
        }, 250);
    }

    bgosMask.addEventListener('click', closeSettings);
    bgosClose.addEventListener('click', closeSettings);

    // 默认模式
    document.getElementById('bgosDefaultSelect').addEventListener('change', function() {
        settings.defaultMode = parseInt(this.value, 10);
        saveSettings();
        updateUI();
        renderSettings();
        showToast('全局默认已保存');
    });

    // 延迟滑块
    const delayRange = document.getElementById('bgosDelayRange');
    const delayValue = document.getElementById('bgosDelayValue');
    delayRange.addEventListener('input', function() {
        settings.delaySeconds = parseInt(this.value, 10);
        delayValue.textContent = settings.delaySeconds + '秒';
        saveSettings();
    });

    // 清空日志
    document.getElementById('bgosClearLog').addEventListener('click', () => {
        settings.logs = [];
        saveSettings();
        renderLogs();
        showToast('日志已清空');
    });

    function renderSettings() {
        const domain = getDomain();
        const modeIdx = getEffectiveMode();
        document.getElementById('bgosCurDomain').textContent = domain;
        const badge = document.getElementById('bgosCurBadge');
        const m = getModeByIndex(modeIdx);
        badge.textContent = m.label;
        badge.style.background = m.color;

        document.getElementById('bgosDefaultSelect').value = String(settings.defaultMode);
        delayRange.value = settings.delaySeconds || 0;
        delayValue.textContent = (settings.delaySeconds || 0) + '秒';

        // 已保存网站列表
        const listEl = document.getElementById('bgosList');
        const keys = Object.keys(settings.domains);
        if (keys.length === 0) {
            listEl.innerHTML = '<div style="padding: 12px; text-align: center; color: #666; font-size: 12px;">暂无专属配置<br>点击悬浮球即可保存当前网站</div>';
        } else {
            listEl.innerHTML = keys.map(d => {
                const mIdx = settings.domains[d];
                const mo = getModeByIndex(mIdx);
                const isCur = d === domain;
                return `
                    <div style="
                        display: flex; justify-content: space-between; align-items: center;
                        padding: 8px 10px; border-bottom: 1px solid rgba(255,255,255,0.04);
                        font-size: 12px; ${isCur ? 'background: rgba(255,255,255,0.04);' : ''}
                    ">
                        <div style="display:flex; align-items:center; gap:8px; overflow:hidden;">
                            <span style="color: #aaa; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 160px;" title="${d}">${d}</span>
                            <span style="
                                display:inline-block; padding: 1px 6px; border-radius: 8px;
                                font-size: 11px; font-weight: 600; background: ${mo.color}; color: #fff;
                                white-space: nowrap;
                            ">${mo.label}</span>
                            ${isCur ? '<span style="color:#1e88e5; font-size:11px;">当前</span>' : ''}
                        </div>
                        <button data-del="${d}" style="
                            background: rgba(255,100,100,0.15); color: #ff8a8a;
                            border: none; border-radius: 6px; padding: 2px 8px;
                            font-size: 11px; cursor: pointer;
                        ">删除</button>
                    </div>
                `;
            }).join('');
            listEl.querySelectorAll('button[data-del]').forEach(btn => {
                btn.addEventListener('click', () => {
                    const delDomain = btn.getAttribute('data-del');
                    delete settings.domains[delDomain];
                    saveSettings();
                    updateUI();
                    renderSettings();
                    showToast(`已删除 ${delDomain} 的配置`);
                });
            });
        }

        renderLogs();
    }

    function renderLogs() {
        const listEl = document.getElementById('bgosLogList');
        if (!listEl) return;
        if (!settings.logs || settings.logs.length === 0) {
            listEl.innerHTML = '<div style="padding: 10px; text-align: center; color: #666; font-size: 12px;">暂无记录</div>';
            return;
        }
        listEl.innerHTML = settings.logs.slice(0, 50).map(log => {
            const d = new Date(log.time);
            const timeStr = `${d.getHours().toString().padStart(2,'0')}:${d.getMinutes().toString().padStart(2,'0')}:${d.getSeconds().toString().padStart(2,'0')}`;
            const delayTag = log.delay > 0 ? `<span style="color:#ff9800; font-size:10px; margin-left:4px;">+${log.delay}s</span>` : '';
            const mo = MODES.find(m => m.label === log.mode) || MODES[0];
            return `
                <div style="padding:6px 8px; border-bottom:1px solid rgba(255,255,255,0.04); font-size:11px; line-height:1.4;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="color:#888;">${timeStr}</span>
                        <div style="display:flex; align-items:center;">
                            <span style="display:inline-block; padding:1px 6px; border-radius:6px; background:${mo.color}; color:#fff; font-size:10px; font-weight:600;">${log.mode}</span>
                            ${delayTag}
                        </div>
                    </div>
                    <div style="color:#aaa; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:2px;" title="${log.url}">${log.domain}</div>
                </div>
            `;
        }).join('');
    }

    // ==================== 位置恢复 ====================
    function restorePos() {
        try {
            const saved = localStorage.getItem('bgBallPos_0808');
            if (saved) {
                const p = JSON.parse(saved);
 /*
                ball.style.left = p.left + 'px';
                ball.style.top  = p.top + 'px';
                ball.style.right = 'auto';
                ball.style.bottom = 'auto';
                */

        ball.style.right = '0vw';
        ball.style.top = '-1px';
                return;
            }
        } catch(e) {}
        ball.style.right = '0vw';
        ball.style.top = '-1px';
    }
    restorePos();

    // ==================== 更新外观 ====================
    function updateUI() {
        const mIdx = getEffectiveMode();
        const m = getModeByIndex(mIdx);
        const domain = getDomain();
        const hasCustom = settings.domains[domain] !== undefined;

        ballInner.style.background = m.color;
        ballInner.style.transform = 'scale(0.92)';
        setTimeout(() => ballInner.style.transform = 'scale(1)', 120);
        ballMode.textContent = m.label;

        if (hasCustom) {
            ballSub.textContent = '';//🔴🔴已固定
            ballSub.style.opacity = '1';
            ballSub.style.color = '#ffeb3b';
        } else {
            ballSub.textContent = '';//🔴🔴点击切换
            ballSub.style.opacity = '0.85';
            ballSub.style.color = '#fff';
        }
    }

    // ==================== 切换模式（保存到当前网站） ====================
    function toggleMode() {
        const domain = getDomain();
        const current = getEffectiveMode();
        const next = (current + 1) % MODES.length;

        settings.domains[domain] = next;
        saveSettings();

        updateUI();
        showToast(`${domain} → ${MODES[next].label}`);
    }

    // ==================== Toast 提示 ====================
    let toastTimer = null;
    function showToast(msg) {
        let t = document.getElementById('bgBallToast');
        if (!t) {
            t = document.createElement('div');
            t.id = 'bgBallToast';
            t.style.cssText = `
                position: fixed; bottom: -190px; left: 50%;
                transform: translateX(-50%) translateY(10px);
                background: rgba(0,0,0,0.82); color: #fff;
                padding: 10px 20px; border-radius: 24px;
                font-size: 14px; z-index: 2147483647;
                pointer-events: none; opacity: 0;
                transition: all 0.3s ease;
                font-family: system-ui,-apple-system,sans-serif;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                white-space: nowrap;
            `;
            document.body.appendChild(t);
        }
        t.textContent = msg;
        t.style.opacity = '1';
        t.style.transform = 'translateX(-50%) translateY(0)';
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => {
            t.style.opacity = '0';
            t.style.transform = 'translateX(-50%) translateY(10px)';
        }, 1600);
    }

    // ==================== 拖拽 + 磁吸 ====================
    let isDrag = false, hasMoved = false, startX, startY, startL, startT;

    function getPos() {
        const r = ball.getBoundingClientRect();
        return { x: r.left, y: r.top };
    }

    function savePos() {
        const r = ball.getBoundingClientRect();
        try {
            localStorage.setItem('bgBallPos_0808', JSON.stringify({
                left: r.left, top: r.top
            }));
        } catch(e) {}
    }

    function snapToEdge() {
        const r = ball.getBoundingClientRect();
        const w = window.innerWidth, h = window.innerHeight;
        const gap = 12;
        let nx = r.left, ny = r.top;

        const distLeft   = nx;
        const distRight  = w - nx - r.width;
        const distTop    = ny;
        const distBottom = h - ny - r.height;

        const minH = Math.min(distLeft, distRight);
        const minV = Math.min(distTop, distBottom);

        if (minH < minV) {
            nx = (distLeft < distRight) ? gap : (w - r.width - gap);
        } else {
            ny = (distTop < distBottom) ? gap : (h - r.height - gap);
        }

        ball.style.transition = 'all 0.35s cubic-bezier(0.25,0.8,0.25,1)';
/*🔴🔴        ball.style.left = nx + 'px';
        ball.style.top  = ny + 'px';
        ball.style.right = 'auto';
        ball.style.bottom = 'auto';
        */


        ball.style.right = '0vw';
        ball.style.top = '-1px';
        setTimeout(() => { ball.style.transition = ''; savePos(); }, 350);
    }

    function onStart(clientX, clientY) {
        const p = getPos();
        startL = p.x; startT = p.y;
        startX = clientX; startY = clientY;
        isDrag = true; hasMoved = false;
        ball.style.transition = '';
    }

    function onMove(clientX, clientY) {
        if (!isDrag) return;
        const dx = clientX - startX, dy = clientY - startY;
        if (Math.abs(dx) + Math.abs(dy) > 4) hasMoved = true;
        let nx = startL + dx, ny = startT + dy;
        const w = window.innerWidth - 56, h = window.innerHeight - 56;
        nx = Math.max(0, Math.min(w, nx));
        ny = Math.max(0, Math.min(h, ny));
/*        ball.style.left = nx + 'px';
        ball.style.top  = ny + 'px';
        ball.style.right = 'auto';
        ball.style.bottom = 'auto';*/


        ball.style.right = '0vw';
        ball.style.top = '-1px';
    }

    function onEnd() {
        if (!isDrag) return;
        isDrag = false;
        if (hasMoved) {
            snapToEdge();
        } else {
            savePos();
            toggleMode();
        }
        hasMoved = false;
    }

    ball.addEventListener('touchstart', e => {
        const t = e.touches[0];
        onStart(t.clientX, t.clientY);
    }, { passive: false });
    ball.addEventListener('touchmove', e => {
        e.preventDefault();
        const t = e.touches[0];
        onMove(t.clientX, t.clientY);
    }, { passive: false });
    ball.addEventListener('touchend', e => {
        e.preventDefault();
        onEnd();
    });

    ball.addEventListener('mousedown', e => {
        onStart(e.clientX, e.clientY);
    });
    window.addEventListener('mousemove', e => {
        onMove(e.clientX, e.clientY);
    });
    window.addEventListener('mouseup', () => {
        onEnd();
    });

    // ==================== 链接拦截（含延迟） ====================
    document.addEventListener('click', function(e) {
        const modeIdx = getEffectiveMode();
        if (modeIdx === 0) return;
        if (ball.contains(e.target)) return;
        if (panel.contains(e.target)) return;

        const link = e.target.closest('a');
        if (!link || !link.href) return;
        if (link.href.startsWith('javascript:')) return;
        if (link.href.startsWith('mailto:')) return;
        if (link.href.startsWith('tel:')) return;
        if (link.getAttribute('download')) return;
        if (link.target === '_self' && link.href === location.href + '#') return;

        e.preventDefault();
        e.stopPropagation();

        const isBack = (modeIdx === 2);
        const delayMs = (settings.delaySeconds || 0) * 1000;
        const url = link.href;
        const domain = new URL(url).hostname;
        const modeLabel = getModeByIndex(modeIdx).label;

        const executeOpen = () => {
            try {
                GM_openInTab(url, {
                    active: !isBack,
                    insert: true,
                    setParent: true
                });
            } catch(err) {
                window.open(url, '_blank');
            }
        };

        if (delayMs > 0) {
            showToast(`${settings.delaySeconds}秒后${modeLabel}打开`);
            setTimeout(() => {
                executeOpen();
                addLog(domain, url, modeLabel, settings.delaySeconds);
            }, delayMs);
        } else {
            executeOpen();
            addLog(domain, url, modeLabel, 0);
        }

        if (navigator.vibrate) navigator.vibrate(25);
    }, true);

    // ==================== 油猴菜单 ====================
    try {
        GM_registerMenuCommand('🔁 切换当前网站模式', toggleMode);
        GM_registerMenuCommand('⚙ 打开设置面板', openSettings);
    } catch(e) {}

    // ==================== 初始化 ====================
    loadSettings();
    updateUI();
    //🔴🔴showToast('✨ 悬浮球已加载：点击切换当前网站模式');
})();