// ==UserScript==
// @name   📛网页广告拦截器
// @namespace    http://tampermonkey.net/
// @version      6.7.0
// @author       DeepSeek&GLM
// @description  一个手机端via浏览器适用的强大广告拦截器。注入时机分三档：电脑端浏览器配合脚本猫/Violentmonkey/Tampermonkey(动态模式)多为解析前早注入，仅开「拦截内嵌脚本」即可拦截多数广告链；手机端Firefox/雨见+篡改猴等真扩展为半早 注入；Via等套壳/WebView浏览器为加载完成后晚注入。因此某些网页在电脑端仅开「拦截内嵌脚本」即可去广告，手机端套壳浏览器上却大概率失效——此时若拦截日记有记录而广告仍残留，可开启「清空残留容器」尝试隐藏；更建议开启「拦截动态脚本」+「拦截第三方资源」，或直接开启「覆盖层拦截」「苹果设备模拟」。
// @match        *://*/*
// @license      MIT
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_deleteValue
// @grant        GM_registerMenuCommand
// @grant        GM_notification
// @grant        GM_listValues
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @connect      *
// @run-at       document-start
// ==/UserScript==

(function () {
  'use strict';
  // ===== 注入时机判档 =====
  // 【功能】脚本启动时读取一次 document.readyState, 区分两类宿主:
  //        早注入档 = document-start 注入(readyState=loading, 主流管理器扩展);
  //        晚注入档 = 页面加载完成后注入(readyState=interactive/complete, 套壳浏览器)。
  // 【机制】晚注入档下解析期已结束: 解析期专用的竞速布置按判档跳过;
  //        零操作跳转保护以「注入后窗口」替代「加载期」; 存量 DOM 由初始扫描直接接管。
  var _rs0 = 'loading';
  try { _rs0 = document.readyState || 'loading'; } catch (e) {}
  var _LATE_REGIME = _rs0 !== 'loading';
  var _INIT_AT = Date.now();
  var _ZERO_TOUCH_LATE_MS = 10000;
  // ===== 轻量扩展求值引擎 =====
  // 支持计算样式谓词 :matches-css / :matches-css-before / :matches-css-after
  // (prop: value, 值支持精确/通配符*/正则 /re/, 大小写不敏感), 基底用原生 querySelectorAll 求值;
  // :has()/:not() 为浏览器原生伪类, 路由层把纯原生的这类规则分流进样式表轨;
  // :contains()/:has-text()/:upward()/:nth-ancestor()/:xpath() 等扩展伪类不支持,
  // 含这些伪类的规则按原样跳过（不生效）。
  var MiniExtendedCss = (function () {
    var _PRED_RE = /:matches-css(-before|-after)?\(\s*([a-zA-Z-]+)\s*:\s*([^)]*)\)/g;
    var _UNSUP_RE = /:(has|contains|has-text|upward|nth-ancestor|xpath|if|if-not|abp-has)\(/;
    // 宽基底（*）规则 MO 重扫限频窗: 新增节点风暴时星号子树求值（限界候选×计算样式）是
    // 扩展引擎最贵的一段, 窗口内的 MO 批次跳过星号扫描, 由补扫定时器对根节点一次兜底
    var _STAR_THROTTLE_MS = 500;
    function splitList(s) {
      var out = [];
      var cur = '';
      for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (c === ',') { if (cur.trim()) out.push(cur.trim()); cur = ''; }
        else cur += c;
      }
      if (cur.trim()) out.push(cur.trim());
      return out;
    }
    // 解析单条扩展选择器: 剥掉 :matches-css* 谓词得原生基底; 返回 null 表示非扩展/不支持
    function parseSelector(sel) {
      var preds = [];
      var rest = sel.replace(_PRED_RE, function (m, pseudo, prop, val) {
        preds.push({ pseudo: pseudo ? pseudo.replace(/^-/, '') : null, prop: prop.trim().toLowerCase(), value: val.trim() });
        return '';
      });
      if (!preds.length) return null;
      if (_UNSUP_RE.test(rest)) return null;
      var base = rest.trim();
      if (!base) base = '*';
      return { base: base, preds: preds };
    }
    function cssVal(el, pseudo, prop, memo) {
      try {
        var mkey = (pseudo || '') + '|' + prop;
        var em = null;
        if (memo) { em = memo.get(el); if (em && em.has(mkey)) return em.get(mkey); }
        var v;
        if (pseudo) {
          if (!_globals.getComputedStyle) return null;
          v = _globals.getComputedStyle(el, pseudo === 'before' ? '::before' : '::after').getPropertyValue(prop);
        } else {
          v = _globals.getComputedStyle ? _globals.getComputedStyle(el).getPropertyValue(prop) : null;
        }
        if (memo) { if (!em) { em = new Map(); memo.set(el, em); } em.set(mkey, v); }
        return v;
      } catch (e) { return null; }
    }
    // 谓词值三态匹配: 精确（无通配符）/通配符（*/跨任意段）/正则(/re/ 包裹, 无 flags), 大小写不敏感;
    // z-index 纯数字走数值相等快路径; 编译结果缓存在谓词对象上（扫描热路径只编译一次）
    function buildPredMatcher(pred) {
      if (pred._m) return pred._m;
      var val = String(pred.value);
      var m;
      if (pred.prop === 'z-index' && /^\d+$/.test(val)) {
        m = { t: 'zi', n: parseInt(val, 10) };
      } else if (val.length > 2 && val.charAt(0) === '/' && val.charAt(val.length - 1) === '/') {
        try { m = { t: 're', r: new RegExp(val.slice(1, -1), 'i') }; } catch (e) { m = null; }
        if (!m) m = { t: 'exact', s: val.toLowerCase() };
      } else if (val.indexOf('*') !== -1) {
        var parts = val.split('*');
        for (var k = 0; k < parts.length; k++) parts[k] = parts[k].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        try { m = { t: 're', r: new RegExp('^' + parts.join('.*') + '$', 'i') }; } catch (e2) { m = { t: 'exact', s: val.toLowerCase() }; }
      } else {
        m = { t: 'exact', s: val.toLowerCase() };
      }
      pred._m = m;
      return m;
    }
    function predOk(el, pred, memo) {
      var v = cssVal(el, pred.pseudo, pred.prop, memo);
      if (v === null || v === undefined) return false;
      var m = buildPredMatcher(pred);
      if (m.t === 'zi') { var n = parseInt(v, 10); return !isNaN(n) && n === m.n; }
      if (m.t === 're') { try { return m.r.test(String(v)); } catch (e) { return false; } }
      return String(v).toLowerCase() === m.s;
    }
    function ruleOk(el, parsed, memo) {
      for (var i = 0; i < parsed.preds.length; i++) {
        if (!predOk(el, parsed.preds[i], memo)) return false;
      }
      return true;
    }
    function MiniExtendedCss(opts) {
      this._rules = [];
      this._hidden = [];
      this._mo = null;
      try {
        var sheet = (opts && opts.styleSheet) || '';
        var lines = sheet.split(String.fromCharCode(10));
        for (var i = 0; i < lines.length; i++) {
          var line = lines[i].trim();
          if (!line) continue;
          var br = line.indexOf('{');
          if (br <= 0) continue;
          var list = splitList(line.slice(0, br));
          for (var j = 0; j < list.length; j++) {
            var parsed = parseSelector(list[j]);
            if (parsed) this._rules.push({ parsed: parsed, sel: list[j] });
          }
        }
      } catch (e) {}
      this._hasStarRule = false;
      for (var _ri = 0; _ri < this._rules.length; _ri++) {
        if (this._rules[_ri].parsed.base === '*') { this._hasStarRule = true; break; }
      }
      this._lastStarScanAt = 0;
      this._starTimer = null;
      this._churnAt = [];
      this._churnN = [];
      this._susp = [];
    }
    // 宽基底（*）规则 MO 限频补扫: 限频窗内跳过的星号扫描由这个定时器对根节点一次兜底,
    // 覆盖窗内累积的全部新增节点; 非星号规则（窄基底）不受限频, 照常即时求值
    MiniExtendedCss.prototype._scheduleStarCatchup = function () {
      var self = this;
      if (self._starTimer) return;
      self._starTimer = _setTimeout(function () {
        self._starTimer = null;
        try { self._scan(_document.documentElement || _document, null); } catch (e) {}
      }, _STAR_THROTTLE_MS);
    };
    // 猫鼠熔断: 单条扩展规则在滚动窗内增量隐藏计数, 超阈值即冻结该规则本页的增量求值,
    // 阈值高于引擎单轮候选上限 —— 单轮扫描永不触发, 持续多轮重建(约>60个/秒)才熔断,
    // 已隐藏元素保持原状(样式观察器维持), 刷新自动恢复。仅统计变更驱动路径, 初始全量
    // 扫描不计 —— 正常页面远达不到阈值, 触发即意味着页面在持续批量重建同类元素
    MiniExtendedCss.prototype._noteHide = function (idx, fromMo) {
      if (!fromMo) return;
      var now = Date.now();
      if (!this._churnAt[idx] || now - this._churnAt[idx] > 10000) { this._churnAt[idx] = now; this._churnN[idx] = 0; }
      this._churnN[idx]++;
      if (this._churnN[idx] > 600 && !this._susp[idx]) {
        this._susp[idx] = true;
        try {
          if (typeof LogManager !== 'undefined' && LogManager.add) LogManager.add('elementCssBlock', null, {
            type: 'CSS_EXT_CHURN_BREAK',
            detail: '扩展规则短窗隐藏超限(页面在持续批量重建同类元素), 本页暂停其增量求值, 刷新恢复: ' + String((this._rules[idx] && this._rules[idx].sel) || '').slice(0, 120)
          });
        } catch (e) {}
      }
    };

    MiniExtendedCss.prototype._hide = function (el) {
      try {
        if (el.getAttribute && el.getAttribute('data-ab-ext') === '1') return;
        // 脚本自身 UI 豁免(标记面板宿主已 markSafe): 宽形态规则不得把自家拾取面板当广告藏掉
        if (typeof _isSafe === 'function' && _isSafe(el)) return;
        if (typeof _hasSafeAncestor === 'function' && _hasSafeAncestor(el)) return;
        if (el.setAttribute) el.setAttribute('data-ab-ext', '1');
        el.style.setProperty('display', 'none', 'important');
        el.style.setProperty('visibility', 'hidden', 'important');
        el.style.setProperty('pointer-events', 'none', 'important');
        this._protect(el);
        this._hidden.push(el);
      } catch (e) {}
    };
    MiniExtendedCss.prototype._scan = function (root, memo, fromMo) {
      try {
        if (!root) return;
        // 无谓容器标签整棵跳过: 这类节点自身不可能满足扩展谓词（不可见/无计算形态）,
        // 省掉"每新增节点 × 每规则 qSA+computed 求值"里的整段空转
        if (root.nodeType === 1 && (root.tagName === 'SCRIPT' || root.tagName === 'STYLE' || root.tagName === 'LINK' || root.tagName === 'META' || root.tagName === 'NOSCRIPT' || root.tagName === 'BR' || root.tagName === 'HR')) return;
        var self = this;
        // 全量基底（*）规则的子树候选整批只查一次, 多条 * 规则共享同一集合 ——
        // 子树查询数与规则数解耦, N 条宽版规则共用一次 qSA
        var starSub = null;
        for (var i = 0; i < self._rules.length; i++) {
          var p = self._rules[i].parsed;
          if (self._susp && self._susp[i]) continue;
          try {
            if (root.matches && root.matches(p.base) && ruleOk(root, p, memo)) { self._noteHide(i, fromMo); if (!self._susp[i]) self._hide(root); }
          } catch (e) {}
          if (p.base === '*') {
            // 宽基底 MO 限频: 限频窗内的 MO 批次跳过星号子树求值, 由补扫定时器兜底
            if (fromMo && self._hasStarRule) {
              var _nowS = Date.now();
              if (_nowS - self._lastStarScanAt < _STAR_THROTTLE_MS) { self._scheduleStarCatchup(); continue; }
              self._lastStarScanAt = _nowS;
            }
            // 全量基底（去标签化的形态规则）: 命中元素常是新增容器内的子节点, 必须扫子树;
            // 限界预筛 class/id 持有者(伪元素层样式必须以 class/id 为目标)防超大子树卡段;
            // 非渲染元素(script/style/link/meta/noscript/br/hr)的伪元素无计算形态,
            // position 恒不等于 fixed, 候选直接剔除（结果不变, 省去无效求值）
            if (!starSub) {
              starSub = [];
              if (root.querySelectorAll) {
                try {
                  var _sub = root.querySelectorAll('*[class],[id]');
                  for (var _sk = 0; _sk < _sub.length && _sk < 500; _sk++) {
                    var _tg = (_sub[_sk].tagName || '').toUpperCase();
                    if (_tg === 'SCRIPT' || _tg === 'STYLE' || _tg === 'LINK' || _tg === 'META' || _tg === 'NOSCRIPT' || _tg === 'BR' || _tg === 'HR') continue;
                    starSub.push(_sub[_sk]);
                  }
                } catch (e) {}
              }
            }
            for (var _si2 = 0; _si2 < starSub.length; _si2++) {
              var _el2 = starSub[_si2];
              try {
                if (_el2.getAttribute && _el2.getAttribute('data-ab-ext') === '1') {
                  if (_el2.style && _el2.style.getPropertyValue('display') !== 'none') self._applyHideStyles(_el2);
                  continue;
                }
                if (ruleOk(_el2, p, memo)) { self._noteHide(i, fromMo); if (!self._susp[i]) self._hide(_el2); }
              } catch (e) {}
            }
            continue;
          }
          if (p.base.indexOf(' ') !== -1) continue;
          if (!root.querySelectorAll) continue;
          var els = root.querySelectorAll(p.base);
          for (var j = 0; j < els.length; j++) {
            var el = els[j];
            try {
              if (el.getAttribute && el.getAttribute('data-ab-ext') === '1') {
                // 已标记元素被页面改回可见(如整串 cssText 重写)时重新隐藏
                if (el.style && el.style.getPropertyValue('display') !== 'none') self._applyHideStyles(el);
                continue;
              }
              if (ruleOk(el, p, memo)) { self._noteHide(i, fromMo); if (!self._susp[i]) self._hide(el); }
            } catch (e) {}
          }
        }
      } catch (e) {}
    };
    // 隐藏样式补写(保护观察者与重隐共用; 不重复入 _hidden/不打标记)
    MiniExtendedCss.prototype._applyHideStyles = function (el) {
      el.style.setProperty('display', 'none', 'important');
      el.style.setProperty('visibility', 'hidden', 'important');
      el.style.setProperty('pointer-events', 'none', 'important');
    };
    // 每个被隐藏元素挂 style 属性观察: 页面改写内联样式(整串 cssText 重写等)后自动补隐;
    // 单元素补隐上限 50 次防互改死循环; 元素离树即断开观察
    MiniExtendedCss.prototype._protect = function (el) {
      var self = this;
      if (!self._protectors) self._protectors = [];
      if (self._protectors.length > 400) return;
      var n = 0;
      var mo = new _MutationObserver(function () {
        try {
          if (!el.isConnected) { mo.disconnect(); return; }
          if (el.style && el.style.getPropertyValue('display') !== 'none') {
            if (++n > 50) { mo.disconnect(); return; }
            self._applyHideStyles(el);
          }
        } catch (e) {}
      });
      try { mo.observe(el, { attributes: true, attributeFilter: ['style'] }); } catch (e) { return; }
      self._protectors.push(mo);
    };

    MiniExtendedCss.prototype.apply = function () {
      var self = this;
      try { this._scan(_document.documentElement || _document); } catch (e) {}
      if (this._mo) { try { this._mo.disconnect(); } catch (e) {} }
      try {
        this._mo = new MutationObserver(function (muts) {
          try {
            // 同批求值记忆: 主规则+变体镜像规则常读同一元素同一属性, computed 只取一次;
            // 记忆随回调结束丢弃, 不跨回调缓存（页面样式会变）
            var memo = null;
            try { memo = new Map(); } catch (e) {}
            for (var m = 0; m < muts.length; m++) {
              var nodes = muts[m].addedNodes;
              for (var n = 0; n < nodes.length; n++) {
                var node = nodes[n];
                if (!node || node.nodeType !== 1) continue;
                self._scan(node, memo, true);
              }
            }
          } catch (e) {}
        });
        this._mo.observe(_document.documentElement, { childList: true, subtree: true });
      } catch (e) {}
    };
    MiniExtendedCss.prototype.dispose = function () {
      if (this._mo) { try { this._mo.disconnect(); } catch (e) {} this._mo = null; }
      if (this._starTimer) { try { _clearTimeout(this._starTimer); } catch (e) {} this._starTimer = null; }
      this._lastStarScanAt = 0;
      this._churnAt = [];
      this._churnN = [];
      this._susp = [];
      if (this._protectors) {
        for (var pi = 0; pi < this._protectors.length; pi++) { try { this._protectors[pi].disconnect(); } catch (e2) {} }
        this._protectors = [];
      }
      for (var i = 0; i < this._hidden.length; i++) {
        try {
          var el = this._hidden[i];
          if (!el || !el.style) continue;
          if (el.removeAttribute) el.removeAttribute('data-ab-ext');
          el.style.removeProperty('display');
          el.style.removeProperty('visibility');
          el.style.removeProperty('pointer-events');
        } catch (e) {}
      }
      this._hidden = [];
    };
    // 面板/卡片计数同款查询（只匹配不隐藏）
    MiniExtendedCss.query = function (selList) {
      var out = [];
      try {
        var seen = null;
        try { seen = new Set(); } catch (e) {}
        var items = splitList(String(selList || ''));
        for (var i = 0; i < items.length; i++) {
          var parsed = parseSelector(items[i]);
          if (!parsed) continue;
          var els = _document.querySelectorAll(parsed.base);
          for (var j = 0; j < els.length; j++) {
            if (ruleOk(els[j], parsed)) {
              if (seen) { if (!seen.has(els[j])) { seen.add(els[j]); out.push(els[j]); } }
              else out.push(els[j]);
            }
          }
        }
      } catch (e) {}
      return out;
    };
    return MiniExtendedCss;
  })();

  // ===== 轻量引擎定义结束 =====

  // ======================== 调试辅助 ========================
    // 【功能】全脚本统一的异常/调试日志入口 _debugCatch：所有 try/catch 的失败信息都从这里输出。
    // 【机制】仅当 设置→高级→调试日志(DEBUG) 开启时才输出到 F12→Console（[AB] 前缀），并自动附带调用位置行号；
    //        自身带防递归保护，catch 块里调用它不会二次抛错。
    // 【用户体验】排查问题三步：① 开启 DEBUG → ② 触发问题 → ③ F12 Console 看 [AB] 日志；
    //        拦截记录看 设置面板→「拦截日志」（每条可点「加白」放行）。


  // 轻量扩展求值引擎: MiniExtendedCss 以 var 声明在本 IIFE 作用域内, 直接引用
  let _ExtCss = MiniExtendedCss;
  // 支持 :matches-css/-before/-after 计算样式谓词
  const _debugCatch = function(e, ctx) {
    if (_debugCatch._isRunning) return;
    _debugCatch._isRunning = true;
    try {
      if (typeof currentConfig !== 'undefined' && currentConfig.DEBUG && typeof console !== 'undefined') {
        // 自动附带调用位置（行号）, 无需各调用点手动传入截断上下文串
        var _loc = '';
        try {
          var _st = new Error().stack || '';
          var _ln = _st.split('\n')[2];
          if (_ln) _loc = ' @' + _ln.trim().slice(0, 90);
        } catch(_e2) {}
        console.warn('[AB]', ctx || '', _loc, e && e.message ? e.message : e);
      }
    } catch(_) {
      try { console.error('[AB] _debugCatch error:', _ && _.message ? _.message : _); } catch(__) {}
    } finally {
      _debugCatch._isRunning = false;
    }
  };

  // ======================== 初始样式注入 ========================
    // 【功能】页面一启动就注入全局隐藏类 ._uh 的样式定义。
    // 【机制】覆盖层拦截等 JS 隐藏路径给元素加上 ._uh 类 → visibility:hidden + opacity:0 + pointer-events:none，
    //        保留原布局尺寸（不引发页面跳动），且不可点击；加白恢复时移除该类即可
    //        （CSS 样式表轨与扩展引擎的隐藏走内联样式+专属标记, 不经此类）。
    // 【注意】此样式独立于任何模块，模块全关也保留；data-hs 属性用于识别脚本自身的样式标签。

  (function () {
    try {
      var s = document.createElement('style');
      s.setAttribute('data-hs', 'true');
      s.textContent = '._uh{visibility:hidden!important;opacity:0!important;pointer-events:none!important}';
      (document.documentElement || document).appendChild(s);
    } catch(e) { _debugCatch(e, "初始隐藏样式注入失败"); }
  })();

  // ======================== 默认配置 ========================
    // 【功能】定义脚本的全部默认状态：模块开关、高级配置项、CSP 规则模板、内置黑名单关键词、启发式正则、标题黑白名单。
    // 【机制】面板里的开关/设置修改后写入 GM 存储（按域名隔离），刷新后生效；「全局重置」恢复本文件默认值。
    // 【注意】内置黑名单是广告特征字符串（统计站域名/混淆代码片段），命中即拦，可在「脚本黑名单」面板单独移除；
    //        启发式黑名单默认关闭（误杀风险较高，需在高级设置手动开启）。

  const DEFAULT_MODULE_STATE = {
    removeInlineScripts: false,
    removeExternalScripts: false,
    interceptThirdParty: false,
    blockDynamicScripts: false,
    manageCSP: false,
    overlayIntercept: false,
    scriptBlacklistMode: true,
  };

  const DEFAULT_CONFIG_STATE = {
    inlineScriptStrictMode: false,
    dynamicScriptStrictMode: false,
    thirdPartyStrictMode: false,
    thirdPartyStrictMethod: false,
    funnelStrictMode: false,
    spoofUAEnabled: false,
    simplePlatformSpoof: false,
    residualCleanupEnabled: false,
    iframeUIFix: false,
    redirectBlockerEnabled: true,
    builtinBlacklistEnabled: true,
    redirectBlockerCompatibilityMode: true,
    heuristicBlacklistEnabled: false,
    crossTagPatternThreshold: 3,
    trackingParamsCleanerEnabled: true,
    redirectTitleBlacklistEnabled: true,
    redirectTitleWhitelistEnabled: true,
    redirectBlockAllEnabled: false,
    redirectWhitelistBlockMode: false,
    DEBUG: false,
    adLinkClickBlock: false,
    logNoiseReduction: true,
    overlayStrictMode: false,
    staticScriptContentCheck: true,
  };

  const DEFAULT_CSP_RULES_TEMPLATE = [
    { id: 1, name: '只允许同源外部脚本', rule: "script-src 'self'", enabled: false },
    { id: 2, name: '只允许同源外部样式', rule: "style-src 'self'", enabled: false },
    { id: 3, name: '只允许同源图片', rule: "img-src 'self'", enabled: false },
    { id: 4, name: '只允许同源框架', rule: "frame-src 'self'", enabled: false },
    { id: 5, name: '只允许同源媒体', rule: "media-src 'self'", enabled: false },
    { id: 6, name: '只允许同源对象与嵌入', rule: "object-src 'self'", enabled: false },
    { id: 7, name: '只允许同源网络请求', rule: "connect-src 'self'", enabled: false },
  ];

  // 内置黑名单关键词：常见广告/统计脚本特征串（如统计站域名、混淆代码片段），
  // 脚本内容或地址命中任意一条即拦截。
  const BUILTIN_BLACKLIST_KEYWORDS = [
    'hm.baidu.com', 'tongji()', 'tj()', 'push.js', 'cnzz', 'histats.com', 'https://hongosi.xn--', '{return void 0!==b[a]?b[a]:a}).join("")}', '${scripts[randomIndex]}', '${scripts[Math.random()', 'https://"+Date.parse(new Date())+', 'https://"+(new Date().getDate())+"', 'https://{randomstr}.', 'new Function(t)()', 'new Function(b)()', 'new Function(c)()', 'new Function(t);', 'new Function(b);', 'new Function(c);', "new Function('d',e)", 'new Function(document[', 'new Function(function(p,a,c,k,e,d)', 'function guanggao(', 'nginx pc', ':8003/', ':8004/', ':8006/', ':8007/', ':8008/', ':8009/', ':8010/', ':8891/', ':8887/', ':21467/', ':690/', ':6681/', ':21233/', '2147483646', 'OJ:5LF_XDRT4', '.insertAdjacentElement("beforebegin",_el)', 'Math.floor(2147483648 * Math.random());', 'Math.floor(Math.random()*url.length)', 'Math.floor(Math.random() * urls.length)', "new Date()['getTime']()", 'newDate=new window', 'Math.floor(((new Date()).getTime()', '&&navigator[', '=navigator;', 'navigator.platform){setTimeout(function', 'disableDebugger', 'blockDeveloperTools', '["Date"]())[\'getTime\']()', '</\'+\'s\'+\'c\'+\'ri\'+\'pt\'+\'>\')', '<\\/\'+\'s\'+\'c\'+\'ri\'+\'pt\'+\'>\')', '(\'#htmlContenthtml\').html', 'D.createElement(\'span\');', 'window.$m(', '{win:false,mac:false,xll:false}', 'parseInt(Math[\'random\''
  ];

  var _heuristicRegexGroups = null;
  function getHeuristicRegexGroups() {
    if (_heuristicRegexGroups !== null) return _heuristicRegexGroups;
    if (!currentConfig.heuristicBlacklistEnabled) return null;
    try {
      const hexGroup = [
        '(?:_0x[a-zA-Z0-9]{4,}.*){5,}',
        'parseInt\\s*\\(\\s*[\'"\\x60]0x[0-9a-fA-F]{2,}[\'"\\x60]?\\s*\\)\\s*(?:\\||\\^|&)',
        '(?:\\\\x[0-9a-fA-F]{2}){10,}',
        '(?:\\\\u[0-9a-fA-F]{4}){10,}',
        '\\\\x[0-9a-fA-F]{2}(?:\\\\x[0-9a-fA-F]{2}){20,}',
        '(?:\\^|\\||~)\\s*0x[0-9a-fA-F]{2,}\\s*(?:\\^|\\||~)',
        'parseInt\\s*\\([^)]+\\)\\s*\\^\\s*0x[0-9a-fA-F]{2,}',
      ];
      const domGroup = [
        "(?:setTimeout|setInterval)\\s*\\(\\s*(?:atob|unescape)\\s*\\(",
        '\\bwith\\s*\\(\\s*(?:document|window)\\s*\\)\\s*\\{',
        '(?:window|document)\\s*\\[\\s*[\'"][^\'"]+[\'"]\\s*\\+\\s*[\'"][^\'"]+[\'"]\\s*\\]\\s*\\(',
      ];
      const controlGroup = [
        'blockDeveloperTools|disableDebugger|devtoolschange',
        'setTimeout\\s*\\(\\s*[\'"\\x60](?:javascript:|eval\\s*\\(|Function\\s*\\()',
        'setInterval\\s*\\(\\s*[\'"\\x60](?:javascript:|eval\\s*\\(|Function\\s*\\()',
        'setTimeout\\s*\\(\\s*(?:function|\\(\\)\\s*=>)\\s*\\{[^}]*?location\\.(?:href|replace|assign)',
        '\\b(?:document|window)\\.(?:oncontextmenu|onkeydown|onkeyup|onselectstart|ondragstart|onmousedown)\\s*=\\s*function',
      ];
      const cipherGroup = [
        'atob\\s*\\([^)]*\\)[^;]{0,100}?(?:eval|Function)\\s*\\(',
        '(?:eval|Function|document\\.write)\\s*\\([^)]{0,200}?atob\\s*\\(',
        'atob\\s*\\(.+?\\.split\\s*\\(\\s*[\'"][\'"]\\s*\\)\\s*\\.map',
        '\\batob\\s*\\(\\s*[\'"][A-Za-z0-9+/=]{80,}[\'"]\\s*\\)[^;]{0,200}?(?:eval|Function|document\\.write|\\.src\\s*=|\\.href\\s*=)',
        'atob\\s*\\(.*?\\).*?atob\\s*\\(',
        'unescape\\s*\\(.*?\\)\\s*\\+\\s*unescape',
        '(?:eval|Function)\\s*\\([^)]{0,200}?unescape\\s*\\(',
        'unescape\\s*\\([^)]*\\)[^;]{0,100}?(?:eval|Function)\\s*\\(',
        '(?:eval|Function)\\s*\\([^)]{0,200}?decodeURIComponent\\s*\\(',
        'decodeURIComponent\\s*\\([^)]*\\)[^;]{0,100}?(?:eval|Function)\\s*\\(',
        '"[\\w\\-~!@#$%^&*()+=\\[\\]{}|\\\\:;\'<>,.?/` ]{60,}"[^;]{0,120}?(?:eval)\\s*\\(',
        '\\.replace\\s*\\(\\s*\\/\\\\\\\\[a-f0-9]+\\/g\\s*,\\s*[\'"\\x60]\\\\\\\\x[\'"\\x60]\\s*\\).*?(?:eval|Function)\\s*\\(',
        '(?:\\\\x[0-9a-fA-F]{2}){10,}[^;]{0,100}?(?:eval|Function)\\s*\\(',
        '(?:\\\\u[0-9a-fA-F]{4}){5,}[^;]{0,100}?(?:eval|Function)\\s*\\(',
        '(?:var|let|const)\\s+\\w+\\s*=\\s*[\'"][A-Za-z0-9+/=]{300,}[\'"][^;]{0,80}?(?:eval|Function)\\s*\\(',
        '(?:String\\.fromCharCode|fromCodePoint)\\s*\\([^)]{20,}\\)[^;]{0,100}?(?:eval|Function)\\s*\\(',
        '\\[\\d{2,3}(?:,\\d{2,3}){5,}\\][^;]{0,50}?(?:eval|Function|String\\.fromCharCode)\\s*\\(',
        '\\.split\\s*\\(\\s*""\\s*\\)\\s*\\.\\s*map\\s*\\([^)]{0,1000}\\)[^;]{0,1000}?new\\s+Function',
        'String\\.fromCharCode\\.apply\\s*\\(null,\\s*\\[',
        '\\(function\\s*\\([^)]*\\)\\s*\\{[^}]{0,800}?(?:atob[^}]{0,800}?(?:eval|Function)|(?:eval|Function)[^}]{0,800}?atob)\\s*\\(',
        'function\\s+\\w+\\s*\\([^)]*\\)\\s*\\{[^}]*?atob[^}]*?(?:eval|Function)\\s*\\(',
        '(?:toString|split|replace|substring|substr|slice|trim|charAt|charCodeAt|join|reverse){5,}[^;]{0,200}?(?:eval|Function|atob|document\\.write)\\s*\\(',
        '(?:setTimeout|setInterval)\\s*\\(\\s*(?:function|\\(\\)\\s*=>)\\s*\\{[^}]{0,300}?(?:eval|Function|atob)\\s*\\(',
        '(?:fetch|XMLHttpRequest)\\s*\\(?[^)]{0,200}?\\)[^;]{0,300}?(?:eval|Function)\\s*\\(',
        '\\beval\\s*\\(\\s*atob\\s*\\(',
        '\\beval\\s*\\(\\s*String\\.fromCharCode\\s*\\(',
        '\\blocation\\s*\\.\\s*href\\s*=\\s*(?:atob|String\\.fromCharCode|decodeURIComponent)',
        '\\blocation\\s*(?:\\.\\s*href|\\[\\s*[\'"]href[\'"]\\s*\\])\\s*=\\s*[\'"][^\'"]{200,}',
        'setTimeout\\s*\\(\\s*[\'"][^\'"]*location\\.href[^\'"]*[\'"]',
        'new\\s+Function\\s*\\(\\s*[\'"\\x60][^\'"\\x60]{500,}[\'"\\x60]\\s*\\)',
        '(?:eval|Function)\\s*\\(\\s*(?:[\\w$]+\\s*\\+\\s*){2,}[\\w$]+\\s*\\)',
        '(?:eval|Function)\\s*\\(\\s*[\\w$]+\\s*\\.\\s*(?:split|slice|substring|replace|join|reverse)\\s*\\(',
        '(?:eval|Function)\\s*\\(\\s*\\[\\s*[^\\]]{0,300}?\\]\\s*\\.\\s*join\\s*\\(\\s*[\'"\\x60][\'"\\x60]\\s*\\)\\s*\\)',
        '\\b(?:atob|decodeURIComponent|unescape)\\s*\\([^)]{30,}\\)\\s*;?\\s*(?:eval|Function)\\s*\\(',
        'String\\.fromCharCode\\s*\\(\\s*\\d{1,3}(?:\\s*,\\s*\\d{1,3})+\\s*\\)\\s*\\+',
        '\\b(?:window|document|self|top)\\s*\\[\\s*[\'"\\x60][^\'"\\x60]{1,10}[\'"\\x60]\\s*\\]\\s*=\\s*(?:atob|String\\.fromCharCode|decodeURIComponent|unescape)',
        '(?:eval|Function)\\s*\\(\\s*[\'"\\x60][^\'"\\x60]{0,120}[\'"\\x60]\\s*\\+\\s*[\'"\\x60][^\'"\\x60]{0,120}[\'"\\x60]\\s*\\+',
        '\\b[a-z_][a-zA-Z0-9_]{1,5}\\s*\\(\\s*\\d{5,}(?:\\s*,\\s*\\d+){1,}\\s*\\)',
        '^[a-zA-Z_$]\\w{2,}\\s*\\(\\s*\\d{4,}(?:\\s*,\\s*\\d+)*\\s*\\)\\s*;?\\s*$',
        "(?:document\\.write|document\\.writeln)\\s*\\(\\s*unescape\\s*\\(",
        "window\\.open\\s*\\(\\s*(?:atob|unescape|decodeURIComponent)\\s*\\(",
        '(?:setTimeout|setInterval)\\s*\\(\\s*(?:atob|unescape)\\s*\\(',
      ];
      const miscGroup = [
        'constructor\\s*\\(\\s*[\'"\\x60]return\\s+this[\'"\\x60]\\s*\\)\\s*\\(',
        '\\.constructor\\.constructor\\([^\\)]+\\)\\s*\\(',
        'try\\s*\\{[^}]{0,200}?(?:eval|Function|atob|document\\.write)\\s*\\([^)]{0,200}\\}\\s*catch\\s*\\(\\s*[a-zA-Z_]+\\s*\\)\\s*\\{\\s*\\}',
        'try\\s*\\{[^}]{0,150}\\}\\s*catch\\s*\\(\\s*\\w+\\s*\\)\\s*\\{\\s*return\\s+(?:_0x|this|constructor)',
        '\\.style\\.position\\s*=\\s*[\'"]fixed[\'"][\\s\\S]{0,50}?\\.style\\.zIndex\\s*=\\s*[\'"]?[1-9]\\d{4,}',
        '_0x[0-9a-f]+\\s*=\\s*function\\s*\\(\\s*_0x[0-9a-f]+\\s*,\\s*_0x[0-9a-f]+\\s*\\)',
        '_0x[0-9a-f]+\\s*=\\s*function\\s*\\(\\s*_0x[0-9a-f]+\\s*,\\s*_0x[0-9a-f]+\\s*,\\s*_0x[0-9a-f]+\\s*\\)',
        '(?:Object\\.keys|Object\\.values)\\s*\\(\\s*_0x[0-9a-f]+\\s*\\)\\.map\\s*\\(',
        '_0x[0-9a-f]+\\s*\\.forEach\\s*\\(\\s*(?:_0x[0-9a-f]+|function)\\s*\\(',
        '(?:const|let|var)\\s*\\{[^}]{5,}\\}\\s*=\\s*_0x[0-9a-f]+\\s*\\(',
        '!function\\s*\\(\\s*\\)\\s*\\{[^}]{0,200}return\\s+_0x[0-9a-f]+\\s*\\(',
        'JSON\\.parse\\s*\\(\\s*_0x[0-9a-f]+\\s*\\(',
        '(?:window|document|navigator)\\s*\\[\\s*[\'"][^\'"]{2,10}[\'"]\\s*\\+\\s*[\'"][^\'"]{2,10}[\'"]\\s*\\]\\s*\\(',
        'function\\s+[a-z]\\d[a-z0-9]{6,}',
        '\\[\\s*[\'"][^\'"]{1,10}[\'"]\\s*\\+\\s*[\'"][^\'"]{1,10}[\'"]\\s*\\+\\s*[\'"][^\'"]{1,10}[\'"]\\s*\\]',
        'arguments\\s*\\[\\s*\\d+\\s*\\]\\s*\\(\\s*\\d+\\s*\\)',
        'try\\s*\\{\\s*[a-zA-Z_]\\w*?\\d{1,4}\\s*\\([^)]*\\)\\s*;?\\s*\\}\\s*catch\\s*\\(\\s*\\w+\\s*\\)\\s*\\{\\s*\\}?\\s*;?\\s*try\\s*\\{\\s*[a-zA-Z_]\\w*?\\d{1,4}\\s*\\([^)]*\\)\\s*;?\\s*\\}\\s*catch\\s*\\(\\s*\\w+\\s*\\)\\s*\\{\\s*\\}?\\s*;?\\s*try\\s*\\{\\s*[a-zA-Z_]\\w*?\\d{1,4}\\s*\\([^)]*\\)\\s*;?\\s*\\}\\s*catch\\s*\\(\\s*\\w+\\s*\\)\\s*\\{\\s*\\}?\\s*',
        'document\\.cookie[^;]{0,200}?(?:new\\s+)?Image\\s*[=(]',
        '_0x[0-9a-f]+\\s*\\(\\s*_0x[0-9a-f]+\\s*\\)[^;]{0,50}?(?:eval|Function|atob|JSON\\.parse)\\s*\\(',
        "\\[\\s*['\\\"]push['\\\"]\\s*\\]\\s*\\(\\s*[^)\\[]{0,40}\\[\\s*['\\\"]shift['\\\"]\\s*\\]",
      ];
      const adkitGroup = [
        'writeln\\s*\\(\\s*[\'"]<script src="\\/[\'"]\\s*\\)',
        '[\'"]https?:\\/\\/["\']\\s*\\+\\s*diffDays\\b',
        'https?:\\/\\/fw\\d{2,6}\\.[a-z0-9]{4,}\\.[a-z]{2,7}\\/index\\/(?:home\\.)?html',
        'currKey\\s*===?\\s*123\\b',
      ];
      const baseGroups = [
        new RegExp(hexGroup.map(p => `(?:${p})`).join('|')),
        new RegExp(domGroup.map(p => `(?:${p})`).join('|')),
        new RegExp(controlGroup.map(p => `(?:${p})`).join('|')),
        new RegExp(cipherGroup.map(p => `(?:${p})`).join('|')),
        new RegExp(miscGroup.map(p => `(?:${p})`).join('|')),
        new RegExp(adkitGroup.map(p => `(?:${p})`).join('|')),
      ];
      _heuristicRegexGroups = baseGroups;
      return baseGroups;
    } catch (e) {
      _heuristicRegexGroups = null;
      return null;
    }
  }


  const DEFAULT_REDIRECT_TITLE_BLACKLIST = ['小说', '章节', '阅读', '在线', '热播', '影院', '影音',  're:第[\\d零一二三四五六七八九十百千万亿]+[章节页]'];
  const DEFAULT_REDIRECT_TITLE_WHITELIST = ['银行', '转账', '支付', '安全中心', '登录', '验证', '密码', '交易', '脚本', '搜索'];

  let currentConfig = {
    ...DEFAULT_CONFIG_STATE,
    modules: { ...DEFAULT_MODULE_STATE },
    cspRules: DEFAULT_CSP_RULES_TEMPLATE.map((rule) => ({ ...rule })),
    whitelist: new Set(),
    keywordWhitelist: new Set(),
    scriptBlacklist: new Set(),
    thirdPartyWhitelist: [],
    removedBuiltinKeywords: new Set(),
    whitelistDisplayNames: new Map(),
    redirectTitleBlacklistKeywords: [...DEFAULT_REDIRECT_TITLE_BLACKLIST],
    redirectTitleWhitelistKeywords: [...DEFAULT_REDIRECT_TITLE_WHITELIST],
    trackingParamKeys: [],
    elementCssRules: [],
  };


  const ConfigUpdater = {
    saveNow() {
      // 存储异常隔离: GM_setValue 失败（配额/瞬时错误）不中断调用方流程,
      // 否则 change handler 会在保存处中断
      try {
        StorageManager.saveConfig();
      } catch (e) {
        _debugCatch(e, '配置保存失败(GM 存储异常)');
      }
    },
  };


  // ======================== 配置存储管理 ========================
    // 【功能】配置的加载/保存/重置：按域名隔离存储（每个网站一套设置），并同步全局参数（标题黑白名单、追踪参数）。
    // 【机制】GM_getValue/GM_setValue 读写 JSON；加载时逐项合并到 currentConfig（缺省项用默认值兜底）；
    //        保存失败不影响当前内存配置（异常已被隔离，不会卡住面板开关）。
    // 【用户体验】每个网站可独立配置；「当前域名重置」只清本站设置，「全局重置」清空全部数据。
  const StorageManager = {
    getConfigKey(domain) {
      return `adblock_unified_config_${domain}`;
    },
    loadConfig() {
      const hostname = location.hostname;
      const key = this.getConfigKey(hostname);
      try {
        const saved = GM_getValue(key, null);
        if (saved) {
          const data = JSON.parse(saved);
          if (data.modules) Object.assign(currentConfig.modules, data.modules);
          if (data.cspRules) currentConfig.cspRules = data.cspRules.map((r) => ({ ...r }));
          if (Array.isArray(data.whitelist)) currentConfig.whitelist = new Set(data.whitelist);
          if (Array.isArray(data.keywordWhitelist)) currentConfig.keywordWhitelist = new Set(data.keywordWhitelist);
          if (Array.isArray(data.scriptBlacklist)) currentConfig.scriptBlacklist = new Set(data.scriptBlacklist);
          if (Array.isArray(data.thirdPartyWhitelist)) currentConfig.thirdPartyWhitelist = data.thirdPartyWhitelist;
          if (Array.isArray(data.elementCssRules)) currentConfig.elementCssRules = data.elementCssRules;
          if (Array.isArray(data.removedBuiltinKeywords)) currentConfig.removedBuiltinKeywords = new Set(
            data.removedBuiltinKeywords
          );
          if (Array.isArray(data.whitelistDisplayNames)) {
            try {
              currentConfig.whitelistDisplayNames = new Map(data.whitelistDisplayNames);
            } catch (e) {
              currentConfig.whitelistDisplayNames = new Map();
            }
          }
          Object.keys(DEFAULT_CONFIG_STATE).forEach((configKey) => {
            if (data[configKey] !== undefined) {
              currentConfig[configKey] = data[configKey];
            } else if (currentConfig[configKey] === undefined) {
              currentConfig[configKey] = DEFAULT_CONFIG_STATE[configKey];
            }
          });
        }

        try {
          var glBlKw = GM_getValue('adblock_gl_blacklistKeywords', null);
          if (glBlKw !== null) currentConfig.redirectTitleBlacklistKeywords = JSON.parse(glBlKw);
          var glWlKw = GM_getValue('adblock_gl_whitelistKeywords', null);
          if (glWlKw !== null) currentConfig.redirectTitleWhitelistKeywords = JSON.parse(glWlKw);
          var glTp = GM_getValue('adblock_gl_trackingParams', null);
          if (glTp !== null) {
            currentConfig.trackingParamKeys = JSON.parse(glTp);
            rebuildTrackingParamRegex(currentConfig.trackingParamKeys);
          }
        } catch(e) { _debugCatch(e, "currentConfig.trackingParamKeys"); }
      } catch (e) {
        console.warn(
          '[广告拦截器] 配置加载失败，已回退默认值:', e.message || e
        );
        try { GM_deleteValue(key); } catch (e2) { }
      }
    },
    saveConfig() {
      const hostname = location.hostname;
      const key = this.getConfigKey(hostname);
      const toStore = {
        modules: currentConfig.modules,
        cspRules: currentConfig.cspRules,
        whitelist: Array.from(currentConfig.whitelist),
        keywordWhitelist: Array.from(currentConfig.keywordWhitelist),
        scriptBlacklist: Array.from(currentConfig.scriptBlacklist),
        thirdPartyWhitelist: currentConfig.thirdPartyWhitelist,
        elementCssRules: currentConfig.elementCssRules,
        removedBuiltinKeywords: Array.from(currentConfig.removedBuiltinKeywords),
        whitelistDisplayNames: Array.from(currentConfig.whitelistDisplayNames.entries()),
      };
      Object.keys(DEFAULT_CONFIG_STATE).forEach((k) => {
        toStore[k] = currentConfig[k];
      });
      GM_setValue(key, JSON.stringify(toStore));
    },
    resetAllSettings() {
      currentConfig.modules = { ...DEFAULT_MODULE_STATE };
      currentConfig.cspRules = DEFAULT_CSP_RULES_TEMPLATE.map((rule) => ({
        ...rule,
      }));
      currentConfig.whitelist.clear();
      currentConfig.keywordWhitelist.clear();
      currentConfig.scriptBlacklist.clear();
      currentConfig.thirdPartyWhitelist = [];
      currentConfig.removedBuiltinKeywords.clear();
      currentConfig.whitelistDisplayNames.clear();
      currentConfig.elementCssRules = [];
      currentConfig.redirectTitleBlacklistKeywords = [...DEFAULT_REDIRECT_TITLE_BLACKLIST];
      currentConfig.redirectTitleWhitelistKeywords = [...DEFAULT_REDIRECT_TITLE_WHITELIST];
      Object.keys(DEFAULT_CONFIG_STATE).forEach((k) => {
        currentConfig[k] = DEFAULT_CONFIG_STATE[k];
      });

      try {
        GM_deleteValue('adblock_gl_blacklistKeywords');
        GM_deleteValue('adblock_gl_whitelistKeywords');
        GM_deleteValue('adblock_gl_trackingParams');
      } catch(e) { _debugCatch(e, "删除全局黑名单配置失败"); }
      currentConfig.trackingParamKeys = [...DEFAULT_TRACKING_PARAMS];
      rebuildTrackingParamRegex(currentConfig.trackingParamKeys);
      this.saveConfig();
    },
  };
  StorageManager.loadConfig();


  // ======================== 菜单命令注册 ========================
    // 【功能】向油猴菜单注册入口：设置面板 / 苹果设备模拟 / 清空白名单 / 重置设置。
    // 【机制】面板懒加载——首次使用菜单命令时才初始化 UI；面板初始化失败会弹通知提示刷新重试。
    // 【用户体验】菜单命令「1 ⚙️ 广告拦截设置面板」是打开面板的主入口；重置类命令都有二次确认弹窗。
  let menuCommandsRegistered = false;
  try { registerAllMenuCommands(); } catch(e) { _debugCatch(e, "registerAllMenuCommands"); }

  // ======================== 页面滚动解锁守卫 ========================
    // 【功能】对抗"广告锁滚动"：广告脚本注入全屏浮层时顺手把 html/body 的 overflow 锁成 hidden，
    //        隐藏广告后页面仍无法滑动。本守卫统一解除锁定并恢复用户的滚动位置。
    // 【机制】任何拦截路径隐藏广告后调用 arm()/armForElement()，在 15 秒窗口内持续检测并解除
    //        html/body 的 overflow 锁定（内联 !important 覆盖样式表规则，支持反复加锁对抗），
    //        并恢复一次用户滚动位置。
    // 【注意】窗口期外或从未隐藏广告时绝不干预——不会误伤网站自身合法的滚动锁定（弹窗/抽屉等）；
    //        隐藏"覆盖层形态"（fixed/absolute 或占视口一半以上）的元素才触发解锁，普通广告位不触发。

  const ScrollLockGuard = {
    _initialized: false,
    _lastUserY: 0,
    _unlockUntil: 0,
    _unlockY: 0,
    _sawLockAtArm: false,
    _restored: false,
    _driverTimer: null,
    _prevBodyOverflow: null,
    _prevBodyOverflowY: null,
    _prevHtmlOverflow: null,
    _prevHtmlOverflowY: null,
    _lastLockCheckAt: 0,
    _lastLockResult: undefined,
    _onScroll: null,

    init: function () {
      if (this._initialized) return;
      this._initialized = true;
      var self = this;
      // 持续跟踪用户滚动位置: 广告锁定把页面顶回顶部后, 靠这里记录的位置恢复
      this._onScroll = function () {
        try {
          self._lastUserY = _globals.scrollY || _globals.pageYOffset || 0;
        } catch (e) {}
      };
      try {
        _globals.addEventListener('scroll', this._onScroll, { passive: true, capture: true });
      } catch (e) {
        try { _document.addEventListener('scroll', this._onScroll, true); } catch (e2) {}
      }
    },

    disable: function () {
      this._initialized = false;
      // 停掉窗口期自驱动定时器
      if (this._driverTimer) {
        try { _clearTimeout(this._driverTimer); } catch(e) {}
        this._driverTimer = null;
      }
      if (this._onScroll) {
        try { _globals.removeEventListener('scroll', this._onScroll, { capture: true }); } catch (e) {
          try { _document.removeEventListener('scroll', this._onScroll, true); } catch (e2) {}
        }
        this._onScroll = null;
      }
      this._unlockUntil = 0;
      this._unlockY = 0;
      this._sawLockAtArm = false;
      this._restored = false;
      this._lastLockCheckAt = 0;
      this._lastLockResult = undefined;
      this._restoreInlineOverflow();
    },

    _saveInlineOverflow: function () {
      try {
        if (_document.body && this._prevBodyOverflow === null) {
          var bs = _document.body.style;
          this._prevBodyOverflow = bs.getPropertyValue('overflow');
          this._prevBodyOverflowY = bs.getPropertyValue('overflow-y');
        }
      } catch (e) {}
      try {
        if (_document.documentElement && this._prevHtmlOverflow === null) {
          var hs = _document.documentElement.style;
          this._prevHtmlOverflow = hs.getPropertyValue('overflow');
          this._prevHtmlOverflowY = hs.getPropertyValue('overflow-y');
        }
      } catch (e) {}
    },

    _restoreInlineOverflow: function () {
      try {
        if (_document.body && this._prevBodyOverflow !== null) {
          var bs = _document.body.style;
          if (this._prevBodyOverflow === '') bs.removeProperty('overflow');
          else bs.setProperty('overflow', this._prevBodyOverflow);
          if (this._prevBodyOverflowY === '') bs.removeProperty('overflow-y');
          else bs.setProperty('overflow-y', this._prevBodyOverflowY);
        }
      } catch (e) {}
      try {
        if (_document.documentElement && this._prevHtmlOverflow !== null) {
          var hs = _document.documentElement.style;
          if (this._prevHtmlOverflow === '') hs.removeProperty('overflow');
          else hs.setProperty('overflow', this._prevHtmlOverflow);
          if (this._prevHtmlOverflowY === '') hs.removeProperty('overflow-y');
          else hs.setProperty('overflow-y', this._prevHtmlOverflowY);
        }
      } catch (e) {}
      this._prevBodyOverflow = null;
      this._prevBodyOverflowY = null;
      this._prevHtmlOverflow = null;
      this._prevHtmlOverflowY = null;
    },

    _isScrollLocked: function () {
      try {
        var b = _document.body ? _getComputedStyle(_document.body) : null;
        var h = _document.documentElement ? _getComputedStyle(_document.documentElement) : null;
        if (b && (b.overflow === 'hidden' || b.overflowY === 'hidden')) return true;
        if (h && (h.overflow === 'hidden' || h.overflowY === 'hidden')) return true;
      } catch (e) {}
      return false;
    },

    // 节流的锁定复查: 隐藏大量广告时每次隐藏都会触发一次锁定判定,
    // 每次都读两次 getComputedStyle 会连续触发回流; 300ms 内复用上次结果,
    // 复查由周期驱动(800ms)与后续隐藏兜底, 反复加锁的广告脚本仍会被持续解除
    _isScrollLockedThrottled: function () {
      var _n = Date.now();
      if (_n - this._lastLockCheckAt < 300) {
        return this._lastLockResult === undefined ? this._isScrollLocked() : this._lastLockResult;
      }
      this._lastLockCheckAt = _n;
      this._lastLockResult = this._isScrollLocked();
      return this._lastLockResult;
    },

    _restoreScrollPosition: function () {
      try {
        var dh = (_document.documentElement && _document.documentElement.scrollHeight) ||
          (_document.body && _document.body.scrollHeight) || 0;
        var vh = _globals.innerHeight || (_document.documentElement && _document.documentElement.clientHeight) || 0;
        var y = _globals.scrollY || _globals.pageYOffset || 0;
        if (y <= 0 && this._unlockY > 0 && dh > vh + 50) {
          this._restored = true;
          _globals.scrollTo(0, this._unlockY);
        }
      } catch (e) {}
    },

    // 隐藏广告后调用（所有拦截路径统一入口）: 记录滚动位置并开启 15 秒解锁窗口
    arm: function () {
      this.init();
      this._unlockUntil = Date.now() + 15000;
      try {
        this._unlockY = _globals.scrollY || _globals.pageYOffset || this._lastUserY || 0;
      } catch (e) {
        this._unlockY = this._lastUserY || 0;
      }
      this._restored = false;
      this._sawLockAtArm = this._isScrollLockedThrottled();
      this._saveInlineOverflow();
      this.apply();
      this._startDriver();
    },

    // 窗口期自驱动: 15 秒内每 800ms 复查一次滚动锁定（广告脚本反复加锁也能持续解除）;
    // 窗口过期或守卫关闭后定时器自停
    _startDriver: function () {
      var self = this;
      if (this._driverTimer) return;
      var tick = function () {
        if (!self._initialized || Date.now() > self._unlockUntil) {
          self._driverTimer = null;
          return;
        }
        try { self.apply(); } catch (e) {}
        self._driverTimer = _setTimeout(tick, 800);
      };
      this._driverTimer = _setTimeout(tick, 800);
    },

    // 带元素判定的统一入口: 仅当被隐藏元素确实是"覆盖层形态"(fixed/absolute 或占视口一半以上)
    // 才解锁滚动 —— 普通内容流里的广告位隐藏不会误触网站自身的滚动锁定
    armForElement: function (el) {
      if (!el) return;
      var isOverlayLike = false;
      try {
        // 内联定位优先(高频路径, 广告元素普遍内联写死 position), 免去计算样式/回流
        var _ip = (el.style && el.style.position) || '';
        if (_ip === 'fixed' || _ip === 'absolute') {
          isOverlayLike = true;
        } else {
          var _cp = _getComputedStyle(el).position;
          isOverlayLike = (_cp === 'fixed' || _cp === 'absolute');
          if (!isOverlayLike) {
            isOverlayLike = (el.offsetWidth >= (_globals.innerWidth || 1) * 0.5) ||
              (el.offsetHeight >= (_globals.innerHeight || 1) * 0.5);
          }
        }
      } catch (e) {
        isOverlayLike = true;  // 无法判定时保守触发, 由 apply 内部条件把关
      }
      if (isOverlayLike) this.arm();
    },

    // 幂等解锁: 窗口期内检测到 overflow 锁定就强制解除（防广告脚本反复加锁）,
    // 并恢复一次滚动位置; 窗口期外或未锁定则不做任何事
    apply: function () {
      if (!this._initialized) return;
      if (Date.now() > this._unlockUntil) return;
      if (this._isScrollLockedThrottled()) {
        try {
          if (_document.body) {
            _document.body.style.setProperty('overflow', 'auto', 'important');
            _document.body.style.setProperty('overflow-y', 'auto', 'important');
          }
        } catch (e) {}
        try {
          if (_document.documentElement) {
            _document.documentElement.style.setProperty('overflow', 'auto', 'important');
            _document.documentElement.style.setProperty('overflow-y', 'auto', 'important');
          }
        } catch (e) {}
        this._restoreScrollPosition();
        return;
      }
      // 未锁定但页面被顶回顶部（锁定已被他方移除/样式表未生效） → 窗口期内只恢复一次位置
      if (!this._restored && this._sawLockAtArm) this._restoreScrollPosition();
    },
  };

  // ======================== ScriptSyncGuard 中央同步脚本拦截器 ========================
    // 【功能】拦截页面动态插入的 <script>（通过 hook appendChild/insertBefore 实现）：
    //        先查白名单/保护放行，再按模块顺序检查（内嵌移除/外联移除/脚本黑名单/动态脚本），命中即阻止执行。
    // 【机制】checkScriptSync（完整检查）→ neutralizeScript（type=text/plain + 清空内容，阻止执行）；
    //        检查顺序保证"加白优先"：任何白名单命中（关键词/元素级/URL 键）直接放行；
    //        拦截记日志（可加白），所有路径统一放行。
    // 【注意】脚本 src 的 setter 路径(checkPendingSrc)与元素路径共用同一套键，保证加白一致性。
  const ScriptSyncGuard = {

    checkScriptSync: function(scriptElement) {
      if (!scriptElement || !_isElementLike(scriptElement) || scriptElement.tagName !== 'SCRIPT') return null;
      if (ProcessedElementsCache.isProcessed(scriptElement)) return null;
      if (_isSafe(scriptElement)) return null;
      // 页面已加白放行 → 本页所有脚本（含黑名单命中）整体放行
      try { if (typeof RedirectBlocker !== 'undefined' && RedirectBlocker._isPageReleased()) return null; } catch(e) {}
      if (isWhitelistedOrProtected(scriptElement)) return null;
      var src = scriptElement.src || scriptElement.getAttribute('src') || '';
      var content = scriptElement.textContent || '';
      var ci = Utils.getContentIdentifier(scriptElement);
      if (ci && currentConfig.whitelist.has(ci)) return null;
      if (Whitelisting.isElementWhitelisted(scriptElement)) return null;
      if (currentConfig.keywordWhitelist.size > 0) {
        var kr = getKeywordWhitelistRegex();
        if (kr) {
          var srcOrContent = src || content;
          if (srcOrContent && kr.test(srcOrContent)) return null;
        }
      }

      if (currentConfig.modules.removeInlineScripts && !src && content) {
        var inlineCI = ci || Utils.getContentIdentifier(null, { type: '内嵌脚本移除', detail: content });
        if (inlineCI && currentConfig.whitelist.has(inlineCI)) return null;
        return { blocked: true, moduleKey: 'removeInlineScripts',
          reason: { type: '内嵌脚本移除', detail: '内容: ' + Utils.truncateString(content, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: inlineCI }};
      }

      // 同时开启「拦截第三方资源」时第三方域名脚本归第三方模块管, 本路径只管同源;
      // 跳过本块后继续走脚本黑名单/后续判定(黑名单模块语义独立不受分工影响)
      if (currentConfig.modules.removeExternalScripts && src
        && !(currentConfig.modules.interceptThirdParty && Utils.isThirdParty(src, Utils.getBlockParentSubDomainsSetting()))) {
        // 独立白名单键(EXTERNAL_SCRIPT: 绝对URL): 加白只作用于外联移除路径,
        // 只写 EXTERNAL_SCRIPT 键, 外联移除加白不影响第三方拦截路径
        var _extKey = Utils.externalScriptKey(src);
        if (currentConfig.whitelist.has(_extKey)) return null;
        if (Utils.externalScriptStructKey && currentConfig.whitelist.has(Utils.externalScriptStructKey(src))) return null;   // 结构键（去时间戳/随机段）加白也放行
        if (ci && currentConfig.whitelist.has(ci)) return null;   // SCRIPT_SRC 键既有加白仍放行
        // 内容检查模式（高级设置→严格模式→「外联脚本」开）: 按内容命中黑名单才移除,
        // 内容不可得时按已知坏缓存判, 未知的放行交静态检查管线异步取内容判定
        if (currentConfig.staticScriptContentCheck) {
          var _kStable = 'SCRIPT_SRC: ' + Utils.truncateString(_stableSrcKey(src), CONFIG.LOG_DETAIL_LENGTH);
          if (currentConfig.whitelist.has(_kStable)) return null;   // 已知坏日记的加白键, 任一路径加白全路径放行
          var _hitKw = content ? this._ssccContentHit(content) : null;
          if (_hitKw) {
            return { blocked: true, moduleKey: 'removeExternalScripts',
              reason: { type: '外联脚本移除(内容命中)', detail: '关键词: ' + _hitKw + ' - SRC: ' + Utils.truncateString(src, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _kStable }};
          }
          var _badKw = this._ssccKnownBadKw(_kStable, content);
          if (_badKw) {
            return { blocked: true, moduleKey: 'removeExternalScripts',
              reason: { type: '外联脚本移除(内容黑名单已知坏)', detail: (_badKw !== '1' ? '关键词: ' + _badKw + ' - ' : '') + 'SRC: ' + Utils.truncateString(src, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _kStable }};
          }
        } else {
          return { blocked: true, moduleKey: 'removeExternalScripts',
            reason: { type: '外联脚本移除', detail: 'SRC: ' + Utils.truncateString(src, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _extKey }};
        }
      }

      if (currentConfig.modules.scriptBlacklistMode) {
        // 已知坏缓存同步判定(外联脚本): 内容检查管线异步命中登记后, 后续页面在插入瞬间即拦,
        // 免再输一次加载竞速; 加白 SCRIPT_SRC 稳定键即放行
        if (src) {
          var _kbAbs = src;
          try { _kbAbs = new _URL(src, _location.href).href; } catch (eKb) {}
          var _kStableBl = 'SCRIPT_SRC: ' + Utils.truncateString(_stableSrcKey(_kbAbs), CONFIG.LOG_DETAIL_LENGTH);
          if (currentConfig.whitelist.has(_kStableBl)) return null;
          var _kbBl = this._ssccKnownBadKw(_kStableBl, '');
          if (_kbBl) {
            return { blocked: true, moduleKey: 'scriptBlacklistMode',
              reason: { type: 'SCRIPT_BLACKLIST', detail: '外联脚本内容黑名单(已知坏): ' + (_kbBl !== '1' ? '关键词: ' + _kbBl + ' - ' : '') + 'SRC: ' + Utils.truncateString(src, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _kStableBl }};
          }
        }
        // 内容优先: 外联脚本加载后内容也参与黑名单检查(src||content 都参与,
        // 含字符映射 join 拼接等黑名单特征的混淆广告脚本同样被拦)
        var fullContent = content || src;
        if (fullContent) {
          var activeArr = Utils.getActiveBlacklistArray();
          var _sbrRe = getSbrBlacklistRegex(activeArr);
          if (_sbrRe && _sbrRe.test(fullContent)) {
            var _hitKw = null;
            for (var pi = 0; pi < activeArr.length; pi++) {
              if (activeArr[pi] && fullContent.indexOf(activeArr[pi]) !== -1) { _hitKw = activeArr[pi]; break; }
            }
            return { blocked: true, moduleKey: 'scriptBlacklistMode',
              reason: { type: 'SCRIPT_BLACKLIST', detail: '命中关键词: ' + (_hitKw || activeArr[0]) + ' - ' + (src ? 'SRC: ' + Utils.truncateString(src, CONFIG.LOG_DETAIL_LENGTH) : '内嵌: ' + Utils.truncateString(content, CONFIG.LOG_DETAIL_LENGTH)), elementContentIdentifier: ci }};
          }
          if (!src && currentConfig.heuristicBlacklistEnabled && content) {
            var hrgs = getHeuristicRegexGroups();
            if (hrgs) {
              var samples = content.length > 2000 ? [content.substring(0, 2000), content.substring(Math.floor(content.length/2)-1000, Math.floor(content.length/2)+1000), content.substring(content.length-2000)] : [content];
              for (var si = 0; si < samples.length; si++) {
                for (var ji = 0; ji < hrgs.length; ji++) {
                  if (hrgs[ji].test(samples[si])) {
                    return { blocked: true, moduleKey: 'scriptBlacklistMode',
                      reason: { type: 'SCRIPT_BLACKLIST', detail: '命中启发式规则 - 内嵌: ' + Utils.truncateString(content, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: ci }};
                  }
                }
              }
            }
          }
          if (currentConfig.heuristicBlacklistEnabled && content) {
            // 内容键必须先于追踪器取样: 追踪器命中时可能已对当前脚本执行取消(清空内容),
            // 之后取键会退化成空键 'SCRIPT_CONTENT: ', 对该日记加白会放过整条跨标签拦截路径
            var crossCI = Utils.getContentIdentifier(scriptElement);
            var crossResult = CrossScriptPatternTracker.checkScript(scriptElement, content);
            // 跨页面、跨标签页记录"反复出现的相同脚本内容"，用于识别广告网络脚本（不靠写死域名）。
            if (crossResult.blocked) {
              if (crossCI && !currentConfig.whitelist.has(crossCI)) {
                return { blocked: true, moduleKey: 'scriptBlacklistMode',
                  reason: { type: 'SCRIPT_BLACKLIST', detail: '命中跨标签重复模式: ' + (crossResult.subject || '未知'), elementContentIdentifier: crossCI }};
              }
            }
          }
        }
      }

      if (currentConfig.modules.blockDynamicScripts) {
        if (DynamicScriptInterceptor.shouldBlockScriptElement(scriptElement, true)) {
          var _dynCI = null;
          try { _dynCI = Utils.getContentIdentifier(scriptElement); } catch(e) {}
          return { blocked: true, moduleKey: 'blockDynamicScripts',
            reason: { type: 'BLOCK_DYNAMIC_SCRIPT', detail: '动态脚本: ' + Utils.truncateString(src || content, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _dynCI || undefined }};
        }
      }
      return null;
    },

    checkPendingSrc: function(scriptElement, newSrc) {
      if (!newSrc || typeof newSrc !== 'string') return null;
      if (ProcessedElementsCache.isProcessed(scriptElement)) return null;
      if (_isSafe(scriptElement)) return null;
      // 页面已加白放行 → 本页所有脚本（含黑名单命中）整体放行
      try { if (typeof RedirectBlocker !== 'undefined' && RedirectBlocker._isPageReleased()) return null; } catch(e) {}
      if (isWhitelistedOrProtected(scriptElement)) return null;
      // 统一元素型日记键(与 checkScriptSync/拦截日记一致): 加白任一路径的日记, 其他路径同样放行。
      // 注意: 用解析后的绝对地址(new URL)与元素路径的 el.src(浏览器解析后的值)对齐,
      // 否则相对/协议相对(//cdn.com/x.js)地址在 setter 路径与元素路径会得到两个不同的键。
      var _psResolved = newSrc;
      try { _psResolved = new _URL(newSrc, _location.href).href; } catch(e) {}
      var _pendingSrcKey = 'SCRIPT_SRC: ' + Utils.truncateString(_stableSrcKey(_psResolved), CONFIG.LOG_DETAIL_LENGTH);
      if (currentConfig.whitelist.has(_pendingSrcKey)) return null;
      if (currentConfig.keywordWhitelist.size > 0) {
        var kr = getKeywordWhitelistRegex();
        if (kr && kr.test(newSrc)) return null;
      }
      var _extKeyPs = Utils.externalScriptKey(newSrc);
      // 同时开启「拦截第三方资源」时第三方域名脚本归第三方模块管, 本路径只管同源;
      // 跳过本块后继续走第三方/脚本黑名单后续判定
      if (currentConfig.modules.removeExternalScripts
        && !(currentConfig.modules.interceptThirdParty && Utils.isThirdParty(newSrc, Utils.getBlockParentSubDomainsSetting()))) {
        // 独立白名单键(EXTERNAL_SCRIPT): 与第三方路径的 SCRIPT_SRC 键互不干扰
        if (currentConfig.whitelist.has(_extKeyPs)) return null;
        if (Utils.externalScriptStructKey && currentConfig.whitelist.has(Utils.externalScriptStructKey(newSrc))) return null;
        // 内容检查模式（高级设置→严格模式→「外联脚本」开）: 按已知坏缓存判, 未知的放行
        // 交静态检查管线异步取内容判定; 关闭时保持无差别移除的原行为
        if (currentConfig.staticScriptContentCheck) {
          var _badKwPs = this._ssccKnownBadKw(_pendingSrcKey, '');
          if (_badKwPs) {
            return { blocked: true, moduleKey: 'removeExternalScripts',
              reason: { type: '外联脚本移除(内容黑名单已知坏)', detail: (_badKwPs !== '1' ? '关键词: ' + _badKwPs + ' - ' : '') + 'SRC: ' + Utils.truncateString(newSrc, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _pendingSrcKey }};
          }
        } else {
          return { blocked: true, moduleKey: 'removeExternalScripts',
            reason: { type: '外联脚本移除', detail: 'SRC: ' + Utils.truncateString(newSrc, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _extKeyPs }};
        }
      }
      if (currentConfig.modules.interceptThirdParty && shouldBlockResource(newSrc)) {
        return { blocked: true, moduleKey: 'interceptThirdParty',
          reason: { type: 'THIRD_PARTY', detail: 'SCRIPT: ' + Utils.truncateString(newSrc, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _pendingSrcKey }};
      }
      if (currentConfig.modules.scriptBlacklistMode) {
        // 已知坏缓存同步判定(外联脚本): 内容检查管线异步命中登记后, 后续插入瞬间即拦
        var _kbPs = this._ssccKnownBadKw(_pendingSrcKey, '');
        if (_kbPs) {
          return { blocked: true, moduleKey: 'scriptBlacklistMode',
            reason: { type: 'SCRIPT_BLACKLIST', detail: '外联脚本内容黑名单(已知坏): ' + (_kbPs !== '1' ? '关键词: ' + _kbPs + ' - ' : '') + 'SRC: ' + Utils.truncateString(newSrc, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _pendingSrcKey }};
        }
        var activeArr = Utils.getActiveBlacklistArray();
        var _sbrRe2 = getSbrBlacklistRegex(activeArr);
        if (_sbrRe2 && _sbrRe2.test(newSrc)) {
          var _hitKw2 = null;
          for (var pi = 0; pi < activeArr.length; pi++) {
            if (activeArr[pi] && newSrc.indexOf(activeArr[pi]) !== -1) { _hitKw2 = activeArr[pi]; break; }
          }
          return { blocked: true, moduleKey: 'scriptBlacklistMode',
            reason: { type: 'SCRIPT_BLACKLIST', detail: '命中关键词: ' + (_hitKw2 || activeArr[0]) + ' - SRC: ' + Utils.truncateString(newSrc, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _pendingSrcKey }};
        }
      }
      if (currentConfig.modules.blockDynamicScripts) {
        if (newSrc.startsWith('data:text/javascript') || newSrc.toLowerCase().startsWith('javascript:')) {
          return { blocked: true, moduleKey: 'blockDynamicScripts',
            reason: { type: 'BLOCK_DYNAMIC_SCRIPT', detail: '动态脚本SRC: ' + Utils.truncateString(newSrc, CONFIG.LOG_DETAIL_LENGTH), elementContentIdentifier: _pendingSrcKey }};
        }
      }
      return null;
    },

    neutralizeScript: function(scriptElement) {
      if (!scriptElement || !_isElementLike(scriptElement)) return;
      // 白名单守卫: 已加白的脚本一律不中性化（防止任何调用方绕过白名单）
      if (isWhitelistedOrProtected(scriptElement)) return;
      try {
        scriptElement.setAttribute('type', 'text/plain');
        if (scriptElement.src || scriptElement.getAttribute('src')) {
          scriptElement.removeAttribute('src');
        }
        scriptElement.textContent = '';
        ProcessedElementsCache.markAsProcessed(scriptElement);
      } catch (e) { _debugCatch(e, "neutralizeScript"); }
    },

    // ===== 静态外联脚本内容检查（高级设置→严格模式→「外联脚本」, 默认关） =====
    // 【功能】解析器直插的 <script src> 不经过 appendChild/src setter 钩子, 内容从不参与
    //        黑名单检查; 开关开启后对外联脚本取内容查黑名单（同源走 XHR, 第三方走 GM_xmlhttpRequest 跨源）, 命中即摘除+记日记。
    // 【机制】元素出现时先查"已知坏"持久缓存(GM 键, 值=命中的黑名单关键词, 命中=同步摘除,
    //        必赢过脚本执行, 日记列出该关键词; 黑名单里删除该关键词即解除已知坏);
    //        未知的走异步取内容(浏览器刚下载过同一资源, 命中 HTTP 缓存近零成本, 截断限正则
    //        成本), 命中=摘除（若仍在树上）+写缓存+日记。首次见到且脚本抢先执行完的场合无法
    //        回溯, 由下次加载起同步摘除兜住。跨域脚本读不到内容(CORS), 走原有路径。
    _ssccPending: null,
    _ssccLogged: null,
    _ssccInstalled: false,
    installStaticScriptCheck: function () {
      if (this._ssccInstalled) return;
      this._ssccInstalled = true;
      var self = this;
      try {
        var mo = new MutationObserver(function (ms) {
          try {
            for (var i = 0; i < ms.length; i++) {
              var m = ms[i];
              if (m.type === 'attributes') {
                if (m.target && m.target.nodeType === 1 && m.target.tagName === 'SCRIPT') self._staticScriptContentCheck(m.target);
                continue;
              }
              var added = m.addedNodes || [];
              for (var j = 0; j < added.length; j++) {
                var n = added[j];
                if (!n || n.nodeType !== 1) continue;
                if (n.tagName === 'SCRIPT') {
                  self._staticScriptContentCheck(n);
                  if (n.querySelectorAll) {
                    var subs = n.querySelectorAll('script[src]');
                    for (var k = 0; k < subs.length; k++) self._staticScriptContentCheck(subs[k]);
                  }
                } else if (n.querySelectorAll && n.children && n.children.length) {
                  var subs2 = n.querySelectorAll('script[src]');
                  for (var k2 = 0; k2 < subs2.length; k2++) self._staticScriptContentCheck(subs2[k2]);
                }
              }
            }
          } catch (e) { _debugCatch(e, 'sscc observer'); }
        });
        mo.observe(_document.documentElement || _document, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
      } catch (e) { _debugCatch(e, 'sscc install'); }
    },
    // 已知坏缓存（持久, 值=命中的黑名单关键词）: 命中=同步摘除必赢过脚本执行; 同步路径与异步管线共用同一把键。
    // 读取时校验关键词仍在活动黑名单——用户在脚本黑名单面板删除该关键词即自动解除这条已知坏（缓存一并清掉）;
    // 值为 '1' 的是未存关键词的记录: 内容可得时同步重查并回写关键词, 供已知坏日记列出
    _ssccKnownBadKw: function (stableKey, content) {
      var _kw = null;
      try { _kw = GM_getValue('adblock_ssrc_bad_' + generateContentHash(stableKey), null) || null; } catch (e) { return null; }
      if (!_kw) return null;
      if (_kw !== '1') {
        if (_kw.indexOf('启发式:') === 0) {
          // 启发式记录: 「启发式黑名单」开关关闭即解除该记录（对齐黑名单删词解除的自救语义）
          if (!currentConfig.heuristicBlacklistEnabled) {
            try { GM_deleteValue('adblock_ssrc_bad_' + generateContentHash(stableKey)); } catch (eHD) {}
            return null;
          }
          return _kw;
        }
        var _arr = null;
        try { _arr = Utils.getActiveBlacklistArray(); } catch (eA) { return _kw; }
        if (_arr.indexOf(_kw) === -1) {
          try { GM_deleteValue('adblock_ssrc_bad_' + generateContentHash(stableKey)); } catch (eD) {}
          return null;
        }
        return _kw;
      }
      if (content) {
        var _hit = this._ssccContentHit(content);
        if (_hit) {
          try { GM_setValue('adblock_ssrc_bad_' + generateContentHash(stableKey), _hit); } catch (eS) {}
          return _hit;
        }
      }
      return '1';
    },
    _ssccContentHit: function (text) {
      try {
        var arr = Utils.getActiveBlacklistArray();
        for (var pi = 0; pi < arr.length; pi++) {
          if (arr[pi] && text.indexOf(arr[pi]) !== -1) return arr[pi];
        }
      } catch (e) { _debugCatch(e, 'ssccContentHit'); }
      return null;
    },
    // 启发式正则组命中判定（与内嵌脚本的启发式检查同源, 受「启发式黑名单」开关门控）:
    // 外联内容检查管线在黑名单关键词未命中时跑一遍（采样对齐内嵌: 头/中/尾各 2000）,
    // 命中返回 '启发式:组名' 作为已知坏记录值——日记照常以「关键词:」列出; 该值不参与
    // 黑名单删词解除, 自救路径=关闭「启发式黑名单」开关或对该脚本加白
    _ssccHeuristicHit: function (text) {
      try {
        if (!currentConfig.heuristicBlacklistEnabled) return null;
        var hrgs = getHeuristicRegexGroups();
        if (!hrgs) return null;
        var names = ['hex', 'dom', 'control', 'cipher', 'misc'];
        var samples = text.length > 2000 ? [text.substring(0, 2000), text.substring(Math.floor(text.length / 2) - 1000, Math.floor(text.length / 2) + 1000), text.substring(text.length - 2000)] : [text];
        for (var si = 0; si < samples.length; si++) {
          for (var ji = 0; ji < hrgs.length; ji++) {
            try { if (hrgs[ji].test(samples[si])) return '启发式:' + (names[ji] || String(ji)); } catch (eH) {}
          }
        }
      } catch (e) { _debugCatch(e, 'ssccHeuristicHit'); }
      return null;
    },
    _staticScriptContentCheck: function (el) {
      try {
        if (!currentConfig.staticScriptContentCheck) return;
        if (!currentConfig.modules.scriptBlacklistMode && !currentConfig.modules.removeExternalScripts) return;
        if (!el || el.tagName !== 'SCRIPT' || ProcessedElementsCache.isProcessed(el)) return;
        var src = el.src || el.getAttribute('src') || '';
        if (!src || /^(data|about|blob|#):/i.test(src)) return;
        var abs = src;
        try { abs = new _URL(src, _location.href).href; } catch (e) { return; }
        // 同源走 XHR(走 HTTP 缓存); 第三方域名跨源受 CORS 限制, 宿主提供 GM_xmlhttpRequest 时
        // 取回内容走同一检查管线, 无 GM 的宿主第三方按既有动态/第三方路径处理
        var _absSameOrigin = abs.indexOf(_location.origin + '/') === 0 || abs.split('/')[2] === _location.hostname;
        if (!_absSameOrigin && typeof GM_xmlhttpRequest !== 'function') return;
        if (isWhitelistedOrProtected(el)) return;
        if (!this._ssccPending) { this._ssccPending = {}; this._ssccLogged = {}; }
        if (this._ssccLogged[abs]) return;
        var stableKey = 'SCRIPT_SRC: ' + Utils.truncateString(_stableSrcKey(abs), CONFIG.LOG_DETAIL_LENGTH);
        if (currentConfig.whitelist.has(stableKey)) return;
        // 双键加白一致性: 外联精确键/结构键在无差别路径的既有加白, 内容检查管线同样放行
        if (Utils.externalScriptKey && currentConfig.whitelist.has(Utils.externalScriptKey(abs))) return;
        if (Utils.externalScriptStructKey && currentConfig.whitelist.has(Utils.externalScriptStructKey(abs))) return;
        if (currentConfig.keywordWhitelist.size > 0) {
          var kr = getKeywordWhitelistRegex();
          if (kr && kr.test(abs)) return;
        }
        var self = this;
        // 第三方域名的命中日记归「脚本黑名单」语义(分工: 第三方 URL 级由第三方模块管, 本管线管内容级)
        var _mk = currentConfig.modules.removeExternalScripts && _absSameOrigin ? 'removeExternalScripts' : 'scriptBlacklistMode';
        var _badKwEl = this._ssccKnownBadKw(stableKey, '');
        if (_badKwEl) {
          // 已知坏: 同步摘除（脚本元素在取内容完成前被摘除即不会执行）
          this._ssccLogged[abs] = 1;
          try { if (el.isConnected && el.parentNode) el.parentNode.removeChild(el); } catch (eR) {}
          ProcessedElementsCache.markAsProcessed(el);
          LogManager.add(_mk, el, {
            type: 'SCRIPT_BLACKLIST',
            detail: '外联脚本内容黑名单: ' + (_badKwEl !== '1' ? '关键词: ' + _badKwEl + ' - ' : '') + 'SRC: ' + Utils.truncateString(abs, CONFIG.LOG_DETAIL_LENGTH),
            elementContentIdentifier: stableKey,
          });
          if (_badKwEl === '1') {
            // 未存关键词的记录: 异步复核一次内容, 命中（关键词或启发式）则把命中标识补进
            // 缓存供后续日记列出, 内容未命中（如关键词已被用户从黑名单删除）则清掉记录解除已知坏
            this._fetchExternalText(abs, function (text) {
              try {
                if (text == null) return;
                var _kw2 = self._ssccContentHit(text) || self._ssccHeuristicHit(text);
                if (_kw2) { try { GM_setValue('adblock_ssrc_bad_' + generateContentHash(stableKey), _kw2); } catch (eS2) {} }
                else { try { GM_deleteValue('adblock_ssrc_bad_' + generateContentHash(stableKey)); } catch (eD2) {} }
              } catch (e3) { _debugCatch(e3, 'sscc badkw refresh'); }
            });
          }
          return;
        }
        if (this._ssccPending[abs]) return;
        this._ssccPending[abs] = 1;
        this._fetchExternalText(abs, function (text) {
          try {
            delete self._ssccPending[abs];
            if (text == null) return;
            var hitKw = self._ssccContentHit(text);
            if (!hitKw) hitKw = self._ssccHeuristicHit(text);
            if (!hitKw) return;
            self._ssccLogged[abs] = 1;
            try { GM_setValue('adblock_ssrc_bad_' + generateContentHash(stableKey), hitKw); } catch (eS) {}
            try { if (el.isConnected && el.parentNode) el.parentNode.removeChild(el); } catch (eR2) {}
            ProcessedElementsCache.markAsProcessed(el);
            LogManager.add(_mk, el, {
              type: 'SCRIPT_BLACKLIST',
              detail: '外联脚本内容命中: ' + hitKw + ' - SRC: ' + Utils.truncateString(abs, CONFIG.LOG_DETAIL_LENGTH),
              elementContentIdentifier: stableKey,
            });
          } catch (e2) { _debugCatch(e2, 'sscc check'); }
        });
      } catch (e) { _debugCatch(e, 'staticScriptContentCheck'); }
    },
    _fetchExternalText: function (url, cb) {
      // 同源取内容(走 HTTP 缓存), 第三方域名经 GM_xmlhttpRequest 跨源取内容;
      // 262144 字节截断限正则成本; 失败静默放行; 单测可整体注入替换本方法
      try {
        var _sameOrigin = url.indexOf(_location.origin + '/') === 0 || url.split('/')[2] === _location.hostname;
        var _cutText = function (t) { t = String(t || ''); return t.length > 262144 ? t.slice(0, 262144) : t; };
        if (!_sameOrigin) {
          if (typeof GM_xmlhttpRequest !== 'function') { cb(null); return; }
          GM_xmlhttpRequest({
            method: 'GET',
            url: url,
            timeout: 8000,
            onload: function (resp) {
              try {
                if (resp.status !== 200 && resp.status !== 0) { cb(null); return; }
                cb(_cutText(resp.responseText));
              } catch (e2) { cb(null); }
            },
            onerror: function () { cb(null); },
            ontimeout: function () { cb(null); },
          });
          return;
        }
        var _x = new XMLHttpRequest();
        _x.open('GET', url, true);
        _x.onreadystatechange = function () {
          if (_x.readyState !== 4) return;
          if (_x.status !== 200 && _x.status !== 0) { cb(null); return; }
          var t = String(_x.responseText || '');
          cb(t.length > 262144 ? t.slice(0, 262144) : t);
        };
        _x.onerror = function () { cb(null); };
        try { _x.send(null); } catch (e) { cb(null); }
      } catch (e) { cb(null); }
    },

    interceptAndLog: function(scriptElement) {
      var result = this.checkScriptSync(scriptElement);
      if (!result || !result.blocked) return false;
      // 先记日志、再中性化: 日志键必须取自"未清空前的脚本内容/地址"(SCRIPT_SRC/SCRIPT_CONTENT 键),
      // 否则清空后元素只剩固定空键 'SCRIPT_CONTENT: ', 导致 ①不同动态脚本去重成一条日记、
      // ②加白日记后刷新仍不认键（加白无效）。reason 缺 elementContentIdentifier 时在此补上。
      if (result.reason) {
        if (!result.reason.elementContentIdentifier) {
          try {
            var _ciInt = Utils.getContentIdentifier(scriptElement);
            if (_ciInt) result.reason.elementContentIdentifier = _ciInt;
          } catch(e) {}
        }
        LogManager.add(result.moduleKey, scriptElement, result.reason);
      }
      this.neutralizeScript(scriptElement);
      try { if (scriptElement.parentNode) scriptElement.parentNode.removeChild(scriptElement); } catch(e) {}
      return true;
    },

    checkAdElementSync: function(element) {
      if (!element || !_isElementLike(element)) return null;
      if (ProcessedElementsCache.isProcessed(element)) return null;
      if (_isSafe(element)) return null;
      if (isWhitelistedOrProtected(element)) return null;
      if (Utils.isUIElement && Utils.isUIElement(element)) return null;
      var t = element.tagName;
      if (t === 'SCRIPT' || t === 'STYLE' || t === 'LINK' || t === 'META' || t === 'NOSCRIPT' || t === 'BR' || t === 'HR') return null;

      if (currentConfig.modules.interceptThirdParty) {
        var handler = TAG_HANDLERS[t];
        // 按标签分发处理器：SCRIPT/IFRAME/IMG/A/LINK/STYLE/EMBED/OBJECT 各自的拦截检查
        // （通过 TAG_HANDLERS[tagName] 动态分发）。
        if (handler) {
          var u = element[handler.srcAttr] || element.getAttribute(handler.srcAttr) || (handler.dataSrcAttr && element.getAttribute(handler.dataSrcAttr));
          if (u && shouldBlockResource(u)) {
            return { blocked: true, moduleKey: 'interceptThirdParty',
              reason: { type: 'THIRD_PARTY', detail: t + ': ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH) }};
          }
        }
      }

      if (currentConfig.modules.overlayIntercept && OverlayInterceptor._enabled) {
        var is = element.style;
        if (is) {
          var pos = (is.position || '').toLowerCase();
          if (pos === 'fixed' || pos === 'absolute') {
            var zi = parseInt(is.zIndex);
            var sw = is.width, sh = is.height;
            var isFS = (sw === '100%' || sw === '100vw') && (sh === '100%' || sh === '100vh');
            if ((!isNaN(zi) && zi > CONFIG.ZINDEX_HIDE_THRESHOLD) || isFS) {
              // 子树保护与白名单同权: 容器内含已放行元素时同步路径同样不拦（防连坐隐藏）
              if (!isOverlayWhitelistedForElement(element) && !hasReleasedOverlayInTree(element)) {
                // src 型 iframe + 页面有正文或标题 → 正常播放器(移动端播放器常为
                // fixed 全屏覆盖式 src iframe), 放行——与 checkAndHandle 全屏检测的
                // "src型仅劫持页（无正文无标题）才拦" 策略保持一致, 防止同步路径先手误杀
                var _syncAllow = false;
                if (t === 'IFRAME' && element.getAttribute && element.getAttribute('src') && !element.getAttribute('srcdoc')) {
                  try {
                    var _bTxt3 = (_document.body ? (_document.body.textContent || '') : '').replace(/\s+/g, ' ').trim();
                    var _hO3 = _bTxt3.length > 30;
                    if (!_hO3) { try { _hO3 = _document.querySelectorAll('img, a, video').length > 3; } catch(e) {} }
                    // 严格模式（覆盖层拦截）: 页面有正文/标题也照拦
                    if ((_hO3 || (_document.title || '').trim().length >= 5) && !currentConfig.overlayStrictMode) _syncAllow = true;
                  } catch(e) {}
                }
                if (!_syncAllow) {
                  var _isScroll = false;
                  try {
                    // 与 isOverlayElement 的可滚动豁免口径一致: 只保护带 src 的全屏 iframe 播放器,
                    // DIV 包裹 iframe 的固定全屏广告覆盖层不豁免（同步路径同样拦截）。
                    // 同步路径不调用 getComputedStyle(手机端强制 layout 高成本, 拖慢交互),
                    // 可滚动豁免只按 inline overflow 判定; 计算样式判定由异步路径(isOverlayElement)负责。
                    if (t === 'IFRAME' && element.getAttribute && element.getAttribute('src')) {
                      var _ov5 = (is.overflowY || is.overflow || '').toLowerCase();
                      if (_ov5.indexOf('auto') !== -1 || _ov5.indexOf('scroll') !== -1) {
                        _isScroll = true;
                      }
                    }
                  } catch(e) {}
                  if (!_isScroll) {
                    // 拦截日记降噪（默认开）: 同步路径只静默隐藏不记日记,
                    // 由 hideElement 按"位置"记第一条日记并去重;
                    // 关闭降噪时同步路径照常记日记（每元素独立键, 可加白）。
                    // IFRAME 型覆盖层(带 src)例外: 播放器误伤最常走同步路径(动态创建的 src iframe),
                    // 静默吞日志会让用户"找不到条目无法加白" → IFRAME 即使降噪也记一条。
                    var _syncNoLog = currentConfig.logNoiseReduction !== false &&
                      !(t === 'IFRAME' && element.getAttribute && element.getAttribute('src'));
                    try {
                      // 日记键: iframe 用 IFRAME_SRC(去参稳定键), 容器类(DIV等)用 OVERLAY_ 结构哈希
                      // (与 hideElement 同公式) → 加白后可放行
                      var _syncCi = _overlayContentKey(element) || Utils.getContentIdentifier(element);
                      if (!_syncCi) {
                        var _ti2 = _overlayTagIdent(element);
                        _syncCi = 'OVERLAY_' + generateContentHash('overlayIntercept:' + _ti2 + ':' + Utils.truncateString(element.textContent || '', 100));
                      }
                      if (OverlayInterceptor && OverlayInterceptor._hiddenElementsMap) {
                        OverlayInterceptor._hiddenElementsMap.set(element, _syncCi || _getFullscreenAdKeys(element)[0] || null);
                      }
                      // 槽位预计算一次, 键/备钥组/显示短标识共用(src 型 iframe 不遍历)
                      var _syncDispPre = _overlaySlotPreSlots(element);
                    } catch(e) {}
                    return { blocked: true, moduleKey: 'overlayIntercept',
                      reason: { type: 'OVERLAY', detail: '同步覆盖层拦截: ' + (_overlaySlotDisplay(element, _syncDispPre) || t), elementContentIdentifier: _syncCi || undefined, altContentIdentifiers: _syncDispPre ? _overlayBackupKeys(element, _syncDispPre) : _overlayBackupKeys(element) },
                      noLog: _syncNoLog || undefined };
                  }
                }
              }
            }
          }
        }
        // 容器内 iframe 的第三方检查由异步 MO 回调补查(见第三方模块订阅者, 新插入容器内的
        // iframe[src] 一次性全部检查): 同步路径不深扫子树(手机端每次 appendChild 的
        // O(子树) 扫描会拖慢交互), 拦截由异步路径覆盖, 延迟一帧以内
      }
      return null;
    },

    neutralizeAdElement: function(element, reason) {
      if (!element || !_isElementLike(element)) return;
      try {
        element.classList.add('_uh');
        element.style.setProperty('display', 'none', 'important');
        element.style.setProperty('visibility', 'hidden', 'important');
        element.style.setProperty('pointer-events', 'none', 'important');
        ProcessedElementsCache.markAsProcessed(element);
      } catch(e) { _debugCatch(e, "neutralizeAdElement"); }
      // 同步路径隐藏覆盖层后同样触发滚动解锁(广告脚本常同时用样式表锁死 html/body 滚动)
      try { ScrollLockGuard.armForElement(element); } catch(e) { _debugCatch(e, "neutralizeAdElement arm"); }
    }
  };


  var _sbrHash = '', _sbrBlackRegex = null;
  function getSbrBlacklistRegex(activeArr) {

    var cleanArr = activeArr.filter(function (k) { return k; });
    var h = cleanArr.join('\x00');
    if (h !== _sbrHash) {
      _sbrHash = h;
      _sbrBlackRegex = null;
      if (cleanArr.length) {
        try {
          _sbrBlackRegex = new RegExp(cleanArr.map(function (k) {
            return k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          }).join('|'));
        } catch (e) { _sbrBlackRegex = null; }
      }
    }
    return _sbrBlackRegex;
  }

  // ======================== 全局常量 ========================
    // 【功能】集中管理全部调参阈值：拦截判定（z-index/尺寸）、扫描节奏（周期/批量）、日志与缓存容量。
    // 【机制】纯数值配置，多处复用；改动此处即可全局调整行为，无需散改各模块。
    // 【注意】ZINDEX_HIDE_THRESHOLD 决定"多高的 z-index 算覆盖层广告"；STRONG_BLOCK_TIMEOUT 控制强拦截窗口。
  const CONFIG = {
    CACHE_TTL: 300000,
    BATCH_SIZE: 20,
    LOG_MAX: 200,
    LOG_IDENTIFIER_TTL: 300000,
    STRONG_BLOCK_TIMEOUT: 600000,
    RESIDUAL_MIN_WIDTH: 30,
    RESIDUAL_MIN_HEIGHT: 30,
    CONTENT_PREVIEW_LENGTH: 200,
    LOG_DETAIL_LENGTH: 500,
    TOOLTIP_GAP: 12,
    ZINDEX_HIDE_THRESHOLD: 600,
    FIXED_HEIGHT_THRESHOLD: 50,
    CONTAINER_MIN_VISIBLE: 10,
    LAZY_PLACEHOLDER_MAX_LEN: 200,
    INVALID_HOSTNAME_TTL: 30000,
    DATA_URL_TTL: 60000,
    IDLE_SCAN_INTERVAL: 3000,
    BATCH_SIZE_CLEANUP: 30,
    PAGE_SIZE: 20,
    CACHE_CAPACITY_URL: 1000,
    CACHE_CAPACITY_SMALL: 500,
    ANCHOR_CLICK_THROTTLE: 16,
  };


  // 1×1 透明像素图：用来替换被拦截的图片/iframe，占位但不显示内容。
  const TRANSPARENT_PIXEL = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';


  const ACTIVATING_TYPES = ['', 'text/javascript', 'application/javascript',
      'application/ecmascript', 'text/ecmascript', 'module'];


  // ======================== 安全引用原生对象 ========================
    // 【功能】在页面脚本运行前缓存原生 window/document/MutationObserver/XMLHttpRequest 等引用。
    // 【机制】页面 JS 可能重写 window.fetch、document.write 等，本脚本一律使用 _ 前缀的缓存引用，
    //        保证拦截逻辑永远操作"真原生"对象，不被页面劫持/欺骗。
    // 【注意】_safeElementSet 标记脚本自身元素（面板/宿主），拦截逻辑一律跳过这些元素（防自拦）。
  const _globals = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;
  const _document = _globals.document;
  const _location = _globals.location;
  const _MutationObserver = _globals.MutationObserver;
  const _Element = _globals.Element;
  const _isElementLike = function(el) {
    if (!el) return false;
    if (el instanceof _Element) return true;
    return typeof el.nodeType === 'number' && el.nodeType === 1 && typeof el.nodeName === 'string' && typeof el.getAttribute === 'function' && typeof el.setAttribute === 'function';
  };
  const _Document = _globals.Document;
  const _Node = _globals.Node;
  const _setTimeout = _globals.setTimeout;
  const _clearTimeout = _globals.clearTimeout;
  const _requestAnimationFrame = _globals.requestAnimationFrame;
  const _XMLHttpRequest = _globals.XMLHttpRequest;
  const _fetch = _globals.fetch;
  // URL 构造器快照: 页面脚本可用顶层 var URL = ... 重写 window.URL,
  // 重写后按页面值构造会抛错, 使域名解析失效、第三方判定全部放行;
  // 优先取文档启动时的裸 URL(隔离环境恒为原生), 仅在裸 URL 不可用时回退 _globals.URL
  const _URL = (typeof URL === 'function') ? URL : _globals.URL;
  const _Proxy = _globals.Proxy;
  const _Set = _globals.Set;
  const _Map = _globals.Map;
  const _getComputedStyle = _globals.getComputedStyle ? _globals.getComputedStyle.bind(_globals) : window.getComputedStyle;
  const _requestIdleCallback = _globals.requestIdleCallback || function (cb) {
    return _setTimeout(() => cb({ timeRemaining: () => 50, didTimeout: false }), 1);
  };
  const _cancelIdleCallback = _globals.cancelIdleCallback || _clearTimeout;

  const _safeElementSet = new WeakSet();
  function _markSafe(el) {
    if (el) _safeElementSet.add(el);
  }
  function _isSafe(el) {
    if (!el) return false;
    return _safeElementSet.has(el);
  }
  // 祖先链安全检查: 元素自身未标记但处于"脚本自身 UI"(已 _markSafe 的宿主/面板/标记器)
  // 内部时同样视为安全 —— 槽位锁 MO 深扫子元素时会逐个检查容器内部节点,
  // 标记面板卡片等 innerHTML 动态子元素不在此放行会被已存规则的槽位键误锁（面板不弹出）。
  function _hasSafeAncestor(el) {
    try {
      var p = el && el.parentElement;
      while (p) {
        if (_safeElementSet.has(p)) return true;
        p = p.parentElement;
      }
    } catch (e) {}
    return false;
  }
  // ======================== 全局DOM同步hook ========================
    // 【功能】hook Node.prototype.appendChild/insertBefore：任何动态插入的元素都先过一遍检查
    //        （脚本→ScriptSyncGuard，其他元素→覆盖层/第三方资源检查），命中即中性化后再插入。
    // 【机制】_anyActive() 快速开关：所有相关模块关闭时直接透传原生方法（零开销）；
    //        动态创建的 <script> 打 data-ab-new 标记，供"静态/动态"区分。
    // 【注意】只处理"同步插入"路径；parser 直接解析的静态元素由 MutationObserver/周期扫描兜底。

  (function installGlobalHooks() {
    var _anyActive = function() {
      var m = currentConfig.modules;
      return m.removeInlineScripts || m.removeExternalScripts
        || m.scriptBlacklistMode || m.blockDynamicScripts || m.overlayIntercept
        || (m.interceptThirdParty && currentConfig.thirdPartyStrictMethod);


    };

    try {
      var origAC = _Node.prototype.appendChild;
      _Node.prototype.appendChild = function(child) {
        if (!_anyActive()) return origAC.call(this, child);
        if (child && Utils.isElement(child)) {
          if (child.tagName === 'SCRIPT') {

            try { child.setAttribute('data-ab-new', '1'); } catch(e) {}
            var sr = ScriptSyncGuard.checkScriptSync(child);
            if (sr && sr.blocked) {
              LogManager.add(sr.moduleKey, child, sr.reason);
              ScriptSyncGuard.neutralizeScript(child);
              return child;
            }
          }
          var ar = ScriptSyncGuard.checkAdElementSync(child);
          if (ar && ar.blocked) {
            ScriptSyncGuard.neutralizeAdElement(child, ar.reason);
            if (!ar.noLog) LogManager.add(ar.moduleKey, child, ar.reason);
          }
        }
        return origAC.call(this, child);
      };
    } catch(e) { _debugCatch(e, "globalAC"); }

    try {
      var origIB = _Node.prototype.insertBefore;
      _Node.prototype.insertBefore = function(newNode, refNode) {
        if (!_anyActive()) return origIB.call(this, newNode, refNode);
        if (newNode && Utils.isElement(newNode)) {
          if (newNode.tagName === 'SCRIPT') {

            try { newNode.setAttribute('data-ab-new', '1'); } catch(e) {}
            var sr2 = ScriptSyncGuard.checkScriptSync(newNode);
            if (sr2 && sr2.blocked) {
              LogManager.add(sr2.moduleKey, newNode, sr2.reason);
              ScriptSyncGuard.neutralizeScript(newNode);
              return newNode;
            }
          }
          var ar2 = ScriptSyncGuard.checkAdElementSync(newNode);
          if (ar2 && ar2.blocked) {
            ScriptSyncGuard.neutralizeAdElement(newNode, ar2.reason);
            if (!ar2.noLog) LogManager.add(ar2.moduleKey, newNode, ar2.reason);
          }
        }
        return origIB.call(this, newNode, refNode);
      };
    } catch(e) { _debugCatch(e, "globalIB"); }

    // 静态外联脚本内容检查的观察器（解析器直插脚本不经过上方钩子）;
    // 每元素内部按 scriptBlacklistMode+staticScriptContentCheck 门控, 关闭时零开销
    try { ScriptSyncGuard.installStaticScriptCheck(); } catch (e) { _debugCatch(e, "sscc boot"); }
  })();


  // ======================== 白名单+保护+位置指纹 ========================
    // 【功能】三个基础能力：①白名单优先——用户放行的内容一律不拦；②保护标记——脚本自身 UI 与
    //        用户指定内容（data-ow/data-oci/data-slot-protected）不被拦截；③位置指纹——记录元素
    //        在页面中的位置，用于识别"同一个位置反复冒出来的广告"。
    // 【机制】isWhitelistedOrProtected 是全局放行判定（属性级）；markSlotProtected 给用户放行的
    //        内容连同父链打保护标记；位置指纹（gp.tagName + 子索引）在父容器被替换后依然稳定。
    // 【注意】数据属性(data-*)是脚本与页面沟通的"放行令牌"，页面脚本伪造它们也无法绕过
    //        whitelist Set 的内容键判定（双层保险）。
  function isWhitelistedOrProtected(el) {
    if (!el || !_isElementLike(el)) return false;
    if (el.getAttribute) {
      if (el.getAttribute('data-ow') === 'true') return true;
      if (el.getAttribute('data-adblock-whitelist') === 'true') return true;
      if (el.getAttribute('data-slot-protected') === 'true') return true;
      var oci = el.getAttribute('data-oci');
      if (oci && currentConfig.whitelist.has(oci)) return true;
    }
    if (typeof Whitelisting !== 'undefined' && Whitelisting.isElementWhitelisted(el)) return true;
    if (currentConfig.keywordWhitelist.size > 0) {
      var kr = getKeywordWhitelistRegex();
      if (kr) { var src = el.src || el.href || (el.getAttribute && el.getAttribute('data-src')) || ''; if (src && kr.test(src)) return true; }
    }
    return false;
  }
  function hasWhitelistedContentInTree(el) {
    if (!el || !_isElementLike(el)) return false;
    if (isWhitelistedOrProtected(el)) return true;
    if (el.querySelectorAll) {
      try { if (el.querySelector('[data-ow="true"], [data-adblock-whitelist="true"], [data-slot-protected="true"]')) return true; } catch(e) {}
    }
    return false;
  }
  function markSlotProtected(el) {
    if (!el || !_isElementLike(el)) return;
    el.setAttribute('data-slot-protected', 'true');
    var p = el.parentElement, d = 0;
    while (p && p !== _document.body && p !== _document.documentElement && d < 3) {
      if (_isElementLike(p)) p.setAttribute('data-slot-protected', 'true');
      p = p.parentElement; d++;
    }
  }

  // ======================== 覆盖层白名单统一判定 ========================
    // 【功能】同一个元素可能被多条拦截路径命中（同步钩子/全屏 iframe 移除/常规隐藏），
    //        各路径只查自己的键时，会出现"日记里加白了、另一条路径照样拦"的问题。
    // 【机制】isOverlayWhitelistedForElement 做统一判定：稳定键(IFRAME_SRC 去参/OVERLAY_ 结构哈希)
    //        + 全屏 iframe 页面键/内容键，任一命中即完全放行；hideElement/灭菌路径/顶部门卫全部走这里。
    // 【用户体验】在拦截日记里加白任一条目，所有拦截路径立即放行，无需逐条加白。
  function _getFullscreenAdKeys(el) {
    try {
      var _pgKey = 'OVERLAY_FULLSCREEN_AD:' + generateContentHash(((_location && _location.href) || '').split('#')[0]);
      // 与 checkAndHandle 内计算保持一致: srcdoc 需小写(_fsd = srcdoc.toLowerCase())
      var _sdKey = ((el.getAttribute('srcdoc') || '').toLowerCase()) || (el.getAttribute('src') || '');
      if (_sdKey.length > 204800) _sdKey = _sdKey.slice(0, 204800);
      var _ciF = 'OVERLAY_FULLSCREEN_AD:' + generateContentHash(_sdKey.replace(/\s+/g, '').replace(/[0-9]{6,}/g, 'N').slice(0, 4000));
      return [_pgKey, _ciF];
    } catch(e) { return []; }
  }

  // ======================== 覆盖层稳定白名单键 ========================
    // 【功能】生成"刷新后依然有效"的白名单键：不依赖易变内容（src 带 token、动态文本、
    //        逐次变化的随机数字尾缀）。
    // 【机制】· IFRAME(带 src) → 'IFRAME_SRC: ' + 去易变参数的 src（剥离 token/sign/ts/时间戳等）
    //        · 其他 → 'OVERLAY_' + hash(结构槽位)：槽位 = 稳定锚点(id 剥尾部数字) + 相对位置；
    //          并配一把去名槽位备键（锚点只留标签名+兄弟序号），锚点名逐次随机时备键仍稳定。
    //        日志键与白名单检查键同公式（加白即生效），多钥匙任一命中即放行。
    // 【用户体验】加白的键若不匹配当前内容，在拦截日记里重新加白一次即可（无需重置设置）。
  function _stableSrcKey(src) {
    if (!src || typeof src !== 'string') return src;
    try {
      var u = new _URL(src, _location.href);
      var keep = [];
      if (u.searchParams && typeof Array.from === 'function') {
        var drop = /^(?:token|sign|sig|ts|_t|t|timestamp|time|rand|random|r|callback|cb|session|sid|expires|auth|key|from|utm_source|utm_medium|utm_campaign|utm_term|utm_content)$/i;
        var keys = Array.from(u.searchParams.keys());
        for (var i = 0; i < keys.length; i++) {
          var v = u.searchParams.get(keys[i]);
          // 复用「追踪参数」机制（用户可在面板自定义名单）: 命中的追踪参数同样不进键
          if (typeof EnhancedTrackingCleaner !== 'undefined' && EnhancedTrackingCleaner.isTrackingParam(keys[i])) continue;
          if (drop.test(keys[i])) continue;
          if (/^\d{9,}$/.test(v || '')) continue;   // 纯时间戳数字值
          // 无等号的长随机 query(如 hm.js?<32位hex>、push.js?<超长token>): 键随参数每次变,
          // 剥掉让日记/白名单键稳定; 保留语义化短参数（版本号等）。
          if (v === '' && keys[i].length >= 16) continue;
          // key 名本身为长 hex(统计/埋点随机参数)
          if (keys[i].length >= 12 && /^[a-f0-9]{12,}$/i.test(keys[i])) continue;
          keep.push(keys[i] + '=' + v);
        }
      }
      var base = u.origin + u.pathname;
      return keep.length ? base + '?' + keep.sort().join('&') : base;
    } catch (e) { return src; }
  }

  // 覆盖层标签身份段(full=恒含 id+class): 键模式 identity=键含 id+class, 随名字走;
  // stable(结构槽位, 默认)=弃 id+class, 键只看文档结构位置, 跨加载稳定。
  // _overlayTagIdentFull 同时充当身份公式备钥: 无论当前模式, 匹配时都额外按它算一把备钥,
  // 与主键任一命中白名单即放行。
  function _overlayTagIdentFull(el) {
    var _cls = '';
    try {
      _cls = String(el.className || '').split(/\s+/).filter(function (c) {
        return c && c !== '_uh';
      }).join('.');
    } catch (e) {}
    return el.tagName + (el.id ? '#' + el.id : '') + (_cls ? '.' + _cls : '');
  }
  function _overlayTagIdent(el) {
    return el.tagName;
  }
  // 锚点 id 归一化: 剥离尾部数字段(swipercontainer31313→swipercontainer)后再入键,
  // 数字尾缀逐次变化的 id 与键解耦; 剥完不含字母的 id(纯数字)不计入锚点标识。
  function _normAnchorId(id) {
    if (!id) return '';
    var _n = String(id).replace(/\d+$/, '');
    return (_n && /[A-Za-z]/.test(_n)) ? _n : '';
  }
  // 是否可作为"稳定结构锚点": 带稳定 id 或有非随机类名的元素(body/html 兜底);
  // 纯数字 id、长 hex 类名视为随机, 不作锚点; id 入键前经 _normAnchorId 归一化。
  function _isStableAnchor(node) {
    if (!node || node.nodeType !== 1) return false;
    if (node.tagName === 'BODY' || node.tagName === 'HTML') return true;
    var id = node.id || '';
    if (id && /[A-Za-z]/.test(id)) return true;
    var cls = (typeof node.className === 'string' ? node.className : '');
    if (cls) {
      return cls.split(/\s+/).some(function (c) {
        return c && c !== '_uh' && /[A-Za-z]/.test(c) && !/^[a-f0-9]{8,}$/i.test(c);
      });
    }
    return false;
  }
  // 结构槽位键(stable 默认): 取最近稳定祖先(带稳定 id/class 的容器, 否则 body)为锚点,
  // 键 = 锚点标签 + 锚点下相对 tag[子序号]链 + media 标记 —— 广告每次几何/文本/id 全变,
  // 只要落在同一结构位置键就稳定（加白刷新长期有效）; 锚点层级越高越抗同层前插漂移。
  // 同一次遍历并行产出四把槽位, 稳定性递增、特异性递减, 配套使用:
  //   [0]=命名槽位(锚点带归一化 id/class) —— 锚点名稳定时命中, 特异性最高;
  //   [1]=去名槽位(锚点只留 tagName+[兄弟序号]) —— 锚点名逐次随机时兜底;
  //   [2]=松散链槽位(锚点到目标只留 tagName) —— 序号漂移时兜底, 同形广告位共享此键;
  //   [3]=BODY根链槽位(BODY 起全程 tagName, 不依赖锚点选择) —— 广告落点在
  //      不同容器间跳变（锚点选择翻转）时的最终兜底, 页面标签深度稳定即稳定。
  function _overlayStableSlots(el) {
    if (!el || !_isElementLike(el)) return null;
    try {
      var node = el.parentElement;
      var anchorNode = _document.body, anchorTag = 'BODY', anchorBare = 'BODY', anchorLoose = 'BODY';
      var anchorFound = false;
      var aboveChain = [];
      while (node && node.nodeType === 1 && node !== _document.documentElement) {
        if (!anchorFound && _isStableAnchor(node)) {
          anchorFound = true;
          anchorNode = node;
          var _id = _normAnchorId(node.id || '');
          var _cl = '';
          if (typeof node.className === 'string') {
            _cl = String(node.className).split(/\s+/).filter(function (c) {
              return c && c !== '_uh' && /[A-Za-z]/.test(c) && !/^[a-f0-9]{8,}$/i.test(c);
            }).join('.');
          }
          anchorTag = node.tagName + (_id ? '#' + _id : '') + (_cl ? '.' + _cl : '');
          if (node === _document.body || node === _document.documentElement) {
            anchorBare = node.tagName;
            anchorLoose = node.tagName;
          } else {
            var _ai = 0;
            if (node.parentElement && node.parentElement.children) {
              var _aa = Array.from(node.parentElement.children);
              _ai = _aa.indexOf(node);
            }
            anchorBare = node.tagName + '[' + _ai + ']';
            anchorLoose = node.tagName;
          }
        } else if (anchorFound && node !== _document.body) {
          aboveChain.push(node.tagName);
        }
        node = node.parentElement;
      }
      var rel = [];
      var relLoose = [];
      var n = el;
      while (n && n.nodeType === 1 && n !== anchorNode && n !== _document.documentElement) {
        var p = n.parentElement;
        if (!p) break;
        var idx = 0;
        if (p.children) { var arr = Array.from(p.children); idx = arr.indexOf(n); }
        rel.unshift(n.tagName + '[' + idx + ']');
        relLoose.unshift(n.tagName);
        n = p;
      }
      var media = 0;
      try { media = (el.querySelector && el.querySelector('video,audio,iframe,canvas,embed')) ? 1 : 0; } catch (e) {}
      var _tailIdx = '>' + (rel.length ? rel.join('>') : el.tagName) + ':m' + media;
      var _tailLoose = '>' + (relLoose.length ? relLoose.join('>') : el.tagName) + ':m' + media;
      aboveChain.reverse();
      // BODY 根链补上锚点自身的标签段(body 锚点除外, 避免与前缀重复),
      // 保证链条覆盖 body 到目标之间的每一层
      if (anchorNode !== _document.body && anchorNode !== _document.documentElement) {
        aboveChain.push(anchorLoose);
      }
      var _chainTags = aboveChain.concat(relLoose);
      var _bodyChain = 'BODY>' + (_chainTags.length ? _chainTags.join('>') : el.tagName) + ':m' + media;
      return [
        anchorTag + _tailIdx,
        anchorBare + _tailIdx,
        anchorLoose + _tailLoose,
        _bodyChain
      ];
    } catch (e) { return null; }
  }
  // 覆盖层日记显示层短标识: 用[1]去名槽位(锚点tag[序号]链)替代 tag#id.class ——
  // 随机 id/类名不会进入日记字面/白名单显示名; 只影响显示, 加白键仍是
  // contentIdentifier+备钥组(白名单 Set/判定链路不动)。src 型 iframe 直接给去参 URL。
  function _overlaySlotDisplay(el, _preSlots) {
    try {
      if (!el || !_isElementLike(el)) return '';
      if (el.tagName === 'IFRAME') {
        var _s2 = el.src || el.getAttribute('src') || '';
        if (_s2) return 'IFRAME@' + Utils.truncateString(_stableSrcKey(_s2), 70);
      }
      var _slots = _preSlots || _overlayStableSlots(el);
      if (_slots && _slots[1]) {
        var _d = String(_slots[1]).replace(/:m[01]$/, '');
        if (_d) return _d;
      }
      return el.tagName;
    } catch (e) { return ''; }
  }
  // 显示层槽位预计算(src 型 iframe 不需要, 避免多余祖先遍历): 供显示短标识与
  // altContentIdentifiers 备钥组共用一次槽位遍历
  function _overlaySlotPreSlots(el) {
    try {
      if (el && el.tagName === 'IFRAME' && (el.src || el.getAttribute('src') || '')) return null;
      return _overlayStableSlots(el);
    } catch (e) { return null; }
  }
  // 身份公式备钥: 按完整身份(tag#id.class)计算, 作为结构槽位主键之外的另一把备钥参与匹配
  function _overlayIdentityKey(el) {
    if (!el || !_isElementLike(el)) return null;
    try {
      if (el.tagName === 'IFRAME') {
        var _s = el.src || el.getAttribute('src') || '';
        if (_s) return 'IFRAME_SRC: ' + Utils.truncateString(_stableSrcKey(_s), CONFIG.LOG_DETAIL_LENGTH);
      }
      var media = 0;
      try { media = (el.querySelector && el.querySelector('video,audio,iframe,canvas,embed')) ? 1 : 0; } catch (e) {}
      return 'OVERLAY_' + generateContentHash('overlayIntercept:' + _overlayTagIdentFull(el) + ':m' + media);
    } catch (e) { return null; }
  }

  function _overlayContentKey(el, _preSlots) {
    // 覆盖层专用白名单键（见上方注释）, 与 hideElement/同步路径的日记键同公式;
    // _preSlots 传入预计算的槽位对时可免去重复结构遍历
    if (!el || !_isElementLike(el)) return null;
    try {
      // IFRAME 带 src: 始终用去参数稳定键(IFRAME_SRC), 两种键模式共用
      if (el.tagName === 'IFRAME') {
        var _s = el.src || el.getAttribute('src') || '';
        if (_s) return 'IFRAME_SRC: ' + Utils.truncateString(_stableSrcKey(_s), CONFIG.LOG_DETAIL_LENGTH);
      }
      // 结构槽位（默认）: 稳定锚点 + 相对路径 + media, 几何/文本/id 全变也不动键;
      // 无可用锚点路径时退回几何兜底键, 保证日记键始终可算。
      var _slots = _preSlots || _overlayStableSlots(el);
      if (_slots && _slots[0]) return 'OVERLAY_' + generateContentHash('overlayIntercept:' + _slots[0]);
      var _st = el.style || {};
      var _pos = (_st.position || '').toLowerCase();
      var _geom = [_pos, _st.left || '', _st.top || '', _st.right || '', _st.bottom || '',
        _st.width || '', _st.height || ''].join('|');
      var _zi = parseInt(_st.zIndex);
      var _zTier = isNaN(_zi) ? 'z' : (_zi > 1000000 ? 'zh' : (_zi > CONFIG.ZINDEX_HIDE_THRESHOLD ? 'zm' : 'zl' + Math.min(Math.floor(_zi / 100), 20)));
      var media = 0;
      try { media = (el.querySelector && el.querySelector('video,audio,iframe,canvas,embed')) ? 1 : 0; } catch (e) {}
      return 'OVERLAY_' + generateContentHash('overlayIntercept:' + el.tagName + ':' + _geom + ':' + _zTier + ':m' + media);
    } catch (e) { return null; }
  }

  // 覆盖层备钥组: 与主键同一次结构遍历产出 —— [去名槽位键, 松散链键]; 带 src 的 iframe
  // 主键已是去参稳定 URL、identity 模式由身份备钥覆盖, 这两种情况不发备钥;
  // 与主键重复或彼此重复的键剔除。
  function _overlayBackupKeys(el, _preSlots) {
    if (!el || !_isElementLike(el)) return [];
    try {
      if (el.tagName === 'IFRAME') {
        var _s = el.src || el.getAttribute('src') || '';
        if (_s) return [];
      }
      var _slots = _preSlots || _overlayStableSlots(el);
      if (!_slots) return [];
      var _out = [];
      for (var _si3 = 1; _si3 < _slots.length; _si3++) {
        if (!_slots[_si3] || _slots[_si3] === _slots[0]) continue;
        var _k = 'OVERLAY_' + generateContentHash('overlayIntercept:' + _slots[_si3]);
        if (_out.indexOf(_k) === -1) _out.push(_k);
      }
      return _out;
    } catch (e) {}
    return [];
  }

  // 多钥匙匹配: 当前模式主键（日记键） + 备钥组（去名槽位/松散链） + 身份公式备钥,
  // 任一命中白名单即放行; 槽位只算一次, 全部钥匙共用
  function _overlayKeyMatches(el, wl, _preSlots) {
    if (!el || !wl || wl.size === 0) return false;
    var _slots = _preSlots || _overlayStableSlots(el);
    var _ok = _overlayContentKey(el, _slots);
    if (_ok && wl.has(_ok)) return true;
    var _baks = _overlayBackupKeys(el, _slots);
    for (var _mi2 = 0; _mi2 < _baks.length; _mi2++) {
      if (_baks[_mi2] !== _ok && wl.has(_baks[_mi2])) return true;
    }
    var _idk = _overlayIdentityKey(el);
    if (_idk && _idk !== _ok && _baks.indexOf(_idk) === -1 && wl.has(_idk)) return true;
    return false;
  }

  function isOverlayWhitelistedForElement(el, _preSlots) {
    if (!el || !_isElementLike(el)) return false;
    // isWhitelistedOrProtected 已覆盖: data-ow/data-oci 属性、关键词白名单
    if (isWhitelistedOrProtected(el)) return true;
    if (currentConfig.whitelist.size > 0) {
      // 多钥匙匹配: 主键(IFRAME_SRC 去参 / OVERLAY_ 结构槽位或身份哈希) + 去名/身份备钥,
      // 任一命中即完全放行; _preSlots 由热路径（槽位锁）传入, 避免同一元素重复祖先遍历
      try {
        if (_overlayKeyMatches(el, currentConfig.whitelist, _preSlots)) return true;
      } catch(e) {}
      // 仅补充全屏iframe专属的页面键/内容键（其他路径不认这两把钥匙）
      var keys = _getFullscreenAdKeys(el);
      for (var i = 0; i < keys.length; i++) {
        if (keys[i] && currentConfig.whitelist.has(keys[i])) return true;
      }
    }
    return false;
  }

  // 子树放行扫描: 容器内任一元素命中覆盖层白名单（多钥匙/属性标记）即视为受保护容器,
  // 残留清理/尸体清理不得隐藏它 —— 防止用户加白放行的广告被所在空容器连坐隐藏
  function hasReleasedOverlayInTree(root) {
    if (!root || !root.querySelectorAll) return false;
    try {
      var list = root.querySelectorAll('*');
      for (var i = 0; i < list.length; i++) {
        if (isOverlayWhitelistedForElement(list[i])) return true;
      }
    } catch (e) {}
    return false;
  }

  // ======================== 元素CSS屏蔽 ========================
    // 【功能】用户点击标记页面元素，生成 CSS 隐藏规则（display:none）——标记了、有规则就生效，
    //        无总开关。标记卡片上三种屏蔽方式自选（各方式命中数实时预览），并可一键
    //        封杀广告来源第三方域名。
    // 【机制】三方式互补：
    //        · 类名/ID 钥匙：目标自身的稳定类名(div.cls)或完整稳定 id(#id) —— 抗结构位移；
    //        · 物理结构钥匙：稳定锚点 + tag:nth-of-type 链 / body 全链 / 尾部兜底链，
    //          完全不引用目标自身的类名/ID —— 抗名字随机化；锚点尾缀数字变化用
    //          [id^="归一化前缀"] 消化；
    //        · 形态特征（内联样式片段）钥匙：[style*="position:fixed" i] 等高信号片段组合，
    //          与名字/结构/数值全解耦 —— 专打"类名/ID/结构全随机"的注入层(透明点击
    //          劫持层等)，一条规则命中全部同形态层（含后续新注入变种）。
    //        域名封杀：元素或子树内首个第三方域 → [src*=]/[href*=]/[data-src*=] 属性
    //        选择器规则，指向该域名的图片/iframe/脚本/链接全部隐藏。
    //        样式表在 document-start 注入（防闪现），3 秒防删守卫自动重建。
    // 【用户体验】广告拦截设置主面板 →「🎯 标记屏蔽元素」(位于覆盖层拦截/脚本黑名单
    //        开关下方)；点击元素 → 卡片切换方式/选父级 →「屏蔽它」或「🔥 封杀来源域名」。
    //        规则在「📋 CSS屏蔽规则」里管理（删除即恢复）。
    // 【注意】纯 CSS 匹配浏览器自动应用到后续插入节点，零逐元素扫描成本；
    //        结构位移由类名/ID 钥匙兜底，名字随机由物理钥匙兜底，名字结构全随机由
    //        形态钥匙兜底；形态钥匙可能波及同形态的正常元素，由命中数预览把守。

  function _cssEscapeIdent(s) {
    s = String(s);
    try { if (typeof CSS !== 'undefined' && CSS && CSS.escape) return CSS.escape(s); } catch (e) {}
    return s.replace(/([^a-zA-Z0-9_\u00A0-\uFFFF-])/g, '\\$1');
  }
  // 随机形态类名/标识判定(比 _isStableAnchor 更严, 只影响本模块的锚点/类名取舍):
  // hex 哈希、含 3 位以上连续数字、无元音随机串(kvypxtv)、超长无分隔串视为易变,
  // 判错的代价只是退回 body 物理链, 方向安全。
  function _looksVolatileClassName(c) {
    if (!c) return true;
    if (c === '_uh' || c === 'ab-pick-hl') return true;
    if (/^[a-f0-9]{6,}$/i.test(c)) return true;
    if (/\d{3,}/.test(c)) return true;
    if (c.length >= 7 && !/[aeiou]/.test(c)) return true;
    if (c.length >= 16 && /^[a-z0-9]+$/i.test(c)) return true;
    // 随机前缀+角色尾缀类名(kx7q2_a / ad123_b / iFWjS_a): 前缀每次加载随机、尾缀
    // 稳定 → 整体按易变处理（不进类名/锚点）, 稳定尾缀由 _cssSuffixSelectors 单独出
    // 键。随机特征取 无元音 | 含数字 | 混合大小写 —— 真实广告框架的随机字符集含
    // 元音且常混大小写（仅无元音判定只覆盖约一半真机类名）。
    var _sm = /^([a-z0-9]{4,12})_([a-z0-9]{1,4})$/i.exec(c);
    if (_sm && (!/[aeiou]/i.test(_sm[1]) || /\d/.test(_sm[1]) || (/[a-z]/.test(_sm[1]) && /[A-Z]/.test(_sm[1])))) return true;
    return false;
  }
  function _cssStableClasses(node) {
    var out = [];
    try {
      if (typeof node.className !== 'string') return out;
      var parts = node.className.split(/\s+/);
      for (var i = 0; i < parts.length && out.length < 3; i++) {
        var c = parts[i];
        if (!c || c.length < 2 || !/[A-Za-z]/.test(c)) continue;
        if (_looksVolatileClassName(c)) continue;
        out.push(c);
      }
    } catch (e) {}
    return out;
  }
  function _cssIsStableAnchor(node) {
    if (!node || node.nodeType !== 1) return false;
    if (node.tagName === 'BODY' || node.tagName === 'HTML') return true;
    var id = node.id || '';
    if (id) {
      var nid = _normAnchorId(id);
      if (nid && nid.length >= 3 && !_looksVolatileClassName(nid)) return true;
    }
    return _cssStableClasses(node).length > 0;
  }
  // 锚点选择器: 完整稳定 id → #id 精确; 尾缀数字被归一化剥掉 → [id^="前缀"];
  // 稳定类名最多带 3 个提高特异性; 全无 → null(该层兜底交 body 物理链)
  function _cssAnchorSelector(node) {
    var id = node.id || '';
    var nid = _normAnchorId(id);
    var idPart = '';
    if (nid) {
      idPart = (id === nid)
        ? '#' + _cssEscapeIdent(id)
        : '[id^="' + nid.replace(/[\u0022]/g, '\\"') + '"]';
    }
    var cls = _cssStableClasses(node);
    var clsPart = cls.length ? '.' + cls.map(_cssEscapeIdent).join('.') : '';
    return (idPart + clsPart) || null;
  }
  function _cssNthSeg(node) {
    var tag = (node.tagName || 'div').toLowerCase();
    var n = 1, sib = node.previousElementSibling;
    while (sib) { if (sib.tagName === node.tagName) n++; sib = sib.previousElementSibling; }
    return tag + ':nth-of-type(' + n + ')';
  }
  // 类名/ID 钥匙: div.稳定类（抗结构位移, 元素挪位置不失配） + #完整稳定id;
  // 尾缀数字 id 用 [id^="归一化前缀"] 前缀消化变号（覆盖层锚点同口径）;
  // 随机前缀+稳定尾缀类名整体不进选择器, 尾缀单独出 [class$=] 键。
  // 层上下文(样式表以 fixed/absolute 伪元素定位注入层): 前缀类名/ID 每刷新随机,
  // 进规则即失配 —— 抑制随机前缀类与 id 钥匙, 只留稳定尾缀键, 形态特征方式兜底。
  function _cssNameSelectors(el) {
    var out = [];
    try {
      if (!el || !_isElementLike(el)) return out;
      var tg = (el.tagName || 'div').toLowerCase();
      var _ctx = _cssLayerRuleClass(el);
      var stableCls = [];
      if (_ctx) {
        try {
          if (typeof el.className === 'string') {
            var _parts2 = el.className.split(/\s+/);
            for (var _pc2 = 0; _pc2 < _parts2.length && stableCls.length < 3; _pc2++) {
              var _c3 = _parts2[_pc2];
              if (!_c3 || _c3.length < 2 || !/[A-Za-z]/.test(_c3)) continue;
              if (/^[a-z0-9]{4,12}_[a-z0-9]{1,4}$/i.test(_c3)) continue;
              if (_looksVolatileClassName(_c3)) continue;
              stableCls.push(_c3);
            }
          }
        } catch (e) {}
      } else {
        stableCls = _cssStableClasses(el);
      }
      if (stableCls.length) out.push(tg + '.' + stableCls.map(_cssEscapeIdent).join('.'));
      if (!_ctx) {
        var elId = el.id || '';
        var elNid = _normAnchorId(elId);
        if (elId && elNid && elNid.length >= 3 && !_looksVolatileClassName(elNid)) {
          if (elId === elNid) out.push('#' + _cssEscapeIdent(elId));
          else out.push('[id^="' + elNid.replace(/[\u0022]/g, '\\"') + '"]');
        }
      }
      var _suf = _cssSuffixSelectors(el, _ctx);
      for (var _si = 0; _si < _suf.length; _si++) out.push(_suf[_si]);
      var _idSuf = _cssIdSuffixKeys(el);
      for (var _isi = 0; _isi < _idSuf.length; _isi++) out.push(_idSuf[_isi]);
    } catch (e) {}
    return out;
  }
  // 稳定角色尾缀键: 类名形如"随机前缀_角色尾缀"(kx7q2_a/ad123_b)时, 前缀每次
  // 加载随机、尾缀是广告框架的稳定角色位 → 整体不进类名/锚点, 尾缀单独出
  // [class$="_尾缀"] 键, 前缀旋转不失配; 常规前缀（含元音）类名走稳定类名。
  // 标签不进键: 注入框架宿主标签名同样每刷新随机(kpm/ssn), 带标签必失配。
  // 层上下文(_cssLayerRuleClass 命中)时前缀是否为随机不在话下, 一律发 ——
  // 注入框架前缀可能全大写/含元音(PPEQX), 常规易变判定会漏判。
  function _cssSuffixSelectors(el, _layerHit) {
    var out = [];
    try {
      if (!el || !_isElementLike(el)) return out;
      var clsStr = (typeof el.className === 'string' ? el.className : '').trim();
      if (!clsStr) return out;
      var parts = clsStr.split(/\s+/);
      var last = parts[parts.length - 1];
      var m = /^([a-z0-9]{4,12})_([a-z0-9]{1,4})$/i.exec(last);
      if (!m) return out;
      if (!_layerHit && !_looksVolatileClassName(last)) return out;
      out.push('[class$="_' + m[2] + '"]');
    } catch (e) {}
    return out;
  }
  // id 尾缀键: id 形如"随机前缀_行_列"(fehPF_0_0)的生成网格 —— 前缀/宿主标签每载
  // 重掷, 行列尾缀确定。同前缀群体 >=5 闸门排除站点自身的编号型 id(单个/成对不收)。
  // 发 [id$="_r_c"] 一格一键, 前缀重掷不失配; 与类尾缀键同型, 层上下文同样可用。
  function _cssIdSuffixKeys(el) {
    var out = [];
    try {
      if (!el || !_isElementLike(el)) return out;
      var id = el.id || '';
      var _im = /^([a-zA-Z0-9]{3,12})_(\d{1,4})_(\d{1,4})$/.exec(id);
      if (!_im) return out;
      var _swarm = 0;
      try { _swarm = _document.querySelectorAll('[id^="' + _im[1] + '_"]').length; } catch (e) {}
      if (_swarm < 5) return out;
      out.push('[id$="_' + _im[2] + '_' + _im[3] + '"]');
    } catch (e) {}
    return out;
  }
  // 样式表规则扫描: 在页面 styleSheets 里找"引用该元素类名/ID 且规则体含
  // position:fixed/absolute"的规则(含 :before/:after 伪元素选择器)。注入型
  // 广告层的定位/背景全在样式块、元素自身无内联信号, 以规则扫描(含
  // 伪元素选择器)与计算样式双通道识别; 返回 {cls,pseudo,strong}。
  function _cssLayerRuleClass(el) {
    try {
      var classes = (typeof el.className === 'string' ? el.className : '').split(/\s+/).filter(Boolean);
      var id = el.id || '';
      if (!classes.length && !id) return null;
      var sheets = null;
      try { sheets = _document.styleSheets; } catch (e) {}
      if (!sheets) return null;
      for (var i = 0; i < sheets.length; i++) {
        var rules = null;
        try { rules = sheets[i].cssRules; } catch (e) { continue; }
        if (!rules) continue;
        for (var j = 0; j < rules.length; j++) {
          var r = rules[j];
          if (!r || !r.selectorText) continue;
          var stx = String(r.selectorText);
          var body = String((r.style && r.style.cssText) ? r.style.cssText : (r.cssText || ''));
          if (!/position\s*:\s*(fixed|absolute)/i.test(body)) continue;
          var pm = /:((?:before|after))\b/i.exec(stx);
          var pseudo = pm ? pm[1].toLowerCase() : null;
          var strong = /(z-index\s*:\s*\d{4,})|(?:background(?:-image)?\s*:\s*url)|(opacity\s*:\s*0\b)|(visibility\s*:\s*hidden)/i.test(body);
          for (var k = 0; k < classes.length; k++) {
            var c = classes[k];
            if (!c) continue;
            if (stx.indexOf('.' + c) !== -1) return { cls: c, pseudo: pseudo, strong: strong };
          }
          if (id && stx.indexOf('#' + id) !== -1) return { cls: '', pseudo: pseudo, strong: strong };
        }
      }
    } catch (e) {}
    return null;
  }
  // 样式表定位层形态钥匙: 注入样式块以随机类名(+:before/:after)定位的
  // fixed/absolute 广告层, 元素自身无内联定位信号 → 类名/ID与内联形态全落空。
  // 这里从样式表规则/计算样式确认"层"形态, 产出:
  //   · 稳定角色尾缀键 [class$="_a"] —— 原生 CSS 键（标签不带入: 宿主标签名同样随机）;
  //   · 扩展求值键（轻量引擎）: 默认以尾缀类收窄([class$="_a"]:matches-css-before/after
  //     (position: fixed)); 无稳定尾缀可收窄, 或拾取时勾选「全页同形态」主动放宽为全页层
  //     (*:matches-css-before/after / *:matches-css(position: fixed)),
  //     self 层叠加 z 谓词, 与随机名解耦, 计算样式命中即隐藏。
  // 强信号闸门(避免波及站点自身的 fixed 头/导航): 规则体含高 z-index(≥4位)/
  // background(-image):url/opacity:0/visibility:hidden, 或计算样式 z>1000/
  // opacity 0/背景图 —— 无强信号返回空, 卡片命中数预览兜底。
  function _cssShapeLayerRules(el) {
    var out = [];
    if (!el || !_isElementLike(el)) return out;
    try {
      var kind = null;
      var strong = false;
      var layer = _cssLayerRuleClass(el);
      if (layer) {
        kind = layer.pseudo || 'self';
        strong = !!layer.strong;
      }
      var cs = null;
      try { cs = _globals.getComputedStyle ? _globals.getComputedStyle(el) : getComputedStyle(el); } catch (e) {}
      if (cs) {
        var pos = cs.position || '';
        var zi = parseInt(cs.zIndex, 10) || 0;
        if ((pos === 'fixed' || pos === 'absolute') && (zi > 1000 || cs.opacity === '0' || (cs.backgroundImage && cs.backgroundImage !== 'none'))) {
          if (!kind) kind = 'self';
          strong = true;
        }
      }
      if (!kind || !strong) return out;
      var _suf = _cssSuffixSelectors(el, layer ? true : false);
      for (var i = 0; i < _suf.length; i++) out.push(_suf[i]);
      if (typeof _ExtCss !== 'undefined' && _ExtCss) {
        // 扩展键两档: 有稳定尾缀默认尾缀收窄(命中面只含该尾缀类元素, 误伤风险更低,
        // 且规避全页形态键在持续重建页面引发的全量求值负担); 拾取卡片勾选「全页同
        // 形态」可主动放宽为全页键。无稳定尾缀可收窄时回退全页形态（宽）兜底。
        // 宿主标签名每刷新随机(kpm/ssn), 带标签基底必失配,
        // 故基底只用稳定尾缀类或 *。
        var _wideOpt = typeof ElementCssBlocker !== 'undefined' && !!ElementCssBlocker._pickWideEnable;
        if (_wideOpt || !_suf.length) {
          if (kind === 'before') out.push('*:matches-css-before(position: fixed)');
          else if (kind === 'after') out.push('*:matches-css-after(position: fixed)');
          else {
            var sel = '*:matches-css(position: fixed)';
            if (cs) {
              // z 谓词恒附加(仅当计算出数值 z; z:auto/NaN 不加): 纯 position 单谓词会一次
              // 匹配全站所有 fixed 层（含站点自身顶栏/悬浮条）, 判等 z 后只命中同层级广告
              var zi2 = parseInt(cs.zIndex, 10);
              if (!isNaN(zi2)) sel += ':matches-css(z-index: ' + zi2 + ')';
            }
            out.push(sel);
          }
        } else {
          for (var _si3 = 0; _si3 < _suf.length; _si3++) {
            var _sfx = _suf[_si3];
            if (kind === 'before') out.push(_sfx + ':matches-css-before(position: fixed)');
            else if (kind === 'after') out.push(_sfx + ':matches-css-after(position: fixed)');
            else {
              var sel2 = _sfx + ':matches-css(position: fixed)';
              if (cs) {
                var zi3 = parseInt(cs.zIndex, 10);
                if (!isNaN(zi3)) sel2 += ':matches-css(z-index: ' + zi3 + ')';
              }
              out.push(sel2);
            }
          }
        }
      }
    } catch (e) { _debugCatch(e, '_cssShapeLayerRules'); }
    return out;
  }
  // 物理结构钥匙: 命名锚点+完整物理链（锚点名稳时最准） / body 全物理链（锚点名随机时兜底） /
  // 命名锚点+尾部两级（链中间层级增减时兜底, 链≥3 才发） —— 完全不引用目标自身类名/ID
  function _cssStructSelectors(el) {
    if (!el || !_isElementLike(el)) return [];
    try {
      // 层上下文(样式表以 fixed/absolute 伪元素定位的注入层): 宿主标签/容器 id 每刷新
      // 随机, 物理链必失配, 直接不发结构键 —— 该形态的正解是稳定尾缀键与形态特征规则
      if (_cssLayerRuleClass(el)) return [];
      var anchor = null;
      var node = el.parentElement;
      while (node && node.nodeType === 1 && node !== _document.documentElement) {
        if (node === _document.body) break;
        if (_cssIsStableAnchor(node)) { anchor = node; break; }
        node = node.parentElement;
      }
      var stop = anchor || _document.body;
      var chain = [];
      var n = el;
      while (n && n.nodeType === 1 && n !== stop && chain.length < 30) {
        chain.unshift(_cssNthSeg(n));
        n = n.parentElement;
      }
      if (!chain.length) return [];
      var anchorSel = null, bodyToAnchor = [];
      if (anchor && anchor !== _document.body) {
        anchorSel = _cssAnchorSelector(anchor);
        var m = anchor;
        while (m && m.nodeType === 1 && m !== _document.body && bodyToAnchor.length < 30) {
          bodyToAnchor.unshift(_cssNthSeg(m));
          m = m.parentElement;
        }
      }
      var rel = chain.join(' > ');
      var out = [];
      if (anchorSel) out.push(anchorSel + ' > ' + rel);
      out.push('body' + (bodyToAnchor.length ? ' > ' + bodyToAnchor.join(' > ') : '') + ' > ' + rel);
      if (anchorSel && chain.length >= 3) out.push(anchorSel + ' ' + chain.slice(-2).join(' > '));
      return out;
    } catch (e) { _debugCatch(e, '_cssStructSelectors'); return []; }
  }
  // 形态特征（内联样式片段）钥匙: 面向"类名/ID/结构全随机"的注入层(透明点击劫持层、
  // 跟随页面滑动的 fixed 浮动广告条等)。只取高信号且与顺序/数值解耦的片段
  // (position/opacity/visibility/四边定位/铺满/inset), 每个 [style*=] 独立子串匹配、
  // 彼此是与关系 → 同形态的所有层（含后续新注入的变种）一条规则全中。
  // 【空格写法兼容】页面 style 属性值常带空格(position: fixed), 而 CSS 属性子串
  // 匹配按字面 —— 带空格与紧凑写法都要生成对应片段, 任一命中即隐藏。
  // 现在基于 style 原文（单空格归一）提取片段, 每条渲染两个变体:
  //   A=原文空格版片段（匹配带空格写法）, B=全紧凑版片段（匹配无空格写法）,
  // 任一变体命中即隐藏; 片段保留原文单位(px/vw 等)。
  // 标准 HTML 标签集合: 注入层常用的随机自定义标签不在其中, 形态键基底换为 *(标签逐代
  // 轮换时键仍存活); 标准标签元素基底保持原样不动
  var _CSS_STD_TAGS_RE = /^(div|span|p|a|img|ul|ol|li|br|h1|h2|h3|h4|h5|h6|section|article|header|footer|nav|button|input|form|label|strong|em|b|i|u|font|center|ins|iframe|svg|path|time|small|dl|dt|dd|main|aside|video|source|audio|canvas|textarea|select|option|table|tbody|thead|tr|td|th|figure|figcaption|picture|noscript|style|script|meta|link|body|html|head|title|area|map|object|embed|param|track|wbr|col|colgroup|caption|tfoot|sup|sub|pre|code|blockquote|q|cite|abbr|address|details|summary|dialog|template|slot|del|s|strike|hr|fieldset|legend|datalist|output|progress|meter|ruby|rt|rp|bdi|bdo|var|kbd|samp|dfn|hgroup|search)$/;
  function _cssShapeSelectors(el) {
    if (!el || !_isElementLike(el)) return [];
    try {
      var st = (el.getAttribute && el.getAttribute('style')) || '';
      if (!st || st.length > 1200) {
        // 无内联样式: 转样式表定位层识别（注入样式块以随机类名+伪元素定位的层）
        return st ? [] : _cssShapeLayerRules(el);
      }
      var raw = st.replace(/\s+/g, '').toLowerCase();   // 全紧凑(信号判定 + B 变体)
      var orig = st.replace(/\s+/g, ' ').trim();         // 单空格归一(A 变体)
      var tag = (el.tagName || 'div').toLowerCase();
      if (!_CSS_STD_TAGS_RE.test(tag)) tag = '*';
      if (!(/position:fixed/.test(raw) || /position:absolute/.test(raw))) {
        // 内联存在但无定位信号: 同转样式表定位层识别
        return _cssShapeLayerRules(el);
      }
      var _frag = function (src, prop) {
        // 提取 "prop: 值" 片段（到分号/花括号/引号前）, 保留原文单位(px/vw 等);
        // i 标志: style 大写写法(POSITION:FIXED)也能提取, 选择器端 [style*="..." i] 匹配大小写不敏感
        try {
          var m = new RegExp(prop + '\\s*:\\s*[^;\}\\"\']+', 'i').exec(src);
          return m ? m[0].replace(/\s+/g, ' ').trim() : null;
        } catch (e) { return null; }
      };
      var sigs = [];   // [prop, rawRe]
      // 格群组信号: 带内透明(0<opacity<=0.25)/极端z(>=2147483000)/透明背景 —— 透明点击
      // 格群的群体共享信号, 与逐格坐标解耦。组信号出现时四边坐标片段退出(每格坐标唯一,
      // 入键即一格一规则); 极端z只作触发器不入键(同形变种的z常各不相同, 入键即收窄失配);
      // 剔除坐标后不足两个片段则回退坐标（保底精准键）。
      var _gGroup = false;
      var _opm = /opacity:([0-9.]+)/.exec(raw);
      if (_opm) {
        var _opv = parseFloat(_opm[1]);
        if (_opv === 0) sigs.push(['opacity']);
        else if (_opv > 0 && _opv <= 0.25) { sigs.push(['opacity']); _gGroup = true; }
      } else if (/filter:alpha\(opacity=0/.test(raw)) sigs.push(['alpha']);
      var _zim = /z-index:(\d+)/.exec(raw);
      if (_zim && parseInt(_zim[1], 10) >= 2147483000) _gGroup = true;
      // 透明背景族: 关键字 transparent 与 rgba(0,0,0,α≤0.25) 同族(后者即"阴影感"半透明层,
      // 且与关键字形态逐代轮换), 两者同作组信号
      var _bgFamily = false, _bgm = null;
      var _bgm0 = /(?:^|;)(background-color|background):(transparent|rgba\(0,0,0,([0-9.]+)\))/.exec(raw);
      if (_bgm0 && (_bgm0[3] === undefined || parseFloat(_bgm0[3]) <= 0.25)) {
        _bgFamily = true;
        _bgm = _bgm0;
        sigs.push([_bgm0[1]]);
        _gGroup = true;
      }
      if (/visibility:hidden/.test(raw)) sigs.push(['visibility']);
      if (/left:0/.test(raw)) sigs.push(['left']);
      if (/right:0/.test(raw)) sigs.push(['right']);
      if (/top:0/.test(raw)) sigs.push(['top']);
      if (/bottom:0/.test(raw)) sigs.push(['bottom']);
      if (/inset:0/.test(raw)) sigs.push(['inset']);
      if (/width:100%/.test(raw)) sigs.push(['width']);
      else if (/width:100vw/.test(raw)) sigs.push(['width']);
      if (/height:100%/.test(raw)) sigs.push(['height']);
      else if (/height:100vh/.test(raw)) sigs.push(['height']);
      if (_gGroup) {
        var _kept = [];
        for (var _gi2 = 0; _gi2 < sigs.length; _gi2++) {
          var _gp = sigs[_gi2][0];
          if (_gp === 'left' || _gp === 'right' || _gp === 'top' || _gp === 'bottom' || _gp === 'inset') continue;
          _kept.push(sigs[_gi2]);
        }
        if (_kept.length >= 1) sigs = _kept;
      }
      var fragsA = [_frag(orig, 'position')];
      var fragsB = [_frag(raw, 'position')];
      var _bgRgba = _bgFamily && _bgm[3] !== undefined;
      for (var si = 0; si < sigs.length; si++) {
        var prop = sigs[si][0];
        var fa, fb;
        if (_bgFamily && prop === _bgm[1] && _bgRgba) {
          // rgba 家族发前缀片段: "rgba(0, 0, 0, 0" 覆盖 0/.05/.1 等全部 alpha 轮换
          fa = prop + ': rgba(0, 0, 0, 0';
          fb = prop + ':rgba(0,0,0,0';
        } else {
          fa = _frag(orig, prop) || _frag(raw, prop);
          fb = _frag(raw, prop);
        }
        if (fa) fragsA.push(fa);
        if (fb && fb !== fa) fragsB.push(fb);
      }
      if (fragsA.length < 2) return [];
      var out = [];
      var mkSel = function (frags) {
        return tag + frags.map(function (f) { return '[style*="' + f + '" i]'; }).join('');
      };
      var selA = mkSel(fragsA);
      out.push(selA);
      if (fragsB.length >= 2 && mkSel(fragsB) !== selA) out.push(mkSel(fragsB));
      // 背景轮换备选形态: 把背景片段换成另一形态(关键字↔rgba前缀, 其余片段不变)再发一条
      // 选择器并集 —— 两代之间背景写法轮换时规则仍命中
      if (_bgFamily) {
        var _primBgA = _bgRgba ? (_bgm[1] + ': rgba(0, 0, 0, 0') : _frag(orig, _bgm[1]);
        var _altBgA = _bgRgba ? (_bgm[1] + ': transparent') : (_bgm[1] + ': rgba(0, 0, 0, 0');
        var _primBgB = _bgRgba ? (_bgm[1] + ':rgba(0,0,0,0') : _frag(raw, _bgm[1]);
        var _altBgB = _bgRgba ? (_bgm[1] + ':transparent') : (_bgm[1] + ':rgba(0,0,0,0');
        var _swapFrag = function (frags, primBg, altBg) {
          if (!primBg || !altBg || altBg === primBg) return null;
          var arr = frags.slice();
          for (var fi = 0; fi < arr.length; fi++) {
            if (arr[fi] === primBg) { arr[fi] = altBg; return arr; }
          }
          return null;
        };
        var _altA = _primBgA ? _swapFrag(fragsA, _primBgA, _altBgA) : null;
        if (_altA) {
          var _selAA = mkSel(_altA);
          if (out.indexOf(_selAA) === -1) out.push(_selAA);
        }
        if (fragsB.length >= 2 && _primBgB) {
          var _altB = _swapFrag(fragsB, _primBgB, _altBgB);
          if (_altB) {
            var _selBB = mkSel(_altB);
            if (out.indexOf(_selBB) === -1) out.push(_selBB);
          }
        }
      }
      return out;
    } catch (e) { _debugCatch(e, '_cssShapeSelectors'); return []; }
  }
  // 格群群体识别: 元素的形态键或同前缀 id 网格在页内命中 >=5 即视为生成格群,
  // 返回群体元素列表 —— 供「屏蔽全部」按群体扇出（单格键当轮只中拾取元素本身）
  function _cssShapeSwarmList(el) {
    var out = [];
    try {
      if (!el || !_isElementLike(el)) return out;
      var _cand = null;
      var _cands = _cssShapeSelectors(el);
      for (var i = 0; i < _cands.length; i++) {
        var _els = [];
        try { _els = _document.querySelectorAll(_cands[i]); } catch (e2) {}
        if (_els && _els.length >= 5) { _cand = _els; break; }
      }
      if (!_cand) {
        var _im = /^([a-zA-Z0-9]{3,12})_\d{1,4}_\d{1,4}$/.exec(el.id || '');
        if (_im) {
          try { _cand = _document.querySelectorAll('[id^="' + _im[1] + '_"]'); } catch (e3) {}
          if (_cand && _cand.length < 5) _cand = null;
        }
      }
      if (_cand) for (var j = 0; j < _cand.length && j < 200; j++) out.push(_cand[j]);
    } catch (e) {}
    return out;
  }
  // 键卫生: 引擎隐藏过的元素再拾取时, 本脚本写入的 display/visibility/pointer-events
  // important 隐藏样式会混入 style 原文形态键, 生成前临时剥离这三段(仅 important 段,
  // 站点自身的非 important 隐藏样式保留原样), 提取完恢复原文; 快照-剥离-恢复全程同步,
  // fn 抛错也恢复原文(finally)
  function _cssStripOwnHideStyle(el, fn) {
    var _snap = null, _stripped = false;
    try {
      if (el && _isElementLike(el) && el.style && el.style.getPropertyPriority) {
        var _dd = el.style.getPropertyPriority('display') === 'important';
        var _vv = el.style.getPropertyPriority('visibility') === 'important';
        var _pp = el.style.getPropertyPriority('pointer-events') === 'important';
        if (_dd || _vv || _pp) {
          _snap = el.getAttribute('style');
          if (_dd) el.style.removeProperty('display');
          if (_vv) el.style.removeProperty('visibility');
          if (_pp) el.style.removeProperty('pointer-events');
          _stripped = true;
        }
      }
      return fn(el);
    } finally {
      if (_stripped) {
        try { if (_snap === null || _snap === undefined) el.removeAttribute('style'); else el.setAttribute('style', _snap); } catch (e2) {}
      }
    }
  }
  // 同质校验: 群体元素须与拾取元素同标签 + 同样式信号集（透明度带/透明背景/隐藏/铺满）
  // + 同尺寸档, 才允许组键扇出 —— 防"fixed+width:100%"一类宽组键把页内同形站点元素
  // (头部/悬浮条)连坐隐藏。尺寸档按近全屏/线性尺寸分档; 元素被隐藏（矩形 0）时退回
  // 内联宽高比对, 不可得则不拦（隐藏元素只在真实群体内出现, 从宽不损能力）
  function _cssSwarmSameShape(ref, el) {
    try {
      if (!ref || !el || !_isElementLike(ref) || !_isElementLike(el)) return false;
      if ((ref.tagName || '') !== (el.tagName || '')) return false;
      var _sig = function (n) {
        var st = (n.getAttribute && n.getAttribute('style')) || '';
        if (st.length > 1200) return null;
        var raw = st.replace(/\s+/g, '').toLowerCase();
        if (!/position:fixed/.test(raw) && !/position:absolute/.test(raw)) return null;
        var s = { op: 0, bg: 0, vis: 0, w: 0, h: 0 };
        var _om = /opacity:([0-9.]+)/.exec(raw);
        if (_om) { var _ov = parseFloat(_om[1]); if (_ov === 0) s.op = 1; else if (_ov > 0 && _ov <= 0.25) s.op = 2; }
        // 与形态键生成器同口径: transparent 与 rgba(0,0,0,α≤0.25) 同属透明背景族
        var _bgm = /(?:^|;)(?:background-color|background):(?:transparent|rgba\(0,0,0,([0-9.]+)\))/.exec(raw);
        if (_bgm && (_bgm[1] === undefined || parseFloat(_bgm[1]) <= 0.25)) s.bg = 1;
        if (/visibility:hidden/.test(raw)) s.vis = 1;
        if (/width:100%/.test(raw) || /width:100vw/.test(raw)) s.w = 1;
        if (/height:100%/.test(raw) || /height:100vh/.test(raw)) s.h = 1;
        return s;
      };
      var _ra = _sig(ref), _rb = _sig(el);
      if (!_ra || !_rb) return false;
      if (_ra.op !== _rb.op || _ra.bg !== _rb.bg || _ra.vis !== _rb.vis || _ra.w !== _rb.w || _ra.h !== _rb.h) return false;
      var _bkt = function (n) {
        try {
          var r = n.getBoundingClientRect();
          if (r && (r.width > 0 || r.height > 0)) {
            var vw = _globals.innerWidth || _document.documentElement.clientWidth || 0;
            var vh = _globals.innerHeight || _document.documentElement.clientHeight || 0;
            if (vw > 0 && vh > 0 && r.width >= vw * 0.9 && r.height >= vh * 0.9) return 'full';
            var m = Math.max(r.width, r.height);
            if (m <= 60) return 'xs';
            if (m <= 160) return 's';
            if (m <= 400) return 'm';
            if (m <= 1200) return 'l';
            return 'xl';
          }
          var _wm = /(?:^|;)\s*width\s*:\s*([0-9.]+)/i.exec((n.getAttribute('style') || ''));
          var _hm = /(?:^|;)\s*height\s*:\s*([0-9.]+)/i.exec((n.getAttribute('style') || ''));
          if (_wm && _hm) {
            var _mm = Math.max(parseFloat(_wm[1]), parseFloat(_hm[1]));
            if (_mm <= 60) return 'xs';
            if (_mm <= 160) return 's';
            if (_mm <= 400) return 'm';
            if (_mm <= 1200) return 'l';
            return 'xl';
          }
          return 'zero';
        } catch (e) { return '?'; }
      };
      var _ba = _bkt(ref), _bb = _bkt(el);
      if (_ba === 'zero' || _bb === 'zero' || _ba === '?' || _bb === '?') return true;
      return _ba === _bb;
    } catch (e) { return false; }
  }
  // 组键同质校验: 形态键页内命中 ≥5 且抽样命中元素全部与拾取元素同质, 才允许并入规则
  function _cssSwarmKeyHomogeneous(el, sel) {
    try {
      var _els = _document.querySelectorAll(sel);
      if (!_els || _els.length < 5) return false;
      var _n = Math.min(_els.length, 30);
      for (var i = 0; i < _n; i++) {
        if (!_cssSwarmSameShape(el, _els[i])) return false;
      }
      return true;
    } catch (e) { return false; }
  }
  // 三类钥匙合体(selectors[0] 兼作去重键): 类名/ID → 物理结构
  function _cssStructuralSelectors(el) {
    var out = _cssNameSelectors(el).concat(_cssStructSelectors(el));
    var uniq = [];
    for (var i = 0; i < out.length; i++) { if (uniq.indexOf(out[i]) === -1) uniq.push(out[i]); }
    return uniq;
  }
  // 同族容器检测: 广告位容器(class 常固定, 如 biquge 正文的 ins.adsbygoogle)被 AdSense
  // 类脚本填充随机内容后, 用户点中的是随机内容、类名/ID 全变 → 向上找"页面中重复出现
  // 的同 tag+稳定类祖先", 一键整族屏蔽。返回 {sel, count} 或 null。
  // 保护: ①稳定类过滤（随机名不参与） ②count 2~60 之外不收（太泛/单数无意义）
  // ③祖先容器文本量 >3000 视为正文容器跳过 ④若存在多个候选取"最近且 count 适中"的。
  function _cssFindRepeatContainer(el) {
    if (!el || !_isElementLike(el)) return null;
    try {
      var node = el;
      var best = null;
      for (var depth = 0; node && node.nodeType === 1 && node !== _document.body && node !== _document.documentElement && depth < 6; depth++) {
        var tg = (node.tagName || '').toLowerCase();
        if (!tg) break;
        var cls = _cssStableClasses(node);
        var idPart = '';
        var nid = _normAnchorId(node.id || '');
        if (nid && !_looksVolatileClassName(nid)) idPart = '#' + _cssEscapeIdent(nid);
        var sel = null;
        if (idPart && !cls.length) sel = idPart;
        else if (cls.length) sel = tg + (idPart || '') + '.' + cls.map(_cssEscapeIdent).join('.');
        if (!sel) { node = node.parentElement; continue; }
        if (cls.length && cls.length > 3) { node = node.parentElement; continue; }
        var cnt = 0;
        try { cnt = _document.querySelectorAll(sel).length; } catch (e) {}
        if (cnt >= 2 && cnt <= 60) {
          // 正文容器保护: 文本超 3000 字（章节正文容器）不整族屏蔽
          var txtLen = 0;
          try { txtLen = (node.textContent || '').length; } catch (e) {}
          if (txtLen <= 3000) {
            best = { sel: sel, count: cnt, depth: depth };
            break;
          }
        }
        node = node.parentElement;
      }
      return best;
    } catch (e) { _debugCatch(e, '_cssFindRepeatContainer'); return null; }
  }
  // 扩展选择器判定: 含扩展伪类的选择器无法进原生 CSS 样式表,
  // 扩展求值轨由引擎执行; 无引擎时跳过并在面板标注
  function _cssIsExtSelector(s) {
    if (/:matches-css|-ext-/.test(s)) return true;
    // 其余扩展伪类仍走扩展轨（引擎内按不支持跳过）
    if (/:-abp-has|:contains\(|:has-text\(|:upward\(|:nth-ancestor|:xpath\(|:if(?:-not)?\(/.test(s)) return true;
    // :has()/:not() 为浏览器原生伪类, 无其他扩展伪类时整条走原生样式表轨（样式表规则免疫内联覆盖）
    return false;
  }
  // 提取广告来源第三方域名: 元素自身或子树内媒体/脚本的 src/href/data-src 里
  // 第一个与当前页不同主域的 host —— 供「封杀来源域名」一键屏蔽
  function _cssExtractThirdPartyDomain(el) {
    try {
      if (!el || !_isElementLike(el)) return null;
      var urls = [];
      var own = (el.getAttribute && (el.getAttribute('src') || el.getAttribute('data-src') || el.getAttribute('href'))) || '';
      if (own) urls.push(String(own));
      var kids = el.querySelectorAll ? el.querySelectorAll('img,iframe,video,embed,a,source,script') : [];
      for (var i = 0; i < kids.length && i < 12; i++) {
        var k = kids[i];
        var u = (k.getAttribute && (k.getAttribute('src') || k.getAttribute('data-src') || k.getAttribute('href'))) || k.src || k.href || '';
        if (u) urls.push(String(u));
      }
      var pageHost = _location.hostname || '';
      for (var j = 0; j < urls.length; j++) {
        var u2 = urls[j];
        if (!u2 || u2.indexOf('data:') === 0 || u2.indexOf('blob:') === 0 || u2.indexOf('javascript:') === 0 || u2.indexOf('#') === 0) continue;
        try {
          var host = new _URL(u2, _location.href).hostname;
          if (!host || host === pageHost) continue;
          // 同主域（互为子域名）不算第三方
          if (pageHost && (host.endsWith('.' + pageHost) || pageHost.endsWith('.' + host))) continue;
          return host;
        } catch (e) {}
      }
    } catch (e) {}
    return null;
  }
  function _cssElLabel(el) {
    try {
      var s = (el.tagName || '').toLowerCase();
      if (el.id) s += '#' + el.id;
      var cls = typeof el.className === 'string'
        ? el.className.split(/\s+/).filter(function (c) { return c && c !== 'ab-pick-hl' && c !== '_uh'; }).slice(0, 3).join('.')
        : '';
      if (cls) s += '.' + cls;
      return s.length > 90 ? s.slice(0, 90) + '…' : s;
    } catch (e) { return (el && el.tagName) || '?'; }
  }

  const ElementCssBlocker = {
    _cssVersion: 0,
    _guardTimer: null,
    _picking: false,
    _pickExtEnable: false,   // 「扩展屏蔽」勾选状态: 勾选后保存的规则带槽位锁（泛化隐藏）,
                             // 默认=仅选择器+尾缀收窄扩展键
    _pickWideEnable: false,  // 「全页同形态（宽）」勾选状态: 有稳定尾缀时也发全页形态键（会话级, 默认关;
                             // 持续重建的页面由引擎熔断止损）
    _pickExtDescOpen: false, // 「扩展屏蔽」说明块默认收起, 用户点击按钮才展开
    _pickVariantEnable: false, // 「变体联动」勾选状态: 勾选后保存形态规则时联动派生 absolute/iframe 变体（覆盖广告形态轮换）
    _pickVarDescOpen: false,   // 「变体联动」说明块默认收起
    _pushPrevPT: null,       // 下推让位: 进入拾取前 html 的原 paddingTop(退出精确还原)
    _pushApplied: false,
    _pickHost: null,
    _pickCard: null,
    _pickStyle: null,
    _pickTarget: null,
    _pickSelectors: null,
    _pickModes: null,
    _pickMode: null,
    _pickDomain: null,
    _pickFamily: null,
    _onClick: null,
    _onCtx: null,
    _onDown: null,
    _downX: null,
    _downY: null,
    _pickedIframes: null,
    _iframePierceTimer: null,
    _removalTimer: null,
    _extApplier: null,
    _frameMsgHandler: null,
    _iframeClickListener: null,
    _lastFrameHitAt: 0,
    _lastPickAt: 0,
    _slotMo: null,
    _cssHideMo: null,    // CSS 轨隐藏规则的新增节点观察(滚动解锁用, 无规则断开)
    _cssHideSels: null,
    _slotRules: [],          // 已保存规则里的稳定槽位指纹组(锚点链/去名链/松散链/BODY根链)
    _slotHidden: null,
    _slotMatchMap: null,     // 槽位锁隐藏元素 → {规则id:1}(面板按规则统计槽位锁命中, 免重算几何指纹)
    _removedTotal: {},       // remove/combo 规则运行时累计已移除数（仅面板计数用, 不持久化）
    _removalChurn: {},       // remove/combo 规则连续高删除周期计数（猫鼠限流用, 不持久化）
    _churnHideMap: {},       // 已触发猫鼠限流降级为隐藏的规则（本页内存态, 刷新即恢复）
    _cssCountCache: {},      // 面板计数 500ms 缓存（重渲染不反复全量求值）

    // 重建/摘除样式表: 有规则就生效（无总开关）; 规则空 → 移除并停守卫。
    // 规则按 mode 分流:
    //   remove  = 不注入样式表, 只由移除引擎删除命中元素(免疫内联 important 覆盖)
    //   combo   = 注入样式表(先 CSS 隐藏防闪现) + 移除引擎后台删除
    //   其他     = 仅 CSS 隐藏（原生选择器进样式表; 扩展伪类选择器走扩展求值轨）
    // 变体联动派生: 输入形态选择器数组, 输出派生规则(absolute/fixed 镜像 + iframe 承载版)
    _cssVariantRules: function (sels) {
      var out = [];
      if (!sels || !sels.length) return out;
      var seen = {};
      var now = Date.now();
      for (var i = 0; i < sels.length; i++) {
        var s = String(sels[i] || '').trim();
        if (!/:matches-css/.test(s)) continue;
        if (/:(has|contains|has-text|upward|nth-ancestor|xpath)\(/.test(s)) continue;
        var base = s.replace(/:matches-css(?:-before|-after)?\([^)]*\)/g, '').trim().replace(/[:\s>+~]+$/, '');
        if (!base) continue;
        var preds = [];
        var re = /:matches-css(?:-before|-after)?\(\s*([a-zA-Z-]+)\s*:\s*([^)]*)\)/g;
        var m2;
        while ((m2 = re.exec(s)) !== null) preds.push({ prop: m2[1].trim().toLowerCase(), val: m2[2].trim(), raw: m2[0] });
        if (preds.length <= 1) continue;
        var pos = null;
        for (var p = 0; p < preds.length; p++) { if (preds[p].prop === 'position') { pos = preds[p].val.toLowerCase(); break; } }
        if (pos !== 'fixed' && pos !== 'absolute') continue;
        var rev = pos === 'fixed' ? 'absolute' : 'fixed';
        var parts = [];
        for (var q = 0; q < preds.length; q++) {
          if (preds[q].prop === 'position') parts.push(':matches-css(position: ' + rev + ')');
          else parts.push(preds[q].raw);
        }
        var mirrorSel = base + parts.join('');
        if (mirrorSel === s) continue;
        if (!seen[mirrorSel]) {
          seen[mirrorSel] = 1;
          out.push({ id: 'cssr_' + now.toString(36) + '_' + Math.floor(Math.random() * 1e5).toString(36),
            selectors: [mirrorSel], label: '【变体联动·' + rev + '】', mode: 'shape', slots: null, form: null, createdAt: now });
        }
        if (base === 'div') {
          var iframeSel = 'iframe' + parts.join(''); // iframe 承载版用镜像后的定位(真实全屏广告 iframe 常为 absolute)
          if (!seen[iframeSel]) {
            seen[iframeSel] = 1;
            out.push({ id: 'cssr_' + now.toString(36) + '_' + Math.floor(Math.random() * 1e5).toString(36),
              selectors: [iframeSel], label: '【变体联动·iframe】', mode: 'shape', slots: null, form: null, createdAt: now });
          }
        }
      }
      return out;
    },

    applyCss: function () {
      var rules = currentConfig.elementCssRules || [];
      var existing = null;
      try { existing = _document.querySelector('style[data-ab-css-block]'); } catch (e) {}
      var hasAny = false;
      for (var _r0 = 0; _r0 < rules.length; _r0++) { if (rules[_r0] && rules[_r0].selectors && rules[_r0].selectors.length) { hasAny = true; break; } }
      if (!hasAny) {
        this._cssVersion++;
        if (existing && existing.parentNode) { try { existing.parentNode.removeChild(existing); } catch (e) {} }
        this._stopGuard();
        this.stopRemovalEngine();
        this._disposeExtApply();
        this._syncSlotLock();
        this._syncCssHideGuard();
        return;
      }
      var parts = [];
      var extParts = [];
      var needRemoval = false;
      for (var i = 0; i < rules.length; i++) {
        var r = rules[i];
        if (!r || !r.selectors || !r.selectors.length) continue;
        var rMode = r.mode || '';
        var sels = [];
        var nativeSels = [];
        var hasExt = false;
        for (var j = 0; j < r.selectors.length; j++) {
          var s = String(r.selectors[j]).trim();
          if (!s || s.length >= 2000) continue;
          sels.push(s);
          if (_cssIsExtSelector(s)) { hasExt = true; continue; }
          nativeSels.push(s);
        }
        if (!sels.length) continue;
        if (rMode === 'remove') {
          needRemoval = true;                 // remove: 只删不隐
          continue;
        }
        if (rMode === 'combo') {
          needRemoval = true;                 // combo: 先隐后删
        }
        if (nativeSels.length) {
          parts.push('/*abcss:' + (r.id || i) + '*/' + nativeSels.join(',') +
            '{display:none!important;visibility:hidden!important;pointer-events:none!important}');
        }
        if (hasExt) {
          // 注意: 扩展规则体不带注释（轻量引擎按行解析）
          extParts.push(sels.join(',') +
            '{display:none!important;visibility:hidden!important;pointer-events:none!important}');
        }
      }
      this._cssVersion++;
      var el = existing;
      if (!el) {
        el = _document.createElement('style');
        el.setAttribute('data-ab-css-block', '1');
        el.setAttribute('data-hs', 'true');
        _markSafe(el);
        try { ProcessedElementsCache.markAsProcessed(el); } catch (e) {}
        (_document.head || _document.documentElement).appendChild(el);
      }
      el.textContent = parts.join('\n');
      el.setAttribute('data-v', String(this._cssVersion));
      if (!parts.length) { try { el.parentNode && el.parentNode.removeChild(el); } catch (e) {} }
      this._ensureGuard();
      this._applyExt(extParts);
      if (needRemoval) this.startRemovalEngine();
      else this.stopRemovalEngine();
      this._syncSlotLock();
      this._armGuardForCssHides();
      this._syncCssHideGuard();
    },

    // 扩展求值轨: 含扩展伪类的规则交给轻量引擎(MiniExtendedCss) 以计算样式求值应用;
    // 无引擎时 _ExtCss 为 null, 扩展规则跳过。
    _applyExt: function (extParts) {
      if (!extParts || !extParts.length) { this._disposeExtApply(); return; }
      if (typeof _ExtCss === 'undefined' || !_ExtCss) { this._disposeExtApply(); return; }
      try {
        var sheet = extParts.join('\n');
        if (this._extApplier) {
          try { this._extApplier.dispose(); } catch (e) {}
        }
        this._extApplier = new _ExtCss({ styleSheet: sheet });
        this._extApplier.apply();
      } catch (e) { _debugCatch(e, '_applyExt'); }
    },
    _disposeExtApply: function () {
      if (this._extApplier) {
        try { this._extApplier.dispose(); } catch (e) {}
        this._extApplier = null;
      }
    },

    // ===== 移除引擎: remove/combo 类规则命中元素直接删除(免疫内联 important 覆盖/防复活) =====
    startRemovalEngine: function () {
      if (this._removalTimer) return;
      var self = this;
      var tick = function () {
        self._removalTimer = _setTimeout(tick, 2000);
        try {
          if (!self._removalActive()) { self.stopRemovalEngine(); return; }
          self._flushRemoval();
        } catch (e) {}
      };
      this._removalTimer = _setTimeout(tick, 2000);
    },
    _removalActive: function () {
      var rules = currentConfig.elementCssRules || [];
      for (var i = 0; i < rules.length; i++) {
        var r = rules[i];
        if (r && (r.mode === 'remove' || r.mode === 'combo') && r.selectors && r.selectors.length) return true;
      }
      return false;
    },
    _flushRemoval: function () {
      var rules = currentConfig.elementCssRules || [];
      for (var i = 0; i < rules.length; i++) {
        var r = rules[i];
        if (!r || (r.mode !== 'remove' && r.mode !== 'combo') || !r.selectors || !r.selectors.length) continue;
        var sels = [];
        for (var j = 0; j < r.selectors.length; j++) {
          var s = String(r.selectors[j]).trim();
          if (s && s.length < 2000 && !_cssIsExtSelector(s)) sels.push(s);
        }
        if (!sels.length) continue;
        var hits = null;
        try { hits = _document.querySelectorAll(sels.join(',')); } catch (e) { continue; }
        if (!hits || !hits.length) continue;
        // 猫鼠限流: 已降级规则本页改用隐藏方式(能力等价替换, 停止"删了又建"的 DOM churn)
        if (this._churnHideMap[r.id]) {
          for (var k3 = 0; k3 < hits.length && k3 < 200; k3++) {
            var el3 = hits[k3];
            if (_isSafe(el3)) continue;
            try {
              if (el3.style && el3.style.getPropertyValue('display') !== 'none') {
                el3.style.setProperty('display', 'none', 'important');
                el3.style.setProperty('visibility', 'hidden', 'important');
                el3.style.setProperty('pointer-events', 'none', 'important');
              }
            } catch (e4) {}
          }
          continue;
        }
        var removed = 0;
        for (var k = 0; k < hits.length && removed < 200; k++) {
          var el = hits[k];
          if (_isSafe(el)) continue;
          // 移除的全屏/覆盖层形态元素可能触发站点滚动锁定, 复用覆盖层 ScrollLockGuard 兜底
          try { if (typeof ScrollLockGuard !== 'undefined' && ScrollLockGuard.armForElement) ScrollLockGuard.armForElement(el); } catch (eG) {}
          try { if (el.parentNode) { el.parentNode.removeChild(el); removed++; } } catch (e2) {}
        }
        if (removed > 0) this._removedTotal[r.id] = (this._removedTotal[r.id] || 0) + removed;
        // 猫鼠限流: 连续 3 个周期每周期删除 ≥3 个 = 命中元素在被反复重建（删了又建）,
        // 本页内存降级为隐藏方式并记日记; 用户配置不动, 刷新后恢复原方式
        if (removed >= 3) {
          this._removalChurn[r.id] = (this._removalChurn[r.id] || 0) + 1;
          if (this._removalChurn[r.id] >= 3 && !this._churnHideMap[r.id]) {
            this._churnHideMap[r.id] = true;
            try {
              LogManager.add('elementCssBlock', null, {
                type: 'CSS_REMOVE_DEGRADE',
                detail: '移除规则连续3个周期删除≥3个元素(命中元素被反复重建), 本页自动改为隐藏方式: ' + (r.label || r.id),
              });
            } catch (eL) {}
          }
        } else {
          this._removalChurn[r.id] = 0;
        }
      }
    },
    stopRemovalEngine: function () {
      if (this._removalTimer) { try { _clearTimeout(this._removalTimer); } catch (e) {} this._removalTimer = null; }
      this._removalChurn = {};
      this._churnHideMap = {};
    },
    // 面板计数口径: 静态选择器(querySelectorAll) ∪ 扩展引擎(MiniExtendedCss.query) ∪
    // 该规则槽位指纹锁已隐藏元素 —— 与卡片预览同款分轨 Set 去重, 再加槽位锁命中。
    // 500ms 缓存: 面板重开/删规则后重渲染不反复全量求值（扩展求值与槽位锁遍历在低端机偏贵）。
    _cssRuleCountInfo: function (r) {
      var no = { total: -1, ext: 0, removed: 0 };
      if (!r || !r.selectors || !r.selectors.length) return no;
      var now = Date.now();
      var cache = this._cssCountCache;
      if (cache) {
        var c = cache[r.id];
        if (c && now - c.at < 500) return { total: c.total, ext: c.ext, removed: c.removed };
      }
      var nat = [], ext = [];
      for (var i = 0; i < r.selectors.length; i++) {
        var s = String(r.selectors[i] || '').trim();
        if (!s || s.length >= 2000) continue;
        if (_cssIsExtSelector(s)) ext.push(s); else nat.push(s);
      }
      var seen = null;
      try { seen = new Set(); } catch (e) {}
      var natOk = false, extOk = false;
      if (nat.length) {
        try {
          var nl = _document.querySelectorAll(nat.join(','));
          for (var j = 0; j < nl.length; j++) { if (seen) seen.add(nl[j]); }
          natOk = true;
        } catch (e) { natOk = false; }
      } else { natOk = true; }
      var extN = 0;
      if (ext.length) {
        if (typeof _ExtCss !== 'undefined' && _ExtCss) {
          try {
            var el2 = _ExtCss.query(ext.join(','));
            for (var k = 0; k < (el2 ? el2.length : 0); k++) { if (seen) seen.add(el2[k]); extN++; }
            extOk = true;
          } catch (e) { extOk = false; }
        } else { extOk = true; }   // B2 无扩展引擎: 扩展选择器不参与计数, 不视为异常
      } else { extOk = true; }
      var slotN = 0;
      if (r.slots && r.slots.length && this._slotMatchMap) {
        try {
          var locked = _document.querySelectorAll('[data-ab-slotlock]');
          for (var m = 0; m < locked.length; m++) {
            var ids = this._slotMatchMap.get(locked[m]);
            if (ids && ids[r.id]) { if (seen) seen.add(locked[m]); slotN++; }
          }
        } catch (e) {}
      }
      var total = (natOk && extOk) ? (seen ? seen.size : 0) : -1;
      var rem = (this._removedTotal && this._removedTotal[r.id]) || 0;
      if (!cache) { try { this._cssCountCache = {}; cache = this._cssCountCache; } catch (e) {} }
      if (cache) {
        if (!cache.__n) cache.__n = 0;
        if (!cache[r.id]) { cache.__n++; if (cache.__n > 512) { var ck; for (ck in cache) { if (ck !== '__n') delete cache[ck]; } cache.__n = 0; } }
        cache[r.id] = { at: now, total: total, ext: extN, removed: rem };
      }
      return { total: total, ext: extN, removed: rem };
    },

    // ===== 运行时槽位锁死: 覆盖层"加白识别变体"的反向 —— 保存标记时把被标记元素的
    // 稳定槽位指纹组(命名锚点链/去名链/松散链/BODY根链, 同 _overlayStableSlots)记进
    // 规则; 之后对新插入节点做廉价闸门, 命中任一槽位钥匙且未加白 → 立即隐藏。
    // 广告每次加载随机改名/换容器/结构漂移重建, 只要落在大致相同的槽位就能再认出。
    _syncSlotLock: function () {
      var rules = currentConfig.elementCssRules || [];
      var slotRules = [];
      for (var i = 0; i < rules.length; i++) {
        var r = rules[i];
        if (r && r.slots && r.slots.length) slotRules.push({ id: r.id, slots: r.slots, form: r.form || null });
      }
      this._slotRules = slotRules;
      if (!slotRules.length) {
        if (this._slotMo) { try { this._slotMo.disconnect(); } catch (e) {} this._slotMo = null; }
        this._slotHidden = null;
        this._slotMatchMap = null;
        this._slotRestoreAll();
        return;
      }
      if (!this._slotHidden) this._slotHidden = new WeakSet();
      if (!this._slotMatchMap) this._slotMatchMap = new WeakMap();
      if (!this._slotMo) {
        var self = this;
        this._slotMo = new MutationObserver(function (muts) {
          try {
            for (var m = 0; m < muts.length; m++) {
              var nodes = muts[m].addedNodes;
              for (var n = 0; n < nodes.length; n++) {
                var node = nodes[n];
                if (!node || node.nodeType !== 1) continue;
                self._slotTry(node);
                // 深扫新增容器子元素（限界防抖）: 广告重建常整体包进新容器, 顶层节点指纹
                // 不命中时子树内的命中元素仍需检查（横幅图/内嵌层）; 形态闸门已防文档误锁
                if (node.querySelectorAll) {
                  try {
                    var _sub = node.querySelectorAll('*');
                    for (var k2 = 0; k2 < _sub.length && k2 < 200; k2++) self._slotTry(_sub[k2]);
                  } catch (e) {}
                }
              }
            }
          } catch (e) {}
        });
        try { this._slotMo.observe(_document.documentElement, { childList: true, subtree: true }); } catch (e) {}
      }
      // 保存后立即扫一遍廉价候选, 把"保存时已存在的同槽位重建变体"也锁住
      var cands = this._slotCandidates();
      for (var c = 0; c < cands.length; c++) this._slotTry(cands[c]);
    },
    // 廉价候选闸门（不做布局读取）: fixed/absolute 内联、高 z-index、含媒体元素、
    // 带 class/id 的容器、IMG/IFRAME 本体、随机前缀+尾缀类名 —— 命中才往下算指纹
    _slotCandidates: function () {
      var out = [];
      if (!_document.querySelectorAll) return out;
      try {
        // 原生引擎廉价预筛: 只把含门内信号(内联定位/inline z-index/下划线类/媒体本体)的
        // 元素交给 JS 再判 gate, 不做全 DOM 的 div/span/a 大枚举 + 逐节点 subtree 查询
        // (真机大页面/低端机上那是每次 applyCss 的卡顿源; _slotGate 判定仍逐条完整保留)
        var all = _document.querySelectorAll('[style*="position"], [style*="z-index"], [class*="_"], img[src], img[data-src], iframe[src], iframe[srcdoc]');
        for (var i = 0; i < all.length; i++) {
          var el = all[i];
          if (this._slotGate(el)) out.push(el);
        }
      } catch (e) {}
      return out;
    },
    _slotGate: function (el) {
      try {
        if (!el || el.nodeType !== 1) return false;
        var tg = (el.tagName || '').toUpperCase();
        if (tg === 'SCRIPT' || tg === 'STYLE' || tg === 'LINK' || tg === 'META' || tg === 'NOSCRIPT' || tg === 'HTML' || tg === 'BODY') return false;
        var sty = (el.style && el.style.cssText) || (el.getAttribute && (el.getAttribute('style') || '')) || '';
        if (/(^|;)\s*(position\s*:\s*(fixed|absolute)|z-index\s*:\s*\d{4,})/i.test(sty)) return true;
        var cls = (typeof el.className === 'string') ? el.className.trim() : '';
        if (cls) {
          var last = cls.split(/\s+/).pop();
          if (/^[A-Za-z0-9]{3,15}_[A-Za-z0-9]{1,4}$/.test(last)) return true;
        }
        if (tg === 'IMG' || tg === 'IFRAME') {
          var s = el.getAttribute('src') || el.getAttribute('data-src') || el.getAttribute('srcdoc') || '';
          if (s) return true;
        }
        try { if (el.querySelector && el.querySelector('img,iframe,video,embed,object')) return true; } catch (e) {}
      } catch (e) {}
      return false;
    },
    // 形态签名（廉价, 不读计算样式/零回流）: tag|定位类型(内联0无/1absolute/2fixed)|z量级
    // (内联0无/1>阈值/2>10000)|文本类（0短≤40/1长）|媒体(自身或子树含 img/iframe/video 等)
    // 槽位锁死比对用: 广告重建变体随机改名但形态不变 → 命中锁定; 评论区条目/正文容器/
    // 站点头部/悬浮条等文档元素至少一个维度不同（长文本/静态流/含图/标签不同） → 不误锁。
    _slotFormSig: function (el) {
      try {
        var st = (el.style && el.style.cssText) || (el.getAttribute && (el.getAttribute('style') || '')) || '';
        var pos = 0, z = 0;
        if (st) {
          var pm = /(?:^|;)\s*position\s*:\s*(fixed|absolute)/i.exec(st);
          if (pm) pos = pm[1].toLowerCase() === 'fixed' ? 2 : 1;
          var zm = /(?:^|;)\s*z-index\s*:\s*(\d+)/i.exec(st);
          if (zm) {
            var zi = parseInt(zm[1], 10) || 0;
            z = zi > 10000 ? 2 : (zi > CONFIG.ZINDEX_HIDE_THRESHOLD ? 1 : 0);
          }
        }
        var tx = 0;
        try { tx = (el.textContent || '').replace(/\s+/g, '').length > 40 ? 1 : 0; } catch (e) {}
        var m = 0;
        var _tg = (el.tagName || '').toUpperCase();
        if (_tg === 'IMG' || _tg === 'IFRAME' || _tg === 'VIDEO' || _tg === 'AUDIO' || _tg === 'EMBED' || _tg === 'OBJECT') m = 1;
        else if (el.querySelector) { try { if (el.querySelector('img,iframe,video,audio,embed,object')) m = 1; } catch (e) {} }
        return _tg + '|' + pos + '|' + z + '|' + tx + '|' + m;
      } catch (e) { return ''; }
    },
    // 单节点槽位比对: 指纹组命中且未加白 → 隐藏并记录
    _slotTry: function (el) {
      try {
        if (!el || el.nodeType !== 1) return;
        if (this._slotHidden && this._slotHidden.has(el)) return;
        if (_isSafe(el)) return;
        if (_hasSafeAncestor(el)) return;   // 脚本自身 UI(标记器/面板宿主已 markSafe)内部节点绝不锁
        // 槽位比对先行（纯字符串, 零布局/零祖先遍历）: 绝大多数新增节点在此退出。
        // 白名单否决与形态签名只在"真命中槽位"后才运行, 命中后否决仍先于隐藏,
        // 未命中槽位的元素本就永远不会被锁, 结果保持不变。
        var slots = _overlayStableSlots(el);
        if (!slots || !slots.length) return;
        var rules = this._slotRules || [];
        var hitIds = null;
        var _myForm = null;
        for (var r = 0; r < rules.length; r++) {
          var rs = rules[r];
          var hitR = false;
          for (var k = 0; k < rs.slots.length && !hitR; k++) {
            if (slots.indexOf(rs.slots[k]) !== -1) hitR = true;
          }
          if (hitR) {
            // 形态一致性硬闸门: 槽位指纹命中且形态与保存时一致才锁 —— 广告重建变体随机
            // 改名但形态不变(定位/z量级/文本类/媒体), 而评论区/正文/站点头部等文档元素
            // 至少一个形态维度不同（长文本/静态流/含图/标签不同） → 绝不误锁。
            // 形态签名懒化: 只在带 form 闸门的规则命中后才计算（多数候选不算）;
            // 签名算不出（空串）时保持原有语义 —— 不设限, 照锁
            if (rs.form) {
              if (_myForm === null) _myForm = this._slotFormSig ? (this._slotFormSig(el) || '') : '';
              if (_myForm && rs.form !== _myForm) continue;
            }
            if (!hitIds) hitIds = {};
            hitIds[rs.id] = 1;
          }
        }
        if (!hitIds) return;
        // 白名单否决放到命中后: slots 已算好, 透传避免 `_overlayStableSlots` 第二次祖先遍历
        if (typeof isOverlayWhitelistedForElement === 'function' && isOverlayWhitelistedForElement(el, slots)) return;
        if (this._slotHidden) this._slotHidden.add(el);
        if (this._slotMatchMap) this._slotMatchMap.set(el, hitIds);
        el.classList.add('_uh');
        el.setAttribute('data-ab-slotlock', '1');
        el.style.setProperty('display', 'none', 'important');
        el.style.setProperty('visibility', 'hidden', 'important');
        el.style.setProperty('pointer-events', 'none', 'important');
        // 槽位锁隐藏的覆盖层形态元素可能触发站点滚动锁定, 复用覆盖层 ScrollLockGuard 兜底
        try { if (typeof ScrollLockGuard !== 'undefined' && ScrollLockGuard.armForElement) ScrollLockGuard.armForElement(el); } catch (eG) {}
      } catch (e) { _debugCatch(e, '_slotTry'); }
    },
    // 规则清空/删除时恢复所有被槽位锁隐藏的元素（与面板"删除即恢复"一致）
    _slotRestoreAll: function () {
      try {
        var els = _document.querySelectorAll('[data-ab-slotlock]');
        for (var i = 0; i < els.length; i++) {
          var el = els[i];
          try {
            if (this._slotMatchMap) this._slotMatchMap.delete(el);
            el.removeAttribute('data-ab-slotlock');
            if (el.classList) el.classList.remove('_uh');
            if (el.style) {
              el.style.removeProperty('display');
              el.style.removeProperty('visibility');
              el.style.removeProperty('pointer-events');
            }
          } catch (e2) {}
        }
      } catch (e) {}
    },

    // 防删守卫: 广告脚本把样式表删掉/清空(data-v 失配) → 自动重建
    _ensureGuard: function () {
      if (this._guardTimer) return;
      var self = this;
      var tick = function () {
        self._guardTimer = _setTimeout(tick, 3000);
        try {
          if (!(currentConfig.elementCssRules || []).length) {
            self._stopGuard();
            return;
          }
          var el = _document.querySelector('style[data-ab-css-block]');
          if (!el || !el.parentNode || el.getAttribute('data-v') !== String(self._cssVersion)) {
            self.applyCss();
          }
        } catch (e) {}
      };
      this._guardTimer = _setTimeout(tick, 3000);
    },
    _stopGuard: function () {
      if (this._guardTimer) {
        try { _clearTimeout(this._guardTimer); } catch (e) {}
        this._guardTimer = null;
      }
    },

    // ===== 滚动解锁: CSS 轨隐藏的覆盖层同样触发 ScrollLockGuard =====
    // 样式表轨(applyCss)隐藏元素不经 JS 隐藏路径, 而广告脚本注入的 html/body
    // overflow 锁滚需要守卫解除; 此处对规则命中元素补一次 overlay 判定并 arm,
    // 使标记屏蔽规则在刷新后与保存/移除/槽位锁路径行为一致 —— 只解锁、
    // 不隐藏、不加白、不记日记; 无规则时零开销。
    _armGuardForCssHides: function () {
      try {
        if (typeof ScrollLockGuard === 'undefined' || !ScrollLockGuard.armForElement) return;
        var rules = currentConfig.elementCssRules || [];
        var done = 0;
        for (var i = 0; i < rules.length && done < 50; i++) {
          var r = rules[i];
          if (!r || !r.selectors || !r.selectors.length) continue;
          var nat = [];
          var ext = [];
          for (var j = 0; j < r.selectors.length; j++) {
            var s = String(r.selectors[j]).trim();
            if (!s || s.length >= 2000) continue;
            if (_cssIsExtSelector(s)) ext.push(s);
            else nat.push(s);
          }
          var els = [];
          if (nat.length) {
            try {
              var nl = _document.querySelectorAll(nat.join(','));
              for (var n0 = 0; n0 < nl.length; n0++) els.push(nl[n0]);
            } catch (e) {}
          }
          if (ext.length && typeof _ExtCss !== 'undefined' && _ExtCss && _ExtCss.query) {
            try {
              var ex = _ExtCss.query(ext.join(','));
              for (var e0 = 0; e0 < ex.length; e0++) { if (els.indexOf(ex[e0]) === -1) els.push(ex[e0]); }
            } catch (e2) {}
          }
          if (!els.length) continue;
          for (var k = 0; k < els.length && done < 50; k++) {
            var el = els[k];
            if (!el || _isSafe(el)) continue;
            try { ScrollLockGuard.armForElement(el); } catch (e3) {}
            done++;
          }
        }
      } catch (e) { _debugCatch(e, 'css-hide guard arm'); }
    },
    // CSS 轨隐藏规则的新增节点观察: 规则应用时广告层可能尚未注入(刷新后由站点脚本
    // 后插入), 对新增元素节点按规则选择器自身匹配, 命中即 arm —— 补"规则早、广告晚"
    // 的时序; 只监听 childList, 不做子树深扫与计算样式; 隐藏规则清空即断开, 零持续开销
    _syncCssHideGuard: function () {
      var rules = currentConfig.elementCssRules || [];
      var natSels = [];
      for (var i = 0; i < rules.length; i++) {
        var r = rules[i];
        if (!r || !r.selectors || !r.selectors.length) continue;
        if (r.mode === 'remove' || r.mode === 'combo') continue;   // 移除轨已自行 arm
        for (var j = 0; j < r.selectors.length; j++) {
          var s = String(r.selectors[j]).trim();
          if (!s || s.length >= 2000 || _cssIsExtSelector(s)) continue;
          if (natSels.indexOf(s) === -1) natSels.push(s);
        }
      }
      var selStr = natSels.join(',');
      if (!selStr) {
        if (this._cssHideMo) {
          try { this._cssHideMo.disconnect(); } catch (e) {}
          this._cssHideMo = null;
          this._cssHideSels = null;
        }
        return;
      }
      if (this._cssHideSels !== selStr) {
        if (this._cssHideMo) { try { this._cssHideMo.disconnect(); } catch (e) {} this._cssHideMo = null; }
        this._cssHideSels = selStr;
      }
      if (!this._cssHideMo) {
        var self = this;
        this._cssHideMo = new MutationObserver(function (muts) {
          try {
            var armed = 0;
            for (var mm = 0; mm < muts.length; mm++) {
              var added = muts[mm].addedNodes;
              for (var n = 0; n < added.length; n++) {
                var node = added[n];
                if (!node || node.nodeType !== 1) continue;
                var tg = (node.tagName || '').toUpperCase();
                if (tg === 'SCRIPT' || tg === 'STYLE' || tg === 'LINK' || tg === 'META' || tg === 'NOSCRIPT' || tg === 'BR' || tg === 'HR' || tg === 'HTML' || tg === 'BODY') continue;
                if (_isSafe(node)) continue;
                // 廉价预筛: 无 class/id/内联样式的普通元素不可能是覆盖层广告
                var hasSig = false;
                try {
                  hasSig = !!(node.getAttribute && (node.getAttribute('class') || node.getAttribute('id') || node.getAttribute('style')));
                } catch (e) {}
                if (!hasSig && tg !== 'IMG' && tg !== 'IFRAME' && tg !== 'VIDEO' && tg !== 'EMBED' && tg !== 'OBJECT') continue;
                try {
                  if (node.matches && node.matches(selStr)) {
                    ScrollLockGuard.armForElement(node);
                    if (++armed >= 10) return;
                  }
                } catch (e) {}
              }
            }
          } catch (e) {}
        });
        try { this._cssHideMo.observe(_document.documentElement, { childList: true, subtree: true }); } catch (e) {}
      }
    },

    // 下推让位: 拾取期间给 html 加 padding-top(=面板实高), 正文整体让位到面板下方,
    // 面板让位不覆盖页面顶部内容; 退出时精确还原原值。每次卡片渲染/屏幕变化后同步。
    _pickPushSync: function () {
      try {
        var de = _document.documentElement;
        if (!de || !this._pickHost) return;
        if (this._pushPrevPT === null && de.style) {
          this._pushPrevPT = de.style.getPropertyValue('padding-top');
        }
        var h = this._pickHost.offsetHeight || 0;
        if (h > 0 && de.style) {
          de.style.setProperty('padding-top', h + 'px', 'important');
          this._pushApplied = true;
        }
      } catch (e) { _debugCatch(e, 'pickPush'); }
    },
    _pickPushRestore: function () {
      try {
        var de = _document.documentElement;
        if (de && this._pushApplied && de.style) {
          if (this._pushPrevPT) de.style.setProperty('padding-top', this._pushPrevPT);
          else de.style.removeProperty('padding-top');
        }
      } catch (e) { _debugCatch(e, 'pickPushRestore'); }
      this._pushPrevPT = null;
      this._pushApplied = false;
    },

    startPicking: function () {
      if (this._picking) return;
      this._picking = true;
      this._pickExtEnable = false;   // 每次拾取会话默认普通屏蔽, 要泛化由用户勾选
      this._pickExtDescOpen = false;  // 说明默认收起, 点击「查看说明」展开
      this._pickVariantEnable = false;  // 每次拾取会话默认不联动, 要联动由用户勾选
      this._pickWideEnable = false;  // 每次拾取会话默认收窄, 要全页形态由用户勾选
      this._pickVarDescOpen = false;    // 变体说明默认收起
      // 拾取期挂起扩展引擎: 宽形态规则不干预拾取期间的页面显示（所见即真实布局）,
      // 面板自身也不会被自家规则藏掉; 退出拾取时 applyCss 幂等恢复
      try { if (this._extApplier) { this._extApplier.dispose(); this._extApplier = null; } } catch (eS) { _debugCatch(eS, 'pick suspend ext'); }
      var self = this;
      this._pickStyle = _document.createElement('style');
      this._pickStyle.setAttribute('data-ab-csspick-style', '1');
      this._pickStyle.setAttribute('data-hs', 'true');
      this._pickStyle.textContent =
        '.ab-pick-hl{outline:3px solid #ff3b30!important;outline-offset:-3px!important;' +
        'background-color:rgba(255,59,48,.12)!important;cursor:crosshair!important}';
      _markSafe(this._pickStyle);
      _document.documentElement.appendChild(this._pickStyle);
      var host = _document.createElement('div');
      host.setAttribute('data-ab-csspick', '1');
      host.setAttribute('data-hs', 'true');
      _markSafe(host);
      try { ProcessedElementsCache.markAsProcessed(host); } catch (e) {}
      host.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;' +
        'font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;';
      host.style.setProperty('z-index', '2147483647', 'important');
      host.innerHTML = [
        '<div style="background:rgba(20,20,20,.92);color:#fff;padding:8px 12px;font-size:13px;display:flex;align-items:center;gap:8px;">',
          '<span style="flex:1;">🎯 点击要屏蔽的元素（选小了可点"选父级"）</span>',
          '<button type="button" data-pick-act="exit" style="border:none;background:rgba(255,59,48,.9);color:#fff;border-radius:6px;padding:4px 10px;font-size:12px;">退出</button>',
        '</div>',
        '<div data-pick-card="1" style="display:none;background:#fff;color:#222;border-top:1px solid #eee;padding:10px 12px;font-size:12px;box-shadow:0 -4px 16px rgba(0,0,0,.15);"></div>'
      ].join('');
      _document.documentElement.appendChild(host);
      this._pickHost = host;
      this._pickCard = host.querySelector('[data-pick-card]');
      if (this._pickCard) { _markSafe(this._pickCard); try { ProcessedElementsCache.markAsProcessed(this._pickCard); } catch (e) {} }
      this._pickPushSync();
      host.addEventListener('click', function (e) {
        e.stopPropagation();
        var modeBtn = e.target.closest ? e.target.closest('button[data-pick-mode]') : null;
        if (modeBtn) {
          var mk = modeBtn.getAttribute('data-pick-mode');
          if (self._pickModes && self._pickModes[mk] && self._pickModes[mk].length) {
            self._pickMode = mk;
            self._renderPickCard();
          }
          return;
        }
        var btn = e.target.closest ? e.target.closest('button[data-pick-act]') : null;
        if (!btn) return;
        var act = btn.getAttribute('data-pick-act');
        if (act === 'exit') self._exitPicking();
        else if (act === 'save') self._savePicked('hidden');
        else if (act === 'remove') self._savePicked('remove');
        else if (act === 'combo') self._savePicked('combo');
        else if (act === 'saveAll') self._saveAllPicked();
        else if (act === 'swarm') self._saveSwarmPicked();
        else if (act === 'domain') self._saveDomainKill();
        else if (act === 'family') self._saveFamilyPicked();
        else if (act === 'parent') {
          var p = self._pickTarget && self._pickTarget.parentElement;
          if (p && p !== _document.body && p !== _document.documentElement) self._selectPickTarget(p);
        }
      }, true);
      // 卡片「扩展屏蔽」勾选/说明: 勾选状态经 change 同步; 感叹号点击展开说明
      host.addEventListener('change', function (e) {
        try {
          if (e.target && e.target.matches && e.target.matches('[data-pick-ext]')) {
            self._pickExtEnable = !!e.target.checked;
          }
          if (e.target && e.target.matches && e.target.matches('[data-pick-var]')) {
            self._pickVariantEnable = !!e.target.checked;
          }
          if (e.target && e.target.matches && e.target.matches('[data-pick-wide]')) {
            self._pickWideEnable = !!e.target.checked;
            try {
              if (self._pickTarget && self._pickModes) {
                self._pickModes.shape = _cssStripOwnHideStyle(self._pickTarget, _cssShapeSelectors);
              }
            } catch (e3) {}
            self._renderPickCard();
          }
        } catch (e2) {}
      }, true);
      host.addEventListener('click', function (e) {
        try {
          var infoBtn = e.target.closest ? e.target.closest('[data-pick-ext-info]') : null;
          if (infoBtn) {
            e.preventDefault();
            self._pickExtDescOpen = !self._pickExtDescOpen;
            var _desc = self._pickCard && self._pickCard.querySelector('[data-pick-ext-desc]');
            if (_desc) _desc.style.display = self._pickExtDescOpen ? 'block' : 'none';
            if (infoBtn.tagName === 'BUTTON') {
              infoBtn.textContent = self._pickExtDescOpen ? '收起扩展屏蔽说明 ▲' : 'ⓘ 查看扩展屏蔽说明 ▼';
            }
            return;
          }
          var varBtn = e.target.closest ? e.target.closest('[data-pick-var-info]') : null;
          if (varBtn) {
            e.preventDefault();
            self._pickVarDescOpen = !self._pickVarDescOpen;
            var _vdesc = self._pickCard && self._pickCard.querySelector('[data-pick-var-desc]');
            if (_vdesc) _vdesc.style.display = self._pickVarDescOpen ? 'block' : 'none';
            if (varBtn.tagName === 'BUTTON') {
              varBtn.textContent = self._pickVarDescOpen ? '收起变体联动说明 ▲' : 'ⓘ 查看变体联动说明 ▼';
            }
            return;
          }
        } catch (e3) {}
      }, true);
      // 触摸设备: 部分广告在 touchstart 阶段抢跳/吞掉合成 click(点击劫持层),
      // 只有 pointerup/touchend 到达 → 与 click 同口径在这两个事件上也选中;
      // 同一手势 pointerup/touchend/click 会连发, 300ms 手势窗口去重。
      var _pickFromEvent = function (e) {
        try {
          if (e.target && e.target.closest && e.target.closest('[data-ab-csspick]')) return;
          // 滑动手势(起止位移>=10px)视为滚动: 放行不选中; 轻点才拦截选中
          var _ex = e, _dx = 0, _dy = 0;
          try {
            if (e.changedTouches && e.changedTouches[0]) _ex = e.changedTouches[0];
            _dx = Math.abs((typeof _ex.clientX === 'number' ? _ex.clientX : 0) - (self._downX != null ? self._downX : 0));
            _dy = Math.abs((typeof _ex.clientY === 'number' ? _ex.clientY : 0) - (self._downY != null ? self._downY : 0));
          } catch (e2) {}
          if (self._downX !== null && (_dx >= 10 || _dy >= 10)) return;
          // 拦截必须先于去重: 同手势 touchend 选中后, 浏览器随后合成的 click 若放行,
          // 页面自身 click 委托(如"下载APP"跳转类)会照常触发 —— 重复事件同样掐断。
          e.preventDefault();
          e.stopPropagation();
          if (e.stopImmediatePropagation) { try { e.stopImmediatePropagation(); } catch (e3) {} }
          if (self._lastPickAt && Date.now() - self._lastPickAt < 300) return;
          var el = e.target;
          if (!el || _isSafe(el) || el === _document.documentElement) return;
          if (el === _document.body) { self._selectPickTarget(null); return; }
          var tg = (el.tagName || '').toUpperCase();
          if (tg === 'SCRIPT' || tg === 'STYLE' || tg === 'LINK' || tg === 'META' || tg === 'NOSCRIPT') return;
          self._lastPickAt = Date.now();
          self._selectPickTarget(el);
          self._downX = null; self._downY = null;
        } catch (err) { _debugCatch(err, 'csspick pick'); }
      };
      this._onClick = _pickFromEvent;
      this._onUp = _pickFromEvent;
      this._onCtx = function (e) { e.preventDefault(); };
      // 广告脚本常用 mousedown/touchstart 阶段提前跳转(点击还没到 click 事件页面就跑了)。
      // 防跳转但不能误伤标记本身:
      //   · down 阶段(mousedown/touchstart/pointerdown)一律不 preventDefault —— 触摸设备上
      //     compat mousedown/down 被 preventDefault 可能阻止 click 合成导致"选不中";
      //   · 只记录起止坐标供 click 时判滑动(位移<10px 才算点击);
      //   · 仍 stopPropagation 断掉广告 bubble 阶段的 down 抢跳转(不 preventDefault 不动
      //     浏览器默认, 即不锁滚动、不吞 click)。
      this._onDown = function (e) {
        try {
          var tg = e.target;
          if (tg && tg.closest && tg.closest('[data-ab-csspick]')) return;
          var _p = e;
          try { if (e.touches && e.touches[0]) _p = e.touches[0]; } catch (e2) {}
          self._downX = (typeof _p.clientX === 'number') ? _p.clientX : null;
          self._downY = (typeof _p.clientY === 'number') ? _p.clientY : null;
          e.stopPropagation();
        } catch (err) {}
      };
      _document.addEventListener('mousedown', this._onDown, true);
      _document.addEventListener('pointerdown', this._onDown, true);
      _document.addEventListener('touchstart', this._onDown, { capture: true, passive: false });
      _document.addEventListener('click', this._onClick, true);
      _document.addEventListener('pointerup', this._onUp, true);
      _document.addEventListener('touchend', this._onUp, { capture: true, passive: false });
      _document.addEventListener('contextmenu', this._onCtx, true);
      this._startFrameBridge();
      this._enableIframePierce();
    },

    // iframe 穿透: 标记模式期间所有 iframe/frame 置
    // pointer-events:none(保存原值), 顶层点击穿透 iframe 落到宿主/下层元素 ——
    // 联盟广告常装进跨域 iframe, 顶层事件收不到内部点击, 穿透后可选中宿主。
    // 动态新增的 iframe 由 2s 定时补扫; 退出标记模式恢复全部原值。
    _enableIframePierce: function () {
      this._pickedIframes = [];
      var self = this;
      var apply = function () {
        try {
          var ifs = _document.querySelectorAll('iframe, frame');
          for (var i = 0; i < ifs.length; i++) {
            var f = ifs[i];
            if (self._pickedIframes.indexOf(f) !== -1) continue;
            var orig = '';
            try { orig = (f.style && f.style.getPropertyValue('pointer-events')) || ''; } catch (e3) {}
            self._pickedIframes.push({ el: f, orig: orig });
            try { f.style.setProperty('pointer-events', 'none', 'important'); } catch (e3) {}
          }
        } catch (e) {}
      };
      apply();
      this._iframePierceTimer = _setTimeout(function tick() {
        if (!self._picking) { self._iframePierceTimer = null; return; }
        apply();
        self._iframePierceTimer = _setTimeout(tick, 2000);
      }, 2000);
    },
    _disableIframePierce: function () {
      if (this._iframePierceTimer) { try { _clearTimeout(this._iframePierceTimer); } catch (e) {} this._iframePierceTimer = null; }
      var arr = this._pickedIframes || [];
      for (var i = 0; i < arr.length; i++) {
        try {
          var f = arr[i];
          if (f.el && f.el.style) {
            if (f.orig) f.el.style.setProperty('pointer-events', f.orig, 'important');
            else f.el.style.removeProperty('pointer-events');
          }
        } catch (e) {}
      }
      this._pickedIframes = null;
    },

    // ===== iframe 广告桥: 广告常被放进跨域 iframe(联盟广告位), 顶层收不到 iframe
    // 内部的点击, 用户"点了广告没反应/页面跳走"。方案: 标记模式开启时向所有 frame
    // 广播 on, iframe 内脚本实例挂 capture 点击监听, 点在"自身带第三方域"的媒体元素
    // (img/iframe/script/video/embed) 上就把域名回传顶层; 顶层按域名定位宿主 iframe,
    // 自动选中它并弹出卡片（可直接「屏蔽它」或「🔥 封杀来源域名」）。
    _startFrameBridge: function () {
      var self = this;
      this._frameMsgHandler = function (e) {
        var d = e.data;
        if (!d || typeof d !== 'object') return;
        if (d.__abCssPick === 'on') {
          if (window.self === window.top) return;
          self._iframeOn();
          return;
        }
        if (d.__abCssPick === 'off') {
          if (window.self !== window.top) self._iframeOff();
          return;
        }
        if (d.__abCssPick === 'hit') {
          if (window.self !== window.top) return;
          self._onFrameHit(d);
        }
      };
      _globals.addEventListener('message', this._frameMsgHandler);
      if (window.self !== window.top) return;   // iframe 实例等顶层广播即可
      try { _globals.postMessage({ __abCssPick: 'on' }, '*'); } catch (e) {}
    },
    _stopFrameBridge: function () {
      if (this._frameMsgHandler) {
        try { _globals.removeEventListener('message', this._frameMsgHandler); } catch (e) {}
        this._frameMsgHandler = null;
      }
      this._iframeOff();
      if (window.self !== window.top) return;
      try { _globals.postMessage({ __abCssPick: 'off' }, '*'); } catch (e) {}
    },
    _iframeOn: function () {
      if (this._iframeClickListener) return;
      var self = this;
      this._iframeClickListener = function (ev) {
        try {
          var el = ev.target;
          if (!el || !_isElementLike(el)) return;
          var t = (el.tagName || '').toUpperCase();
          if (t !== 'IMG' && t !== 'IFRAME' && t !== 'SCRIPT' && t !== 'VIDEO' && t !== 'EMBED' && t !== 'OBJECT') return;
          var dom = _cssExtractThirdPartyDomain(el);
          if (!dom) return;
          if (self._lastFrameHitAt && Date.now() - self._lastFrameHitAt < 1500) return;
          self._lastFrameHitAt = Date.now();
          try { _globals.postMessage({ __abCssPick: 'hit', domain: dom }, '*'); } catch (e) {}
        } catch (e) {}
      };
      // 挂 window capture 层: 先于 document capture 的点击拦截(_onClick 的
      // stopImmediatePropagation 会掐断同捕获阶段后续监听器), 保证桥先收到点击
      _globals.addEventListener('click', this._iframeClickListener, true);
    },
    _iframeOff: function () {
      if (this._iframeClickListener) {
        try { _globals.removeEventListener('click', this._iframeClickListener, true); } catch (e) {}
        this._iframeClickListener = null;
      }
    },
    _onFrameHit: function (d) {
      if (!d || !d.domain) return;
      var host = null;
      var iframes = [];
      try { iframes = _document.querySelectorAll('iframe'); } catch (e) {}
      for (var i = 0; i < iframes.length; i++) {
        try {
          var h = new _URL(iframes[i].src || '', _location.href).hostname;
          if (h === d.domain) { host = iframes[i]; break; }
        } catch (e) {}
      }
      if (!host) {
        try {
          GM_notification({ text: '检测到广告来源 ' + d.domain + '（在页面框架内）。请点选框架元素，或直接用它生成封杀域名规则', title: '广告拦截器' });
        } catch (e) {}
        return;
      }
      this._selectPickTarget(host);
      this._renderPickCard();
      try {
        GM_notification({ text: '已定位广告所在的框架（' + d.domain + '）：可直接「屏蔽它」或「🔥 封杀来源域名」', title: '广告拦截器' });
      } catch (e) {}
    },

    _selectPickTarget: function (el) {
      if (this._pickTarget && this._pickTarget.classList) {
        try { this._pickTarget.classList.remove('ab-pick-hl'); } catch (e) {}
      }
      this._pickTarget = el;
      this._pickSelectors = null;
      this._pickModes = null;
      this._pickDomain = null;
      this._pickFamily = null;
      if (!el) { this._pickCard.style.display = 'none'; return; }
      try { el.classList.add('ab-pick-hl'); } catch (e) {}
      var modes = { id: [], struct: [], shape: [] };
      // 键卫生: 生成前剥离本脚本写入的 important 隐藏样式, 防止隐藏段混入形态键
      try { modes.id = _cssStripOwnHideStyle(el, _cssNameSelectors); } catch (e) { _debugCatch(e, 'pick name sels'); }
      try { modes.struct = _cssStripOwnHideStyle(el, _cssStructSelectors); } catch (e) { _debugCatch(e, 'pick struct sels'); }
      try { modes.shape = _cssStripOwnHideStyle(el, _cssShapeSelectors); } catch (e) { _debugCatch(e, 'pick shape sels'); }
      this._pickModes = modes;
      // 已选方式仍可用则保持, 否则回退: 类名/ID → 物理结构
      if (!this._pickMode || !modes[this._pickMode] || !modes[this._pickMode].length) {
        this._pickMode = modes.id.length ? 'id' : 'struct';
      }
      // 格群扇出改为显式操作: 同形群体 ≥5 时由卡片「整群屏蔽」按钮提供一键群杀
      // (同质校验通过才显示), 默认方式保持单元素键, 群体连坐由按钮显式确认
      try { this._pickDomain = _cssExtractThirdPartyDomain(el); } catch (e) { _debugCatch(e, 'pick domain'); }
      // 同族容器: 广告位容器 class 固定但内容随机时, 提供整族屏蔽
      try { this._pickFamily = _cssFindRepeatContainer(el); } catch (e) { _debugCatch(e, 'pick family'); }
      this._renderPickCard();
    },

    _renderPickCard: function () {
      var el = this._pickTarget;
      if (!el || !this._pickCard) return;
      var modes = this._pickModes || { id: [], struct: [], shape: [] };
      var mode = this._pickMode || 'struct';
      var modeNames = { id: '类名/ID', struct: '物理结构', shape: '形态特征' };
      var countOf = function (sels) {
        if (!sels || !sels.length) return -1;
        var _nat = [], _ext = [];
        for (var _ci = 0; _ci < sels.length; _ci++) {
          if (_cssIsExtSelector(sels[_ci])) _ext.push(sels[_ci]);
          else _nat.push(sels[_ci]);
        }
        var _seen = null;
        try { _seen = new Set(); } catch (e) {}
        var _ok = false;
        if (_nat.length) {
          try {
            var _nl = _document.querySelectorAll(_nat.join(','));
            for (var _nj = 0; _nj < _nl.length; _nj++) { if (_seen) _seen.add(_nl[_nj]); else _ok = true; }
            _ok = true;
          } catch (e) { return -1; }
        }
        if (_ext.length && typeof _ExtCss !== 'undefined' && _ExtCss) {
          try {
            var _el2 = _ExtCss.query(_ext.join(','));
            for (var _ek = 0; _ek < (_el2 ? _el2.length : 0); _ek++) { if (_seen) _seen.add(_el2[_ek]); else _ok = true; }
            _ok = true;
          } catch (e2) {}
        }
        if (!_ok) return -1;
        return _seen ? _seen.size : -1;
      };
      var chipsHtml = '';
      var chipStyles = {
        on: 'border:2px solid #007AFF;background:#e8f2ff;color:#007AFF;font-weight:600;',
        off: 'border:1px solid #ddd;background:#f2f2f7;color:#333;'
      };
      var order = ['id', 'struct', 'shape'];
      for (var ci = 0; ci < order.length; ci++) {
        var k = order[ci];
        var sels = modes[k] || [];
        var n = countOf(sels);
        var disabled = !sels.length;
        var st = disabled ? 'border:1px solid #eee;background:#eee;color:#aaa;' : (k === mode ? chipStyles.on : chipStyles.off);
        chipsHtml += '<button type="button" data-pick-mode="' + k + '"' + (disabled ? ' disabled' : '') +
          ' style="flex:1;padding:6px 2px;border-radius:8px;font-size:12px;' + st + '">' +
          modeNames[k] + (n < 0 ? '' : ' ' + n) + '</button>';
      }
      var cur = modes[mode] || [];
      var cnt = countOf(cur);
      var cntHtml = !cur.length
        ? '<span style="color:#d32f2f;">该方式不可用，请换一种</span>'
        : (cnt < 0
          ? '<span style="color:#d32f2f;">选择器异常，请换一种方式</span>'
          : '命中 <b style="color:' + (cnt > 30 ? '#d32f2f' : '#34c759') + ';">' + cnt + '</b> 个元素' +
            (cnt > 30 ? '（偏多：试试切换其它屏蔽方式，或点页面里更具体的元素）' : ''));
      var domainHtml = this._pickDomain
        ? '<button type="button" data-pick-act="domain" style="width:100%;margin-bottom:8px;padding:8px 0;border:none;border-radius:8px;background:#ff3b30;color:#fff;font-size:13px;font-weight:600;">🔥 彻底封杀来源域名 ' + escapeHtml(this._pickDomain) + '</button>'
        : '';
      var familyHtml = this._pickFamily
        ? '<button type="button" data-pick-act="family" style="width:100%;margin-bottom:8px;padding:8px 0;border:none;border-radius:8px;background:#ff9500;color:#fff;font-size:13px;font-weight:600;">👥 屏蔽全部同类容器 (' + this._pickFamily.count + ' 个, ' + escapeHtml(this._pickFamily.sel.slice(0, 40)) + ')</button>'
        : '';
      // 整群屏蔽按钮: 同形群体(形态键/同前缀 id 命中 ≥5)且群体与所选元素同质时显示,
      // 点击才保存组键 —— 一键群杀能力不减, 连坐从静默默认改为用户显式确认
      var swarmHtml = '';
      try {
        var _swList = _cssShapeSwarmList(el);
        var _swN = 0;
        for (var _swi = 0; _swi < _swList.length; _swi++) {
          if (_cssSwarmSameShape(el, _swList[_swi])) _swN++;
        }
        if (_swN >= 5) {
          swarmHtml = '<button type="button" data-pick-act="swarm" style="width:100%;margin-bottom:8px;padding:8px 0;border:none;border-radius:8px;background:#af52de;color:#fff;font-size:13px;font-weight:600;">🎯 检测到同形群体 ' + _swN + ' 个 → 整群屏蔽</button>';
        }
      } catch (e) {}
      var _sufAvail = false;
      try { _sufAvail = _cssSuffixSelectors(el, true).length > 0; } catch (e) {}
      this._pickCard.style.display = 'block';
      this._pickCard.innerHTML =
        '<div style="word-break:break-all;color:#555;margin-bottom:6px;">已选: <b style="color:#111;">' + escapeHtml(_cssElLabel(el)) + '</b></div>' +
        '<div style="font-size:11px;color:#888;margin-bottom:4px;">屏蔽方式（各方式命中数实时预览，点击切换）:</div>' +
        '<div style="display:flex;gap:6px;margin-bottom:6px;">' + chipsHtml + '</div>' +
        '<div style="margin-bottom:8px;">' + cntHtml + '</div>' +
        (cur.length ? '<div style="word-break:break-all;color:#999;font-size:10px;margin-bottom:8px;font-family:monospace;">' + escapeHtml(cur[0].slice(0, 120)) + '</div>' : '') +
        '<div style="margin-bottom:6px;border-top:1px solid #eee;padding-top:6px;">' +
          '<label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:13px;color:#222;padding:4px 0;">' +
            '<input type="checkbox" data-pick-ext="1" style="width:19px !important;height:19px !important;appearance:auto !important;-webkit-appearance:checkbox !important;display:inline-block !important;visibility:visible !important;opacity:1 !important;position:static !important;transform:none !important;clip-path:none !important;accent-color:#007AFF;cursor:pointer;flex:none;margin:0;padding:0;"' + (this._pickExtEnable ? ' checked' : '') + '>' +
            '<span>扩展屏蔽<span style="color:#999;font-size:11px;">（默认不勾选＝普通屏蔽；勾选＝换名/重建也隐藏）</span></span>' +
          '</label>' +
          '<button type="button" data-pick-ext-info="1" style="width:100%;margin:2px 0 4px;padding:7px 0;border:1px solid #007AFF;border-radius:8px;background:#f2f8ff;color:#007AFF;font-size:12px;">' + (this._pickExtDescOpen ? '收起扩展屏蔽说明 ▲' : 'ⓘ 查看扩展屏蔽说明 ▼') + '</button>' +
          '<div data-pick-ext-desc="1" style="display:' + (this._pickExtDescOpen ? 'block' : 'none') + ';font-size:11px;color:#555;background:#f2f8ff;border:1px solid #cfe3ff;border-radius:6px;padding:6px 8px;margin-bottom:4px;line-height:1.5;word-break:break-all;">' +
          '扩展屏蔽：除上方类名/ID、结构、形态选择器外，额外记录广告所在的结构位置（槽位指纹）。之后广告即使换类名/ID、换结构重建，只要落在相同槽位也会再次被隐藏——适合类名/ID 随机变化的顽固广告位。<br>' +
          '副作用：同槽位的相似结构内容（如评论区条目、固定悬浮条）也可能被连带隐藏。<br>' +
          '如出现误隐藏：取消勾选重新保存，或到「CSS屏蔽规则」删除该条。<br>' +
          '<b>不勾选 = 普通屏蔽</b>：仅按保存的选择器隐藏，与常规广告屏蔽器一致。' +
        '</div>' +
        ((_sufAvail && this._pickMode === 'shape')
          ? '<label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:13px;color:#222;padding:4px 0;">' +
            '<input type="checkbox" data-pick-wide="1" style="width:19px !important;height:19px !important;appearance:auto !important;-webkit-appearance:checkbox !important;display:inline-block !important;visibility:visible !important;opacity:1 !important;position:static !important;transform:none !important;clip-path:none !important;accent-color:#ff9500;cursor:pointer;flex:none;margin:0;padding:0;"' + (this._pickWideEnable ? ' checked' : '') + '>' +
            '<span>全页同形态（宽）<span style="color:#999;font-size:11px;">（默认不勾选＝仅同尾缀层；勾选＝改收整页所有同定位层，含站点自身悬浮元素）</span></span>' +
          '</label>'
          : '') +
        '<div style="margin-top:2px;">' +
          (this._pickMode === 'shape'
            ? '<label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:13px;color:#222;padding:4px 0;">' +
              '<input type="checkbox" data-pick-var="1" style="width:19px !important;height:19px !important;appearance:auto !important;-webkit-appearance:checkbox !important;display:inline-block !important;visibility:visible !important;opacity:1 !important;position:static !important;transform:none !important;clip-path:none !important;accent-color:#34C759;cursor:pointer;flex:none;margin:0;padding:0;"' + (this._pickVariantEnable ? ' checked' : '') + '>' +
              '<span>变体联动<span style="color:#999;font-size:11px;">（勾选＝把 absolute/iframe 等形态轮换一并覆盖）</span></span>' +
            '</label>' +
            '<button type="button" data-pick-var-info="1" style="width:100%;margin:2px 0 4px;padding:7px 0;border:1px solid #34C759;border-radius:8px;background:#f0fff4;color:#34C759;font-size:12px;">' + (this._pickVarDescOpen ? '收起变体联动说明 ▲' : 'ⓘ 查看变体联动说明 ▼') + '</button>' +
            '<div data-pick-var-desc="1" style="display:' + (this._pickVarDescOpen ? 'block' : 'none') + ';font-size:11px;color:#555;background:#f0fff4;border:1px solid #b8e6c8;border-radius:6px;padding:6px 8px;margin-bottom:4px;line-height:1.5;word-break:break-all;">' +
            '变体联动：除当前形态规则外，同时按「同标签 + 相同样式条件」生成 absolute/fixed 镜像、以及 iframe 承载版变体规则，广告每次加载轮换形态（悬浮条↔顶栏、div↔iframe）也能持续命中。<br>' +
            '规则仅含定位条件（无其它样式条件）时不生成（防误伤站内大量 absolute 元素）；批量屏蔽不联动；变体规则为普通隐藏（不带扩展屏蔽槽位）。' +
            '</div>'
            : '') +
        '</div>' +
        domainHtml + familyHtml + swarmHtml +
        '<div style="display:flex;gap:8px;">' +
          '<button type="button" data-pick-act="combo" style="flex:2;border:none;background:#ff3b30;color:#fff;border-radius:8px;padding:8px 0;font-size:13px;font-weight:600;">✅ 屏蔽(先隐后删)</button>' +
          // 整群屏蔽按钮可见时不并排「全部 N」: 组键一条覆盖全群且耐刷新,
          // 逐元素键并集在该场景属冗余; 非格群多命中场景保留「全部 N」入口
          (cnt > 1 && !swarmHtml
            ? '<button type="button" data-pick-act="saveAll" style="flex:1;padding:8px 0;border:none;border-radius:8px;background:#ff9500;color:#fff;font-size:12px;">👥 全部 ' + cnt + '</button>'
            : '<button type="button" data-pick-act="save" style="flex:1;border:none;background:#f2f2f7;color:#333;border-radius:8px;padding:8px 0;font-size:13px;">👁 仅隐藏</button>') +
          '<button type="button" data-pick-act="parent" style="flex:1;border:none;background:#f2f2f7;color:#333;border-radius:8px;padding:8px 0;font-size:13px;">⬆ 选父级</button>' +
          '<button type="button" data-pick-act="exit" style="flex:1;border:none;background:#f2f2f7;color:#333;border-radius:8px;padding:8px 0;font-size:13px;">取消</button>' +
        '</div>' +
        '<div style="font-size:10px;color:#999;margin-top:6px;">组合=先 CSS 隐藏防闪现, 后台每 2 秒移除命中元素(广告重建也照删)。「仅隐藏」=纯 CSS 规则。</div>';
      this._pickPushSync();
    },

    // 规则命中计数（保存明示用）: 原生选择器走 querySelectorAll, 扩展选择器走扩展引擎
    // query, Set 去重后取并集总数; 计数失败返回 -1
    _cssSelHitCount: function (sels) {
      if (!sels || !sels.length) return -1;
      var _nat = [], _ext = [];
      for (var _ci = 0; _ci < sels.length; _ci++) {
        if (_cssIsExtSelector(sels[_ci])) _ext.push(sels[_ci]);
        else _nat.push(sels[_ci]);
      }
      var _seen = null;
      try { _seen = new Set(); } catch (e) { return -1; }
      var _ok = false;
      if (_nat.length) {
        try {
          var _nl = _document.querySelectorAll(_nat.join(','));
          for (var _nj = 0; _nj < _nl.length; _nj++) _seen.add(_nl[_nj]);
          _ok = true;
        } catch (e2) { return -1; }
      }
      if (_ext.length && typeof _ExtCss !== 'undefined' && _ExtCss) {
        try {
          var _el2 = _ExtCss.query(_ext.join(','));
          for (var _ek = 0; _ek < (_el2 ? _el2.length : 0); _ek++) _seen.add(_el2[_ek]);
          _ok = true;
        } catch (e3) {}
      }
      return _ok ? _seen.size : -1;
    },

    _savePicked: function (actionMode) {
      var el = this._pickTarget;
      if (!el) return;
      var mode = this._pickMode || 'struct';
      var sels = (this._pickModes && this._pickModes[mode] && this._pickModes[mode].length)
        ? this._pickModes[mode]
        : null;
      if (!sels) {
        try { sels = _cssStructuralSelectors(el); } catch (e) {}
      }
      if (!sels || !sels.length) {
        try { GM_notification({ text: '选择器生成失败，未保存', title: '广告拦截器' }); } catch (e) {}
        return;
      }
      var modeName = mode === 'id' ? '类名/ID' : (mode === 'shape' ? '形态特征' : '物理结构');
      var actionName = actionMode === 'remove' ? '移除' : (actionMode === 'combo' ? '组合(先隐后删)' : '隐藏');
      var _ext = !!this._pickExtEnable;   // 「扩展屏蔽」勾选才带槽位锁（泛化隐藏）
      var _hitsNote = '';
      var label = _cssElLabel(el) + '【' + modeName + '·' + actionName + '】' + (_ext ? '·扩展屏蔽' : '');
      var rules = currentConfig.elementCssRules || [];
      var dup = false;
      for (var i = 0; i < rules.length; i++) {
        if (rules[i] && rules[i].selectors && rules[i].selectors[0] === sels[0]) { dup = true; break; }
      }
      if (!dup) {
        var _slots = null;
        if (_ext) { try { _slots = _overlayStableSlots(el); } catch (e) {} }
        rules.push({
          id: 'cssr_' + Date.now().toString(36) + '_' + Math.floor(Math.random() * 1e5).toString(36),
          selectors: sels,
          label: label,
          mode: actionMode === 'remove' ? 'remove' : (actionMode === 'combo' ? 'combo' : mode),
          slots: _slots && _slots.length ? _slots : null,
          form: _ext ? (this._slotFormSig ? this._slotFormSig(el) : null) : null,
          createdAt: Date.now()
        });
        // 命中明示: 保存的规则实际命中超过拾取的单个元素时, 规则上记录命中数与窄键
        // (物理结构键), 「CSS屏蔽规则」面板该条提供「仅隐藏所选」一键回退
        try {
          var _hitN = this._cssSelHitCount(sels);
          if (_hitN > 1) {
            var _narrow = _cssStructuralSelectors(el);
            if (_narrow && _narrow.length) {
              rules[rules.length - 1].savedHits = _hitN;
              rules[rules.length - 1].narrowSels = _narrow;
              _hitsNote = '，该规则同时命中 ' + _hitN + ' 个元素（CSS屏蔽规则面板可一键回退为仅隐藏所选）';
            }
          }
        } catch (eH) { _debugCatch(eH, 'savePicked hitsNote'); }
        currentConfig.elementCssRules = rules;
        ConfigUpdater.saveNow();
        // 变体联动: 由形态规则派生 absolute/fixed 镜像与 iframe 承载版（覆盖广告形态轮换）;
        // 只继承 :matches-css 谓词, 丢弃 base 类名/ID; 裸 position 不派生; 派生规则为普通隐藏（无槽位锁）
        if (this._pickVariantEnable && mode === 'shape' && actionMode !== 'remove') {
          var _vars = this._cssVariantRules(sels);
          if (_vars && _vars.length) {
            for (var _vi = 0; _vi < _vars.length; _vi++) {
              var _vr = _vars[_vi];
              var _vdup = false;
              for (var _vk = 0; _vk < rules.length; _vk++) {
                if (rules[_vk] && rules[_vk].selectors && rules[_vk].selectors[0] === _vr.selectors[0]) { _vdup = true; break; }
              }
              if (!_vdup) rules.push(_vr);
            }
            currentConfig.elementCssRules = rules;
            ConfigUpdater.saveNow();
          }
        }
      }
      this.applyCss();
      // 全屏/覆盖层形态屏蔽后站点脚本可能遗留滚动锁定(body overflow hidden 等),
      // 复用覆盖层 ScrollLockGuard 兜底(仅 overlay-like 元素触发, 15 秒窗口内持续复查)
      try { if (typeof ScrollLockGuard !== 'undefined' && ScrollLockGuard.armForElement) ScrollLockGuard.armForElement(el); } catch (e) {}
      this._exitPicking();
      try {
        GM_notification({
          text: (dup ? '规则已存在，未重复保存' : '已按「' + actionName + '」方式保存并生效' + (actionMode === 'remove' || actionMode === 'combo' ? '，命中元素将被移除' : '') + _hitsNote) + '（管理入口：广告拦截设置→CSS屏蔽规则）',
          title: '广告拦截器'
        });
      } catch (e) {}
    },

    // 屏蔽全部 N 个: 把当前方式命中的每一个元素各自的钥匙(物理链/类名ID/形态)
    // 并集进同一条规则 —— 同页面 40 个同结构广告（名字随机）一次保存, 不用逐一点 40 次;
    // 后续新注入的同结构/同形态变种由 CSS 自动命中。
    _saveAllPicked: function () {
      var el = this._pickTarget;
      if (!el) return;
      var mode = this._pickMode || 'struct';
      var baseSels = (this._pickModes && this._pickModes[mode]) || null;
      if (!baseSels || !baseSels.length) {
        try { GM_notification({ text: '当前屏蔽方式不可用，请换一种', title: '广告拦截器' }); } catch (e) {}
        return;
      }
      var genFor = function (n) {
        // 键卫生: 群体成员也可能带本脚本写入的隐藏样式, 生成前同样剥离
        if (mode === 'id') return _cssStripOwnHideStyle(n, _cssNameSelectors);
        if (mode === 'shape') return _cssStripOwnHideStyle(n, _cssShapeSelectors);
        return _cssStripOwnHideStyle(n, _cssStructSelectors);
      };
      var merged = [];
      var _natS = [];
      for (var _ni = 0; _ni < baseSels.length; _ni++) {
        if (!_cssIsExtSelector(baseSels[_ni])) _natS.push(baseSels[_ni]);
      }
      var all = [];
      try { all = _natS.length ? _document.querySelectorAll(_natS.join(',')) : []; } catch (e) {}
      var list = [];
      for (var i = 0; i < all.length && i < 200; i++) list.push(all[i]);
      if (!list.length) list.push(el);
      // 格群扇出: base 键(单格 body 索引键/单尾缀键)当轮只命中拾取元素本身, 而页内
      // 存在同形群体（透明点击格群）时按群体补齐 —— 一键全群, 不必逐格拾取;
      // 群体成员须通过同质校验（同标签+同信号集+同尺寸档）才并入, 防宽键连坐站点元素
      if (list.length === 1) {
        try {
          var _swarmEls = _cssShapeSwarmList(list[0]);
          for (var _swi = 0; _swi < _swarmEls.length && list.length < 200; _swi++) {
            if (list.indexOf(_swarmEls[_swi]) === -1 && _cssSwarmSameShape(list[0], _swarmEls[_swi])) list.push(_swarmEls[_swi]);
          }
        } catch (e) {}
      }
      for (var j = 0; j < list.length; j++) {
        var sels2 = [];
        try { sels2 = genFor(list[j]); } catch (e2) {}
        for (var k = 0; k < sels2.length; k++) {
          if (merged.indexOf(sels2[k]) === -1) merged.push(sels2[k]);
        }
      }
      if (!merged.length) {
        try { GM_notification({ text: '批量选择器生成失败，未保存', title: '广告拦截器' }); } catch (e) {}
        return;
      }
      // 群键并入: 群体由形态组键识别时把组键并入规则 —— 组键与索引/随机前缀解耦,
      // 后续加载的格子（坐标/前缀重掷）持续命中; 页内命中 <5 的形态键不并入（非群体）,
      // 命中 ≥5 还须组键命中集整体通过同质校验才并入
      try {
        var _gkeys = _cssStripOwnHideStyle(el, _cssShapeSelectors);
        for (var _gki = 0; _gki < _gkeys.length; _gki++) {
          if (merged.indexOf(_gkeys[_gki]) !== -1) continue;
          if (_cssSwarmKeyHomogeneous(el, _gkeys[_gki])) merged.push(_gkeys[_gki]);
        }
      } catch (e) {}
      var modeName = mode === 'id' ? '类名/ID' : (mode === 'shape' ? '形态特征' : '物理结构');
      var _extA = !!this._pickExtEnable;   // 「扩展屏蔽」勾选才带槽位锁（泛化隐藏）
      var rules = currentConfig.elementCssRules || [];
      var dup = false;
      for (var m = 0; m < rules.length; m++) {
        if (rules[m] && rules[m].selectors && rules[m].selectors[0] === merged[0] &&
            rules[m].selectors.length === merged.length) { dup = true; break; }
      }
      if (!dup) {
        var _slotsA = [];
        if (_extA) {
          for (var _si = 0; _si < list.length && _si < 60; _si++) {
            try {
              var _ssl = _overlayStableSlots(list[_si]);
              if (_ssl) {
                for (var _sk = 0; _sk < _ssl.length; _sk++) {
                  if (_slotsA.indexOf(_ssl[_sk]) === -1) _slotsA.push(_ssl[_sk]);
                }
              }
            } catch (e2) {}
          }
        }
        rules.push({
          id: 'cssr_' + Date.now().toString(36) + '_' + Math.floor(Math.random() * 1e5).toString(36),
          selectors: merged,
          label: _cssElLabel(el) + '【' + modeName + '·全部' + list.length + '个】' + (_extA ? '·扩展屏蔽' : ''),
          mode: mode,
          slots: _slotsA.length ? _slotsA : null,
          form: _extA ? (this._slotFormSig ? this._slotFormSig(el) : null) : null,
          createdAt: Date.now()
        });
        currentConfig.elementCssRules = rules;
        ConfigUpdater.saveNow();
      }
      this.applyCss();
      // 批量保存: 对覆盖层形态元素逐个 arm 滚动解锁
      try {
        for (var _armI = 0; _armI < list.length && _armI < 60; _armI++) {
          if (typeof ScrollLockGuard !== 'undefined' && ScrollLockGuard.armForElement) ScrollLockGuard.armForElement(list[_armI]);
        }
      } catch (e) {}
      this._exitPicking();
      try {
        GM_notification({
          text: (dup ? '规则已存在，未重复保存' : '已按「' + modeName + '」批量屏蔽全部 ' + list.length + ' 个元素') + '（管理入口：广告拦截设置→CSS屏蔽规则）',
          title: '广告拦截器'
        });
      } catch (e) {}
    },

    // 整群屏蔽: 保存通过同质校验的形态组键(页内命中 ≥5 且命中集与所选元素同标签+
    // 同信号集+同尺寸档), 由卡片按钮显式触发 —— 40 格群一键能力不减, 连坐从
    // "静默默认方式"改为"用户点了才生效"
    _saveSwarmPicked: function () {
      var el = this._pickTarget;
      if (!el) return;
      var merged = [];
      try {
        var _gkeys = _cssStripOwnHideStyle(el, _cssShapeSelectors);
        for (var _gki = 0; _gki < _gkeys.length; _gki++) {
          if (merged.indexOf(_gkeys[_gki]) !== -1) continue;
          if (_cssSwarmKeyHomogeneous(el, _gkeys[_gki])) merged.push(_gkeys[_gki]);
        }
      } catch (e) {}
      if (!merged.length) {
        try { GM_notification({ text: '同形群体校验未通过（群体需与所选元素同标签、同样式信号、同尺寸档），未保存', title: '广告拦截器' }); } catch (e) {}
        return;
      }
      var _cnt = 0;
      try { _cnt = _document.querySelectorAll(merged.join(',')).length; } catch (e2) {}
      var rules = currentConfig.elementCssRules || [];
      var dup = false;
      for (var m = 0; m < rules.length; m++) {
        if (rules[m] && rules[m].selectors && rules[m].selectors[0] === merged[0] &&
            rules[m].selectors.length === merged.length) { dup = true; break; }
      }
      if (!dup) {
        var _slotsS = null;
        if (this._pickExtEnable) { try { _slotsS = _overlayStableSlots(el); } catch (e3) {} }
        rules.push({
          id: 'cssr_' + Date.now().toString(36) + '_' + Math.floor(Math.random() * 1e5).toString(36),
          selectors: merged,
          label: _cssElLabel(el) + '【形态特征·整群' + _cnt + '个】' + (this._pickExtEnable ? '·扩展屏蔽' : ''),
          mode: 'shape',
          slots: _slotsS && _slotsS.length ? _slotsS : null,
          form: this._pickExtEnable ? (this._slotFormSig ? this._slotFormSig(el) : null) : null,
          createdAt: Date.now()
        });
        currentConfig.elementCssRules = rules;
        ConfigUpdater.saveNow();
      }
      this.applyCss();
      try { if (typeof ScrollLockGuard !== 'undefined' && ScrollLockGuard.armForElement) ScrollLockGuard.armForElement(el); } catch (e4) {}
      this._exitPicking();
      try {
        GM_notification({
          text: (dup ? '规则已存在，未重复保存' : '已整群屏蔽同形群体 ' + _cnt + ' 个元素') + '（管理入口：广告拦截设置→CSS屏蔽规则）',
          title: '广告拦截器'
        });
      } catch (e5) {}
    },

    // 一键屏蔽全部同类容器: 广告位容器 class 固定(AdSense 的 ins.adsbygoogle / 各站
    // 固定广告容器), 内容被随机注入 → 整族一条 class 规则全中, 后续新注入的
    // 同族广告位也自动隐藏
    _saveFamilyPicked: function () {
      var fam = this._pickFamily;
      if (!fam || !fam.sel) return;
      var rules = currentConfig.elementCssRules || [];
      for (var i = 0; i < rules.length; i++) {
        if (rules[i] && rules[i].mode === 'family' && rules[i].selectors && rules[i].selectors[0] === fam.sel) {
          this._exitPicking();
          try { GM_notification({ text: '该同类容器屏蔽规则已存在', title: '广告拦截器' }); } catch (e) {}
          return;
        }
      }
      var nowCnt = 0;
      try { nowCnt = _document.querySelectorAll(fam.sel).length; } catch (e) {}
      rules.push({
        id: 'cssr_' + Date.now().toString(36) + '_' + Math.floor(Math.random() * 1e5).toString(36),
        selectors: [fam.sel],
        label: '👥 同类容器 ' + fam.sel + '（' + nowCnt + ' 个）',
        mode: 'family',
        createdAt: Date.now()
      });
      currentConfig.elementCssRules = rules;
      ConfigUpdater.saveNow();
      this.applyCss();
      this._exitPicking();
      try {
        GM_notification({
          text: '已整族屏蔽同类容器 ' + fam.sel + '（' + nowCnt + ' 个），新注入的同类广告位也会自动隐藏（管理入口：广告拦截设置→CSS屏蔽规则）',
          title: '广告拦截器'
        });
      } catch (e) {}
    },

    // 一键封杀来源域名: 页面里凡是 src/href/data-src 指向该域名的元素全部隐藏
    // (图片/iframe/脚本/链接), 广告脚本本身与其后续注入的同源资源一并命中
    _saveDomainKill: function () {
      var host = this._pickDomain;
      if (!host) return;
      var rules = currentConfig.elementCssRules || [];
      for (var i = 0; i < rules.length; i++) {
        if (rules[i] && rules[i].domain === host) {
          this._exitPicking();
          try { GM_notification({ text: '该域名已在封杀列表中', title: '广告拦截器' }); } catch (e) {}
          return;
        }
      }
      var sel = '[src*="' + host + '"],[href*="' + host + '"],[data-src*="' + host + '"]';
      rules.push({
        id: 'cssr_' + Date.now().toString(36) + '_' + Math.floor(Math.random() * 1e5).toString(36),
        selectors: [sel],
        label: '🌐 封杀域名 ' + host,
        domain: host,
        mode: 'domain',
        createdAt: Date.now()
      });
      currentConfig.elementCssRules = rules;
      ConfigUpdater.saveNow();
      this.applyCss();
      this._exitPicking();
      try {
        GM_notification({
          text: '已彻底封杀来源域名 ' + host + '：页面内指向该域名的图片/iframe/脚本/链接全部隐藏（管理入口：广告拦截设置→CSS屏蔽规则）',
          title: '广告拦截器'
        });
      } catch (e) {}
    },

    _exitPicking: function () {
      this._picking = false;
      this._stopFrameBridge();
      this._disableIframePierce();
      this._downX = null;
      this._downY = null;
      if (this._onClick) { try { _document.removeEventListener('click', this._onClick, true); } catch (e) {} this._onClick = null; }
      if (this._onUp) {
        try { _document.removeEventListener('pointerup', this._onUp, true); } catch (e) {}
        try { _document.removeEventListener('touchend', this._onUp, { capture: true, passive: false }); } catch (e) {}
        this._onUp = null;
      }
      this._lastPickAt = 0;
      if (this._onCtx) { try { _document.removeEventListener('contextmenu', this._onCtx, true); } catch (e) {} this._onCtx = null; }
      if (this._onDown) {
        try { _document.removeEventListener('mousedown', this._onDown, true); } catch (e) {}
        try { _document.removeEventListener('pointerdown', this._onDown, true); } catch (e) {}
        try { _document.removeEventListener('touchstart', this._onDown, true); } catch (e) {}
        this._onDown = null;
      }
      if (this._pickTarget && this._pickTarget.classList) {
        try { this._pickTarget.classList.remove('ab-pick-hl'); } catch (e) {}
      }
      this._pickTarget = null;
      this._pickSelectors = null;
      this._pickModes = null;
      this._pickDomain = null;
      this._pickFamily = null;
      this._pickMode = null;
      this._pickExtEnable = false;
      this._pickVariantEnable = false;
      this._pickWideEnable = false;
      if (this._pickHost && this._pickHost.parentNode) {
        try { this._pickHost.parentNode.removeChild(this._pickHost); } catch (e) {}
      }
      this._pickHost = null;
      this._pickCard = null;
      if (this._pickStyle && this._pickStyle.parentNode) {
        try { this._pickStyle.parentNode.removeChild(this._pickStyle); } catch (e) {}
      }
      this._pickStyle = null;
      this._pickPushRestore();
      // 恢复扩展引擎: 按当前规则幂等重建（无扩展规则时自动为空操作）; 最后执行,
      // 避免尚未挂起的宽规则扫到仍在页面上的拾取宿主
      try { this.applyCss(); } catch (e4) { _debugCatch(e4, 'pick resume ext'); }
    },
  };

  function restoreNeutralizedElement(el) {
    if (!el || !_isElementLike(el)) return;
    try {
      if (el.classList) el.classList.remove('_uh');
      var _rs = el.style;
      if (_rs) {
        _rs.removeProperty('display');
        _rs.removeProperty('visibility');
        _rs.removeProperty('opacity');
        _rs.removeProperty('pointer-events');
        _rs.removeProperty('height');
        _rs.removeProperty('overflow');
        _rs.removeProperty('transform');
      }
    } catch(e) {}
  }


  function escapeHtml(unsafe) {
    if (unsafe == null) return '';
    return String(unsafe)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/`/g, '&#96;');
  }


  function generateContentHash(str) {
    if (typeof str !== 'string') return '';
    let hash = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) {
      hash ^= str.charCodeAt(i);
      hash = (hash * 0x01000193) >>> 0;
    }
    return 'hash_' + hash.toString(36);
  }

  function _logDisplayName(content) {
    // 白名单显示名: 去掉日志内容自带的类型前缀(SCRIPT:/SRC:/IMG: 等),
    // 面板显示时前缀由 prefixMap 标签提供, 避免"脚本SRC: SRC: ..."双重前缀
    if (typeof content !== 'string') return '';
    return content.replace(/^(?:[A-Z][A-Z0-9_]{1,20}:|SRC:|阻止:)\s*/, '');
  }

  // ======================== 日志类型共享常量 ========================
    // 面板日志按类型前缀分组显示（如 OVERLAY_WRITE_BLOCKED: 覆盖层拦截 document.write 广告）。
  const HASH_TYPE_PREFIX_MAP = {
    EVAL: 'EVAL_HASH',
    FUNCTION_CONSTRUCTOR: 'FUNCTION_HASH',
    DOCUMENT_WRITE: 'DOCUMENT_WRITE_HASH',
    SETTIMEOUT: 'SETTIMEOUT_HASH',
    SETINTERVAL: 'SETINTERVAL_HASH',
    REQUESTANIMATIONFRAME: 'REQUESTANIMATIONFRAME_HASH',
  };
  const HASH_TYPE_NAMES = Object.keys(HASH_TYPE_PREFIX_MAP);
  const OBFUSCATION_SUFFIX_RE = /_(?:OBFUSCATED|INDIRECT)$/i;
  // 从日志详情文本里提取第一个 http(s) 网址（日志里常混着描述文字，只需要其中的链接）。
  function extractFirstUrl(detail) {
    if (!detail || typeof detail !== 'string') return null;
    // 支持协议相对地址(//cdn.xxx/...), 协议相对资源的日志键统一取绝对 URL
    // (协议相对不参与截断, 加白链接按绝对 URL 键命中)
    var m = detail.match(/(?:https?:)?\/\/[^\s]+/);
    return m ? m[0] : null;
  }
  function getBaseReasonType(type) {
    return type ? type.replace(OBFUSCATION_SUFFIX_RE, '') : type;
  }

  // ======================== LRU缓存实现 ========================
    // 【功能】带容量上限与 TTL 的 LRU 缓存：URL 解析、第三方判定、白名单匹配等高频计算都走缓存。
    // 【机制】命中即刷新位置（LRU 语义）；超容量淘汰最久未用；TTL 过期自动失效。
    // 【注意】容量上限防长会话内存膨胀；缓存键设计成"参数拼接串"避免碰撞。
  class LRUCache {
    constructor(capacity, defaultTTL) {
      this.capacity = capacity || 100;
      this.defaultTTL = defaultTTL || 0;
      this.cache = new _Map();
    }
    get(key) {
      if (!this.cache.has(key)) return null;
      const entry = this.cache.get(key);
      const ttl = entry.ttl !== undefined ? entry.ttl : this.defaultTTL;
      if (ttl > 0 && Date.now() - entry.timestamp > ttl) {
        this.cache.delete(key);
        return null;
      }
      this.cache.delete(key);
      this.cache.set(key, entry);
      return entry.value;
    }
    set(key, value, ttl) {
      const finalTTL = ttl !== undefined ? ttl : this.defaultTTL;
      const entry = { value: value, timestamp: Date.now(), ttl: finalTTL };
      if (this.cache.has(key)) {
        this.cache.delete(key);
      } else if (this.cache.size >= this.capacity) {
        const firstKey = this.cache.keys().next().value;
        this.cache.delete(firstKey);
      }
      this.cache.set(key, entry);
    }
    has(key) {
      const entry = this.cache.get(key);
      if (!entry) return false;
      const ttl = entry.ttl !== undefined ? entry.ttl : this.defaultTTL;
      if (ttl > 0 && Date.now() - entry.timestamp > ttl) {
        this.cache.delete(key);
        return false;
      }
      return true;
    }
    delete(key) {
      return this.cache.delete(key);
    }
    clear() {
      this.cache.clear();
    }
  }


  const PUBLIC_SUFFIX_LIST = new Set([
    'co.uk', 'org.uk', 'me.uk', 'ltd.uk', 'plc.uk', 'net.uk', 'sch.uk', 'ac.uk', 'gov.uk',
    'com.cn', 'net.cn', 'org.cn', 'gov.cn', 'edu.cn',
    'co.jp', 'ne.jp', 'or.jp', 'go.jp', 'ac.jp', 'ad.jp',
    'com.au', 'net.au', 'org.au', 'edu.au', 'gov.au', 'asn.au', 'id.au',
    'co.nz', 'org.nz', 'net.nz', 'edu.nz', 'govt.nz',
    'com.hk', 'org.hk', 'edu.hk', 'gov.hk', 'net.hk',
    'com.tw', 'net.tw', 'org.tw', 'edu.tw', 'gov.tw', 'idv.tw', 'game.tw', 'ebiz.tw', 'club.tw'
  ]);
  const COMMON_SLD_HEURISTIC = ['com', 'co', 'org', 'net', 'edu', 'gov', 'ac', 'go'];

  // ======================== URL解析与缓存 ========================
    // 【功能】URL 解析的统一入口：提取 hostname、计算注册域（公共后缀表）、判定"第三方"、匹配第三方白名单。
    // 【机制】全部带 LRU 缓存（hostname/domain/thirdParty/whitelist 四张表）；第三方判定支持
    //        "含子域名"模式（严格模式=子域名也算第三方）与"仅不同主域"模式。
    // 【注意】data:/blob:/about: 等内联协议直接判"非同源资源"，不做网络解析。

  class URLResolutionCache {
    constructor() {
      this.hostnameCache = new LRUCache(CONFIG.CACHE_CAPACITY_URL, CONFIG.CACHE_TTL);
      this.domainCache = new LRUCache(CONFIG.CACHE_CAPACITY_URL, CONFIG.CACHE_TTL);
      this.thirdPartyCache = new LRUCache(CONFIG.CACHE_CAPACITY_URL, CONFIG.CACHE_TTL);
      this.whitelistCache = new LRUCache(CONFIG.CACHE_CAPACITY_SMALL, CONFIG.CACHE_TTL);
      this._wlHash = '';
      this._wlRe = null;
    }
    getHostname(url) {
      if (!url || typeof url !== 'string') return null;
      const cacheKey = 'hostname_' + url;
      if (this.hostnameCache.has(cacheKey)) return this.hostnameCache.get(cacheKey);
      if (
        url.startsWith('data:') ||
        url.startsWith('blob:') ||
        url.startsWith('about:blank')
      ) {
        this.hostnameCache.set(cacheKey, null, CONFIG.DATA_URL_TTL);
        return null;
      }
      try {
        const hostname = new _URL(url, _location.href).hostname;
        this.hostnameCache.set(cacheKey, hostname, CONFIG.CACHE_TTL);
        return hostname;
      } catch (e) {
        // URL 构造失败(页面重写 URL 或异常 URL)时用正则提取 hostname 兜底,
        // 避免域名解析失效导致第三方判定整体放行。
        var _m = /^(?:[a-z][a-z0-9+.-]*:)?\/\/([^/?#]*)/i.exec(url);
        if (_m && _m[1]) {
          var _h = _m[1].split('@').pop().split(':')[0].replace(/^\[|\]$/g, '').toLowerCase();
          if (_h) {
            this.hostnameCache.set(cacheKey, _h, CONFIG.INVALID_HOSTNAME_TTL);
            return _h;
          }
        }
        this.hostnameCache.set(cacheKey, null, CONFIG.INVALID_HOSTNAME_TTL);
        return null;
      }
    }
    isIPv4(hostname) {
      return /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname);
    }
    getDomain(hostname) {
      if (!hostname) return null;
      const cacheKey = 'domain_' + hostname;
      if (this.domainCache.has(cacheKey)) return this.domainCache.get(cacheKey);
      if (this.isIPv4(hostname)) {
        this.domainCache.set(cacheKey, hostname, CONFIG.CACHE_TTL);
        return hostname;
      }
      const parts = hostname.split('.');
      let domain = hostname;
      for (let i = 1; i <= parts.length; i++) {
        const candidate = parts.slice(-i).join('.');
        if (PUBLIC_SUFFIX_LIST.has(candidate)) {
          if (i + 1 <= parts.length) {
            domain = parts.slice(-(i + 1)).join('.');
          } else {
            domain = candidate;
          }
          break;
        }
      }
      if (domain === hostname && parts.length > 2) {
        const tld = parts[parts.length - 1];
        const sld = parts[parts.length - 2];
        const isCountryCode = /^[a-z]{2}$/i.test(tld);
        if (isCountryCode && COMMON_SLD_HEURISTIC.indexOf(sld) !== -1) {
          domain = parts.slice(-3).join('.');
        } else {
          domain = parts.slice(-2).join('.');
        }
      }
      this.domainCache.set(cacheKey, domain, CONFIG.CACHE_TTL);
      return domain;
    }
    isThirdPartyHost(resourceHostname, currentHost, blockParentSubDomains) {
      if (!resourceHostname) return false;
      const cacheKey = 'thirdparty_' + resourceHostname + '_' + currentHost + '_' + blockParentSubDomains;
      if (this.thirdPartyCache.has(cacheKey)) return this.thirdPartyCache.get(cacheKey);
      let isThirdParty = false;
      if (!currentHost || !resourceHostname) {
        isThirdParty = false;
      } else if (resourceHostname === currentHost) {
        isThirdParty = false;
      } else if (blockParentSubDomains) {
        isThirdParty = true;
      } else {
        const currentDomain = this.getDomain(currentHost);
        const resourceDomain = this.getDomain(resourceHostname);
        isThirdParty = currentDomain !== resourceDomain;
      }
      this.thirdPartyCache.set(cacheKey, isThirdParty, CONFIG.CACHE_TTL);
      return isThirdParty;
    }
    isWhitelisted(url, thirdPartyWhitelist) {
      if (!url || !thirdPartyWhitelist) return false;
      const cacheKey = 'whitelist_' + url + '_' + _location.hostname;
      if (this.whitelistCache.has(cacheKey)) return this.whitelistCache.get(cacheKey);
      let isWhitelisted = false;
      // URL 全匹配分支（含协议/路径的白名单项）
      for (const pattern of thirdPartyWhitelist) {
        if (!pattern) continue;
        if (pattern.includes('://') && url.includes(pattern)) {
          isWhitelisted = true;
          break;
        }
      }
      if (!isWhitelisted) {
        // 主机名通配分支: 组合正则按白名单内容哈希预编译缓存（替代每次调用现场编译）
        try {
          const h = thirdPartyWhitelist.slice().sort().join('\x00');
          if (h !== this._wlHash) {
            this._wlHash = h;
            this._wlRe = null;
            const parts = [];
            for (const pattern of thirdPartyWhitelist) {
              if (!pattern || pattern.includes('://')) continue;
              let ph = pattern.startsWith('*.') ? pattern.substring(2) : pattern;
              ph = ph.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
              parts.push('(^|\\.)' + ph + '$');
            }
            if (parts.length) {
              try { this._wlRe = new RegExp(parts.join('|')); } catch (e2) { this._wlRe = null; }
            }
          }
          if (this._wlRe) {
            const urlHost = new _URL(url, _location.href).hostname;
            if (this._wlRe.test(urlHost)) isWhitelisted = true;
          }
        } catch (e) {
          // 退化: 逐个字符串包含匹配
          for (const pattern of thirdPartyWhitelist) {
            if (pattern && url.includes(pattern)) {
              isWhitelisted = true;
              break;
            }
          }
        }
      }
      this.whitelistCache.set(cacheKey, isWhitelisted, CONFIG.CACHE_TTL);
      return isWhitelisted;
    }
    clear() {
      this.hostnameCache.clear();
      this.domainCache.clear();
      this.thirdPartyCache.clear();
      this.whitelistCache.clear();
    }
  }
  const urlCache = new URLResolutionCache();


  // ======================== 已处理元素缓存 ========================
    // 【功能】记录"已经处理过"的元素（WeakSet，不泄漏），防止同一元素被多条路径重复隐藏/重复记日志。
    // 【机制】拦截/中性化元素时 markAsProcessed；检查入口先 isProcessed 短路。
    // 【注意】WeakSet 键弱引用，元素被 GC 后自动消失；「重置缓存」用于设置变更后强制全量重扫。
  const ProcessedElementsCache = {
    _processedElements: new WeakSet(),
    isProcessed(element) {
      return _isElementLike(element) && this._processedElements.has(element);
    },
    markAsProcessed(element) {
      if (_isElementLike(element)) this._processedElements.add(element);
    },

    clear() {
      this._processedElements = new WeakSet();
    },
  };


  // ======================== 模块名称映射 ========================
    // 【功能】模块内部键名 → 面板显示名（拦截日志/模块列表用）。
  const MODULE_NAMES = {
    removeInlineScripts: '移除内嵌脚本',
    removeExternalScripts: '移除外联脚本',
    blockDynamicScripts: '拦截动态脚本',
    interceptThirdParty: '拦截第三方资源',
    overlayIntercept: '覆盖层拦截',
    elementCssBlock: 'CSS规则引擎',
    manageCSP: 'CSP策略管理',
    scriptBlacklistMode: '脚本黑名单模式',
  };

  // ======================== 通用工具函数 ========================
    // 【功能】全脚本共享的纯函数工具集：截断/主机名/第三方判定/内容标识/空容器判定等。
    // 【机制】isThirdParty 走 URL 缓存；getContentIdentifier 生成日志与白名单用的内容键；
    //        isContainerEmpty/isSuspiciousAdContainer 供"残留容器清理"识别空广告位。
    // 【注意】内容键(ci)是"日志可加白"的基础，各路径必须使用同一公式。
  const Utils = {
    truncateString: function (str, maxLength) {
      maxLength = maxLength || CONFIG.CONTENT_PREVIEW_LENGTH;
      if (typeof str !== 'string') return '';
      if (str.length <= maxLength) return str;
      return str.slice(0, maxLength) + '...';
    },
    getCurrentHostname: function () {
      return _location.hostname;
    },
    isElement: function (el) {
      return _isElementLike(el);
    },
    getScriptContentPreview: function (scriptElement) {
      if (!scriptElement || scriptElement.tagName !== 'SCRIPT') return '';
      return this.truncateString(
        scriptElement.textContent,
        CONFIG.CONTENT_PREVIEW_LENGTH
      );
    },
    getIframeSrcPreview: function (iframeElement) {
      if (!iframeElement || iframeElement.tagName !== 'IFRAME') return '';
      return this.truncateString(iframeElement.src, CONFIG.CONTENT_PREVIEW_LENGTH);
    },
    getResourceHostname: function (url) {
      return urlCache.getHostname(url);
    },
    getDomain: function (hostname) {
      return urlCache.getDomain(hostname);
    },
    isThirdPartyHost: function (resourceHostname, currentHost, blockParentSubDomains) {
      return urlCache.isThirdPartyHost(
        resourceHostname,
        currentHost,
        blockParentSubDomains
      );
    },
    isThirdParty: function (url, blockParentSubDomains) {
      blockParentSubDomains = blockParentSubDomains !== undefined ? blockParentSubDomains : true;
      if (!url) return false;
      try {
        var urlObj = new _URL(url, _location.href);
        var hostname = urlObj.hostname;
        if (!hostname || url.startsWith('data:') || url.startsWith('blob:')) return false;
        return urlCache.isThirdPartyHost(hostname, this.getCurrentHostname(), blockParentSubDomains);
      } catch (e) {
        // URL 构造失败(页面重写 window.URL 或异常 URL)时回退用缓存 hostname 解析,
        // 与 getHostname 同公式兜底, 避免第三方判定整体放行
        var _tpFbHost = null;
        try { _tpFbHost = urlCache.getHostname(url); } catch (_e2) {}
        if (_tpFbHost && _tpFbHost !== 'data:' && _tpFbHost !== 'blob:') {
          return urlCache.isThirdPartyHost(_tpFbHost, this.getCurrentHostname(), blockParentSubDomains);
        }
        return false;
      }
    },
    shouldInterceptByModule: function (element, moduleKey) {
      if (!currentConfig.modules[moduleKey]) return false;
      if (
        ProcessedElementsCache.isProcessed(element) ||
        this.isParentProcessed(element)
      )
        return false;
      if (Whitelisting.isElementWhitelisted(element, moduleKey)) return false;
      return true;
    },
    getBlockParentSubDomainsSetting: function () {
      return !!currentConfig.thirdPartyStrictMode;
    },
    isUIElement: function (el) {
      return (
        el &&
        el.classList &&
        (el.classList.contains('mask') ||
          el.classList.contains('panel') ||
          el.id === 'sc' && el.getAttribute('data-role') === 'settings-container')
      );
    },
    isPanelElement: function (el) {
      return el && el.classList && el.classList.contains('panel');
    },
    isAnyModuleEnabled: function () {
      var mv = Object.values(currentConfig.modules);
      for (var i = 0; i < mv.length; i++) {
        if (mv[i] === true) return true;
      }
      return false;
    },
    isContainerEmpty: function (container, ignoreProcessedFlag) {
      ignoreProcessedFlag = ignoreProcessedFlag !== undefined ? ignoreProcessedFlag : true;
      if (!this.isElement(container)) return false;
      if (
        container.children.length === 0 &&
        container.textContent.trim() === ''
      ) {
        return this.isSuspiciousAdContainer(container);
      }
      let hasVisibleContent = false;
      for (const child of container.childNodes) {
        if (child.nodeType === _Node.TEXT_NODE && child.textContent.trim().length > 0) {
          hasVisibleContent = true;
          break;
        }
        if (child.nodeType === _Node.ELEMENT_NODE) {
          const el = child;
          if (ignoreProcessedFlag && ProcessedElementsCache.isProcessed(el)) continue;
          const style = _getComputedStyle(el);
          if (
            style.display !== 'none' &&
            style.visibility !== 'hidden' &&
            style.opacity !== '0'
          ) {
            if (
              el.tagName === 'IMG' ||
              el.tagName === 'VIDEO' ||
              el.tagName === 'CANVAS' ||
              (el.textContent && el.textContent.trim().length > 0)
            ) {
              hasVisibleContent = true;
              break;
            }
            if (
              el.offsetWidth > 0 &&
              el.offsetHeight > 0 &&
              el.tagName !== 'BR' &&
              el.tagName !== 'HR'
            ) {
              hasVisibleContent = true;
              break;
            }
          }
        }
      }
      return !hasVisibleContent;
    },
    isSuspiciousAdContainer: function (container) {
      if (!this.isElement(container)) return false;
      var is = container.style;
      if (is) {
        if (is.display === 'none' || is.visibility === 'hidden' || is.opacity === '0') return false;
        var ipos = (is.position || '').toLowerCase();
        if (ipos === 'fixed') return true;
        if (ipos === 'absolute' || ipos === 'sticky') return true;
      }
      const style = _getComputedStyle(container);
      const hasVisualStyling = (style.backgroundColor !== 'rgba(0, 0, 0, 0)' &&
        style.backgroundColor !== 'transparent') ||
        style.backgroundImage !== 'none' ||
        style.borderWidth !== '0px' ||
        style.boxShadow !== 'none';
      const hasSuspiciousPosition = style.position === 'absolute' || style.position === 'fixed' || style.position === 'sticky';
      const hasSuspiciousSize = parseFloat(style.width) > CONFIG.RESIDUAL_MIN_WIDTH &&
        parseFloat(style.height) > CONFIG.RESIDUAL_MIN_HEIGHT;
      const hasSpacing = style.paddingTop !== '0px' || style.paddingBottom !== '0px' ||
        style.marginTop !== '0px' || style.marginBottom !== '0px';
      const relativeWithStyle = style.position === 'relative' && hasVisualStyling &&
        (hasSuspiciousSize || hasSpacing);
      const isVisible = style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
      return (
        isVisible &&
        (hasSuspiciousPosition || hasSuspiciousSize || hasSpacing || relativeWithStyle)
      );
    },

    isParentProcessed: function (element) {
      let parent = element.parentElement;
      let depth = 0;
      while (parent && depth < 10) {
        if (ProcessedElementsCache.isProcessed(parent)) return true;
        parent = parent.parentElement;
        depth++;
      }
      return false;
    },
    // 黑名单缓存: 内容按哈希检测变化, 避免每次脚本检查都重建 Set/数组（热路径性能）
    _blHash: '',
    _blCacheSet: null,
    _blCacheArray: null,
    _refreshBlacklistCache: function () {
      // 用插入序拼接做哈希: 内容不变则哈希不变, 增删任意项立即变化(无需排序, O(n))
      var h = Array.from(currentConfig.scriptBlacklist).join('\x00')
        + '\x00' + (currentConfig.builtinBlacklistEnabled ? '1' : '0')
        + '\x00' + Array.from(currentConfig.removedBuiltinKeywords).join('\x00');
      if (h !== this._blHash) {
        this._blHash = h;
        var set = new Set(currentConfig.scriptBlacklist);
        if (currentConfig.builtinBlacklistEnabled) {
          BUILTIN_BLACKLIST_KEYWORDS.forEach(function (k) {
            if (!currentConfig.removedBuiltinKeywords.has(k)) set.add(k);
          });
        }
        this._blCacheSet = set;
        this._blCacheArray = Array.from(set);
      }
    },
    getActiveBlacklistSet: function () {
      this._refreshBlacklistCache();
      return this._blCacheSet;
    },
    getActiveBlacklistArray: function () {
      this._refreshBlacklistCache();
      return this._blCacheArray;
    },
    getContentIdentifier: function (element, reasonType) {
      if (!element && !reasonType) return null;
      if (element && this.isElement(element)) {
        const tagName = element.tagName;
        const handle = {
          SCRIPT: function (el) {
            return el.src
              ? 'SCRIPT_SRC: ' + Utils.truncateString(_stableSrcKey(el.src), CONFIG.LOG_DETAIL_LENGTH)
              : 'SCRIPT_CONTENT: ' + Utils.truncateString(el.textContent, CONFIG.LOG_DETAIL_LENGTH);
          },
          IFRAME: function (el) {
            // 用去参稳定键(易变参数 token/sign/ts 等不参与), 加白刷新后依然有效
            var _is = el.src || '';
            return _is ? 'IFRAME_SRC: ' + Utils.truncateString(_stableSrcKey(_is), CONFIG.LOG_DETAIL_LENGTH) : null;
          },
          IMG: function (el) {
            var src = el.src || el.getAttribute('data-src') || el.href || '';
            return src ? 'IMG_SRC: ' + Utils.truncateString(src, CONFIG.LOG_DETAIL_LENGTH) : null;
          },
          A: function (el) {
            return el.href ? 'A_HREF: ' + Utils.truncateString(el.href, CONFIG.LOG_DETAIL_LENGTH) : null;
          },
          LINK: function (el) {
            return (el.rel === 'stylesheet' && el.href) ? 'CSS_HREF: ' + Utils.truncateString(el.href, CONFIG.LOG_DETAIL_LENGTH) : null;
          },
          STYLE: function (el) {
            return 'STYLE_CONTENT: ' + Utils.truncateString(el.textContent, CONFIG.LOG_DETAIL_LENGTH);
          },
          EMBED: function (el) {
            return el.src ? 'EMBED_SRC: ' + Utils.truncateString(el.src, CONFIG.LOG_DETAIL_LENGTH) : null;
          },
          OBJECT: function (el) {
            return el.data ? 'OBJECT_DATA: ' + Utils.truncateString(el.data, CONFIG.LOG_DETAIL_LENGTH) : null;
          }
        };
        var fn = handle[tagName];
        if (fn) return fn(element);
        var src = element.src || element.getAttribute('data-src') || element.href || element.action || '';
        if (src) return tagName + '_SRC: ' + Utils.truncateString(src, CONFIG.LOG_DETAIL_LENGTH);
        return null;
      }
      if (reasonType && typeof reasonType.detail === 'string') {
        var baseType = getBaseReasonType(reasonType.type);
        var prefix = HASH_TYPE_PREFIX_MAP[baseType];
        if (prefix) return prefix + ': ' + generateContentHash(reasonType.detail);
        if (reasonType.type === 'THIRD_PARTY') {
          var url = extractFirstUrl(reasonType.detail);
          if (url) {
            try { url = new _URL(url, _location.href).href; } catch(e) {}
            return 'THIRD_PARTY_URL: ' + Utils.truncateString(url, CONFIG.LOG_DETAIL_LENGTH);
          }
          return 'THIRD_PARTY_DETAIL: ' + Utils.truncateString(reasonType.detail, CONFIG.LOG_DETAIL_LENGTH);
        }
        if (reasonType.type === 'SCRIPT_BLACKLIST') return 'BLACKLIST: ' + Utils.truncateString(reasonType.detail, CONFIG.LOG_DETAIL_LENGTH);
        if (reasonType.type === '内联事件') return 'INLINE_EVENT: ' + reasonType.detail;
        if (reasonType.type === 'javascript URL') return 'JAVASCRIPT_URL: ' + reasonType.detail;
        if (reasonType.type === '内嵌脚本移除') return 'INLINE_SCRIPT: ' + generateContentHash(reasonType.detail);
        if (reasonType.type === '外联脚本移除') {
          var _eu = extractFirstUrl(reasonType.detail);
          if (_eu) {
            try { _eu = new _URL(_eu, _location.href).href; } catch(e) {}
            return 'EXTERNAL_SCRIPT: ' + Utils.truncateString(_eu, CONFIG.LOG_DETAIL_LENGTH);
          }
          return 'EXTERNAL_SCRIPT: ' + Utils.truncateString(reasonType.detail, CONFIG.LOG_DETAIL_LENGTH);
        }
        return 'LOG_DETAIL: ' + Utils.truncateString(reasonType.detail, CONFIG.LOG_DETAIL_LENGTH);
      }
      return null;
    },
    externalScriptKey: function (src) {
      // 外联脚本移除的独立白名单键: 解析后的绝对 URL(去随机参数) 键, 与第三方/脚本黑名单路径的
      // SCRIPT_SRC 键互不干扰——外联移除加白只放行外联移除拦截, 其他模块照拦
      var _es = src || '';
      try { _es = new _URL(_es, _location.href).href; } catch(e) {}
      return 'EXTERNAL_SCRIPT: ' + Utils.truncateString(_stableSrcKey(_es), CONFIG.LOG_DETAIL_LENGTH);
    },
    externalScriptStructKey: function (src) {
      // 外联脚本"结构稳定键"(与精确键 EXTERNAL_SCRIPT 配套的宽键): 广告外联脚本 URL 每次刷新常换
      // ——路径带时间戳/长数字段(1787740740438.AkenPpLa….txt)、随机子域(267813t.)、随机后缀扩展名,
      // 精确键随 URL 漂移导致"加白后刷新仍拦"。结构键剥掉这些易变成分:
      // 查询参数、路径内 ≥8 位数字段、非脚本后缀扩展名; 域名归一为二级主域+端口（去随机子域前缀）。
      // 加白时精确键+结构键双写, 判定时任一命中即放行（与覆盖层多钥匙同思路）。
      var _es = src || '';
      try { _es = new _URL(_es, _location.href).href; } catch(e) {}
      try {
        var _u = new _URL(_es);
        var _host = '';
        var _h = String(_u.hostname || '').toLowerCase();
        if (_h) {
          var _labels = _h.split('.');
          _host = _labels.length >= 2 ? _labels.slice(-2).join('.') : _h;
        }
        if (_u.port) _host += ':' + _u.port;
        var _p = String(_u.pathname || '').replace(/\d{8,}/g, '').replace(/\/{2,}/g, '/');
        if (!/\.(?:js|mjs|cjs)$/i.test(_p)) {
          var _li = _p.lastIndexOf('.');
          var _ls = _p.lastIndexOf('/');
          if (_li > _ls) _p = _p.slice(0, _li);
        }
        _p = _p.replace(/\.{2,}/g, '.').replace(/^\./, '');
        return 'EXTERNAL_SCRIPT_STRUCT: ' + Utils.truncateString(_host + _p, CONFIG.LOG_DETAIL_LENGTH);
      } catch(e) {
        return 'EXTERNAL_SCRIPT_STRUCT: ' + Utils.truncateString(_stableSrcKey(_es), CONFIG.LOG_DETAIL_LENGTH);
      }
    },
  };


  let _kwRegex = null, _kwHash = '';
  function getKeywordWhitelistRegex() {
    const hash = Array.from(currentConfig.keywordWhitelist).sort().join('\x00');
    if (hash === _kwHash) return _kwRegex;
    _kwHash = hash;
    if (!hash) {
      _kwRegex = null;
      return null;
    }
    const escaped = Array.from(currentConfig.keywordWhitelist).map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    try {
      _kwRegex = new RegExp(escaped.join('|'));
    } catch(e) {
      _kwRegex = null;
    }
    return _kwRegex;
  }


  let _tpRegex = null, _tpHash = '';
  function getThirdPartyWhitelistRegex() {
    const hash = currentConfig.thirdPartyWhitelist.slice().sort().join('\x00');
    if (hash === _tpHash) return _tpRegex;
    _tpHash = hash;
    if (!hash) {
      _tpRegex = null;
      return null;
    }
    const escaped = currentConfig.thirdPartyWhitelist.map(p => {
      let prefix = p.startsWith('*.') ? '(^|\\.)' : '^';
      let host = p.startsWith('*.') ? p.substring(2) : p;
      host = host.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return prefix + host + '$';
    });
    try {
      _tpRegex = new RegExp(escaped.join('|'), 'i');
    } catch(e) {
      _tpRegex = null;
    }
    return _tpRegex;
  }


  // ======================== shouldBlockResource：第三方资源拦截判定 ========================
    // 【功能】判断资源 URL 是否应被"拦截第三方资源"模块拦截：第三方域名且不在白名单内。
    // 【机制】快速路径短路（短 URL/锚点/相对路径/内联协议直接放行）→ 链接级白名单（加白链接）→
    //        hostname 缓存 → 白名单正则 → 第三方判定（URLResolutionCache）；结果带 LRU 缓存（防重复 URL 构造）。
    // 【注意】所有资源标签（script/iframe/img/link 等）共用此判定，是第三方拦截的核心入口。
    //        链接级白名单键用解析后的绝对地址生成（去随机参数, 与日志/检查侧同公式），
    //        只放行该具体链接，同域名其他资源不受影响；命中白名单不写缓存，白名单变更后即时生效。
  function _thirdPartyUrlKey(url) {
    try { url = new _URL(url, _location.href).href; } catch (e) {}
    return 'THIRD_PARTY_URL: ' + Utils.truncateString(_stableSrcKey(url), CONFIG.LOG_DETAIL_LENGTH);
  }
  var _sbrCache = new LRUCache(1000, CONFIG.CACHE_TTL);
  function _getSbrCache() {
    return _sbrCache;
  }
  function _clearSbrCache() {
    _sbrCache = new LRUCache(1000, CONFIG.CACHE_TTL);
  }

  function shouldBlockResource(url) {
    if (!url || typeof url !== 'string') return false;

    if (url.length < 5) return false;
    var fc = url.charAt(0);

    if (fc === '#') return false;
    if (fc === '/' && url.charAt(1) !== '/') return false;
    if (fc === '.' && (url.startsWith('./') || url.startsWith('../'))) return false;

    if (url.startsWith('data:') || url.startsWith('blob:') || url.startsWith('javascript:') || url.startsWith('about:')) return false;

    // 链接级白名单: 命中具体 URL 键即放行; 不写缓存, 白名单增删即时生效
    // THIRD_PARTY_URL 键来自"加白链接", SCRIPT_SRC 键来自脚本黑名单/动态日志加白,
    // EXTERNAL_SCRIPT 键来自外联移除日志加白
    // (脚本同时是第三方资源时, TP 判定同样按脚本任一加白键放行, 三套加白互不干扰)
    if (currentConfig.whitelist.size > 0) {
      try {
        var _rslvUrl = new _URL(url, _location.href).href;
        var _esKw = Utils.externalScriptStructKey ? Utils.externalScriptStructKey(_rslvUrl) : null;
        if (currentConfig.whitelist.has('THIRD_PARTY_URL: ' + Utils.truncateString(_stableSrcKey(_rslvUrl), CONFIG.LOG_DETAIL_LENGTH)) ||
            currentConfig.whitelist.has('SCRIPT_SRC: ' + Utils.truncateString(_stableSrcKey(_rslvUrl), CONFIG.LOG_DETAIL_LENGTH)) ||
            currentConfig.whitelist.has('EXTERNAL_SCRIPT: ' + Utils.truncateString(_stableSrcKey(_rslvUrl), CONFIG.LOG_DETAIL_LENGTH)) ||
            (_esKw && currentConfig.whitelist.has(_esKw))) return false;
      } catch(e) { _debugCatch(e, "wlUrl"); }
    }

    var cache = _getSbrCache();
    var cached = cache.get(url);
    if (cached != null) return cached;

    var hostname = urlCache.getHostname(url);
    if (!hostname) { cache.set(url, false); return false; }
    if (hostname === _location.hostname) { cache.set(url, false); return false; }
    const tpRegex = getThirdPartyWhitelistRegex();
    if (tpRegex) {
      try {
        if (tpRegex.test(hostname)) { cache.set(url, false); return false; }
      } catch(e) { _debugCatch(e, "urlHost"); }
    }

    const kr = getKeywordWhitelistRegex();
    if (kr && kr.test(url)) { cache.set(url, false); return false; }
    var result = Utils.isThirdParty(url, Utils.getBlockParentSubDomainsSetting());

    cache.set(url, result);
    return result;
  }


  function parseLogContext(element, reason) {
    let elementIdentifier = '[未知元素]';
    let interceptedContent = '[无法获取内容]';
    let contentIdentifier = null;
    let resourceDomain = '';

    if (reason && reason.elementContentIdentifier) {
      contentIdentifier = reason.elementContentIdentifier;
    }
    if (reason && typeof reason.detail === 'string') {
      var baseType = getBaseReasonType(reason.type);
      const isSpecificType = [
        '内联事件',
        'javascript URL',
        ...HASH_TYPE_NAMES,
        'THIRD_PARTY',
        'SCRIPT_BLACKLIST',
        'THIRD_PARTY_SCAN',
        '内嵌脚本移除',
        '外联脚本移除',
        'THIRD_PARTY_HTML_INJECTION',
        'TRACKING_PIXEL',
      ].includes(baseType) || baseType.indexOf('外联脚本移除') === 0;   // 内容命中/已知坏变体同样按 detail 显示（日记列出命中关键词）

      if (isSpecificType || !Utils.isElement(element)) {
        interceptedContent = Utils.truncateString(reason.detail, CONFIG.LOG_DETAIL_LENGTH);
        elementIdentifier = reason.type ? '[' + reason.type + ']' : '[未知类型]';
        if (!contentIdentifier) {
          if (HASH_TYPE_NAMES.includes(baseType)) {
            contentIdentifier = Utils.getContentIdentifier(null, {
              type: baseType,
              detail: reason.rawDetail || reason.detail,
            });
          } else {
            contentIdentifier = Utils.getContentIdentifier(null, reason);
          }
        }
        var url = extractFirstUrl(reason.detail);
        if (url) {
          resourceDomain = Utils.getResourceHostname(url) || '';
          try { url = new _URL(url, _location.href).href; } catch(e) {}
        } else {
          url = '';
        }
        if (isSpecificType) return { elementIdentifier, interceptedContent, contentIdentifier, resourceDomain, url };
      }
    }
    if (Utils.isElement(element)) {
      const tagName = element.tagName;
      // 覆盖层类日志: 显示层去随机 id/类名, 改用结构槽位短标识(只影响显示;
      // 加白写入的 contentIdentifier/备钥组与判定链路不受影响)
      if (reason && getBaseReasonType(reason.type) === 'OVERLAY') {
        elementIdentifier = _overlaySlotDisplay(element) || tagName;
      } else {
        const id = element.id ? '#' + element.id : '';
        const className = element.className ? '.' + element.className.split(/\s+/).join('.') : '';
        elementIdentifier = tagName + id + className;
      }
      if (!contentIdentifier) {
        contentIdentifier = Utils.getContentIdentifier(element);
      }
      const tagHandlers = {
        SCRIPT: () => {
          if (element.src) {
            interceptedContent = '外联脚本: ' + Utils.truncateString(element.src, CONFIG.LOG_DETAIL_LENGTH);
            resourceDomain = Utils.getResourceHostname(element.src) || '';
          } else {
            interceptedContent = '内嵌脚本: ' + Utils.getScriptContentPreview(element);
          }
        },
        IFRAME: () => {
          interceptedContent = Utils.getIframeSrcPreview(element);
          if (element.src) resourceDomain = Utils.getResourceHostname(element.src) || '';
        },
        IMG: () => {
          const src = element.src || element.dataset.src || element.getAttribute('data-src') || '';
          interceptedContent = Utils.truncateString(src, CONFIG.LOG_DETAIL_LENGTH);
          if (src) resourceDomain = Utils.getResourceHostname(src) || '';
        },
        A: () => {
          interceptedContent = Utils.truncateString(element.href || '', CONFIG.LOG_DETAIL_LENGTH);
          if (element.href) resourceDomain = Utils.getResourceHostname(element.href) || '';
        },
        LINK: () => {
          interceptedContent = Utils.truncateString(element.href || '', CONFIG.LOG_DETAIL_LENGTH);
          if (element.href) resourceDomain = Utils.getResourceHostname(element.href) || '';
        },
        STYLE: () => {
          interceptedContent = Utils.truncateString(element.textContent, CONFIG.LOG_DETAIL_LENGTH);
        },
        EMBED: () => {
          interceptedContent = Utils.truncateString(element.src || '', CONFIG.LOG_DETAIL_LENGTH);
          if (element.src) resourceDomain = Utils.getResourceHostname(element.src) || '';
        },
        OBJECT: () => {
          interceptedContent = Utils.truncateString(element.data || '', CONFIG.LOG_DETAIL_LENGTH);
          if (element.data) resourceDomain = Utils.getResourceHostname(element.data) || '';
        },
      };
      if (tagHandlers[tagName]) tagHandlers[tagName]();
      else interceptedContent = Utils.truncateString(element.outerHTML, CONFIG.LOG_DETAIL_LENGTH);
      if (!url) {
        try {
          var _elRes = element.src || element.href || element.getAttribute('data-src') || element.action || element.data || '';
          if (_elRes) url = new _URL(_elRes, _location.href).href;
        } catch(e) {}
      }
    }
    return { elementIdentifier, interceptedContent, contentIdentifier, resourceDomain, url: url || '' };
  }

  // ======================== 日志管理 ========================
    // LogManager.add 统一记录拦截/放行事件到面板日志；contentIdentifier 供白名单加白使用。
  const LogManager = {
    logs: [],
    maxLogs: CONFIG.LOG_MAX,
    _logSeq: 0,
    loggedContentIdentifiers: new LRUCache(CONFIG.LOG_MAX, CONFIG.LOG_IDENTIFIER_TTL),
    add: function (moduleKey, element, reason) {
      // 模块门控: 跳转拦截(redirectBlocker)是独立开关而非模块——只开跳转拦截、其他模块全关时
      // 也必须能记日记, 否则可疑链接阻止/重定向链等行为无法加白。
      if (!Utils.isAnyModuleEnabled() && !currentConfig.redirectBlockerEnabled) return;
      if (element !== null && element !== undefined && !Utils.isElement(element)) return;
      if (reason !== null && reason !== undefined && typeof reason !== 'object') return;
      // 日记键白名单一致性: 该日志自带的键已在白名单 → 直接不记（与各拦截路径的加白判定保持一致）
      if (reason && reason.elementContentIdentifier && currentConfig.whitelist.has(reason.elementContentIdentifier)) return;
      if (
        Whitelisting.isElementWhitelisted(element, moduleKey) ||
        Whitelisting.isReasonWhitelisted(reason, moduleKey)
      )
        return;
      const ctx = parseLogContext(element, reason);
      var { elementIdentifier, interceptedContent, contentIdentifier, resourceDomain, url } = ctx;
      if (!contentIdentifier) {
        var fallbackSource = moduleKey;
        if (reason && typeof reason.detail === 'string') {
          fallbackSource += ':' + reason.detail;
        } else if (reason && typeof reason.type === 'string') {
          fallbackSource += ':' + reason.type;
        }
        contentIdentifier = 'FALLBACK_' + generateContentHash(fallbackSource);
      }
      if (contentIdentifier && this.loggedContentIdentifiers.has(contentIdentifier)) {
        return;
      }
      this.logs.push({
        id: ++this._logSeq,
        moduleKey: moduleKey,
        module: MODULE_NAMES[moduleKey] || moduleKey,
        element: elementIdentifier,
        content: interceptedContent,
        domain: resourceDomain,
        url: url || '',
        timestamp: Date.now(),
        contentIdentifier: contentIdentifier,
        altContentIdentifiers: (reason && reason.altContentIdentifiers) || null,
      });
      this.loggedContentIdentifiers.set(contentIdentifier, true);
      if (this.logs.length > this.maxLogs) {
        const removed = this.logs.shift();
        this.loggedContentIdentifiers.delete(removed.contentIdentifier);
      }
    },
    clearLoggedIdentifiers: function () {
      this.loggedContentIdentifiers.clear();
    },
  };

  // ======================== 白名单管理 ========================
    // 用户加白的内容（URL/脚本/关键词/域名）在此维护；白名单命中则跳过拦截并记录放行。
  const Whitelisting = {
    isElementWhitelisted: function (element, moduleKey) {
      if (!element || !Utils.isElement(element)) return false;
      // 快速路径: 无白名单时不构造内容标识（每元素字符串拼接, 热路径性能）
      if (currentConfig.whitelist.size > 0) {
        const ci = Utils.getContentIdentifier(element);
        if (ci && currentConfig.whitelist.has(ci)) return true;
      }

      if (moduleKey === 'interceptThirdParty' && currentConfig.modules.interceptThirdParty) {
        const hostname = Utils.getResourceHostname(
          element.src || element.href || element.action || element.data || element.getAttribute('data-src') || ''
        );
        if (hostname) {
          const ru = element.src || element.href || element.action || element.data || element.getAttribute('data-src') || '';
          if (urlCache.isWhitelisted(ru, currentConfig.thirdPartyWhitelist)) return true;
        }
      }

      if (currentConfig.keywordWhitelist.size > 0) {
        const kr = getKeywordWhitelistRegex();
        if (kr) {
          const sc = element.textContent || '';
          const src = element.src || element.href || element.action || element.data || element.getAttribute('data-src') || '';
          if ((sc && kr.test(sc)) || (src && kr.test(src))) return true;
        }
      }
      return false;
    },
    isReasonWhitelisted: function (reason, moduleKey) {
      if (!reason || typeof reason.detail !== 'string') return false;
      var baseType = reason.type ? reason.type.replace(/_(?:OBFUSCATED|INDIRECT)$/i, '') : reason.type;
      var ci = Utils.getContentIdentifier(null, {
        type: baseType,
        detail: reason.rawDetail || reason.detail,
      });
      if (ci && currentConfig.whitelist.has(ci)) return true;
      if (moduleKey === 'interceptThirdParty' && currentConfig.modules.interceptThirdParty) {
        const um = reason.detail.match(/https?:\/\/[^\s]+/);
        if (um) {
          if (urlCache.isWhitelisted(um[0], currentConfig.thirdPartyWhitelist)) return true;
        }
      }
      if (currentConfig.keywordWhitelist.size > 0) {
        const kr = getKeywordWhitelistRegex();
        if (kr && kr.test(reason.detail)) return true;
      }
      return false;
    },
    isCodeWhitelisted: function (code, type) {
      if (typeof code !== 'string' || code.trim() === '') return false;
      if (currentConfig.keywordWhitelist.size > 0) {
        const kr = getKeywordWhitelistRegex();
        if (kr && kr.test(code)) return true;
      }
      var baseType = type ? type.replace(/_(?:OBFUSCATED|INDIRECT)$/i, '') : type;
      var ci = Utils.getContentIdentifier(null, { type: baseType, detail: code });
      if (ci && currentConfig.whitelist.has(ci)) return true;
      return false;
    },
    add: function (contentIdentifier, displayName) {
      if (!contentIdentifier || contentIdentifier.trim() === '') return;
      currentConfig.whitelist.add(contentIdentifier);
      if (displayName && typeof displayName === 'string' && displayName.trim() !== '') {
        currentConfig.whitelistDisplayNames.set(contentIdentifier, displayName.trim());
      }
      ConfigUpdater.saveNow();
    },
    addKeyword: function (keyword) {
      if (!keyword || keyword.trim() === '') return;
      currentConfig.keywordWhitelist.add(keyword.trim());
      ConfigUpdater.saveNow();
    },
    removeKeywordsMatchingDomain: function (domain) {
      let changed = false;
      const toRemove = [];
      for (const kw of currentConfig.keywordWhitelist) {
        if (kw === domain) {
          toRemove.push(kw);
        }
      }
      toRemove.forEach(function (k) {
        currentConfig.keywordWhitelist.delete(k);
        changed = true;
      });
      if (changed) ConfigUpdater.saveNow();
    },
    clearAllWhitelists: function () {
      currentConfig.whitelist.clear();
      currentConfig.keywordWhitelist.clear();
      currentConfig.thirdPartyWhitelist = [];
      currentConfig.whitelistDisplayNames.clear();
      ConfigUpdater.saveNow();
    },
  };


  function getLogWhitelistStatus(log) {
    if (currentConfig.whitelist.has(log.contentIdentifier)) return 'whitelisted';
    const kr = getKeywordWhitelistRegex();
    if (kr && (kr.test(log.content || '') || kr.test(log.domain || ''))) return 'keyword-whitelisted';
    if (log.moduleKey === 'interceptThirdParty' && log.domain) {
      // 域名补全协议再交给白名单判定(裸 hostname 会被当成相对路径解析成当前站点)
      var _wlD = /^[a-z][a-z0-9+.-]*:/i.test(log.domain) ? log.domain : 'http://' + log.domain;
      if (urlCache.isWhitelisted(_wlD, currentConfig.thirdPartyWhitelist)) return 'whitelisted';
    }
    return '';
  }


  function isThirdPartyUrl(url) {
    if (!url || typeof url !== 'string') return false;
    if (url.startsWith('#') || url.startsWith('javascript:')) return false;
    try {
      const targetUrl = new _URL(url, _location.href);
      const currentHost = _location.hostname;
      if (targetUrl.hostname === currentHost) return false;
      return urlCache.isThirdPartyHost(
        targetUrl.hostname,
        currentHost,
        !!currentConfig.thirdPartyStrictMode
      );
    } catch (e) {
      return false;
    }
  }

  // ======================== 追踪参数清洗工具 ========================


  const DEFAULT_TRACKING_PARAMS = [
    'utm_*', 'gclid', 'fbclid', 'msclkid', 'dclid', '*clid',
    'mc_*', 'track_*', 'click_*', 'aff_*', 'oly_*',
    '_ga', '_gl', '_gid', '_gac', 'is_story_h5', 'mid', 'plat_id', 'unique_*',
    'spm', 'scm', 'spmid', 'spm_*', 'from_spmid', 'buvid', 'buvid_*',
    'share_*', 'igshid', 'shreddit', 'sudaref', 'vd_source',
    'ADTAG', 'ascsubtag', 'dcs', 'irgwc', 'lipi', 'mpid',
    'trk', 'tracking', 'trackid', 'visit_id', 'click_id', 'affiliate_id', 'up_id',
    'from_*', 'medium', 'campaign', 'referring_source',
  ];
  // ==================== 追踪参数清洗器 ====================
    // 【功能】链接/请求的追踪参数清洗执行器：从 URL 中剥离 utm_*/fbclid 等跟踪标记。
    // 【机制】精确键 + 通配键（前缀匹配）双层匹配；清洗规则与网络层/DOM 层共用。

  const EnhancedTrackingCleaner = {
    _exactKeys: null,
    _prefixPatterns: null,
    _suffixPatterns: null,
    _substrPatterns: null,
    buildFromKeys: function(keys) {
      this._exactKeys = new Set();
      this._prefixPatterns = [];
      this._suffixPatterns = [];
      this._substrPatterns = [];
      if (!keys || !keys.length) return;
      for (var i = 0; i < keys.length; i++) {
        var k = (keys[i] || '').trim();
        if (!k) continue;
        var kl = k.toLowerCase();
        if (kl.indexOf('*') !== -1) {
          if (kl.startsWith('*') && kl.endsWith('*')) {
            this._substrPatterns.push(kl.slice(1, -1));
          } else if (kl.startsWith('*')) {
            this._suffixPatterns.push(kl.slice(1));
          } else if (kl.endsWith('*')) {
            this._prefixPatterns.push(kl.slice(0, -1));
          }
        } else {
          this._exactKeys.add(kl);
        }
      }
      this._compilePatterns();
    },
    _compilePatterns: function() {
      // 【黑名单预编译】先把用户配置的黑名单关键词/正则编译好存起来，
      // 后面比对时直接查缓存，不用每次现场编译（页面卡顿时这一步很关键）。
      if (this._prefixPatterns.length > 0) {
        this._prefixRegex = new RegExp('^(' + this._prefixPatterns.map(function(p){return p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');}).join('|') + ')', 'i');
      } else { this._prefixRegex = null; }
      if (this._suffixPatterns.length > 0) {
        this._suffixRegex = new RegExp('(' + this._suffixPatterns.map(function(p){return p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');}).join('|') + ')$', 'i');
      } else { this._suffixRegex = null; }
      if (this._substrPatterns.length > 0) {
        this._substrRegex = new RegExp(this._substrPatterns.map(function(p){return p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');}).join('|'), 'i');
      } else { this._substrRegex = null; }
    },
    isTrackingParam: function(paramName) {
      if (!paramName) return false;
      var lower = paramName.toLowerCase();
      if (this._exactKeys.has(lower)) return true;
      try { var decoded = decodeURIComponent(lower); if (decoded !== lower && this._exactKeys.has(decoded)) return true; } catch (e) {}
      var bi = lower.indexOf('[');
      if (bi > 0) {
        var base = lower.substring(0, bi);
        if (this._exactKeys.has(base)) return true;
        try { var db = decodeURIComponent(base); if (db !== base && this._exactKeys.has(db)) return true; } catch (e) {}
      }
      if (this._prefixRegex && this._prefixRegex.test(lower)) return true;
      if (this._suffixRegex && this._suffixRegex.test(lower)) return true;
      if (this._substrRegex && this._substrRegex.test(lower)) return true;
      try {
        var decodedFull = decodeURIComponent(lower);
        if (decodedFull !== lower) {
          if (this._exactKeys.has(decodedFull)) return true;
          if (this._prefixRegex && this._prefixRegex.test(decodedFull)) return true;
          if (this._suffixRegex && this._suffixRegex.test(decodedFull)) return true;
          if (this._substrRegex && this._substrRegex.test(decodedFull)) return true;
        }
      } catch(e) { _debugCatch(e, "this._suffixRegex.test(de"); }
      return false;
    },
    cleanUrl: function(url) {
      if (typeof url !== 'string') return url;
      if (url.charAt(0) === '#' || url.startsWith('javascript:') || url.startsWith('data:')) return url;
      // 无查询串/无 hash → 无追踪参数可剥: 直接返回, 免去 URL 解析
      // (URL 变化轮询与链接读取都是高频路径, 不带参数的 URL 占大多数)
      if (url.indexOf('?') === -1 && url.indexOf('#') === -1) return url;
      var parsed;
      try { parsed = new _URL(url, _location.href); } catch (e) { return url; }
      var self = this;
      var queryChanged = false;
      var kept = [];
      parsed.searchParams.forEach(function(value, key) {
        if (!self.isTrackingParam(key)) {
          kept.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
        } else { queryChanged = true; }
      });
      var hashChanged = false;
      var newHash = parsed.hash;
      if (parsed.hash && parsed.hash.length > 1) {
        var hc = parsed.hash.substring(1);
        if (hc.includes('=') || hc.includes('&')) {
          var hashPath = '';
          var hashSearch = hc;
          var qi = hc.indexOf('?');
          if (qi >= 0) { hashPath = hc.substring(0, qi); hashSearch = hc.substring(qi + 1); }
          try {
            var hp = new URLSearchParams(hashSearch);
            var hKept = [];
            hp.forEach(function(value, key) {
              if (!self.isTrackingParam(key)) {
                hKept.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
              } else { hashChanged = true; }
            });
            if (hashChanged) {
              newHash = '#' + hashPath + (hKept.length ? '?' + hKept.join('&') : '');
              if (newHash === '#') newHash = '';
            }
          } catch(e) { _debugCatch(e, "newHash"); }
        }
      }
      if (!queryChanged && !hashChanged) return url;
      var result = parsed.origin + parsed.pathname;
      if (kept.length) result += '?' + kept.join('&');
      if (newHash) result += newHash;
      if (url.charAt(0) === '/' && !url.startsWith('//')) {
        result = parsed.pathname + (kept.length ? '?' + kept.join('&') : '') + (newHash || '');
        if (!result.startsWith('/')) result = '/' + result;
      }
      return result;
    },
  };
  function rebuildTrackingParamRegex(keys) {
    currentConfig.trackingParamKeys = keys || [];
    EnhancedTrackingCleaner.buildFromKeys(keys);
  }

  if (!currentConfig.trackingParamKeys) {
    currentConfig.trackingParamKeys = [...DEFAULT_TRACKING_PARAMS];
  } else if (currentConfig.trackingParamKeys.length === 0) {
    var _glTpCheck = GM_getValue('adblock_gl_trackingParams', null);
    if (_glTpCheck === null) {
      currentConfig.trackingParamKeys = [...DEFAULT_TRACKING_PARAMS];
    }
  }
  EnhancedTrackingCleaner.buildFromKeys(currentConfig.trackingParamKeys);

  function cleanTrackingParams(url) {
    return EnhancedTrackingCleaner.cleanUrl(url);
  }

  // ======================== URL参数锁（尝试防止页面追加未知追踪参数） ========================
    // 记录页面已访问 URL 的参数集合；后续导航若被追加未记录参数（广告追踪）则剔除。
  var _cleanUrlLock = null;
  var _settingCleanUrlLock = false;

  function setCleanUrlLock(url) {
    if (_settingCleanUrlLock) return;
    _settingCleanUrlLock = true;
    try {
      var u = new _URL(url, _location.origin);
      var params = new Set();
      u.searchParams.forEach(function(v, k) { params.add(k); });
      _cleanUrlLock = { pathname: u.pathname, params: params };
    } catch(e) { _cleanUrlLock = null; }
    _settingCleanUrlLock = false;
  }

  function applyParamLock(url) {
    if (url == null || typeof url !== 'string') return url;
    if (!_cleanUrlLock) return url;
    if (!currentConfig.trackingParamsCleanerEnabled) return url;
    try {
      var u = new _URL(url, _location.origin);
      if (u.pathname !== _cleanUrlLock.pathname) return url;
      var kept = [];
      var changed = false;
      u.searchParams.forEach(function(v, k) {
        if (_cleanUrlLock.params.has(k)) {
          kept.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
        } else {
          changed = true;
        }
      });
      if (!changed) return url;
      var newQuery = kept.join('&');
      var result = u.origin + u.pathname + (newQuery ? '?' + newQuery : '') + u.hash;
      if (url.charAt(0) === '/' && !url.startsWith('//') && !url.startsWith('://', 1)) {
        result = u.pathname + (newQuery ? '?' + newQuery : '') + u.hash;
        if (!result.startsWith('/')) result = '/' + result;
      }
      return result;
    } catch(e) { return url; }
  }

  // ======================== 标题黑/白名单匹配工具 ========================
    // 根据页面标题关键词判断"是否为跳转/广告中转页"（白名单优先，如银行/登录页）。


  function wildcardMatch(pattern, hostname) {
    if (!pattern || !hostname) return false;
    try {
      var reStr = pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
      return new RegExp('^' + reStr + '$', 'i').test(hostname);
    } catch(e) { return false; }
  }


  function matchKeywordsAgainst(keywords, title, hostname) {
    if (!keywords) return false;
    for (var i = 0; i < keywords.length; i++) {
      var kw = keywords[i];
      if (kw.indexOf('re:') === 0) {

        try {
          var re = new RegExp(kw.substring(3));
          if (title && re.test(title)) return true;
          if (hostname && re.test(hostname)) return true;
        } catch(e) { _debugCatch(e, "RegExp(kw.substring(3))"); }
      } else {

        if (title && title.indexOf(kw) !== -1) return true;
        if (hostname) {
          if (kw.indexOf('*') !== -1) {
            if (wildcardMatch(kw, hostname)) return true;
          } else if (hostname.indexOf(kw) !== -1) {
            return true;
          }
        }
      }
    }
    return false;
  }

  function matchAgainstBlacklist(title, hostname) {
    return matchKeywordsAgainst(currentConfig.redirectTitleBlacklistKeywords, title, hostname);
  }

  function matchAgainstWhitelist(title, hostname) {
    return matchKeywordsAgainst(currentConfig.redirectTitleWhitelistKeywords, title, hostname);
  }

  function resetAllCachesAndStates() {
    if (centralScheduler) centralScheduler.clearCache();
    ProcessedElementsCache.clear();
    LogManager.clearLoggedIdentifiers();
    urlCache.clear();
    _clearSbrCache();
    _kwHash = '';
    _kwRegex = null;
    _tpHash = '';
    _tpRegex = null;
    CrossScriptPatternTracker.reset();
    // 可疑链接判定缓存随加白/配置变更一并失效（否则加白后同一链接仍按旧结论拦截）
    if (typeof RedirectBlocker !== 'undefined' && RedirectBlocker._suspLinkCache) RedirectBlocker._suspLinkCache = new WeakMap();
    // 动态代码回调判定缓存随加白/配置变更一并失效
    if (DynamicScriptInterceptor) DynamicScriptInterceptor._callbackCheckCache = new WeakMap();
    // 位置级记忆（降噪去重/灭菌计数）随加白一并清零: 放行后同位置的新变体重新记日记,
    // 已放行位置停止累计灭菌计数
    try { OverlayInterceptor.resetLocationMemory(); } catch(e) {}
    OverlayInterceptor.restoreWhitelistedElements();
  }
  function refreshUrlAndRegexCache() {
    urlCache.clear();
    _clearSbrCache();
    _kwHash = '';
    _kwRegex = null;
    _tpHash = '';
    _tpRegex = null;
  }

  // ======================== 强拦截模式（阻止页面关闭/跳转） ========================
    // 面板打开期间启用：阻止 beforeunload/导航离开（防广告脚本趁面板操作时跳走）。
  let activePanels = new _Set();
  let strongBlockingEnabled = false;
  let blockingTimer = null;

  let _isInternalNavigationCount = 0;
  const _beforeunloadHandler = function (e) {

    if (_isInternalNavigationCount > 0) {
      _isInternalNavigationCount--;
      return;
    }
    e.preventDefault();
    e.returnValue = '系统可能不会保存您所做的更改。';
    return e.returnValue;
  };
  const _errorHandler = function (e) {
    if (strongBlockingEnabled) {
      disableStrongBlocking();
      activePanels.clear();
    }
  };
  function enableStrongBlocking() {
    if (strongBlockingEnabled) return;
    _globals.addEventListener('beforeunload', _beforeunloadHandler);
    _globals.addEventListener('error', _errorHandler, true);
    strongBlockingEnabled = true;
    if (blockingTimer) _clearTimeout(blockingTimer);
    blockingTimer = _setTimeout(function () {
      if (activePanels.size > 0) {
        activePanels.clear();
        disableStrongBlocking();
      }
    }, CONFIG.STRONG_BLOCK_TIMEOUT);
  }
  function disableStrongBlocking() {
    if (!strongBlockingEnabled) return;
    _globals.removeEventListener('beforeunload', _beforeunloadHandler);
    _globals.removeEventListener('error', _errorHandler, true);
    strongBlockingEnabled = false;
    if (blockingTimer) {
      _clearTimeout(blockingTimer);
      blockingTimer = null;
    }
    if (currentConfig.modules.blockDynamicScripts) DynamicScriptInterceptor.enable();
  }
  function setupNavigationBlocking(panelId) {
    activePanels.add(panelId);
    if (activePanels.size === 1) {
      enableStrongBlocking();
      if (currentConfig.modules.blockDynamicScripts) DynamicScriptInterceptor.disable();
    }
  }
  function teardownNavigationBlocking(panelId) {
    activePanels.delete(panelId);
    if (activePanels.size === 0) {
      disableStrongBlocking();
      if (currentConfig.modules.blockDynamicScripts) DynamicScriptInterceptor.enable();
    }
  }

  // ======================== document.write 钩子管理 ========================
    // WriteHookManager：多个模块可注册 write 钩子，短路执行（首个返回 false 的钩子阻止写入）。
  const WriteHookManager = {
    hooks: [],
    originalWrite: null,
    originalWriteln: null,
    _installed: false,
    init: function () {
      if (this._installed) return;
      this.originalWrite = _document.write;
      this.originalWriteln = _document.writeln;
      this._installed = true;
      const self = this;
      try {
        _document.write = function () {
          const a = arguments;
          for (const hook of self.hooks) {
            try {
              const result = hook(a, 'write');
              if (result === false) return;
            } catch (e) {   }
          }
          return self.originalWrite.apply(this, a);
        };
        _document.writeln = function () {
          const a = arguments;
          for (const hook of self.hooks) {
            try {
              const result = hook(a, 'writeln');
              if (result === false) return;
            } catch (e) {   }
          }
          return self.originalWriteln.apply(this, a);
        };
      } catch(e) { _debugCatch(e, "self.originalWriteln.appl"); }
    },
    addHook: function (hookFn) {
      if (!this.hooks.includes(hookFn)) this.hooks.push(hookFn);
      if (this.hooks.length > 0 && !this._installed) this.init();
    },
    removeHook: function (hookFn) {
      const idx = this.hooks.indexOf(hookFn);
      if (idx !== -1) this.hooks.splice(idx, 1);
      if (this.hooks.length === 0 && this._installed) {
        try {
          _document.write = this.originalWrite;
          _document.writeln = this.originalWriteln;
          this._installed = false;
        } catch(e) { _debugCatch(e, "this.originalWrite"); }
      }
    },
  };

  // ======================== 跳转拦截器（阻止第三方跳转/重定向） ========================
    // 劫持 location/window.open/history 等导航 API + meta refresh，拦截广告跳转/弹窗。
  const RedirectBlocker = {
    _initialized: false,
    _writeTimingHook: null,
    _savedDescriptors: [],
    _savedObservers: [],
    _savedEventHandlers: [],
    _iframeSandboxSet: null,
    _sandboxOriginal: null,
    _lastClick: null,
    _lastTouch: null,
    _touchSyncActive: false,
    _touchJumpWindow: 1000,
    // 触后跳转守卫（通用化四条件, 无站点形态签名）: ①异源目标 ②裸跳转(直接赋值型跳转由
    // navigate 事件防线接入本守卫, a.click/form.submit 合成钩子同样接入) ③触摸关联(触摸派发
    // 同步栈内, 或其后 _touchJumpWindow 窗口内——劫持惯用 setTimeout 100~500ms 绕开同步
    // 检测) ④无主触摸(目标链无可操作元素; video 不豁免——播放器触摸穿透正是劫持路径)。
    // 同源永不拦; 页面已加白放行不拦; 误拦在拦截日记按落地 URL 加白即可恢复。
    _checkTouchJump: function (url, scene) {
      try {
        var _lt = this._lastTouch;
        if (!_lt) return false;
        var _assoc = this._touchSyncActive || ((Date.now() - _lt.time) < this._touchJumpWindow);
        if (!_assoc) return false;
        if (!_lt.ownerless) return false;
        if (this._isPageReleased()) return false;
        var _tp = false;
        try {
          var _u = new _URL(String(url), _location.href);
          _tp = _u.hostname !== _location.hostname;
        } catch (e) { _tp = true; }
        if (!_tp) return false;
        return this._shouldBlockRedirect(String(url), scene || '触后跳转拦截(无主触摸后1秒内异源裸跳转)');
      } catch (e) { return false; }
    },
    _recordTouch: function (e) {
      // 捕获阶段被动记录最近触摸（不阻断不消费）: 时间戳 + 无主判定, 供 _checkTouchJump
      // 关联; 同步栈标志用宏任务清零, 覆盖同一次触摸派发任务内所有同步跳转调用
      try {
        if (!e || !e.target) return;
        var self = this;
        this._touchSyncActive = true;
        _setTimeout(function () { self._touchSyncActive = false; }, 0);
        var _ow = true;
        try {
          var _n = e.target, _depth = 0;
          while (_n && _n.nodeType === 1 && _depth < 30) {
            var _tg = _n.tagName;
            if (_tg === 'A' || _tg === 'BUTTON' || _tg === 'INPUT' || _tg === 'SELECT' || _tg === 'TEXTAREA' || _tg === 'LABEL' || _tg === 'OPTION') { _ow = false; break; }
            if (_n.hasAttribute && (_n.hasAttribute('onclick') || _n.hasAttribute('contenteditable'))) { _ow = false; break; }
            if (_n.getAttribute && _n.getAttribute('role') === 'button') { _ow = false; break; }
            _n = _n.parentElement; _depth++;
          }
        } catch (e2) {}
        var _cx = 0, _cy = 0;
        try {
          var _ts = (e.changedTouches && e.changedTouches.length) ? e.changedTouches[0] : (e.touches && e.touches[0]);
          if (_ts) { _cx = _ts.clientX || 0; _cy = _ts.clientY || 0; }
        } catch (e3) {}
        this._lastTouch = { time: Date.now(), ownerless: _ow, x: _cx, y: _cy };
      } catch (e4) {}
    },
    // 劫持 a.click / form.submit（触后跳转守卫补口）: 跳转梯子的"合成点击/表单提交"
    // 分支不经过 location 钩子; 同一套四条件（异源+触摸关联+无主触摸+页面未放行）在
    // API 层兜住, 同源与正常交互不受影响
    _installSyntheticNavHooks: function () {
      var self = this;
      try {
        var _aPD = Object.getOwnPropertyDescriptor(_globals.HTMLElement.prototype, 'click');
        if (_aPD && _aPD.configurable !== false && _aPD.value) {
          var _aOrig = _aPD.value;
          self._applyDefine(_globals.HTMLAnchorElement.prototype, 'click', {
            value: function () {
              try {
                var _h = this.href || '';
                if (_h && self._checkTouchJump(_h, '触后跳转拦截(无主触摸后合成链接点击)')) return;
              } catch (e) {}
              return _aOrig.apply(this, arguments);
            },
            writable: true,
            configurable: true,
            enumerable: false
          });
        }
      } catch(e) { _debugCatch(e, "aClickHook"); }
      try {
        var _fPD = Object.getOwnPropertyDescriptor(_globals.HTMLFormElement.prototype, 'submit');
        if (_fPD && _fPD.configurable !== false && _fPD.value) {
          var _fOrig = _fPD.value;
          self._applyDefine(_globals.HTMLFormElement.prototype, 'submit', {
            value: function () {
              try {
                var _a3 = this.action || '';
                if (_a3 && self._checkTouchJump(_a3, '触后跳转拦截(无主触摸后表单提交跳转)')) return;
              } catch (e) {}
              return _fOrig.apply(this, arguments);
            },
            writable: true,
            configurable: true,
            enumerable: false
          });
        }
      } catch(e) { _debugCatch(e, "formSubmitHook"); }
    },
    _extractJsUrl: function (jsHref) {
      // 从 javascript: 链接里提取内嵌跳转目标, 供点击劫持/跳转拦截判定。
      // 通用实现: 不依赖特定混淆写法(atob/变量名等), 只要代码里存在跳转类调用
      // (window.open / location 赋值 / location.replace|assign / document.location),
      // 就提取 URL 判定; 提取不到 URL 但确认是跳转调用（混淆/变量形式） → 返回 true 保守拦截。
      // 返回: 提取到的 URL 字符串 / true(跳转调用但无法解析, 拦) / false(无跳转调用, 放行)
      if (!jsHref || typeof jsHref !== 'string') return false;
      try {
        var m;
        // 1) window.open 直接 URL(含 window['open'] / window["open"] 写法)
        m = jsHref.match(/window\s*\[\s*['"]open['"]\s*\]\s*\(\s*['"]([^'"]+)['"]/i);
        if (!m) m = jsHref.match(/window\.open\s*\(\s*['"]([^'"]+)['"]/i);
        if (m) return m[1];
        // 2) location 赋值: location.href= / location= / document.location= / top.location= / parent.location= / self.location=
        m = jsHref.match(/(?:window|document|top|parent|self)?\.?(?:document\.location|location)\s*(?:\.href)?\s*=\s*['"]([^'"]+)['"]/i);
        if (m) return m[1];
        // 3) location.replace / location.assign 调用
        m = jsHref.match(/(?:window|document|top|parent|self)?\.?(?:document\.location|location)\.(?:replace|assign)\s*\(\s*['"]([^'"]+)['"]/i);
        if (m) return m[1];
        // 4) 存在跳转类调用但提取不到 URL(混淆/变量/动态拼接/eval包装) → 保守拦截
        m = jsHref.match(/\beval\s*\(|\bFunction\s*\(|window\s*\[\s*['"]open['"]\s*\]\s*\(|window\.open\s*\(|location\s*(?:\.href)?\s*=|location\.(?:replace|assign)\s*\(|document\.location/i);
        if (m) return true;
      } catch(e) { _debugCatch(e, '_extractJsUrl'); }
      return false;
    },
    _isWhitelistedUrl: function (url) {
      // 全部拦截（白名单生效）模式点击捕获用: 目标域名或本页标题/域名命中白名单关键词则放行;
      // 「全部拦截」模式无白名单承诺, 仅按目标域名判定(保持该模式语义)
      try {
        var _u = new _URL(url, _location.href);
        if (matchAgainstWhitelist('', _u.hostname)) return true;
        if (currentConfig.redirectBlockAllEnabled) return false;
        if (matchAgainstWhitelist(_document.title || '', _location.hostname || '')) return true;
      } catch(e) {}
      return false;
    },
    _isPageReleased: function () {
      // 页面级放行: 用户加白了本页面的日记条目(OVERLAY_FULLSCREEN_AD 页面键 = "放行本页")后,
      // 本页所有"行为类静默拦截"(重定向链/无标题中间页/点击一致性/弹窗链/javascript:链接/iframe沙箱)整体放行,
      // 否则这些拦截不进日记、加白无效, 会把正常播放器初始化卡死。
      try {
        return currentConfig.whitelist.has('OVERLAY_FULLSCREEN_AD:' + generateContentHash(((_location && _location.href) || '').split('#')[0]));
      } catch(e) { return false; }
    },
    // ======================== 可疑链接阻止: 孤立大图广告链接判定 ========================
      // 【功能】识别"孤立大图"广告链接（点击/中键/长按都会被切断），防跳到广告站。
      // 【机制】通用几何+行为规则（无域名/类名硬编码）：链接内"恰好一张主图（忽略≤20px 装饰小图）
      //        + 无可视文字（≤6 字符）+ 主图尺寸/比例/视口特征"，再叠加广告形态特征
      //        （整宽/横幅比/nofollow/href 跳转参数/短链/fixed 悬浮定位）命中任一即视为可疑。
      //        覆盖懒加载占位（data-src/data-original）、<picture>、background-image 大图、
      //        隐藏文字（text-indent 移出视野/不可见字体不计入文字量）。
      // 【用户体验】误拦正常大图链接时，拦截日记里加白该条目即可恢复点击。
    _visibleTextLen: function (t) {
      // 可见文字长度: 跳过 display:none/visibility:hidden/字号0 的节点,
      // 以及 text-indent 把文字移出视野的节点(纯图链接常用 -9999px 藏字)。
      if (!t) return 0;
      var len = 0;
      try {
        // 遍历上限: 大链接整树可达数百节点, 每次点击对每节点读计算样式会连续触发回流;
        // 上限内未累计到可见文字时按已积累结果判定（纯图卡片无文字, 结论不变）
        var _visits = 0;
        var _rec = function (node) {
          if (len > 6 || ++_visits > 100) return;
          if (node.nodeType === 3) { len += (node.textContent || '').replace(/\s+/g, ' ').trim().length; return; }
          if (node.nodeType !== 1) return;
          try {
            // 内联隐藏先短路, 免去计算样式（高频路径）
            if (node.style && (node.style.display === 'none' || node.style.visibility === 'hidden')) return;
            var _cs = _getComputedStyle(node);
            if (_cs.display === 'none' || _cs.visibility === 'hidden' || parseFloat(_cs.fontSize) <= 0) return;
            var _ti = parseFloat(_cs.textIndent);
            if (_ti && Math.abs(_ti) > ((node.offsetWidth || 0) * 2 + 10)) return;
          } catch (e) {}
          for (var i = 0; i < node.childNodes.length; i++) _rec(node.childNodes[i]);
        };
        for (var i = 0; i < t.childNodes.length; i++) _rec(t.childNodes[i]);
      } catch (e) {}
      return len;
    },
    _isSuspiciousImageLink: function (t) {
      // 可疑链接阻止入口: 对同一链接元素短时（3 秒）复用判定结果; 缓存键=元素自身,
      // 元素内容变化后按新 DOM 重新判定
      if (!t || !t.querySelector || !t.querySelectorAll) return false;
      if (!this._suspLinkCache) this._suspLinkCache = new WeakMap();
      var _cached = this._suspLinkCache.get(t);
      var _nowC = Date.now();
      if (_cached && (_nowC - _cached.at) < 3000) return _cached.result;
      var _res = this._isSuspiciousImageLinkCore(t);
      this._suspLinkCache.set(t, { at: _nowC, result: _res });
      return _res;
    },
    _isSuspiciousImageLinkCore: function (t) {
      // 可疑链接阻止核心判定: 链接是否"孤立大图"广告形态（见上方注释, 全通用规则）。
      try {
        var _lvw = _globals.innerWidth || _document.documentElement.clientWidth;
        var _lvh = _globals.innerHeight || _document.documentElement.clientHeight;
        if (!_lvw || !_lvh) return false;

        // ① 收集图片候选(img+懒加载回退 / picture / background-image), 忽略 ≤20px 装饰小图
        var _main = null, _deco = 0;
        var _add = function (w, h) {
          if (!(w > 0) || !(h > 0)) return;
          if (w <= 20 || h <= 20) { _deco++; return; }
          if (!_main || (w * h) > (_main.w * _main.h)) _main = { w: w, h: h };
        };
        var _imgs = t.querySelectorAll('img');
        for (var i = 0; i < _imgs.length; i++) {
          var _im = _imgs[i];
          var _w = _im.offsetWidth || 0, _h = _im.offsetHeight || 0;
          if ((_w <= 0 || _h <= 0) && _im.getAttribute) {
            // 懒加载回退: 占位图（尺寸0）按 data-src/data-original + width/height 属性估计
            var _ds = _im.getAttribute('data-src') || _im.getAttribute('data-original') || '';
            var _aw = parseFloat(_im.getAttribute('width') || '');
            var _ah = parseFloat(_im.getAttribute('height') || '');
            if (!_ds && !_aw && !_ah) continue;   // 既无加载尺寸也无回退依据 → 忽略
            if (!_w) _w = _aw || 120;             // 无宽度信息按 ≥120 下限参与判定
            if (!_h) _h = _ah || 40;
          }
          _add(_w, _h);
        }
        var _pics = t.querySelectorAll('picture');
        for (var p = 0; p < _pics.length; p++) {
          if (_pics[p].querySelector && !_pics[p].querySelector('img')) {
            _add(_pics[p].offsetWidth || 0, _pics[p].offsetHeight || 0);
          }
        }
        var _bgN = 0;
        var _els = t.querySelectorAll('*');
        // 背景图证据扫描上限 50 个元素（常规链接远小于此）, 防整树遍历在点击路径上连续触发回流
        for (var e2 = 0; e2 < _els.length && _bgN < 40 && e2 < 50; e2++) {
          var _be = _els[e2];
          try {
            var _bcs = _getComputedStyle(_be);
            if (_bcs.backgroundImage && _bcs.backgroundImage !== 'none') { _bgN++; _add(_be.offsetWidth || 0, _be.offsetHeight || 0); }
          } catch (e3) {}
        }
        if (!_main) return false;   // 无主图 → 不是图片广告位

        // ② 可见文字 ≤6 字符才算"无文字"(隐藏/移出视野的文字不计)
        if (this._visibleTextLen(t) > 6) return false;

        // ③ 主图尺寸范围: ≥120×40, ≤120%视口宽, ≤60%视口高
        var _lw = _main.w, _lh = _main.h;
        if (_lw < 120 || _lh < 40 || _lw > _lvw * 1.2 || _lh > _lvh * 0.6) return false;

        // ④ 广告形态特征（命中任一即拦）
        var _lBanner = _lh > 0 && (_lw / _lh) >= 2.5;
        var _lNofollow = ((t.getAttribute && t.getAttribute('rel')) || '').toLowerCase().indexOf('nofollow') !== -1;
        var _href = t.href || t.getAttribute('href') || '';
        var _jump = /[?&](?:url|to|link|target|redirect|go|jump|forward|rurl|dest|next|reurl|return|refer)=/i.test(_href);
        var _short = /^https?:\/\/[^\/?#]+\/[a-z0-9_-]{3,10}\/?$/i.test(_href) && _href.indexOf(_location.hostname) === -1;
        if (_lw >= _lvw * 0.6 || _lBanner || (_lNofollow && _lw >= _lvw * 0.4) ||
            (_jump && _lw >= 120) || (_short && _lw >= 120)) return true;

        // ⑤ fixed/absolute 悬浮贴边广告位（向上找 3 层定位祖先）
        try {
          var _anc = t, _depth = 0;
          while (_anc && _depth < 3) {
            if (_getComputedStyle(_anc).position === 'fixed' || _getComputedStyle(_anc).position === 'absolute') {
              var _r = t.getBoundingClientRect();
              if (_r.top <= 20 || _r.bottom >= _lvh - 20 || _r.left <= 20 || _r.right >= _lvw - 20) return true;
              break;
            }
            _anc = _anc.parentElement; _depth++;
          }
        } catch (e4) {}
        return false;
      } catch (e5) { return false; }
    },
    _shouldBlockRedirect: function (url, scene) {
      // 行为类拦截的"日志化+可加白"出口: 拦截前先查白名单(URL键/关键词, 以及标题/域名
      // 白名单——全部拦截模式仅前两者), 未加白则记日记(带 REDIRECT_BLOCK_URL 键), 用户加白后完全放行。
      try {
        var _key = 'REDIRECT_BLOCK_URL: ' + Utils.truncateString(String(url), CONFIG.LOG_DETAIL_LENGTH);
        if (currentConfig.whitelist.has(_key)) return false;
        if (currentConfig.keywordWhitelist.size > 0) {
          var kr = getKeywordWhitelistRegex();
          if (kr && kr.test(String(url))) return false;
        }
        // 标题/域名白名单恒为最高优先级(黑名单+白名单模式与白名单生效模式): 行为类拦截
        // (零操作/触后/重定向链/弹窗链/点击劫持/无标题)全部经此出口, 白名单命中一律放行;
        // 「全部拦截」模式无白名单承诺, 不在此放行(仅保留单条日记加白出口)
        if (!currentConfig.redirectBlockAllEnabled) {
          if (matchAgainstWhitelist(_document.title || '', _location.hostname || '')) return false;
          try { if (matchAgainstWhitelist('', new _URL(String(url), _location.href).hostname)) return false; } catch (eW) {}
        }
        LogManager.add('redirectBlocker', null, {
          type: 'REDIRECT_BLOCK',
          detail: scene + ': ' + Utils.truncateString(String(url), CONFIG.LOG_DETAIL_LENGTH),
          elementContentIdentifier: _key,
        });
        return true;
      } catch(e) { return true; }
    },
    // 主域粗比较: 取主机名末两段对比, 相同视为同站(子域间放行, 如 m.a.com 与 www.a.com);
    // 对 a.com.cn 类双段后缀会把不同主域误判为同站, 只会造成漏拦不会误拦, 方向安全
    _sameSiteHost: function (h1, h2) {
      try {
        if (!h1 || !h2) return false;
        if (h1 === h2) return true;
        var p1 = String(h1).split('.').slice(-2).join('.');
        var p2 = String(h2).split('.').slice(-2).join('.');
        return p1 === p2;
      } catch (e) { return false; }
    },
    // 零操作保护窗有效性: 早注入档=整个加载期(readyState 到 complete 为止);
    // 晚注入档=脚本注入后 _ZERO_TOUCH_LATE_MS 毫秒内(宿主在加载完成后才注入,
    // 加载期已不存在, 以注入时刻起算, 覆盖加载完成后数秒内的无手势延迟跳转)
    _zeroTouchWindowActive: function () {
      try {
        if (_document.readyState !== 'complete') return true;
        return _LATE_REGIME && (Date.now() - _INIT_AT) < _ZERO_TOUCH_LATE_MS;
      } catch (e) { return false; }
    },
    // 零操作加载期跨站跳转判定(异源跳转拦截默认职责): 零操作保护窗内 + 最近 3 秒
    // 无点击/触摸 + 目标跨站(按主域比较)才拦; 窗口结束后本规则自动收手, 由既有规则
    // (触摸跳转/点击一致性/重定向链/弹窗链)接管; 走可加白出口, 子域搬迁不误拦
    _zeroTouchNav: function (url) {
      try {
        if (!currentConfig.redirectBlockerEnabled) return false;
        if (this._isPageReleased()) return false;
        if (!this._zeroTouchWindowActive()) return false;
        var _nowZ = Date.now();
        if (this._lastClick && (_nowZ - this._lastClick.time) < 3000) return false;
        if (this._lastTouch && (_nowZ - this._lastTouch.time) < 3000) return false;
        var _s = String(url || '');
        if (!_s || /^(data|about|blob|javascript):/i.test(_s)) return false;
        var _uz = new _URL(_s, _location.href);
        if (this._sameSiteHost(_uz.hostname, _location.hostname)) return false;
        return this._shouldBlockRedirect(_uz.href, '零操作跳转拦截(无操作跨站跳转)');
      } catch (e) { return false; }
    },
    // 跨站短延迟 meta refresh 判定(异源跳转拦截默认职责): 延迟≤2 秒且目标跨站的
    // refresh 标签在扫描/插入阶段即摘除; 长延迟与同站刷新不受影响, 走可加白出口
    _suspiciousMetaRefresh: function (metaEl) {
      try {
        if (!currentConfig.redirectBlockerEnabled) return false;
        if (this._isPageReleased()) return false;
        var content = (metaEl.getAttribute && metaEl.getAttribute('content')) || '';
        var _dm = content.match(/^\s*(\d+)/);
        if (!_dm || parseInt(_dm[1], 10) > 2) return false;
        var _um = content.match(/url\s*=\s*['"]?([^'"\s]+)/i);
        if (!_um) return false;
        var _u = new _URL(_um[1], _location.href);
        if (this._sameSiteHost(_u.hostname, _location.hostname)) return false;
        return this._shouldBlockRedirect(_u.href, '零操作跳转拦截(跨站短延迟meta refresh)');
      } catch (e) { return false; }
    },
    _checkAndBlockUrl: function (url) {
      // 异源跳转判定流程: 页面放行键优先 → javascript: 链接解析内嵌目标 → 异源判定
      // → 模式分支（全部拦截=全拦 / 白名单生效=白名单命中放行 / 黑名单+白名单=标题白名单
      // → 标题黑名单 → 无标题中间页强化）, 命中即经可加白出口记日记。
      try {
        if (!url || typeof url !== 'string') return false;
        if (/^(data|about|blob|#):/i.test(url)) return false;
        // 页面已加白放行 → 本页所有异源跳转行为整体放行（链检测/无标题/标题黑名单均跳过）
        if (this._isPageReleased()) return false;
        if (/^javascript:/i.test(url)) {
          // javascript: 链接: 解析内嵌跳转 URL 再判定(广告站用 window.open/location 跳广告页)
          var _inner = this._extractJsUrl(url);
          if (!_inner) return false;
          if (_inner === true) {
            // 保守拦截(含跳转调用但无法解析目标URL): 走可加白出口
            if (this._shouldBlockRedirect(url, 'javascript:链接拦截(含跳转调用但无法解析目标URL)')) return true;
            return false;
          }
          url = _inner;
        }
        var _isThirdParty = false;
        try {
          var _u = new _URL(url, _location.href);
          _isThirdParty = _u.hostname !== _location.hostname;
        } catch(e) { _isThirdParty = true; }
        if (!_isThirdParty) return false;
        // 重定向链检测（通用行为规则）: 连续异源跳转 ≥3 次 → 判定为恶意重定向链并拦截。
        // 重置条件: 与上一次跳转间隔超 2 秒 = 用户主动导航, 不累计。
        // 用户点击 3 个不同外站链接（间隔大）不会误拦; 脚本驱动的快速链式跳转会被拦截。
        {
          var _nowH = Date.now();
          if (this._chainStreak && (_nowH - this._lastHopAt) > 2000) {
            this._chainStreak = 0;
          }
          this._chainStreak = (this._chainStreak || 0) + 1;
          this._lastHopAt = _nowH;
          if (this._chainStreak >= 3) {
            this._chainStreak = 0;
            if (this._shouldBlockRedirect(url, '重定向链拦截(连续3次异源跳转)')) return true;
            return false;
          }
        }
        var title = _document.title || '';
        var hostname = _location.hostname || '';

        if (currentConfig.redirectBlockAllEnabled) return true;

        if (currentConfig.redirectWhitelistBlockMode) {
          if (matchAgainstWhitelist(title, hostname)) return false;
          var _uhW = '';
          try { _uhW = _u.hostname; } catch (eHw) {}
          if (matchAgainstWhitelist('', _uhW)) return false;
          return true;
        }

        if (currentConfig.redirectTitleWhitelistEnabled) {
          if (matchAgainstWhitelist(title, hostname)) return false;
          var _uhT = '';
          try { _uhT = _u.hostname; } catch (eHt) {}
          if (matchAgainstWhitelist('', _uhT)) return false;
        }

        if (currentConfig.redirectTitleBlacklistEnabled) {
          if (matchAgainstBlacklist(title, hostname)) return true;
        }
        // 无标题中间页强化: 页面标题为空/极短/形如URL(跳转中间页特征) + 异源跳转 → 拦截。
        // 正常页面都有标题(SEO 需要); 无标题或标题就是网址的页面, 大多是广告跳转中间页。
        // 仅作用于异源跳转, 站内跳转与白名单不受影响; 若误拦可加白对应条目。
        var _tTrim = (title || '').trim();
        if (!_tTrim || _tTrim.length < 5 || /^https?:\/\//i.test(_tTrim)) {
          if (this._shouldBlockRedirect(url, '无标题中间页拦截(页面标题为空或过短)')) return true;
          return false;
        }
        return false;
      } catch(e) { _debugCatch(e, '_checkAndBlockUrl'); return false; }
    },
    _compat: function () { return currentConfig.redirectBlockerCompatibilityMode !== false; },
    _applyDefine: function (obj, prop, descriptor) {
      try {
        var orig = Object.getOwnPropertyDescriptor(obj, prop);
        Object.defineProperty(obj, prop, descriptor);
        this._savedDescriptors.push({ obj: obj, prop: prop, desc: orig });
        return true;
      } catch (e) {
        return false;
      }
    },
    init: function () {
      if (this._initialized) return;
      if (!currentConfig.redirectBlockerEnabled) return;
      this._initialized = true;
      this._savedDescriptors = [];
      this._savedObservers = [];
      this._savedEventHandlers = [];
      this._iframeSandboxSet = new WeakSet();
      this._sandboxOriginal = new WeakMap();
      var self = this;
      // 重定向链/弹窗链行为检测状态（通用行为规则, 不依赖域名）
      this._pageStartAt = Date.now();
      this._chainStreak = 0;
      this._lastHopAt = 0;
      this._popupCount = 0;
      this._popupStart = 0;
      // 用户手势会重置弹窗计数（点击/触摸/按键）, 防止误拦用户主动触发的弹窗
      if (!this._gestureHooked) {
        this._gestureHooked = true;
        var _resetPopups = function () { self._popupCount = 0; self._popupStart = 0; };
        this._gestureReset = _resetPopups;
        ['pointerdown', 'click', 'touchend', 'keydown'].forEach(function (t) {
          try { _document.addEventListener(t, _resetPopups, true); } catch (e) {}
        });
      }
      // 触后跳转守卫: 捕获阶段被动记录最近触摸( touchstart/touchend, 不阻断不消费),
      // 供 navigate 事件防线与 a.click/form.submit 合成钩子里的 _checkTouchJump 做触摸关联判定
      if (!this._touchGuardHooked) {
        this._touchGuardHooked = true;
        var _recordTouchFn = function (e) { self._recordTouch(e); };
        ['touchstart', 'touchend'].forEach(function (t) {
          try { _document.addEventListener(t, _recordTouchFn, { capture: true, passive: true }); } catch (e) {}
        });
      }

      // ========== 早期扫描并移除已有的 meta refresh 标签 ==========

      self._earlyScanMetaRefresh();

      self._installSyntheticNavHooks();

      // ========== 劫持 window.open（直接赋值）==========
      try {
        var _oDesc = Object.getOwnPropertyDescriptor(_globals, 'open');
        if (_oDesc && _oDesc.configurable !== false) {
          var origOpen = _oDesc.value;
          self._applyDefine(_globals, 'open', {
            value: function () {
              // 点击一致性检查: 点击链接后 1 秒内的弹窗, 目标域名与点击链接域名不同 = 点击劫持
              try {
                if (!self._isPageReleased() && self._lastClick && (Date.now() - self._lastClick.time) < 1000) {
                  var _tv = new _URL(String(arguments[0]), _location.href);
                  if (_tv.hostname !== self._lastClick.host) {
                    if (self._shouldBlockRedirect(String(arguments[0]), '点击劫持拦截(点击后1秒内弹窗域名与点击链接不一致)')) return null;
                  }
                }
              } catch (e) {}
              if (self._zeroTouchNav(arguments[0])) return null;
              if (self._checkAndBlockUrl(arguments[0])) return null;
              // 无手势弹窗链拦截（通用行为规则）: 3 秒内 window.open ≥2 次且无用户手势 → 拦截
              // (用户点击/触摸/按键会重置计数, 不误拦主动触发的弹窗)
              var _nowP = Date.now();
              if (!self._popupStart || _nowP - self._popupStart > 3000) { self._popupStart = _nowP; self._popupCount = 0; }
              self._popupCount++;
              if (self._popupCount >= 2) {
                self._popupCount = 0;
                self._popupStart = _nowP;
                if (self._isPageReleased() || !self._shouldBlockRedirect(String(arguments[0]), '弹窗链拦截(3秒内无手势连续2次window.open)')) {
                  if (currentConfig.trackingParamsCleanerEnabled) {
                    arguments[0] = applyParamLock(cleanTrackingParams(arguments[0]));
                  }
                  return origOpen.apply(this, arguments);
                }
                return null;
              }
              if (currentConfig.trackingParamsCleanerEnabled) {
                arguments[0] = applyParamLock(cleanTrackingParams(arguments[0]));
              }
              return origOpen.apply(this, arguments);
            },
            writable: true,
            configurable: true,
            enumerable: _oDesc.enumerable !== undefined ? _oDesc.enumerable : false
          });
        }
      } catch(e) { _debugCatch(e, "origOpen"); }

      // ========== 劫持 history.pushState / replaceState(经 _applyDefine 登记, 关闭时还原默认实现) ==========
      try {
        var origPushState = _globals.history.pushState;
        self._applyDefine(_globals.history, 'pushState', {
          value: function () {
            var url = arguments[2];
            if (url) {
              if (typeof url === 'string') {
                if (url.charAt(0) === '/' || url.startsWith(_location.origin) || url.charAt(0) !== '#') {
                  if (currentConfig.trackingParamsCleanerEnabled) {
                    var cleaned = cleanTrackingParams(url);
                    cleaned = applyParamLock(cleaned);
                    if (cleaned !== url) {
                      arguments[2] = cleaned;
                    }
                  }
                }
                if (url.charAt(0) === '#' || url.charAt(0) === '/' || url.startsWith(_location.origin)) {
                  refreshUrlAndRegexCache();
                  return origPushState.apply(this, arguments);
                }
              }
              if (self._checkAndBlockUrl(url)) return;
            }
            refreshUrlAndRegexCache();
            return origPushState.apply(this, arguments);
          },
          writable: true,
          configurable: true,
        });
      } catch(e) { _debugCatch(e, "pushState"); }
      try {
        var origReplaceState = _globals.history.replaceState;
        self._applyDefine(_globals.history, 'replaceState', {
          value: function () {
            var url = arguments[2];
            if (url) {
              if (typeof url === 'string') {
                if (url.charAt(0) === '/' || url.startsWith(_location.origin) || url.charAt(0) !== '#') {
                  if (currentConfig.trackingParamsCleanerEnabled) {
                    var cleaned = cleanTrackingParams(url);
                    cleaned = applyParamLock(cleaned);
                    if (cleaned !== url) {
                      arguments[2] = cleaned;
                    }
                  }
                }
                if (url.charAt(0) === '#' || url.charAt(0) === '/' || url.startsWith(_location.origin)) {
                  refreshUrlAndRegexCache();
                  return origReplaceState.apply(this, arguments);
                }
              }
              if (self._checkAndBlockUrl(url)) return;
            }
            refreshUrlAndRegexCache();
            return origReplaceState.apply(this, arguments);
          },
          writable: true,
          configurable: true,
        });
      } catch(e) { _debugCatch(e, "replaceState"); }

      // ========== 监听popstate事件，刷新缓存 ==========
      var popstateHandler = function () {
        refreshUrlAndRegexCache();
        try {
          var cleaned = cleanTrackingParams(_location.href);
          applyParamLock(cleaned);
          setCleanUrlLock(cleaned);
          if (cleaned !== _location.href) {
            _isInternalNavigationCount++;
            _location.replace(cleaned);
          }
        } catch(e) {
          try { setCleanUrlLock(_location.href); } catch(e2) {}
        }
      };
      _globals.addEventListener('popstate', popstateHandler, { capture: true });
      self._savedEventHandlers.push({ target: _globals, type: 'popstate', handler: popstateHandler, useCapture: true });

      // ========== 阻止修改 document.domain ==========
      try {
        var dDomain = Object.getOwnPropertyDescriptor(_Document.prototype, 'domain');
        if (dDomain && dDomain.set) {
          self._applyDefine(_Document.prototype, 'domain', {
            get: dDomain.get,
            set: function () { return; },
            enumerable: true,
            configurable: true,
          });
        }
      } catch(e) { _debugCatch(e, "configurable"); }



      // ========== 劫持 area.href ==========
      try {
        var ap = _globals.HTMLAreaElement.prototype;
        var areaHrefDesc = Object.getOwnPropertyDescriptor(ap, 'href');
        if (areaHrefDesc && areaHrefDesc.set && areaHrefDesc.configurable) {
          var origAreaHrefSet = areaHrefDesc.set;
          self._applyDefine(ap, 'href', {
            configurable: true, enumerable: true,
            get: areaHrefDesc.get,
            set: function (v) {
              if (self._checkAndBlockUrl(v)) return;
              origAreaHrefSet.call(this, v);
            },
          });
        }
      } catch(e) { _debugCatch(e, "}"); }

      // ========== 劫持 embed.src ==========
      try {
        var ep = _globals.HTMLEmbedElement.prototype;
        var embedSrcDesc = Object.getOwnPropertyDescriptor(ep, 'src');
        if (embedSrcDesc && embedSrcDesc.set && embedSrcDesc.configurable) {
          var origEmbedSrcSet = embedSrcDesc.set;
          self._applyDefine(ep, 'src', {
            configurable: true, enumerable: true,
            get: embedSrcDesc.get,
            set: function (v) {
              if (self._checkAndBlockUrl(v)) return;
              origEmbedSrcSet.call(this, v);
            },
          });
        }
      } catch(e) { _debugCatch(e, "}"); }

      // ========== 劫持 object.data ==========
      try {
        var op = _globals.HTMLObjectElement.prototype;
        var objDataDesc = Object.getOwnPropertyDescriptor(op, 'data');
        if (objDataDesc && objDataDesc.set && objDataDesc.configurable) {
          var origObjDataSet = objDataDesc.set;
          self._applyDefine(op, 'data', {
            configurable: true, enumerable: true,
            get: objDataDesc.get,
            set: function (v) {
              if (self._checkAndBlockUrl(v)) return;
              origObjDataSet.call(this, v);
            },
          });
        }
      } catch(e) { _debugCatch(e, "}"); }

      // ========== 统一 DOM 守卫观察器(meta/base/iframe 三合一, 减少全树 Observer) ==========
      // base/meta/iframe 三个全树监听合并为一个:
      // 同一 DOM 变更只触发一次全树扫描。
      try {
        var domGuardObserver = new _MutationObserver(function (ms) {
          for (const m of ms) {
            if (m.type === 'childList' && m.addedNodes) {
              for (var gi = 0; gi < m.addedNodes.length; gi++) {
                var n = m.addedNodes[gi];
                if (!_isElementLike(n)) continue;
                if (n.tagName === 'META') {
                  // 先解析目标 URL 经 _checkAndBlockUrl 判定（含页面放行键/白名单）,
                  // 解析失败或命中才删; 同源合法刷新页不受影响
                  if (/refresh/i.test(n.getAttribute('http-equiv')) && /url\s*=/i.test(n.getAttribute('content') || '')) {
                    var _murl = (n.getAttribute('content') || '').match(/url\s*=\s*['"]?([^'"\s]+)/i);
                    if (!_murl || self._checkAndBlockUrl(_murl[1]) || self._suspiciousMetaRefresh(n)) n.remove();
                  }
                } else {
                  if (n.tagName === 'IFRAME') self._sandboxIframe(n);
                  if (n.tagName === 'BASE') {
                    var h = n.getAttribute('href');
                    if (h && self._checkAndBlockUrl(h)) n.removeAttribute('href');
                  }
                  if (n.tagName === 'LINK' && (n.rel === 'prefetch' || n.rel === 'prerender' || n.rel === 'preload')) {
                    var h3 = n.getAttribute('href');
                    if (h3 && self._checkAndBlockUrl(h3)) n.remove();
                  }
                  if (n.querySelectorAll && n.children && n.children.length > 0) {
                    Array.from(n.querySelectorAll('meta[http-equiv="refresh"]')).forEach(function (m2) {
                      var _mc2 = m2.getAttribute('content') || '';
                      var _mu2 = _mc2.match(/url\s*=\s*['"]?([^'"\s]+)/i);
                      if (!_mu2 || self._checkAndBlockUrl(_mu2[1]) || self._suspiciousMetaRefresh(m2)) m2.remove();
                    });
                    var subIframes = n.querySelectorAll('iframe');
                    for (var si = 0; si < subIframes.length; si++) self._sandboxIframe(subIframes[si]);
                  }
                }
              }
            } else if (m.type === 'attributes') {
              var t = m.target;
              if (t.tagName === 'BASE' && m.attributeName === 'href') {
                var h2 = t.getAttribute('href');
                if (h2 && self._checkAndBlockUrl(h2)) t.removeAttribute('href');
              } else if (t.tagName === 'IFRAME' && m.attributeName === 'src') {
                self._sandboxIframe(t);
              }
            }
          }
        });
        domGuardObserver.observe(_document.documentElement || _document, {
          childList: true, subtree: true, attributes: true, attributeFilter: ['href', 'src'],
        });
        self._savedObservers.push(domGuardObserver);
      } catch(e) { _debugCatch(e, "domGuardObserver.observe(_doc"); }

      // ========== 添加 document.write 钩子 ==========
      WriteHookManager.init();
      this._writeTimingHook = function (args, type) {
        if (_document.readyState !== 'loading') {
          // 加载完成后的 document.write 会清空当前文档（破坏性）, 一律阻断;
          // 放行条件: 关键词白名单 / 已加白的脚本地址 / 已加白的内容哈希键(DOCUMENT_WRITE);
          // 危险内容(异源 src/黑名单/危险内联)经统一检测并记日志, 加白对应条目即可放行
          try {
            var _wc = Array.prototype.join.call(args, '');
            if (typeof _wc === 'string' && _wc) {
              if (currentConfig.keywordWhitelist.size > 0) {
                var _kwr = getKeywordWhitelistRegex();
                if (_kwr && _kwr.test(_wc)) return;
              }
              var _wm = _wc.match(/<script[^>]*\bsrc\s*=\s*["']?([^"'\s>]+)["']?/i);
              if (_wm && _wm[1]) {
                var _wurl = _wm[1];
                try { _wurl = new _URL(_wm[1], _location.href).href; } catch(e) {}
                if (currentConfig.whitelist.has('SCRIPT_SRC: ' + Utils.truncateString(_stableSrcKey(_wurl), CONFIG.LOG_DETAIL_LENGTH))) return;
              }
              // 查询参数归一化后按内容哈希匹配白名单(与动态脚本拦截的 DOCUMENT_WRITE 键一致)
              var _keyCode = _wc.replace(/([?&][A-Za-z_0-9]+)=([^&\s"']+)/g, '$1=X');
              var _wCi = Utils.getContentIdentifier(null, { type: 'DOCUMENT_WRITE', detail: _keyCode });
              if (_wCi && currentConfig.whitelist.has(_wCi)) return;
              var _det = _detectDangerousWriteContent(_wc);
              if (_det.thirdParty || _det.srcBlacklisted || _det.dangerInline) {
                LogManager.add('blockDynamicScripts', null, {
                  type: 'DOCUMENT_WRITE',
                  detail: Utils.truncateString(_wc, CONFIG.LOG_DETAIL_LENGTH),
                  elementContentIdentifier: _wCi || undefined,
                });
              }
            }
          } catch(e) {}
          return false;
        }
      };
      WriteHookManager.addHook(this._writeTimingHook);

      // ========== 劫持链接点击（增强 isTrusted 检测） ==========
      var anchorClickLastCheck = 0;
      var anchorClickHandler = function (e) {
        var t = e.target;
        if (!t || t.nodeType !== 1) return;
        if (t.tagName !== 'A') t = t.closest('a');
        if (!t || !t.href) return;
        var h = t.getAttribute('href') || t.href;
        if (!h || h.startsWith('#')) return;
        // 非 http(s)/javascript/data 协议(如 mailto:/tel:/sms:): 不是网页跳转, 不参与拦截判定
        var _scm = h.match(/^([a-z][a-z0-9+.-]*):/i);
        if (_scm) {
          var _sl = _scm[1].toLowerCase();
          if (_sl !== 'http' && _sl !== 'https' && _sl !== 'javascript' && _sl !== 'data') return;
        }
        // 页面已加白放行 → 本页所有链接点击行为整体放行(含 javascript: 链接)
        if (self._isPageReleased()) return;
        // 用户点击 = 主动导航: 重置重定向链计数（防止快速浏览外站被误判为链式跳转）
        self._chainStreak = 0;
        // 可疑链接阻止（严格模式辅助开关"可疑链接阻止"）:
        // 识别"孤立大图"广告链接——链接内恰好一张主图(忽略≤20px装饰小图)、无可视文字（≤6字符）、
        // 图片尺寸中等以上, 且命中任一广告形态特征(整宽/横幅比/nofollow/href跳转参数/短链/fixed悬浮)。
        // 支持懒加载占位(data-src/data-original)、<picture>、background-image、隐藏文字过滤。
        // 即使目标为本站（如服务器302跳转广告）也直接阻止点击——服务器端 302 无法在跳转过程中被脚本拦截,
        // 只能在点击时切断。拦截记日记(REDIRECT_BLOCK_URL 键), 加白后完全放行。
        if (currentConfig.adLinkClickBlock && self._isSuspiciousImageLink(t)) {
          if (!self._shouldBlockRedirect(h, '可疑链接阻止(链接内为孤立大图, 疑似广告跳转)')) return;
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          return false;
        }
        // 记录点击目标（供点击一致性检查: 跳转域名与点击域名不同 = 劫持）
        try {
          var _cu = new _URL(h, _location.href);
          self._lastClick = { host: _cu.hostname, time: Date.now() };
        } catch (e) {
          // javascript: 链接无法解析为 URL: 以当前页面域名为基准
          // (点击后任何跳转到其他域名的行为 = 劫持/广告)
          self._lastClick = { host: _location.hostname, time: Date.now() };
        }
        // 全部拦截/白名单模式: 在点击捕获阶段切断广告脚本的点击监听器
        // (即使广告脚本缓存了原生函数绕过 API 劫持, 监听器被阻止后跳转代码不会执行)
        if ((currentConfig.redirectBlockAllEnabled || currentConfig.redirectWhitelistBlockMode) && e.isTrusted !== false) {
          var _isThirdPartyLink = true;
          try {
            _isThirdPartyLink = new _URL(h, _location.href).hostname !== _location.hostname;
          } catch (e) { _isThirdPartyLink = true; }
          if (_isThirdPartyLink) {
            // 第三方链接: 完全阻止（模式语义: 默认拦截所有异源跳转）
            if (!self._isWhitelistedUrl(h)) {
              e.preventDefault();
              e.stopPropagation();
              e.stopImmediatePropagation();
              return false;
            }
            // 目标域名命中白名单关键词 → 直接放行(否则下方 _checkAndBlockUrl
            // 在"全部拦截/白名单模式"下仍会拦截, 白名单形同虚设)
            return;
          }
          // 站内链接: 保留事件传播与默认导航, 页面自身的路由/统计监听不受影响
        }
        // javascript: 链接: 广告站常用 javascript:window.open(...) 打开色情/赌博广告页,
        // 这里解析出内嵌 URL 检查; 无法解析的 window.open 形式(如 atob 混淆)也走"可加白"出口。
        if (h.startsWith('javascript:')) {
          var _jsU = self._extractJsUrl(h);
          if (_jsU === false) return;  // 普通 javascript:void(0) 等, 放行
          if (_jsU === true) {
            // 保守拦截(含跳转调用但无法解析目标URL): 记日志可加白, 加白后完全放行
            if (!self._shouldBlockRedirect(h, 'javascript:链接拦截(含跳转调用但无法解析目标URL)')) return;
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            return false;
          }
          if (self._checkAndBlockUrl(_jsU)) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            return false;
          }
          return;
        }


        if (e.isTrusted === false) {
          if (self._checkAndBlockUrl(h)) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            return false;
          }
          return;
        }

        var now = Date.now();
        if (now - anchorClickLastCheck < CONFIG.ANCHOR_CLICK_THROTTLE) return;
        anchorClickLastCheck = now;
        if (self._checkAndBlockUrl(h)) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          return false;
        }
      };
      _document.addEventListener('click', anchorClickHandler, true);
      self._savedEventHandlers.push({ target: _document, type: 'click', handler: anchorClickHandler, useCapture: true });
      // ============ 可疑链接阻止: 中键(auxclick) / 长按右键(contextmenu) ============
      // 中键与"新标签页打开"路径不在 click 覆盖范围内, 另设两个捕获级处理器:
      //   · auxclick(button===1 中键): 命中可疑孤立大图链接 → preventDefault 切断新标签打开;
      //   · contextmenu(长按/右键): 命中 → 阻止菜单弹出（堵菜单内"在新标签页中打开"入口）,
      //     副作用是该链接上无法复制/保存图片, 误拦可加白恢复（与点击拦截同键, 加白即放行）。
      var _auxClickHandler = function (e2) {
        try {
          if (!currentConfig.adLinkClickBlock) return;
          if (!e2 || e2.button !== 1) return;
          var _at = e2.target && e2.target.closest ? e2.target.closest('a[href]') : null;
          if (!_at || RedirectBlocker._isPageReleased()) return;
          if (!RedirectBlocker._isSuspiciousImageLink(_at)) return;
          var _ah = _at.href || _at.getAttribute('href') || '';
          if (!RedirectBlocker._shouldBlockRedirect(_ah, '可疑链接阻止(中键打开孤立大图广告链接, 已切断)')) return;
          e2.preventDefault();
        } catch (e3) {}
      };
      _document.addEventListener('auxclick', _auxClickHandler, true);
      self._savedEventHandlers.push({ target: _document, type: 'auxclick', handler: _auxClickHandler, useCapture: true });
      var _ctxMenuHandler = function (e2) {
        try {
          if (!currentConfig.adLinkClickBlock) return;
          var _ct = e2.target && e2.target.closest ? e2.target.closest('a[href]') : null;
          if (!_ct || RedirectBlocker._isPageReleased()) return;
          if (!RedirectBlocker._isSuspiciousImageLink(_ct)) return;
          var _ch = _ct.href || _ct.getAttribute('href') || '';
          if (!RedirectBlocker._shouldBlockRedirect(_ch, '可疑链接阻止(长按/右键孤立大图广告链接, 已禁用其菜单)')) return;
          e2.preventDefault();
        } catch (e3) {}
      };
      _document.addEventListener('contextmenu', _ctxMenuHandler, true);
      self._savedEventHandlers.push({ target: _document, type: 'contextmenu', handler: _ctxMenuHandler, useCapture: true });

      // ========== 劫持 navigation.navigate (Chrome 新 API, 经 _applyDefine 登记) ==========
      try {
        if (_globals.navigation && _globals.navigation.navigate) {
          var origNavigate = _globals.navigation.navigate;
          self._applyDefine(_globals.navigation, 'navigate', {
            value: function (u) {
              if (self._checkAndBlockUrl(u)) {
                return { committed: Promise.reject(), finished: Promise.reject() };
              }
              return origNavigate.apply(this, arguments);
            },
            writable: true,
            configurable: true,
          });
        }
      } catch(e) { _debugCatch(e, "configurable"); }

      // ========== Navigation API navigate 事件监听(navigate 事件防线, 跳转拦截的兜底拦截面) ==========
      // 【修改脚本前必读】location.href / location.search / location.hash / location.assign /
      // location.replace / document.location 的赋值拦截钩子与 a.click 判定拦截在所有内核上都
      // 装不上: Location 的成员是 [LegacyUnforgeable] 实例自有属性(Location.prototype 为空,
      // non-configurable), defineProperty 抛 TypeError, 原型补丁能定义但赋值不经过它——钩子
      // 即使装上也永远不会被调用。请勿把 location 类钩子写回来。
      // 跳转拦截由 navigate 事件防线接管(本监听), 配合 meta refresh 摘除与 window.open /
      // 触后跳转 / form.submit 钩子。
      // 零操作跳转拦截(默认职责): 早注入档(页面加载期间)与晚注入档(脚本注入后 10 秒内)
      // 无任何点击/触摸的跨站跳转一律切断并记日记; 窗口结束后自动收手, 子域间跳转放行,
      // 误拦可在拦截日记加白恢复。

      try {
        if (_globals.navigation && typeof _globals.navigation.addEventListener === 'function') {
          var navigateEventHandler = function (e) {
            try {
              if (!e || !e.destination || !e.destination.url) return;
              // 同文档导航(锚点/SPA 路由)与下载/表单提交导航不拦
              if (e.hashChange === true || e.downloadRequest || e.formData) return;
              // 触后跳转判定(navigate 面缝隙填补): 无主触摸后 1 秒内的异源裸跳转——
              // 此窗口内零操作判定因"3 秒内有触摸"而豁免, 触后四条件专判兜住该缝隙
              // (异源+触摸关联+无主+页面未放行); 用户点链接=触摸落在交互元素=有主=豁免,
              // 同源永不拦, 走可加白出口
              if (self._checkTouchJump(e.destination.url, '触后跳转拦截(无主触摸后1秒内异源裸跳转)')) {
                e.preventDefault();
                return;
              }
              // 零操作判定复用统一出口: 保护窗+3秒无手势+子域放行+页面放行+可加白日记
              if (self._zeroTouchNav(e.destination.url)) {
                e.preventDefault();
                return;
              }
              // 既有全量判定保留: 全拦截/白名单/标题黑名单等模式在保护窗外仍生效
              if (self._checkAndBlockUrl(e.destination.url)) {
                e.preventDefault();
              }
            } catch (eN) { _debugCatch(eN, "navigateEventHandler"); }
          };
          _globals.navigation.addEventListener('navigate', navigateEventHandler);
          self._savedEventHandlers.push({
            target: _globals.navigation,
            type: 'navigate',
            handler: navigateEventHandler,
            useCapture: false,
          });
        }
      } catch(e) { _debugCatch(e, "useCapture"); }

      // ========== iframe sandbox 机制 ==========
      self._setupIframeSandbox();
    },
    // ==================== 早期扫描 meta refresh ====================
    _earlyScanMetaRefresh: function () {
      if (_document.readyState === 'loading' && !_document.documentElement) return;
      try {
        var metas = _document.querySelectorAll('meta[http-equiv="refresh"]');
        for (var i = 0; i < metas.length; i++) {
          var content = metas[i].getAttribute('content') || '';
          if (/url\s*=/i.test(content)) {
            var urlMatch = content.match(/url\s*=\s*['"]?([^'"\s]+)/i);
            if (urlMatch) {
              if (this._checkAndBlockUrl(urlMatch[1])) {
                metas[i].remove();
              } else if (this._suspiciousMetaRefresh(metas[i])) {
                metas[i].remove();
              }
            } else {

              metas[i].remove();
            }
          }
        }
      } catch(e) { _debugCatch(e, "}"); }
    },
    // ==================== iframe sandbox 机制 ====================
    _setupIframeSandbox: function () {
      var self = this;

      try {
        var existingIframes = _document.querySelectorAll('iframe');
        for (var i = 0; i < existingIframes.length; i++) {
          self._sandboxIframe(existingIframes[i]);
        }
      } catch(e) { _debugCatch(e, "existingIframes.length"); }

      // iframe 插入或改 src 的监听统一挂在 init 的 DOM 守卫观察器(domGuardObserver)上
    },
    _sandboxIframe: function (iframe) {
      if (!iframe || !Utils.isElement(iframe)) return;
      if (!this._iframeSandboxSet) return;
      if (!iframe.isConnected) return;
      var src = iframe.src || iframe.getAttribute('src') || '';
      // 已沙箱化的 iframe: 若当前已满足放行条件（第三方白名单/日记键/页面放行） → 恢复原始 sandbox
      if (this._iframeSandboxSet.has(iframe)) {
        if (this._sandboxExempt(iframe, src)) this._restoreIframeSandbox(iframe);
        return;
      }
      if (this._sandboxExempt(iframe, src)) return;
      this._iframeSandboxSet.add(iframe);
      if (!this._sandboxOriginal) this._sandboxOriginal = new WeakMap();
      var existingSandbox = iframe.getAttribute('sandbox');
      if (!this._sandboxOriginal.has(iframe)) this._sandboxOriginal.set(iframe, existingSandbox);
      if (existingSandbox !== null) {

        var tokens = existingSandbox.trim().split(/\s+/);
        var filtered = tokens.filter(function (t) {
          return t !== 'allow-top-navigation' && t !== 'allow-top-navigation-by-user-activation';
        });
        if (filtered.length !== tokens.length) {
          try {
            iframe.setAttribute('sandbox', filtered.join(' '));
          } catch(e) { _debugCatch(e, "tokens.length)"); }
        }
      } else {
        try {
          iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms');
        } catch(e) { _debugCatch(e, "iframe sandbox 属性设置失败"); }
      }
    },
    // 放行条件统一判定: 命中任一即不沙箱化（第三方白名单/日记键/页面放行）
    _sandboxExempt: function (iframe, src) {
      if (!src || src === 'about:blank' || src.startsWith('javascript:') || src.startsWith('data:')) return true;
      if (!isThirdPartyUrl(src)) return true;
      if (urlCache.isWhitelisted(src, currentConfig.thirdPartyWhitelist)) return true;
      try {
        if (_overlayKeyMatches(iframe, currentConfig.whitelist)) return true;
      } catch(e) {}
      if (this._isPageReleased()) return true;
      return false;
    },
    // 恢复原始 sandbox(加白/页面放行后): 无原始记录时移除 sandbox 属性
    _restoreIframeSandbox: function (iframe) {
      if (!iframe || !this._iframeSandboxSet || !this._iframeSandboxSet.has(iframe)) return false;
      var orig = this._sandboxOriginal ? this._sandboxOriginal.get(iframe) : undefined;
      try {
        if (orig === null || orig === undefined) iframe.removeAttribute('sandbox');
        else iframe.setAttribute('sandbox', orig);
      } catch(e) {}
      this._iframeSandboxSet.delete(iframe);
      if (this._sandboxOriginal) this._sandboxOriginal.delete(iframe);
      return true;
    },
    disable: function () { if (!this._initialized) return true;
      var allRestored = true;
      for (var i = this._savedDescriptors.length - 1; i >= 0; i--) {
        var r = this._savedDescriptors[i];
        try {
          if (r.desc) Object.defineProperty(r.obj, r.prop, r.desc);
          else try { delete r.obj[r.prop]; } catch (e2) { }
        } catch (e) {
          allRestored = false;
        }
      }
      this._savedDescriptors = [];
      if (this._writeTimingHook) {
        WriteHookManager.removeHook(this._writeTimingHook);
        this._writeTimingHook = null;
      }
      for (var j = 0; j < this._savedObservers.length; j++) {
        try {
          this._savedObservers[j].disconnect();
        } catch(e) { _debugCatch(e, "this._savedObservers.leng"); }
      }
      this._savedObservers = [];
      for (var k = 0; k < this._savedEventHandlers.length; k++) {
        var eh = this._savedEventHandlers[k];
        try {
          eh.target.removeEventListener(eh.type, eh.handler, eh.useCapture);
        } catch(e) { _debugCatch(e, "this._savedEventHandlers["); }
      }
      this._savedEventHandlers = [];
      if (this._sandboxOriginal) {
        // 关闭模块时恢复全部被沙箱化的 iframe 原始 sandbox(顶导航能力不被永久阉割)
        try {
          var _sbAll = _document.querySelectorAll('iframe[sandbox]');
          for (var _sbi3 = 0; _sbi3 < _sbAll.length; _sbi3++) {
            var _sbf = _sbAll[_sbi3];
            if (this._sandboxOriginal.has(_sbf)) this._restoreIframeSandbox(_sbf);
          }
        } catch(e) {}
      }
      if (this._iframeSandboxSet) {
        this._iframeSandboxSet = new WeakSet();
      }
      this._sandboxOriginal = null;
      // 移除弹窗计数的手势重置监听（模块重开/页面重建后重新挂载）
      if (this._gestureReset) {
        try {
          var _g = this._gestureReset;
          ['pointerdown', 'click', 'touchend', 'keydown'].forEach(function (t) {
            _document.removeEventListener(t, _g, true);
          });
        } catch(e) {}
        this._gestureReset = null;
      }
      this._gestureHooked = false;
      this._initialized = false;
      return allRestored;
    },
  };
  if (typeof currentConfig.redirectBlockerEnabled === 'boolean' && currentConfig.redirectBlockerEnabled) {
    RedirectBlocker.init();
  }

  // ======================== 当前页面URL追踪参数清洗 + 参数锁 ========================
    // 【功能】记录页面已访问 URL 的参数集合，后续导航若被追加未记录参数（广告追踪）则剔除。
    // 【机制】参数锁：把当前 URL 的参数快照保存，SPA 内导航变化时对比——多出来的参数视为追踪注入并剥离。

  if (currentConfig.trackingParamsCleanerEnabled) {
    try {
      var currentUrlClean = cleanTrackingParams(_location.href);
      if (currentUrlClean !== _location.href) {
        _isInternalNavigationCount++;
        setCleanUrlLock(currentUrlClean);
        _location.replace(currentUrlClean);
      } else {
        setCleanUrlLock(_location.href);
      }
    } catch (e) {
      try { setCleanUrlLock(_location.href); } catch(e2) {}
    }
  } else {
    try { setCleanUrlLock(_location.href); } catch(e) {}
  }

  if (!_cleanUrlLock) {
    var _retryLock = function() {
      try { setCleanUrlLock(_location.href); } catch(e) {}
      if (_cleanUrlLock && _document.removeEventListener) _document.removeEventListener('DOMContentLoaded', _retryLock);
    };
    // 解析已结束(晚注入档)时 DCL 不会再触发, 直接同步重试, 参数锁不缺席
    if (_document.readyState && _document.readyState !== 'loading') {
      _retryLock();
    } else {
      try { _document.addEventListener('DOMContentLoaded', _retryLock); } catch(e) {}
    }
  }

  // ======================== URL变化兜底轮询（尝试捕获一切绕过hook的参数注入） ========================
    // 【功能】兜底轮询：周期检查 URL 是否被注入追踪参数（绕过 API 钩子的注入方式）。
    // 【机制】定时比对当前 URL 与上次清洗后的 URL，发现新追踪参数立即 history.replaceState 剔除；
    //        只在开启追踪清洗时运行，避免无谓开销。
  const URLChangeGuard = {
    _lastCleanUrl: null,
    _timer: null,
    _initialized: false,
    init: function() {
      if (this._initialized) return;
      if (!currentConfig.trackingParamsCleanerEnabled) return;
      this._initialized = true;
      try {
        this._lastCleanUrl = cleanTrackingParams(_location.href);
        if (this._lastCleanUrl !== _location.href) {
          setCleanUrlLock(this._lastCleanUrl);
          _isInternalNavigationCount++;
          _location.replace(this._lastCleanUrl);
        } else {
          setCleanUrlLock(this._lastCleanUrl);
        }
      } catch(e) { this._lastCleanUrl = _location.href; }
      this._startPolling();
    },
    _startPolling: function() {
      var self = this;
      var _lastCheckAt = 0;
      var check = function() {
        if (!self._initialized) return;
        if (!currentConfig.trackingParamsCleanerEnabled) { self._timer = null; self._initialized = false; return; }
        var _nowC = Date.now();
        // 节流: 1 秒内最多完整检查一次。无 requestIdleCallback 的环境里回调退化为
        // setTimeout(1) 忙循环, 每次完整检查含 URL 解析会持续占主线程;
        // 1 秒粒度对注入检测足够, 即时路径由 location/history 钩子与 DOM 观察器覆盖
        if (_nowC - _lastCheckAt >= 1000) {
          _lastCheckAt = _nowC;
          try {
            var currentUrl = _location.href;
            var cleanedUrl = cleanTrackingParams(currentUrl);
            if (cleanedUrl !== currentUrl) {
              setCleanUrlLock(cleanedUrl);
              _isInternalNavigationCount++;
              _location.replace(cleanedUrl);
              self._lastCleanUrl = cleanedUrl;
            } else if (currentUrl !== self._lastCleanUrl) {
              var lockedUrl = applyParamLock(currentUrl);
              if (lockedUrl !== currentUrl) {
                _isInternalNavigationCount++;
                _location.replace(lockedUrl);
                self._lastCleanUrl = lockedUrl;
              } else {
                setCleanUrlLock(currentUrl);
                self._lastCleanUrl = currentUrl;
              }
            }
          } catch(e) { _debugCatch(e, "self._lastCleanUrl"); }
        }
        if (self._initialized) {
          if (typeof _globals.requestIdleCallback === 'function') self._timer = _requestIdleCallback(check);
          else self._timer = _setTimeout(check, 1000 - (_nowC - _lastCheckAt));
        }
      };
      _setTimeout(function() { if (self._initialized) { _lastCheckAt = Date.now(); check(); } }, 2000);
    },
    stop: function() {
      if (this._timer) { _cancelIdleCallback(this._timer); this._timer = null; }
      this._initialized = false;
    },
  };

  // ======================== 中央 MutationObserver 分发器 ========================
    // 全局 DOM 变化统一分发（subscribe 模式）；各模块订阅后在新节点插入时收到回调。
  const DomObserver = {
    _observer: null,
    _subscriptions: [],
    _started: false,
    _pendingStart: false,
    subscribe: function(callback) {      this._subscriptions.push({ callback: callback });
      if (!this._started && !this._pendingStart) this._start();
    },
    unsubscribe: function(callback) {
      this._subscriptions = this._subscriptions.filter(function(s) { return s.callback !== callback; });
      if (this._subscriptions.length === 0) this._stop();
    },
    _start: function() {
      if (this._started) return;
      if (!_document.documentElement) {
        this._pendingStart = true;
        var self = this;
        try {
          var tempMO = new _MutationObserver(function() {
            if (_document.documentElement && !self._started) {
              tempMO.disconnect();
              self._pendingStart = false;
              self._start();
            }
          });
          tempMO.observe(_document, { childList: true });
        } catch(e) {
          _debugCatch(e, "DomObserver._start pending");
        }
        return;
      }
      this._started = true;
      self = this;
      this._observer = new _MutationObserver(function(ms) {

        for (var mi = 0; mi < ms.length; mi++) { var m = ms[mi];
          if (m.addedNodes) {
            for (var ni = 0; ni < m.addedNodes.length; ni++) {
              var n = m.addedNodes[ni];
              if (n.nodeType === 1 && n.tagName === 'SCRIPT' && !ProcessedElementsCache.isProcessed(n)) {
                ScriptSyncGuard.interceptAndLog(n);
              }
            }
          }
        }
        for (var si = 0; si < self._subscriptions.length; si++) {
          try { self._subscriptions[si].callback(ms); } catch (e) {}
        }
      });
      this._observer.observe(_document.documentElement, {
        childList: true, subtree: true, attributes: true,
        attributeFilter: ['src', 'href', 'style', 'type', 'rel', 'class']
      });
      // 文档就绪后重连一次: 个别注入环境（如脚本注入时机极早）下, 早期创建的观察器
      // 可能因文档切换而与实际 DOM 根脱节（表现为观察不触发）; 此时幂等重连到
      // 就绪后的文档根, 保证观察持续生效（有订阅时才重连, 开销可忽略）
      try {
        var _rcSelf = this;
        var _reconnect = function () {
          try {
            if (_rcSelf._observer && _rcSelf._started && _rcSelf._subscriptions.length > 0) {
              _rcSelf._observer.observe(_document.documentElement, {
                childList: true, subtree: true, attributes: true,
                attributeFilter: ['src', 'href', 'style', 'type', 'rel', 'class']
              });
            }
          } catch(e) { _debugCatch(e, "DomObserver._start reconnect"); }
        };
        if (_document.readyState === 'loading') {
          _document.addEventListener('DOMContentLoaded', function _rcOnce() {
            _document.removeEventListener('DOMContentLoaded', _rcOnce);
            _setTimeout(_reconnect, 0);
          }, { once: true });
        } else {
          _setTimeout(_reconnect, 0);
        }
      } catch(e) { _debugCatch(e, "DomObserver._start schedule"); }
    },
    _stop: function() {
      if (this._observer) { this._observer.disconnect(); this._observer = null; }
      this._started = false;
      this._pendingStart = false;
    },
    disconnect: function() {
      this._subscriptions = [];
      this._stop();
    },

    flushPending: function() {
      if (!this._observer) return;
      var records = this._observer.takeRecords();
      if (!records || records.length === 0) return;
      for (var mi = 0; mi < records.length; mi++) {
        var m = records[mi];
        if (m.addedNodes) {
          for (var ni = 0; ni < m.addedNodes.length; ni++) {
            var n = m.addedNodes[ni];
            if (n.nodeType === 1 && n.tagName === 'SCRIPT' && !ProcessedElementsCache.isProcessed(n)) {
              ScriptSyncGuard.interceptAndLog(n);
            }
          }
        }
      }
      for (var si = 0; si < this._subscriptions.length; si++) {
        try { this._subscriptions[si].callback(records); } catch (e) {}
      }
    },
  };

  // ======================== NavUrlChecker：导航URL判断器 ========================
    // 导航请求 URL 的拦截判定入口（配合 location/history/anchor 各钩子统一调用）。
  const NavUrlChecker = {
    _resourceExtSet: null,
    _apiSegments: null,
    _getResourceExts: function() {
      if (this._resourceExtSet) return this._resourceExtSet;
      this._resourceExtSet = new _Set([
        '.m3u8', '.m4s', '.mp4', '.flv', '.ts', '.mpd', '.webm', '.ogg', '.f4v',
        '.mp3', '.wav', '.aac', '.flac', '.m4a', '.wma',
        '.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.ico', '.bmp', '.avif',
        '.woff', '.woff2', '.ttf', '.eot', '.otf',
        '.css', '.js', '.json', '.xml', '.pdf', '.zip', '.gz', '.tar', '.rar',
        '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
        '.wasm', '.bin', '.dat', '.map'
      ]);
      return this._resourceExtSet;
    },
    _getApiSegments: function() {
      if (this._apiSegments) return this._apiSegments;
      this._apiSegments = new _Set([
        'api', 'apis', 'api-v2', 'api-v3',
        'v1', 'v2', 'v3', 'v4', 'v5', 'v6', 'v7', 'v8', 'v9',
        'graphql', 'gql',
        'rpc', 'grpc', 'jsonrpc', 'xmlrpc',
        'rest', 'restapi', 'openapi', 'swagger',
        'ws', 'websocket', 'wss', 'socket.io', 'sockjs',
        'sse', 'event-stream', 'eventsource',
        'auth', 'oauth', 'sso', 'cas',
        'token', 'refresh-token', 'revoke',
        'passport',
        'gateway', 'gw', 'proxy', 'forward',
        'internal', 'backend',
        'health', 'status', 'ping',
        'live', 'stream', 'playlist', 'hls', 'dash',
        'segment', 'chunk', 'frag', 'flv',
        'cdn', 'cache', 'mirror', 'origin', 'pull', 'push',
        'rtmp', 'rtsp',
        'pay', 'payment', 'checkout', 'trade', 'purchase',
        'alipay', 'wechatpay', 'wxpay', 'stripe', 'paypal',
        'billing', 'invoice', 'receipt', 'subscription',
        'refund', 'settlement', 'transaction',
        'deposit', 'withdraw', 'recharge', 'topup',
        'balance', 'wallet', 'fund', 'transfer', 'cashier',
        'confirm-pay',
        'upload', 'download', 'file', 'attachment', 'blob',
        'export', 'import', 'oss', 'cos', 's3', 'storage',
        'static', 'assets', 'public', 'dist', 'build',
        'res', 'vendor', 'bundle', 'pack', 'webpack',
        '_next', '__next', 'nuxt',
        'sw', 'service-worker', 'workbox',
        'precache', 'manifest',
        'cgi-bin', 'cgi',
        'mtop',
        'acs',
        'aweme',
        'ncm',
        'aj',
        'well-known',
        'robots.txt', 'sitemap', 'sitemap.xml',
        'favicon.ico'
      ]);
      return this._apiSegments;
    },
    isNavigational: function(url) {
      if (!url || typeof url !== 'string') return false;
      var c = url.charAt(0);
      if (c === '#' || url.startsWith('javascript:') || url.startsWith('data:') || url.startsWith('blob:')) return false;
      try {
        var u = new _URL(url, _location.href);
        if (u.hostname !== _location.hostname) return false;
        var pathname = u.pathname.toLowerCase();
        var lastDot = pathname.lastIndexOf('.');
        var lastSlash = pathname.lastIndexOf('/');
        if (lastDot !== -1 && lastDot > lastSlash) {
          if (this._getResourceExts().has(pathname.substring(lastDot))) return false;
        }
        var segments = pathname.split('/');
        var apiSegments = this._getApiSegments();
        for (var i = 0; i < segments.length; i++) {
          if (apiSegments.has(segments[i])) return false;
        }
        return true;
      } catch (e) { return false; }
    }
  };

  // ======================== LinkCleaner：DOM 链接预清洗 ========================
    // 批量清理页面现有 <a>/<area> 链接：剥追踪参数、拦截黑名单目标（改 href 为 #）。
  const LinkCleaner = {
    _observer: null,
    _rootObserver: null,
    _descriptorSaved: [],
    _initialized: false,
    _clickHandler: null,
    _safeClean: function(url) {
      // 无查询串/无 hash 的 URL 无追踪参数可剥, 免去 URL 解析（链接读取是高频路径）
      if (typeof url !== 'string' || (url.indexOf('?') === -1 && url.indexOf('#') === -1)) return url;
      if (!NavUrlChecker.isNavigational(url)) return url;
      return cleanTrackingParams(url);
    },
    init: function() {
      if (this._initialized) return;
      if (!currentConfig.trackingParamsCleanerEnabled) return;
      this._initialized = true;
      this._hookAnchorHref();
      this._hookFormAction();
      this._setupDOMObserver();
      this._setupClickInterceptor();
    },
    _hookAnchorHref: function() {
      var self = this;
      try {
        var proto = _globals.HTMLAnchorElement.prototype;
        var desc = Object.getOwnPropertyDescriptor(proto, 'href');
        if (!desc || !desc.configurable) return;
        var origGetter = desc.get, origSetter = desc.set;
        var _c = true;
        self._descriptorSaved.push({ obj: proto, prop: 'href', desc: desc });
        Object.defineProperty(proto, 'href', {
          get: function() {
            try {
              var rawUrl = origGetter.call(this);
              if (!currentConfig.trackingParamsCleanerEnabled) return rawUrl;
              var cleaned = self._safeClean(rawUrl);
              return cleaned || rawUrl;
            } catch (e) {
              try { return origGetter.call(this); } catch (e2) { return ''; }
            }
          },
          set: function(v) {
            try {
              if (!currentConfig.trackingParamsCleanerEnabled) return origSetter.call(this, v);
              var cleaned = self._safeClean(v);
              return origSetter.call(this, cleaned || v);
            } catch (e) { return origSetter.call(this, v); }
          },
          configurable: _c, enumerable: true
        });
      } catch(e) { _debugCatch(e, "configurable"); }
    },
    _hookFormAction: function() {
      var self = this;
      try {
        var proto = _globals.HTMLFormElement.prototype;
        var desc = Object.getOwnPropertyDescriptor(proto, 'action');
        if (!desc || !desc.configurable) return;
        var origGetter = desc.get, origSetter = desc.set;
        var _c = (typeof RedirectBlocker._compat === 'function') ? RedirectBlocker._compat() : true;
        self._descriptorSaved.push({ obj: proto, prop: 'action', desc: desc });
        Object.defineProperty(proto, 'action', {
          get: function() {
            try {
              var rawUrl = origGetter.call(this);
              if (!currentConfig.trackingParamsCleanerEnabled) return rawUrl;
              var cleaned = self._safeClean(rawUrl);
              return cleaned || rawUrl;
            } catch (e) {
              try { return origGetter.call(this); } catch (e2) { return ''; }
            }
          },
          set: function(v) {
            try {
              if (!currentConfig.trackingParamsCleanerEnabled) return origSetter.call(this, v);
              var cleaned = self._safeClean(v);
              return origSetter.call(this, cleaned || v);
            } catch (e) { return origSetter.call(this, v); }
          },
          // 原描述符可配置; 清洗类钩子保持可配置, 便于停用时还原(锁定语义仅用于跳转拦截 API)
          configurable: true, enumerable: true
        });
      } catch(e) { _debugCatch(e, "configurable"); }
    },
    _cleanLinkAttribute: function(link) {
      if (!link || link.nodeType !== 1 || link.tagName !== 'A') return;
      if (!currentConfig.trackingParamsCleanerEnabled) return;
      try {
        var rawHref = link.getAttribute('href');
        if (!rawHref || rawHref.charAt(0) === '#' || rawHref.startsWith('javascript:')) return;
        // 无查询串/无 hash 的链接无追踪参数可剥, 免去 URL 解析
        if (rawHref.indexOf('?') === -1 && rawHref.indexOf('#') === -1) return;
        if (!NavUrlChecker.isNavigational(rawHref)) return;
        var cleanedHref = cleanTrackingParams(rawHref);
        if (cleanedHref !== rawHref) link.setAttribute('href', cleanedHref);
      } catch(e) { _debugCatch(e, "cleanedHref"); }
    },
    _cleanAllLinks: function(root) {
      if (!root || !root.querySelectorAll) return;
      try {
        var links = root.querySelectorAll('a[href]');
        for (var i = 0; i < links.length; i++) this._cleanLinkAttribute(links[i]);
      } catch(e) { _debugCatch(e, "links"); }
    },
    _setupDOMObserver: function() {
      var self = this;
      var startObserving = function(rootEl) {
        self._cleanAllLinks(rootEl);
        self._observer = new _MutationObserver(function(mutations) {
          if (!currentConfig.trackingParamsCleanerEnabled) return;
          for (var mi = 0; mi < mutations.length; mi++) {
            var m = mutations[mi];
            if (m.type === 'childList' && m.addedNodes) {
              for (var ni = 0; ni < m.addedNodes.length; ni++) {
                var node = m.addedNodes[ni];
                if (node.nodeType !== 1) continue;
                if (node.tagName === 'A') self._cleanLinkAttribute(node);
                if (node.querySelectorAll) self._cleanAllLinks(node);
              }
            } else if (m.type === 'attributes' && m.attributeName === 'href') {
              if (m.target.tagName === 'A') self._cleanLinkAttribute(m.target);
            }
          }
        });
        self._observer.observe(rootEl, {
          childList: true, subtree: true,
          attributes: true, attributeFilter: ['href']
        });
      };
      if (_document.documentElement) startObserving(_document.documentElement);
      else {
        self._rootObserver = new _MutationObserver(function() {
          if (_document.documentElement) {
            if (self._rootObserver) { self._rootObserver.disconnect(); self._rootObserver = null; }
            startObserving(_document.documentElement);
          }
        });
        self._rootObserver.observe(_document, { childList: true });
      }
    },
    _setupClickInterceptor: function() {
      // 保存监听器引用, disable 时可移除, 避免每次重建重复挂载累积
      this._clickHandler = function(e){
        if (!currentConfig.trackingParamsCleanerEnabled) return;
        var target = e.target;
        if (!target || target.nodeType !== 1) return;
        if (target.tagName !== 'A') target = target.closest && target.closest('a');
        if (!target || !target.href) return;
        var href = target.getAttribute('href') || target.href;
        if (!href || href.charAt(0) === '#' || href.startsWith('javascript:')) return;
        // 无查询串/无 hash 的链接无追踪参数可剥, 免去 URL 解析
        if (href.indexOf('?') === -1 && href.indexOf('#') === -1) return;
        if (!NavUrlChecker.isNavigational(href)) return;
        var cleaned = cleanTrackingParams(href);
        if (cleaned !== href) { try { target.setAttribute('href', cleaned); } catch(e2) {} }
      };
      _document.addEventListener('click', this._clickHandler, true);
    },
    disable: function() {
      if (!this._initialized) return;
      this._initialized = false;
      if (this._clickHandler) {
        try { _document.removeEventListener('click', this._clickHandler, true); } catch (e) {}
        this._clickHandler = null;
      }
      for (var i = this._descriptorSaved.length - 1; i >= 0; i--) {
        var d = this._descriptorSaved[i];
        try { Object.defineProperty(d.obj, d.prop, d.desc); } catch (e) {}
      }
      this._descriptorSaved = [];
      if (this._observer) { this._observer.disconnect(); this._observer = null; }
      if (this._rootObserver) { this._rootObserver.disconnect(); this._rootObserver = null; }
    }
  };

  // ======================== NetworkTrackingCleaner：网络层追踪参数清洗 ========================
    // 拦截 fetch/XHR/sendBeacon 请求，剥离追踪参数后放行；保留响应完整性。
  const NetworkTrackingCleaner = {
    _initialized: false,
    _fetchHooked: false,
    _xhrHooked: false,
    _beaconHooked: false,
    init: function() {
      if (this._initialized) return;
      if (!currentConfig.trackingParamsCleanerEnabled) return;
      this._initialized = true;
      this._hookFetch(); this._hookXHR(); this._hookSendBeacon();
    },
    _hookFetch: function() {
      // 防叠层: 整页重写重建时包装器保持单层(常驻, disable 只复位初始化标记)
      if (this._fetchHooked) return;
      this._fetchHooked = true;
      try {
        var curFetch = _globals.fetch;
        _globals.fetch = new _Proxy(curFetch, {
          apply: function(target, thisArg, args) {
            if (!currentConfig.trackingParamsCleanerEnabled) return Reflect.apply(target, thisArg, args);
            try {
              var url = null, reqObj = null;
              if (typeof args[0] === 'string') url = args[0];
              else if (args[0] && args[0].url) { reqObj = args[0]; url = reqObj.url; }
              if (url && NavUrlChecker.isNavigational(url)) {
                var cleaned = cleanTrackingParams(url);
                if (cleaned !== url) {
                  if (reqObj) {
                    // 带流式/信号/非文本 body 的 Request 重建会丢失语义, 这类请求不洗 URL(走原生)
                    var _rebuildOk = true;
                    try {
                    var _b2 = reqObj.body;
                    var _safeB = _b2 == null || typeof _b2 === 'string' ||
                      (typeof URLSearchParams !== 'undefined' && _b2 instanceof URLSearchParams) ||
                      (typeof ArrayBuffer !== 'undefined' && (_b2 instanceof ArrayBuffer || (ArrayBuffer.isView && ArrayBuffer.isView(_b2))));
                    // 仅已中止的 signal 无法安全重建(正常 Request 都带 signal, 不能据此跳过)
                    if (!_safeB || (reqObj.signal && reqObj.signal.aborted === true)) _rebuildOk = false;
                    } catch(e) { _rebuildOk = false; }
                    if (_rebuildOk) { try { args[0] = new _globals.Request(cleaned, reqObj); } catch(e) { _rebuildOk = false; } }
                  } else args[0] = cleaned;
                }
              }
            } catch(e) { _debugCatch(e, "checkCallback"); }
            return Reflect.apply(target, thisArg, args);
          }
        });
      } catch(e) { _debugCatch(e, "Reflect.apply(target"); }
    },
    _hookXHR: function() {
      if (this._xhrHooked) return;
      this._xhrHooked = true;
      try {
        var origOpen = _XMLHttpRequest.prototype.open;
        _XMLHttpRequest.prototype.open = new _Proxy(origOpen, {
          apply: function(target, thisArg, args) {
            if (currentConfig.trackingParamsCleanerEnabled && args[1] && typeof args[1] === 'string') {
              if (NavUrlChecker.isNavigational(args[1])) { try { var c = cleanTrackingParams(args[1]); if (c !== args[1]) args[1] = c; } catch(e) {} }
            }
            return Reflect.apply(target, thisArg, args);
          }
        });
      } catch(e) { _debugCatch(e, "Reflect.apply(target"); }
    },
    _hookSendBeacon: function() {
      if (this._beaconHooked) return;
      this._beaconHooked = true;
      try {
        var origBeacon = _globals.navigator.sendBeacon;
        if (origBeacon) {
          _globals.navigator.sendBeacon = function(url, data) {
            if (currentConfig.trackingParamsCleanerEnabled && typeof url === 'string' && NavUrlChecker.isNavigational(url)) {
              try { url = cleanTrackingParams(url); } catch(e) {}
            }
            return origBeacon.call(this, url, data);
          };
        }
      } catch(e) { _debugCatch(e, "origBeacon.call(this"); }
    },
    disable: function() { this._initialized = false; }
  };


  if (currentConfig.trackingParamsCleanerEnabled) {
    URLChangeGuard.init();
    LinkCleaner.init();
    NetworkTrackingCleaner.init();
  }

  // ======================== 动态脚本拦截器（eval, Function, 定时器等） ========================
    // 拦截 eval/Function/Worker/定时器字符串执行（可单独开关），与 ScriptSyncGuard 互补。

  // 动态脚本严格模式的危险API特征（函数回调路径与元素路径共用, 懒编译缓存）:
  // 命中任一模式才视为"动态代码中的危险API调用"。注意与启发式黑名单的区别——
  // 严格模式只拦"确实调用危险API"的动态脚本, 不拦内容正常的动态内嵌脚本;
  // 放行判定按内容哈希键精确到具体写入口, 不波及同类普通动态内嵌脚本。
  var _dynamicStrictPatterns = null;
  function getDynamicStrictPatterns() {
    if (_dynamicStrictPatterns !== null) return _dynamicStrictPatterns;
    _dynamicStrictPatterns = [
      /document\s*\.\s*write(?:ln)?\s*\(/i,
      /document\s*\[\s*['"][^'"]*?write[^'"]*?['"]\s*\]\s*\(/i,
      /location\s*\.\s*(?:assign|replace)\s*\(/i,
      /location\s*\[\s*['"][^'"]*?(?:assign|replace)[^'"]*?['"]\s*\]\s*\(/i,
      /location\s*(?:\.\s*href|\[\s*['"][^'"]*?href[^'"]*?['"]\s*\])\s*=/i,
      /(?:window|self|top|parent|frames|globalThis)\s*\.\s*open\s*\(/i,
      /(?:window|self|top|parent|frames|globalThis)\s*\[\s*['"][^'"]*?open[^'"]*?['"]\s*\]\s*\(/i,
      /\w+\s*\[\s*['"][^'"]*?(?:write|writeln)[^'"]*?['"]\s*\]\s*\(/i,
      /\w+\s*\[\s*['"][^'"]*?open[^'"]*?['"]\s*\]\s*\(/i,
      /\w+\s*\[\s*['"][^'"]*?(?:assign|replace|href)[^'"]*?['"]\s*\]\s*[\(=]/i,
      /(?:document|location|window|self|top|parent)\s*\[\s*\w+\s*\]\s*\(/i,
      /['"][wW][rR][iI][tT][eE]['"].*?\+/i,
      /['"](?:open|href|assign|replace)['"].*?\+/i,
    ];
    return _dynamicStrictPatterns;
  }

  // 元素路径专用的严格特征（更精准的子集）: 只匹配"直接改变页面行为/执行代码"的
  // 危险API(document.write/location跳转/window.open/eval/Function构造), 不含
  // 宽泛的方括号字符串方法调用(如 str["replace"](...) 在压缩代码中极常见,
  // 用于整段内嵌脚本内容匹配时会造成大量误拦)。
  var _dynamicElementStrictPatterns = null;
  function getDynamicElementStrictPatterns() {
    if (_dynamicElementStrictPatterns !== null) return _dynamicElementStrictPatterns;
    _dynamicElementStrictPatterns = [
      /document\s*\.\s*write(?:ln)?\s*\(/i,
      /document\s*\[\s*['"][^'"]*?write[^'"]*?['"]\s*\]\s*\(/i,
      /location\s*\.\s*(?:assign|replace)\s*\(/i,
      /location\s*\[\s*['"][^'"]*?(?:assign|replace)[^'"]*?['"]\s*\]\s*\(/i,
      /location\s*(?:\.\s*href|\[\s*['"][^'"]*?href[^'"]*?['"]\s*\])\s*=/i,
      /(?:window|self|top|parent|frames|globalThis)\s*\.\s*open\s*\(/i,
      /(?:window|self|top|parent|frames|globalThis)\s*\[\s*['"][^'"]*?open[^'"]*?['"]\s*\]\s*\(/i,
      /\beval\s*\(/i,
      // 注意: Function 必须大写匹配(不能带 /i)——小写 function 关键字在正常
      // 脚本中无处不在((function(){...})() 立即执行函数/function 声明), 一旦
      // 不分大小写, 严格模式下所有含 function( 的内嵌脚本都会被误拦。
      /\bFunction\s*\(/,
    ];
    return _dynamicElementStrictPatterns;
  }

  // ======================== 统一 document.write 内容检测 ========================
    // 【功能】document.write 注入内容的统一危险检测：动态脚本模块与覆盖层模块共用同一套判定。
    // 【机制】检测三类：① 第三方 <script src> → ② 命中黑名单关键词的 src → ③ 黑名单/动态危险
    //        API/启发式混淆的内联脚本。统一口径后，任意模块组合下内联混淆（方括号调用/atob 链/
    //        启发式特征）都不会因钩子实现差异而漏网。
    // 【注意】命中即记日志（可加白）；页面整体加白后不拦截。
  function _detectDangerousWriteContent(c) {
    var thirdParty = false, srcBlacklisted = false, dangerInline = false;
    var _srcRe = /<script[^>]*\bsrc\s*=\s*["']?([^"'\s>]+)["']?/gi;
    var mm;
    while ((mm = _srcRe.exec(c)) !== null) {
      var u = _decodeHtmlEntities(mm[1]);
      if (u.indexOf('data:') !== 0 && shouldBlockResource(u)) { thirdParty = true; break; }
      if (currentConfig.modules.scriptBlacklistMode) {
        var _ba = Utils.getActiveBlacklistArray();
        var _sbrRe = getSbrBlacklistRegex(_ba);
        if (_sbrRe && _sbrRe.test(u)) { srcBlacklisted = true; break; }
      }
    }
    if (!thirdParty && !srcBlacklisted) {
      var _inlRe = /<script[^>]*>([\s\S]*?)<\/script>/gi;
      var im;
      while ((im = _inlRe.exec(c)) !== null) {
        if (!im[1] || !im[1].trim()) continue;
        if (currentConfig.modules.scriptBlacklistMode) {
          var _ba2 = Utils.getActiveBlacklistArray();
          var _sbrRe2 = getSbrBlacklistRegex(_ba2);
          if (_sbrRe2 && _sbrRe2.test(im[1])) { dangerInline = true; break; }
        }
        var _esmp = getDynamicElementStrictPatterns();
        for (var _ei = 0; _ei < _esmp.length; _ei++) {
          if (_esmp[_ei].test(im[1])) { dangerInline = true; break; }
        }
        if (!dangerInline && currentConfig.heuristicBlacklistEnabled) {
          var hrgs = getHeuristicRegexGroups();
          if (hrgs) {
            for (var _hi = 0; _hi < hrgs.length; _hi++) {
              if (hrgs[_hi].test(im[1])) { dangerInline = true; break; }
            }
          }
        }
        if (dangerInline) break;
      }
    }
    return { thirdParty: thirdParty, srcBlacklisted: srcBlacklisted, dangerInline: dangerInline };
  }

  const DynamicScriptInterceptor = {
    _enabled: false,
    _dynamicWriteHook: null,
    _callbackCheckCache: new WeakMap(),
    originalEval: null,
    originalFunction: null,
    originalFunctionConstructorDescriptor: null,
    originalSetTimeout: null,
    originalSetInterval: null,
    originalClearTimeout: null,
    originalClearInterval: null,
    originalRequestAnimationFrame: null,
    originalCancelAnimationFrame: null,
    originalWorker: null,
    originalSharedWorker: null,
    _proxyRecursive: 0,
    _evalRecursive: 0,
    _functionRecursive: 0,

    isCodeSuspiciousByHeuristic: function (code) {
      var hrgs = getHeuristicRegexGroups();
      if (!currentConfig.heuristicBlacklistEnabled || !hrgs) return false;
      if (typeof code !== 'string' || code.length < 10) return false;
      const samples = [];
      if (code.length > 2000) {
        samples.push(code.substring(0, 2000));
        const mid = Math.floor(code.length / 2);
        samples.push(code.substring(mid - 1000, mid + 1000));
        samples.push(code.substring(code.length - 2000));
      } else {
        samples.push(code);
      }
      for (let si = 0; si < samples.length; si++) {
        for (let j = 0; j < hrgs.length; j++) {
          if (hrgs[j].test(samples[si])) return true;
        }
      }
      return false;
    },

    shouldBlockScriptElement: function(scriptElement, noLog) {
      if (!Utils.isElement(scriptElement) || scriptElement.tagName !== 'SCRIPT') return false;
      if (ProcessedElementsCache.isProcessed(scriptElement)) return false;
      var self = this;
      var checkAndLog = function(code, type) {
        if (typeof code !== 'string' || code.trim() === '') return false;
        if (Whitelisting.isCodeWhitelisted(code, type)) return false;
        var baseType = type.replace(/_(?:OBFUSCATED|INDIRECT)$/i, '');
        var ci = Utils.getContentIdentifier(null, { type: baseType, detail: code });
        var isWhitelistedByCi = ci && currentConfig.whitelist.has(ci);
        if (!isWhitelistedByCi) {
          if (!noLog) {
            LogManager.add('blockDynamicScripts', null, {
              type: type,
              detail: Utils.truncateString(code, CONFIG.LOG_DETAIL_LENGTH),
              rawDetail: code,
              elementContentIdentifier: ci,
            });
          }
          return true;
        }
        return false;
      };

      var src = scriptElement.src || scriptElement.getAttribute('src') || '';

      if (!src && scriptElement.getAttribute('data-ab-new') !== '1') return false;
      if (src) {
        if (src.startsWith('data:text/javascript') || src.toLowerCase().startsWith('javascript:')) {
          return checkAndLog(src, 'SCRIPT_SRC_DATA_OR_JS');
        }

        if (currentConfig.modules.interceptThirdParty && !src.startsWith('data:')) {
          if (shouldBlockResource(src)) {
            return checkAndLog(src, 'SCRIPT_SRC_THIRD_PARTY');
          }
        }
      }

      if (currentConfig.dynamicScriptStrictMode && scriptElement.getAttribute('data-ab-new') === '1') {
        var content = scriptElement.textContent || '';
        if (content && content.trim() !== '') {
          // 先查启发式混淆特征（需开启启发黑名单）, 命中即按"疑似广告动态脚本"处理
          if (self.isCodeSuspiciousByHeuristic(content)) {
            return checkAndLog(content, 'SCRIPT_CONTENT_DYNAMIC_INSERT');
          }
          // 严格模式的职责是"拦截动态代码中的危险API调用", 而不是无差别拦截所有
          // 动态内嵌脚本: 只有内容命中危险API特征(document.write/location跳转/
          // window.open/eval等)才拦截, 内容正常的动态内嵌脚本直接放行。
          var _desmp = getDynamicElementStrictPatterns();
          for (var _depi = 0; _depi < _desmp.length; _depi++) {
            if (_desmp[_depi].test(content)) {
              return checkAndLog(content, 'SCRIPT_CONTENT_DYNAMIC_INSERT');
            }
          }
        }
      }
      return false;
    },
    init: function () {
      if (currentConfig.modules.blockDynamicScripts) this.enable();
    },
    enable: function () {
      if (this._enabled) return;
      this._enabled = true;
      this.originalEval = _globals.eval;
      this.originalFunction = _globals.Function;
      this.originalSetTimeout = _globals.setTimeout;
      this.originalSetInterval = _globals.setInterval;
      this.originalClearTimeout = _globals.clearTimeout;
      this.originalClearInterval = _globals.clearInterval;
      this.originalRequestAnimationFrame = _globals.requestAnimationFrame;
      this.originalCancelAnimationFrame = _globals.cancelAnimationFrame;
      this.originalWorker = _globals.Worker || null;
      this.originalSharedWorker = _globals.SharedWorker || null;
      this._callbackCheckCache = new WeakMap();
      const self = this;
      var strictModePatterns = getDynamicStrictPatterns();
      var checkAndBlock = function (code, type) {
        if (typeof code !== 'string' || code.trim() === '') return null;


        if (Whitelisting.isCodeWhitelisted(code, type)) return 'allow';
        var baseType = type.replace(/_(?:OBFUSCATED|INDIRECT)$/i, '');
        // 白名单键归一化: document.write 注入内容的 URL 常带时间戳(?v=随机数等),
        // 每次刷新内容都不同。这里把查询参数值归一化成 X(与覆盖层 write 钩子的
        // 归一化口径一致), 同一条带时间戳的 write 加白一次即可长期放行;
        // 无参数的静态内容不受影响。
        var _keyCode = code;
        if (baseType === 'DOCUMENT_WRITE') {
          try { _keyCode = code.replace(/([?&][A-Za-z_0-9]+)=([^&\s"']+)/g, '$1=X'); } catch(e) {}
        }
        var ci = Utils.getContentIdentifier(null, { type: baseType, detail: _keyCode });
        var isWhitelistedByCi = ci && currentConfig.whitelist.has(ci);
        if (!isWhitelistedByCi) {
          LogManager.add('blockDynamicScripts', null, {
            type: type,
            detail: Utils.truncateString(code, CONFIG.LOG_DETAIL_LENGTH),
            rawDetail: code,
            elementContentIdentifier: ci,
          });
          return 'block';
        }
        return null;
      };
      var checkCallback = function (callback, type) {
        if (typeof callback === 'function' && self._callbackCheckCache.has(callback)) {
          return self._callbackCheckCache.get(callback);
        }
        var baseType = type.replace(/_(?:OBFUSCATED|INDIRECT)$/i, '');
        if (typeof callback === 'string') {
          return checkAndBlock(callback, baseType) === 'block' ? { blocked: true } : { blocked: false };
        } else if (typeof callback === 'function') {
          var fs = callback.toString();

          if (fs.indexOf('[native code]') !== -1) {
            var nativeResult = { blocked: false };
            self._callbackCheckCache.set(callback, nativeResult);
            return nativeResult;
          }

          if (Whitelisting.isCodeWhitelisted(fs, type)) {
            var ar = { blocked: false };
            self._callbackCheckCache.set(callback, ar);
            return ar;
          }
          if (!currentConfig.dynamicScriptStrictMode) {
            // 非严格模式: 只拦"确实调用危险API"的回调（真实调用形态）,
            // 判定不依赖源码是否含 eval/Function 字符串 —— 变量名/字符串字面量
            // (如 var s='evaluate')一律放行, 避免误杀正常页面功能。
            // 注意: 不能带 /i 且 Function 必须大写 —— 小写 function 关键字是函数声明,
            // 若 /i 匹配会把所有 function( 回调误判为 Function 构造器调用（假阳性）
            var _fnDangerRe = /\beval\s*\(|\bFunction\s*\(|document\s*\.\s*write(?:ln)?\s*\(|location\s*(?:\.\s*href\s*=|\.\s*(?:assign|replace)\s*\()|\b(?:window|self|top|parent|globalThis)\s*\.\s*open\s*\(/;
            if (!_fnDangerRe.test(fs)) {
              var fastResult = { blocked: false };
              self._callbackCheckCache.set(callback, fastResult);
              return fastResult;
            }
            if (checkAndBlock(fs, baseType) === 'block') {
              var br = { blocked: true };
              self._callbackCheckCache.set(callback, br);
              return br;
            }
            var ar0 = { blocked: false };
            self._callbackCheckCache.set(callback, ar0);
            return ar0;
          }
          if (fs.includes('eval') || fs.includes('Function')) {
            if (checkAndBlock(fs, baseType) === 'block') {
              br = { blocked: true };
              self._callbackCheckCache.set(callback, br);
              return br;
            }
          }
          if (currentConfig.dynamicScriptStrictMode) {
            var patternMatched = false;
            for (var si = 0; si < strictModePatterns.length; si++) {
              if (strictModePatterns[si].test(fs)) {
                var result = checkAndBlock(fs, baseType);
                if (result === 'block') {
                  var br2 = { blocked: true };
                  self._callbackCheckCache.set(callback, br2);
                  return br2;
                } else if (result === 'allow') {
                  var ar2 = { blocked: false };
                  self._callbackCheckCache.set(callback, ar2);
                  return ar2;
                }
                patternMatched = true;
                break;
              }
            }
            if (!patternMatched && self.isCodeSuspiciousByHeuristic(fs)) {
              var obsResult = checkAndBlock(fs, baseType);
              if (obsResult === 'block') {
                var obr = { blocked: true };
                self._callbackCheckCache.set(callback, obr);
                return obr;
              } else if (obsResult === 'allow') {
                var oar = { blocked: false };
                self._callbackCheckCache.set(callback, oar);
                return oar;
              }
            }
          }
          var fbr = { blocked: false };
          self._callbackCheckCache.set(callback, fbr);
          return fbr;
        }
        return { blocked: false };
      };

      try {
        _globals.eval = function (code) {
          if (self._functionRecursive > 0) return self.originalEval.call(this, code);
          if (typeof code === 'string') {
            self._evalRecursive++;
            try {
              var result = checkAndBlock(code, 'EVAL');
              if (result === 'block') return undefined;
            } finally {
              self._evalRecursive--;
            }
          }
          return self.originalEval.call(this, code);
        };
      } catch(e) { _debugCatch(e, "self.originalEval.call(th"); }

      try {
        this.originalFunctionConstructorDescriptor = Object.getOwnPropertyDescriptor(
          _globals.Function.prototype, 'constructor'
        );
        _globals.Function = new _Proxy(this.originalFunction, {
          construct: function (target, args, newTarget) {
            if (self._evalRecursive > 0) return Reflect.construct(target, args, newTarget || target);
            var code = args.length > 0 ? String(args[args.length - 1]) : '';
            if (typeof code === 'string') {
              self._functionRecursive++;
              try {
                var result = checkAndBlock(code, 'FUNCTION_CONSTRUCTOR');
                if (result === 'block') return new (self.originalFunction)('return;');
              } finally {
                self._functionRecursive--;
              }
            }
            return Reflect.construct(target, args, newTarget || target);
          },
          apply: function (target, thisArg, args) {
            if (self._evalRecursive > 0) return Reflect.apply(target, thisArg, args);
            var code = args.length > 0 ? String(args[args.length - 1]) : '';
            if (typeof code === 'string') {
              self._functionRecursive++;
              try {
                var result = checkAndBlock(code, 'FUNCTION_CONSTRUCTOR');
                if (result === 'block') return self.originalFunction('return;');
              } finally {
                self._functionRecursive--;
              }
            }
            return Reflect.apply(target, thisArg, args);
          },
        });
        try {
          Object.defineProperty(_globals.Function.prototype, 'constructor', {
            get: function () {
              return _globals.Function;
            },
            configurable: true,
          });
        } catch(e) { _debugCatch(e, "configurable"); }
      } catch(e) { _debugCatch(e, "configurable"); }


      try {
        _globals.setTimeout = function (cb, d) {
          var a = Array.prototype.slice.call(arguments, 2);
          var r = checkCallback(cb, 'SETTIMEOUT');
          if (r.blocked) return -1;
          return self.originalSetTimeout.apply(this, [cb, d].concat(a));
        };
        _globals.setInterval = function (cb, d) {
          var a = Array.prototype.slice.call(arguments, 2);
          var r = checkCallback(cb, 'SETINTERVAL');
          if (r.blocked) return -1;
          return self.originalSetInterval.apply(this, [cb, d].concat(a));
        };
        _globals.clearTimeout = function (id) {
          if (id === -1) return;
          return self.originalClearTimeout.call(this, id);
        };
        _globals.clearInterval = function (id) {
          if (id === -1) return;
          return self.originalClearInterval.call(this, id);
        };
        _globals.requestAnimationFrame = function (cb) {
          var r = checkCallback(cb, 'REQUESTANIMATIONFRAME');
          if (r.blocked) return -1;
          return self.originalRequestAnimationFrame.call(this, cb);
        };
        _globals.cancelAnimationFrame = function (id) {
          if (id === -1) return;
          return self.originalCancelAnimationFrame.call(this, id);
        };
      } catch(e) { _debugCatch(e, "self.originalCancelAnimat"); }

      if (this.originalWorker) {
        try {
          _globals.Worker = new _Proxy(this.originalWorker, {
            construct: function (target, args, newTarget) {
              var url = typeof args[0] === 'string' ? args[0] : '';
              if (url) {

                if (url.startsWith('data:text/javascript') || url.toLowerCase().startsWith('javascript:')) {
                  LogManager.add('blockDynamicScripts', null, {
                    type: 'WORKER_DATA_OR_JS',
                    detail: 'WORKER: ' + Utils.truncateString(url, CONFIG.LOG_DETAIL_LENGTH),
                  });
                  return Reflect.construct(target, ['data:text/javascript,//blocked', args[1]], target);
                }

                if (shouldBlockResource(url)) {
                  LogManager.add('blockDynamicScripts', null, {
                    type: 'THIRD_PARTY',
                    detail: 'WORKER: ' + Utils.truncateString(url, CONFIG.LOG_DETAIL_LENGTH),
                  });
                  return Reflect.construct(target, ['data:text/javascript,//blocked', args[1]], target);
                }
              }
              return Reflect.construct(target, args, newTarget);
            },
          });
        } catch(e) { _debugCatch(e, "Reflect.construct(target"); }
      }
      if (this.originalSharedWorker) {
        try {
          _globals.SharedWorker = new _Proxy(this.originalSharedWorker, {
            construct: function (target, args, newTarget) {
              var url = typeof args[0] === 'string' ? args[0] : '';
              if (url) {

                if (url.startsWith('data:text/javascript') || url.toLowerCase().startsWith('javascript:')) {
                  LogManager.add('blockDynamicScripts', null, {
                    type: 'SHARED_WORKER_DATA_OR_JS',
                    detail: 'SHARED_WORKER: ' + Utils.truncateString(url, CONFIG.LOG_DETAIL_LENGTH),
                  });
                  return Reflect.construct(target, ['data:text/javascript,//blocked', args[1]], target);
                }

                if (shouldBlockResource(url)) {
                  LogManager.add('blockDynamicScripts', null, {
                    type: 'THIRD_PARTY',
                    detail: 'SHARED_WORKER: ' + Utils.truncateString(url, CONFIG.LOG_DETAIL_LENGTH),
                  });
                  return Reflect.construct(target, ['data:text/javascript,//blocked', args[1]], target);
                }
              }
              return Reflect.construct(target, args, newTarget);
            },
          });
        } catch(e) { _debugCatch(e, "Reflect.construct(target"); }
      }

      // 添加 document.write 钩子：拦截用 document.write 注入的动态脚本，
      // 命中黑名单/启发式规则即阻止写入并记日志（DOCUMENT_WRITE 键，可加白）。
      // 白名单放行: 写入内容包含已加白的脚本地址/命中关键词白名单 → 直接放行。
      WriteHookManager.init();
      this._dynamicWriteHook = function (args, type) {
        // 钩子入参是类数组的 arguments 对象, 没有 join 方法,
        // 必须用 Array.prototype.join.call 拼接。
        var c;
        try { c = Array.prototype.join.call(args, ''); } catch(e) { return; }
        if (typeof c !== 'string' || c.length === 0) return;
        try {
          // 白名单优先: 已加白的脚本地址(SCRIPT_SRC 键) / 关键词白名单 → 直接放行
          var _wm3 = c.match(/<script[^>]*\bsrc\s*=\s*["']?([^"'\s>]+)["']?/i);
          if (_wm3 && _wm3[1]) {
            var _wurl3 = _wm3[1];
            try { _wurl3 = new _URL(_wm3[1], _location.href).href; } catch(e) {}
            if (currentConfig.whitelist.has('SCRIPT_SRC: ' + Utils.truncateString(_stableSrcKey(_wurl3), CONFIG.LOG_DETAIL_LENGTH))) return;
          }
          if (currentConfig.keywordWhitelist.size > 0) {
            var _kwr3 = getKeywordWhitelistRegex();
            if (_kwr3 && _kwr3.test(c)) return;
          }
          // 只拦截"动态注入的第三方脚本 / 恶意内联代码", 不拦站内资源:
          // ① 存在任一异源（第三方） <script src> → 拦截（广告链源头切断）;
          //    相对路径/同源/第三方白名单(shouldBlockResource 内置判定) → 放行;
          // ② 无 src 的内联代码命中危险API特征/黑名单关键词/启发式规则 → 拦截;
          // ③ 纯 HTML 写入（阅读设置面板、通知条等）直接放行。
          // 统一检测（与覆盖层钩子同口径, 含启发式组）
          var _det = _detectDangerousWriteContent(c);
          if (!_det.thirdParty && !_det.srcBlacklisted && !_det.dangerInline) return;
        } catch(e) {}
        var result = checkAndBlock(c, 'DOCUMENT_WRITE');
        if (result === 'block') return false;
      };
      WriteHookManager.addHook(this._dynamicWriteHook);

    },
    disable: function () {
      if (!this._enabled) return;
      this._enabled = false;
      if (this._dynamicWriteHook) {
        WriteHookManager.removeHook(this._dynamicWriteHook);
        this._dynamicWriteHook = null;
      }
      try {
        _globals.eval = this.originalEval;
      } catch(e) { _debugCatch(e, "this.originalEval"); }
      try {
        _globals.Function = this.originalFunction;
        if (this.originalFunctionConstructorDescriptor) Object.defineProperty(_globals.Function.prototype, 'constructor', this.originalFunctionConstructorDescriptor);
        else try {
          delete _globals.Function.prototype.constructor;
        } catch(e) { _debugCatch(e, "Object.defineProperty(_gl"); }
      } catch(e) { _debugCatch(e, "delete"); }
      try {
        _globals.setTimeout = this.originalSetTimeout;
      } catch(e) { _debugCatch(e, "this.originalSetTimeout"); }
      try {
        _globals.setInterval = this.originalSetInterval;
      } catch(e) { _debugCatch(e, "this.originalSetInterval"); }
      try {
        _globals.clearTimeout = this.originalClearTimeout;
      } catch(e) { _debugCatch(e, "this.originalClearTimeout"); }
      try {
        _globals.clearInterval = this.originalClearInterval;
      } catch(e) { _debugCatch(e, "this.originalClearInterva"); }
      try {
        _globals.requestAnimationFrame = this.originalRequestAnimationFrame;
      } catch(e) { _debugCatch(e, "this.originalRequestAnima"); }
      try {
        _globals.cancelAnimationFrame = this.originalCancelAnimationFrame;
      } catch(e) { _debugCatch(e, "this.originalCancelAnimat"); }
      if (this.originalWorker) {
        try {
          _globals.Worker = this.originalWorker;
        } catch(e) { _debugCatch(e, "this.originalWorker"); }
      }
      if (this.originalSharedWorker) {
        try {
          _globals.SharedWorker = this.originalSharedWorker;
        } catch(e) { _debugCatch(e, "this.originalSharedWorker"); }
      }
    },
  }
  // ======================== 跨标签重复模式追踪器 ========================
    // 记录跨页面重复出现的资源模式，用于识别广告网络。
  // 跨标签重复模式集: 带容量上限（超出时淘汰最早加入的模式）, 长会话不无限增长
  class CappedPatternSet extends _Set {
    add(v) {
      if (this.has(v)) return this;
      if (this.size >= 200) {
        var _f = this.values().next().value;
        if (_f !== undefined) this.delete(_f);
      }
      return super.add(v);
    }
  }
  const CrossScriptPatternTracker = {
    _counters: null,
    _scriptMap: null,
    _blockedPatterns: null,
    _scriptElements: null,
    _scriptIndex: 0,
    _escapedScripts: null,
    _retroactiveBlockedSet: null,
    _seenPfxPerScript: null,
    SAFE_OBJECTS: new Set([
      'console', 'document', 'window', 'Math', 'JSON', 'Object', 'Array',
      'String', 'Number', 'Boolean', 'Date', 'RegExp', 'Error', 'Map',
      'Set', 'Promise', 'Symbol', 'Proxy', 'Reflect', 'parseInt',
      'parseFloat', 'isNaN', 'isFinite', 'encodeURI', 'decodeURI',
      'encodeURIComponent', 'decodeURIComponent', 'atob', 'btoa',
      'alert', 'confirm', 'prompt', 'setTimeout', 'setInterval',
      'clearTimeout', 'clearInterval', 'requestAnimationFrame',
      'cancelAnimationFrame', 'fetch', 'navigator', 'location',
      'history', 'screen', 'localStorage', 'sessionStorage',
      'indexedDB', 'crypto', 'performance', 'getComputedStyle',
      'matchMedia', 'XMLHttpRequest', 'MutationObserver',
      'IntersectionObserver', 'ResizeObserver', 'AbortController',
      // DOM 导航/集合属性(prefixWordCall 对 parentNode.insertBefore 等正常调用的误杀来源)
      'parentNode', 'parentElement', 'nextSibling', 'previousSibling', 'firstChild',
      'lastChild', 'children', 'childNodes', 'ownerDocument', 'dataset', 'classList',
      'style', 'attributes', 'form', 'files', 'contentDocument', 'defaultView',
      'documentElement', 'head', 'body', 'scripts', 'forms', 'images', 'links',
    ]),
    SAFE_FUNCTIONS: new Set([
      'log', 'warn', 'error', 'info', 'debug', 'trace', 'dir', 'table',
      'time', 'timeEnd', 'group', 'groupEnd', 'assert', 'clear',
      'getElementById', 'getElementsByClassName', 'getElementsByTagName',
      'getElementsByName', 'querySelector', 'querySelectorAll',
      'createElement', 'createTextNode', 'createDocumentFragment',
      'addEventListener', 'removeEventListener', 'dispatchEvent',
      'setAttribute', 'getAttribute', 'removeAttribute', 'hasAttribute',
      'appendChild', 'removeChild', 'insertBefore', 'replaceChild',
      'cloneNode', 'contains', 'observe', 'unobserve', 'disconnect',
      'parseInt', 'parseFloat', 'isNaN', 'isFinite',
      'encodeURI', 'decodeURI', 'encodeURIComponent', 'decodeURIComponent',
      'atob', 'btoa', 'alert', 'confirm', 'prompt',
      'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval',
      'requestAnimationFrame', 'cancelAnimationFrame',
      'fetch', 'getComputedStyle', 'matchMedia',
      'scrollTo', 'scrollIntoView', 'focus', 'blur',
      'open', 'close', 'write', 'writeln',
      'push', 'pop', 'shift', 'unshift', 'splice', 'slice',
      'map', 'filter', 'reduce', 'forEach', 'find', 'findIndex',
      'concat', 'join', 'split', 'replace', 'match', 'search',
      'test', 'exec', 'toString', 'valueOf', 'hasOwnProperty',
      'bind', 'call', 'apply', 'preventDefault', 'stopPropagation',
      'getBoundingClientRect', 'postMessage', 'reload', 'assign',
      'init', 'initialize', 'setup', 'render', 'mount',
      'parse', 'stringify', 'resolve', 'reject', 'then', 'catch',
      'abort', 'cancel', 'start', 'stop', 'pause', 'resume',
      'remove', 'add', 'toggle', 'show', 'hide', 'update',
      'load', 'save', 'read', 'reset', 'clear', 'flush',
      'commit', 'connect', 'disconnect', 'listen',
      'format', 'validate', 'transform', 'convert', 'encode', 'decode',
      'clone', 'copy', 'merge', 'diff', 'sort', 'reverse',
      'debounce', 'throttle', 'memoize', 'compose',
      'notify', 'subscribe', 'unsubscribe', 'dispatch',
      'on', 'off', 'emit', 'trigger', 'handleEvent',
      'register', 'unregister', 'enable', 'disable',
      'next', 'done', 'play', 'send', 'respond',
      'callback', 'handler', 'processor', 'configure',
      'track', 'click', 'select', 'submit', 'input', 'search',
      'find', 'index', 'item', 'list', 'page', 'config', 'options',
      'data', 'result', 'value', 'success', 'complete', 'progress',
      'handle', 'compute', 'calculate', 'request', 'response',
      'scroll', 'resize', 'refresh', 'redirect', 'go', 'back',
      'forward', 'login', 'logout', 'cache', 'token', 'session',
      // JS 全局构造器(prefixWordCall 会把 RegExp( 拆成 Reg+Exp, 完整名检查需要覆盖)
      'RegExp', 'Date', 'Promise', 'Error', 'TypeError', 'EvalError', 'RangeError',
      'ReferenceError', 'SyntaxError', 'URIError', 'Symbol', 'WeakMap', 'WeakSet',
      'ArrayBuffer', 'DataView', 'URL', 'URLSearchParams', 'DOMParser', 'TextEncoder',
      'TextDecoder', 'BigInt', 'Int8Array', 'Uint8Array', 'Uint8ClampedArray',
      'Int16Array', 'Uint16Array', 'Int32Array', 'Uint32Array', 'Float32Array',
      'Float64Array', 'GeneratorFunction', 'AsyncFunction',
      // 通用原型方法(prefixWordCall 对 d.toGMTString()/a.indexOf() 等正常调用的误杀来源)
      'indexOf', 'lastIndexOf', 'includes', 'startsWith', 'endsWith', 'charAt',
      'charCodeAt', 'codePointAt', 'toUpperCase', 'toLowerCase', 'toGMTString',
      'toISOString', 'toUTCString', 'toLocaleString', 'toLocaleDateString',
      'toLocaleTimeString', 'toFixed', 'toExponential', 'toPrecision', 'toJSON',
      'every', 'some', 'sort', 'flat', 'flatMap', 'fill', 'keys', 'values',
      'entries', 'fromCharCode', 'fromCodePoint', 'repeat', 'padStart', 'padEnd',
      'escape', 'unescape',
      'localeCompare', 'normalize', 'getTime', 'getDate', 'getDay', 'getFullYear',
      'getHours', 'getMinutes', 'getSeconds', 'getMilliseconds', 'getMonth',
      'getUTCDate', 'getUTCFullYear', 'getUTCHours', 'getUTCMinutes',
      'getUTCSeconds', 'setTime', 'setDate', 'setFullYear', 'setHours',
      'setMinutes', 'setSeconds', 'setMonth', 'setUTCDate', 'setUTCFullYear',
      'setUTCHours', 'setUTCMinutes', 'setUTCSeconds', 'add', 'remove',
    ]),
    JS_KEYWORDS: new Set([
      'function', 'return', 'var', 'let', 'const', 'if', 'else', 'for',
      'while', 'do', 'switch', 'case', 'break', 'continue', 'try',
      'catch', 'finally', 'throw', 'new', 'delete', 'typeof', 'instanceof',
      'in', 'of', 'void', 'this', 'super', 'class', 'extends', 'import',
      'export', 'default', 'from', 'as', 'async', 'await', 'yield',
      'with', 'debugger', 'null', 'undefined', 'true', 'false',
      'arguments', 'eval', 'static',
    ]),
    SAFE_CAMEL_PREFIXES: [
      'get', 'set', 'is', 'has', 'add', 'remove', 'create', 'delete',
      'can', 'should', 'will',
      'load', 'save', 'update', 'build', 'render', 'run', 'start',
      'stop', 'open', 'close', 'hide', 'show', 'search', 'fetch',
      'send', 'format', 'parse', 'make', 'write', 'read', 'post',
      'put', 'select', 'query', 'request', 'respond', 'handle',
      'compute', 'calculate', 'count', 'check', 'verify', 'confirm',
      'cancel', 'skip', 'scroll', 'resize', 'refresh', 'reload',
      'navigate', 'redirect', 'login', 'logout', 'register', 'validate',
      'encode', 'decode', 'encrypt', 'decrypt', 'compare', 'merge',
      'clone', 'copy', 'move', 'rename', 'swap', 'shuffle', 'bind',
      'unbind', 'attach', 'detach', 'publish', 'expand', 'collapse',
      'lock', 'unlock', 'mark', 'unmark', 'favorite', 'follow', 'share',
      'comment', 'reply', 'prev', 'begin', 'end', 'seek', 'loop',
      'mute', 'unmute', 'fullscreen', 'exit', 'wipe', 'purge',
      'store', 'retrieve', 'upsert', 'patch', 'group', 'aggregate',
      'sum', 'avg', 'min', 'max', 'round', 'ceil', 'floor', 'abs',
      'clamp', 'scale', 'translate', 'skew', 'transform', 'pan',
      'tilt', 'zoom',
    ],
    COMMON_PREFIX_STOPWORDS: new Set([
      'img', 'item', 'list', 'data', 'load', 'init', 'page', 'view',
      'show', 'hide', 'open', 'close', 'click', 'user', 'test', 'main',
      'app', 'help', 'info', 'msg', 'val', 'key', 'name', 'type',
      'size', 'btn', 'box', 'div', 'span', 'tab', 'row', 'col',
      'cell', 'url', 'src', 'href', 'num', 'count', 'index', 'line',
      'text', 'html', 'json', 'time', 'date', 'pos', 'top', 'left',
      'right', 'bottom', 'width', 'height', 'len', 'max', 'min',
      'sum', 'avg', 'log', 'warn', 'error', 'class', 'style', 'body',
      'head', 'meta', 'link', 'script', 'form', 'input', 'area',
      'canvas', 'video', 'audio', 'media', 'icon', 'logo', 'title',
      'label', 'badge', 'card', 'next', 'prev', 'first', 'last',
      'curr', 'total', 'limit', 'offset', 'sort', 'filter', 'search',
      'fetch', 'send', 'get', 'set', 'push', 'pop', 'map', 'arr',
      'obj', 'str', 'bool', 'fn', 'func', 'cb', 'el', 'dom', 'node',
      'doc', 'win', 'nav', 'pic', 'tbl', 'grp',
      // 常见英文/功能词前缀(getset→'gets' 等)
      'gets', 'getse', 'funct', 'functi', 'functio', 'setti', 'creat', 'const', 'retur', 'varia', 'functio',
    ]),
    GP_MIN_PREFIX: 4,
    GP_MAX_PREFIX: 8,
    _patterns: null,
    init: function () {
      this._counters = new _Map();
      this._scriptMap = new _Map();
      this._blockedPatterns = new CappedPatternSet();
      this._scriptElements = [];
      this._scriptIndex = 0;
      this._escapedScripts = [];
      this._retroactiveBlockedSet = new _Set();
      this._seenPfxPerScript = new _Map();
      this._seenPerScript = new _Map();
      this._patterns = {
        funcStr: /(?:\b([a-zA-Z_]\w{1,30})\s*\.\s*)?([a-zA-Z_]\w{1,30})\s*\(\s*["'][^"']{1,80}["']\s*\)/g,
        prefixCall: /(?:\b([a-zA-Z_]\w{1,30})\s*\.\s*)?([a-zA-Z_]\w*?)\d{1,4}\s*\([^)]*\)/g,
        varPrefix: /\bvar\s+([a-zA-Z_]\w*?)\d{1,4}\s*=/g,
        funcDefPrefix: /\bfunction\s+([a-zA-Z_]\w*?)\d{1,4}\s*\(/g,
        assignPrefix: /(?:\b([a-zA-Z_]\w{1,30})\s*\.\s*)?([a-zA-Z_]\w*?)\d{1,4}\s*=[^;,]{1,200}\s*[;,]/g,
        prefixWordCall: /(?:\b([a-zA-Z_]\w{1,20})\s*\.\s*)?([a-zA-Z_]\w{2,20}?)([A-Z][a-z]{0,4}|[a-z]{2,4})\s*\([^)]*\)/g,
        funcNumArg: /(?:\b([a-zA-Z_]\w{1,30})\s*\.\s*)?([a-zA-Z_]\w{2,30})\s*\(\s*\d{3,8}(?:\s*,\s*\d{3,8})*\s*\)/g,
        jQueryCall: /\$\s*\(\s*function\s*\([^)]*\)\s*\{[^}]*?([a-zA-Z_]\w{1,30})\s*\([^)]*\d{3,}[^)]*\)[^}]*\}/g,
        genericCall: /(?:\b([a-zA-Z_]\w{1,20})\s*\.\s*)?([a-zA-Z_]\w{3,25})\s*\([^)]*\)/g,
        singleCall: /^\s*([a-zA-Z_$]\w*)\s*\([^)]*\)\s*;?\s*$/,
      };
    },
    reset: function () { this.init(); },
    _extractPrefix: function (funcName) {
      if (!funcName || funcName.length < 4) return null;
      var self = this;
      var _isStop = function (p) { return self.COMMON_PREFIX_STOPWORDS.has(p.toLowerCase()); };

      var m1 = funcName.match(/^(.+)([A-Z][a-z]{0,2}\d{1,3})$/);
      if (m1 && m1[1].length >= 3 && !self._isSafePrefix(m1[1]) && !_isStop(m1[1])) return m1[1];

      var m2 = funcName.match(/^(.+?)(\d+)$/);
      if (m2 && m2[1].length >= 3 && !self._isSafePrefix(m2[1]) && !_isStop(m2[1])) return m2[1];

      var m3 = funcName.match(/^(.+)([A-Z][a-z]{0,4})$/);
      if (m3 && m3[1].length >= 3 && !self._isSafePrefix(m3[1]) && !_isStop(m3[1])) return m3[1];

      var m4 = funcName.match(/^(.+)([a-z]{3,})$/);
      if (m4 && m4[1].length >= 3 && !self._isSafePrefix(m4[1]) && !_isStop(m4[1])) return m4[1];

      var m5 = funcName.match(/^(.+)([a-z]{2})$/);
      if (m5 && m5[1].length >= 3 && !self._isSafePrefix(m5[1]) && !_isStop(m5[1])) return m5[1];

      var m6 = funcName.match(/^(.+)([a-z])$/);
      if (m6 && m6[1].length >= 3 && !self._isSafePrefix(m6[1]) && !_isStop(m6[1])) return m6[1];
      return null;
    },

    _isSafePrefix: function (pfx) {
      if (!pfx || pfx.length < 3) return false;
      var lower = pfx.toLowerCase();
      for (var i = 0; i < this.SAFE_CAMEL_PREFIXES.length; i++) {
        var sp = this.SAFE_CAMEL_PREFIXES[i];
        if (lower === sp) return true;
        if (lower.length > sp.length && lower.startsWith(sp) && pfx.length > sp.length && pfx[sp.length] === pfx[sp.length].toUpperCase() && pfx[sp.length] !== pfx[sp.length].toLowerCase()) {
          return true;
        }
      }
      return false;
    },
    _extractGPPrefixKeys: function (funcName) {
      if (!funcName || funcName.length < this.GP_MIN_PREFIX) return [];
      var keys = [];
      for (var length = this.GP_MIN_PREFIX; length < Math.min(this.GP_MAX_PREFIX + 1, funcName.length); length++) {
        var _k = funcName.substring(0, length);
        if (this.COMMON_PREFIX_STOPWORDS.has(_k.toLowerCase())) continue;
        keys.push(_k);
      }
      return keys;
    },
    _isSafeFunc: function (funcName) {
      if (this.SAFE_FUNCTIONS.has(funcName)) return true;
      if (this.JS_KEYWORDS.has(funcName)) return true;
      if (funcName.length > 12) return true;

      for (var i = 0; i < this.SAFE_CAMEL_PREFIXES.length; i++) {
        var sp = this.SAFE_CAMEL_PREFIXES[i];
        if (funcName === sp ||
            (funcName.startsWith(sp) &&
             funcName.length > sp.length &&
             funcName.charAt(sp.length) === funcName.charAt(sp.length).toUpperCase() &&
             funcName.charAt(sp.length) !== funcName.charAt(sp.length).toLowerCase())) {
          return true;
        }
      }
      return false;
    },
    _isSafe: function (objectName, funcName) {
      if (objectName) return this.SAFE_OBJECTS.has(objectName);
      return this.SAFE_FUNCTIONS.has(funcName);
    },
    _increment: function (key, scriptIndex) {
      // 按脚本去重: 同一脚本内同 key 只计 1 次 —— "跨标签重复模式"的语义是
      // 跨脚本/跨标签页的重复, 单脚本内重复模式(如 zepto 的 pluck("x")×3)不应触发。
      // FS/PC/FN/VP/FD/AP 六类计数按脚本去重, zepto/wap/bookcase 等
      // 合法脚本不会被误判为广告模式拦截（防大规模误杀）。
      var seen = this._seenPerScript.get(scriptIndex);
      if (!seen) { seen = new _Set(); this._seenPerScript.set(scriptIndex, seen); }
      if (seen.has(key)) return this._counters.get(key) || 0;
      seen.add(key);
      var count = (this._counters.get(key) || 0) + 1;
      this._counters.set(key, count);
      var map = this._scriptMap.get(key) || [];
      map.push(scriptIndex);
      this._scriptMap.set(key, map);
      if (this._counters.size > 2000) {
        var keys = Array.from(this._counters.keys());
        var toRemove = Math.min(1000, keys.length - 1000);
        for (var ki = 0; ki < toRemove; ki++) {
          this._counters.delete(keys[ki]);
          this._scriptMap.delete(keys[ki]);
        }
        this._seenPerScript = new _Map();
        this._seenPfxPerScript = new _Map();
      }
      return count;
    },
    _incrementPfx: function (prefix, scriptIndex) {
      var key = 'PFX:' + prefix;
      var seen = this._seenPfxPerScript.get(scriptIndex);
      if (!seen) {
        seen = new _Set();
        this._seenPfxPerScript.set(scriptIndex, seen);
      }
      if (seen.has(key)) return this._counters.get(key) || 0;
      seen.add(key);
      return this._increment(key, scriptIndex);
    },
    _doRetroactiveScan: function (pattern, currentIdx) {
      if (this._escapedScripts.length === 0) return;
      var blockedIndices = [];
      for (var i = 0; i < this._escapedScripts.length; i++) {
        var entry = this._escapedScripts[i];
        if (entry.index === currentIdx) continue;
        if (this._retroactiveBlockedSet.has(entry.index)) continue;
        if (entry.content.indexOf(pattern) !== -1) {
          blockedIndices.push(i);
          this._retroactiveBlockedSet.add(entry.index);
          if (entry.element && entry.element.isConnected && !ProcessedElementsCache.isProcessed(entry.element)) {
            var ci = Utils.getContentIdentifier(entry.element);
            if (!ci || !currentConfig.whitelist.has(ci)) {
              LogManager.add('scriptBlacklistMode', entry.element, {
                type: 'SCRIPT_BLACKLIST',
                detail: '命中跨标签重复模式(回溯): ' + pattern + ' - 脚本: ' + Utils.truncateString(entry.content, CONFIG.CONTENT_PREVIEW_LENGTH),
                elementContentIdentifier: ci,
              });
              ResourceCanceller.cancelResourceLoading(entry.element);
              ProcessedElementsCache.markAsProcessed(entry.element);
            }
          }
        }
      }
      for (var j = blockedIndices.length - 1; j >= 0; j--) {
        this._escapedScripts.splice(blockedIndices[j], 1);
      }
    },
    _doSCRetroactiveScan: function (currentIdx) {
      if (this._escapedScripts.length === 0) return;
      var singleCallRe = this._patterns.singleCall;
      var blockedIndices = [];
      for (var i = 0; i < this._escapedScripts.length; i++) {
        var entry = this._escapedScripts[i];
        if (entry.index === currentIdx) continue;
        if (this._retroactiveBlockedSet.has(entry.index)) continue;
        if (singleCallRe.test(entry.content)) {
          blockedIndices.push(i);
          this._retroactiveBlockedSet.add(entry.index);
          if (entry.element && entry.element.isConnected && !ProcessedElementsCache.isProcessed(entry.element)) {
            var ci = Utils.getContentIdentifier(entry.element);
            if (!ci || !currentConfig.whitelist.has(ci)) {
            LogManager.add('scriptBlacklistMode', entry.element, {
              type: 'SCRIPT_BLACKLIST',
              detail: '命中单调用脚本聚合(回溯) - 脚本: ' + Utils.truncateString(entry.content, CONFIG.CONTENT_PREVIEW_LENGTH),
              elementContentIdentifier: ci,
            });
            ResourceCanceller.cancelResourceLoading(entry.element);
            ProcessedElementsCache.markAsProcessed(entry.element);
            }
          }
        }
      }
      for (var j = blockedIndices.length - 1; j >= 0; j--) {
        this._escapedScripts.splice(blockedIndices[j], 1);
      }
    },
    _retroactiveBlockFull: function (patternStr, patternName, thresholdNum) {
      if (!patternStr || typeof patternStr !== 'string') return;
      for (var i = 0; i < this._scriptElements.length; i++) {
        var entry = this._scriptElements[i];
        if (!entry || !entry.element || !entry.element.isConnected) continue;
        if (ProcessedElementsCache.isProcessed(entry.element)) continue;
        if (this._retroactiveBlockedSet.has(entry.index)) continue;
        var c = entry.element.textContent || '';
        if (c.indexOf(patternStr) !== -1) {
          this._retroactiveBlockedSet.add(entry.index);
          var ci = Utils.getContentIdentifier(entry.element);
          if (!ci || !currentConfig.whitelist.has(ci)) {
            LogManager.add('scriptBlacklistMode', entry.element, {
              type: 'SCRIPT_BLACKLIST',
              detail: '命中跨标签重复模式: ' + patternName + ' (全量回溯) - 脚本: ' + Utils.truncateString(c, CONFIG.CONTENT_PREVIEW_LENGTH),
              elementContentIdentifier: ci,
            });
            ResourceCanceller.cancelResourceLoading(entry.element);
            ProcessedElementsCache.markAsProcessed(entry.element);
          }
        }
      }
    },
    checkScript: function (scriptElement, content) {
      if (!content || typeof content !== 'string') return { blocked: false, reason: null };
      if (ProcessedElementsCache.isProcessed(scriptElement)) return { blocked: false, reason: null };
      var match;
      var currentIdx = this._scriptIndex++;
      if (this._scriptElements.length > 500) {
        this._scriptElements = this._scriptElements.filter(function(e) { return e.element && e.element.isConnected; });
        if (this._scriptElements.length > 500) this._scriptElements = this._scriptElements.slice(-300);
      }
      this._scriptElements.push({ element: scriptElement, index: currentIdx });
      var self = this;
      var patterns = this._patterns;
      var threshold = (typeof currentConfig.crossTagPatternThreshold === 'number' && currentConfig.crossTagPatternThreshold >= 1)
          ? currentConfig.crossTagPatternThreshold : 3;
      var maybeBlock = null;

      if (this._blockedPatterns.size > 0) {
        var _iter = this._blockedPatterns.values();
        var _result = _iter.next();
        while (!_result.done) {
          var bp = _result.value;
          if (bp === '__SINGLE_CALL__') { _result = _iter.next(); continue; }
          if (content.indexOf(bp) !== -1) {
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: Utils.truncateString(bp, 30), scriptPreview: Utils.truncateString(content, 120) };
            break;
          }
          _result = _iter.next();
        }
      }

      if (!maybeBlock) {
        var re0 = patterns.funcStr; re0.lastIndex = 0;
        while ((match = re0.exec(content)) !== null) {
          var obj0 = match[1], func0 = match[2];
          // obj 安全或函数本身安全都跳过(strCookie.split("; ") 等正常调用均放行)
          if (self._isSafe(obj0, func0) || self._isSafeFunc(func0)) continue;
          var key0 = 'FS:' + func0;
          var count0 = self._increment(key0, currentIdx);
          var pfx0 = self._extractPrefix(func0);
          if (pfx0) self._incrementPfx(pfx0, currentIdx);
          if (count0 >= threshold) {
            self._blockedPatterns.add(func0);
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: func0, scriptPreview: Utils.truncateString(content, 120) };
            self._retroactiveBlock(key0, func0, threshold, currentIdx);
            self._doRetroactiveScan(func0, currentIdx);
            self._retroactiveBlockFull(func0, func0, threshold);
            break;
          }
        }
      }

      if (!maybeBlock) {
        var re1 = patterns.prefixCall; re1.lastIndex = 0;
        while ((match = re1.exec(content)) !== null) {
          var obj1 = match[1], prefix1 = match[2];
          if (obj1 && self.SAFE_OBJECTS.has(obj1)) continue;
          if (!prefix1 || prefix1.length < 1) continue;
          // 合法前缀(load1/init2 等)与常见数字后缀名(img1/item2)不计入
          if (self._isSafePrefix(prefix1) || self.COMMON_PREFIX_STOPWORDS.has(prefix1.toLowerCase())) continue;
          var key1 = 'PC:' + prefix1;
          var count1 = self._increment(key1, currentIdx);
          self._incrementPfx(prefix1, currentIdx);
          if (count1 >= threshold) {
            self._blockedPatterns.add(prefix1);
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: prefix1, scriptPreview: Utils.truncateString(content, 120) };
            self._retroactiveBlock(key1, prefix1 + 'N()', threshold, currentIdx);
            self._doRetroactiveScan(prefix1, currentIdx);
            self._retroactiveBlockFull(prefix1, prefix1 + 'N()', threshold);
            break;
          }
        }
      }

      if (!maybeBlock) {
        var rePW = patterns.prefixWordCall; rePW.lastIndex = 0;
        var matchPW;
        while ((matchPW = rePW.exec(content)) !== null) {
          var objPW = matchPW[1], prefixPW = matchPW[2];
          if (objPW && self.SAFE_OBJECTS.has(objPW)) continue;
          if (!prefixPW || prefixPW.length < 3) continue;
          // 完整函数名在安全名单(SAFE_FUNCTIONS/JS_KEYWORDS)中的调用直接跳过:
          // prefixWordCall 会把 insertBefore 拆成 insertBe+fore、split 拆成 spl+it,
          // 只查前缀会误杀正常脚本(如 insertBefore/split 等常见调用)
          var _fullPW = prefixPW + (matchPW[3] || '');
          if (self.SAFE_FUNCTIONS.has(_fullPW) || self.JS_KEYWORDS.has(_fullPW)) continue;
          if (self._isSafePrefix(prefixPW) || self.COMMON_PREFIX_STOPWORDS.has(prefixPW.toLowerCase())) continue;
          var keyPW = 'PW:' + prefixPW;
          var countPW = self._increment(keyPW, currentIdx);
          self._incrementPfx(prefixPW, currentIdx);
          if (countPW >= threshold) {
            self._blockedPatterns.add(prefixPW);
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: prefixPW, scriptPreview: Utils.truncateString(content, 120) };
            self._retroactiveBlock(keyPW, prefixPW + '*', threshold, currentIdx);
            self._doRetroactiveScan(prefixPW, currentIdx);
            self._retroactiveBlockFull(prefixPW, prefixPW + '*', threshold);
            break;
          }
        }
      }

      if (!maybeBlock) {
        var reFN = patterns.funcNumArg; reFN.lastIndex = 0;
        var matchFN;
        while ((matchFN = reFN.exec(content)) !== null) {
          var objFN = matchFN[1], funcFN = matchFN[2];
          if (self._isSafe(objFN, funcFN) || self._isSafeFunc(funcFN)) continue;
          var keyFN = 'FN:' + funcFN;
          var countFN = self._increment(keyFN, currentIdx);
          var pfxFN = self._extractPrefix(funcFN);
          if (pfxFN) self._incrementPfx(pfxFN, currentIdx);
          if (countFN >= threshold) {
            self._blockedPatterns.add(funcFN);
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: funcFN + '(数字参数)', scriptPreview: Utils.truncateString(content, 120) };
            self._retroactiveBlock(keyFN, funcFN + '(...)', threshold, currentIdx);
            self._doRetroactiveScan(funcFN, currentIdx);
            self._retroactiveBlockFull(funcFN, funcFN + '(...)', threshold);
            break;
          }
        }
      }

      if (!maybeBlock) {
        var reJQ = patterns.jQueryCall; reJQ.lastIndex = 0;
        var matchJQ;
        while ((matchJQ = reJQ.exec(content)) !== null) {
          var innerFunc = matchJQ[1];
          if (!innerFunc || self.SAFE_FUNCTIONS.has(innerFunc)) continue;
          var keyJQ = 'JQ:' + innerFunc;
          var countJQ = self._increment(keyJQ, currentIdx);
          if (countJQ >= threshold) {
            self._blockedPatterns.add(innerFunc);
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: '$().' + innerFunc, scriptPreview: Utils.truncateString(content, 120) };
            self._retroactiveBlock(keyJQ, '$().' + innerFunc, threshold, currentIdx);
            self._doRetroactiveScan(innerFunc, currentIdx);
            break;
          }
        }
      }

      if (!maybeBlock) {
        var reGC = patterns.genericCall; reGC.lastIndex = 0;
        var matchGC;
        var seenPfx = {};
        while ((matchGC = reGC.exec(content)) !== null) {
          var objGC = matchGC[1], funcGC = matchGC[2];
          if (self._isSafe(objGC, funcGC)) continue;
          if (self._isSafeFunc(funcGC)) continue;
          var gpKeys = self._extractGPPrefixKeys(funcGC);
          for (var gi = 0; gi < gpKeys.length; gi++) {
            var gpKeyStr = gpKeys[gi];
            if (seenPfx[gpKeyStr]) continue;
            seenPfx[gpKeyStr] = true;
            var gpCount = self._incrementPfx(gpKeyStr, currentIdx);
            if (gpCount >= threshold && !self._blockedPatterns.has(gpKeyStr)) {
              self._blockedPatterns.add(gpKeyStr);
              maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: gpKeyStr, scriptPreview: Utils.truncateString(content, 120) };
              var pfxKeyFull = 'PFX:' + gpKeyStr;
              self._retroactiveBlock(pfxKeyFull, gpKeyStr + '*', threshold, currentIdx);
              self._doRetroactiveScan(gpKeyStr, currentIdx);
              self._retroactiveBlockFull(gpKeyStr, gpKeyStr + '*', threshold);
              break;
            }
          }
          if (maybeBlock) break;
        }
      }

      if (!maybeBlock) {
        var re3 = patterns.varPrefix; re3.lastIndex = 0;
        while ((match = re3.exec(content)) !== null) {
          var prefix3 = match[1];
          if (!prefix3 || prefix3.length < 1) continue;
          if (self._isSafePrefix(prefix3) || self.COMMON_PREFIX_STOPWORDS.has(prefix3.toLowerCase())) continue;
          var key3 = 'VP:' + prefix3;
          var count3 = self._increment(key3, currentIdx);
          if (count3 >= threshold) {
            self._blockedPatterns.add(prefix3);
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: prefix3, scriptPreview: Utils.truncateString(content, 120) };
            self._retroactiveBlock(key3, 'var ' + prefix3 + 'N', threshold, currentIdx);
            self._doRetroactiveScan(prefix3, currentIdx);
            self._retroactiveBlockFull(prefix3, 'var ' + prefix3 + 'N', threshold);
            break;
          }
        }
      }

      if (!maybeBlock) {
        var re4 = patterns.funcDefPrefix; re4.lastIndex = 0;
        while ((match = re4.exec(content)) !== null) {
          var prefix4 = match[1];
          if (!prefix4 || prefix4.length < 1) continue;
          if (self._isSafePrefix(prefix4) || self.COMMON_PREFIX_STOPWORDS.has(prefix4.toLowerCase())) continue;
          var key4 = 'FD:' + prefix4;
          var count4 = self._increment(key4, currentIdx);
          if (count4 >= threshold) {
            self._blockedPatterns.add(prefix4);
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: prefix4, scriptPreview: Utils.truncateString(content, 120) };
            self._retroactiveBlock(key4, 'function ' + prefix4 + 'N', threshold, currentIdx);
            self._doRetroactiveScan(prefix4, currentIdx);
            self._retroactiveBlockFull(prefix4, 'function ' + prefix4 + 'N', threshold);
            break;
          }
        }
      }

      if (!maybeBlock) {
        var re5 = patterns.assignPrefix; re5.lastIndex = 0;
        while ((match = re5.exec(content)) !== null) {
          var obj5 = match[1], prefix5 = match[2];
          if (obj5 && self.SAFE_OBJECTS.has(obj5)) continue;
          if (!prefix5 || prefix5.length < 1) continue;
          if (self._isSafePrefix(prefix5) || self.COMMON_PREFIX_STOPWORDS.has(prefix5.toLowerCase())) continue;
          var key5 = 'AP:' + prefix5;
          var count5 = self._increment(key5, currentIdx);
          if (count5 >= threshold) {
            self._blockedPatterns.add(prefix5);
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: prefix5, scriptPreview: Utils.truncateString(content, 120) };
            self._retroactiveBlock(key5, prefix5 + 'N =', threshold, currentIdx);
            self._doRetroactiveScan(prefix5, currentIdx);
            self._retroactiveBlockFull(prefix5, prefix5 + 'N =', threshold);
            break;
          }
        }
      }

      if (!maybeBlock) {
        var hasFetch = /\b(?:fetch|XMLHttpRequest)\s*\(/.test(content);
        var hasEval = /\b(?:eval|Function)\s*\(/.test(content);
        if (hasFetch && hasEval) {
          var keyFE = 'FE:fetchEval';
          var countFE = self._increment(keyFE, currentIdx);
          if (countFE >= threshold) {
            self._blockedPatterns.add('fetch+eval');
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: 'fetch后执行', scriptPreview: Utils.truncateString(content, 120) };
            self._retroactiveBlock(keyFE, 'fetch后执行代码', 3, currentIdx);
          }
        }
      }
      if (!maybeBlock) {
        var domCreateCount = (content.match(/document\.createElement\s*\(/g) || []).length;
        if (domCreateCount >= 4) {
          var keyDOM = 'DI:domBatch';
          var countDOM = self._increment(keyDOM, currentIdx);
          if (countDOM >= threshold) {
            self._blockedPatterns.add('domBatch');
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: 'DOM批量创建', scriptPreview: Utils.truncateString(content, 120) };
            self._retroactiveBlock(keyDOM, 'DOM批量创建', threshold, currentIdx);
          }
        }
      }

      if (!maybeBlock) {
        // 单调用脚本: 仅当函数名不在安全名单时才计数(init();/load(); 等合法单调用脚本不计)
        var _scMatch = content.match(patterns.singleCall);
        if (_scMatch && !self._isSafeFunc(_scMatch[1])) {
          // 按函数名计数(避免所有单调用脚本共享 SC:singleCall 被连坐,
          // 页面 3 个以上的 getset() 等正常功能脚本不会被拦)
          var scKey = 'SC:' + (_scMatch[1] || 'singleCall');
          var scCount = self._increment(scKey, currentIdx);
          if (scCount >= threshold) {
            self._blockedPatterns.add('__SINGLE_CALL__');
            maybeBlock = { blocked: true, reason: '跨标签重复模式', subject: '单调用脚本聚合', scriptPreview: Utils.truncateString(content, 120) };
            self._doSCRetroactiveScan(currentIdx);
          }
        }
      }

      if (ProcessedElementsCache.isProcessed(scriptElement)) {
        return { blocked: true, reason: maybeBlock ? maybeBlock.reason : '跨标签重复模式', subject: maybeBlock ? maybeBlock.subject : null };
      }
      if (maybeBlock && maybeBlock.blocked) {
        var ci = Utils.getContentIdentifier(scriptElement);
        if (ci && !currentConfig.whitelist.has(ci)) {
          LogManager.add('scriptBlacklistMode', scriptElement, {
            type: 'SCRIPT_BLACKLIST',
            detail: '命中跨标签重复模式: ' + (maybeBlock.subject || '未知') + ' - 脚本: ' + (maybeBlock.scriptPreview || ''),
            elementContentIdentifier: ci,
          });
          ResourceCanceller.cancelResourceLoading(scriptElement);
          ProcessedElementsCache.markAsProcessed(scriptElement);
          return { blocked: true, reason: maybeBlock.reason, subject: maybeBlock.subject };
        }
      }

      if (!maybeBlock || !maybeBlock.blocked) {
        if (this._escapedScripts.length > 200) {
          this._escapedScripts = this._escapedScripts.filter(function(e) { return e.element && e.element.isConnected; });
          if (this._escapedScripts.length > 200) this._escapedScripts = this._escapedScripts.slice(-150);
        }
        this._escapedScripts.push({ index: currentIdx, content: content, element: scriptElement });
      }
      return { blocked: false, reason: null };
    },
    _retroactiveBlock: function (key, patternName, threshold, currentIdx) {
      var indices = this._scriptMap.get(key) || [];
      var thresholdNum = (threshold || 3);
      for (var i = 0; i < indices.length; i++) {
        if (typeof currentIdx === 'number' && indices[i] === currentIdx) continue;
        if (this._retroactiveBlockedSet.has(indices[i])) continue;
        // _scriptElements 超限时会过滤/截断, 按存储的 index 定位实际元素
        var entry = null;
        for (var _si = 0; _si < this._scriptElements.length; _si++) {
          if (this._scriptElements[_si] && this._scriptElements[_si].index === indices[i]) { entry = this._scriptElements[_si]; break; }
        }
        if (entry && entry.element && entry.element.isConnected && !ProcessedElementsCache.isProcessed(entry.element)) {
          this._retroactiveBlockedSet.add(indices[i]);
          var ci = Utils.getContentIdentifier(entry.element);
          if (!ci || !currentConfig.whitelist.has(ci)) {
            var scriptContent = entry.element.textContent || entry.element.src || '';
            var contentPreview = Utils.truncateString(scriptContent, CONFIG.CONTENT_PREVIEW_LENGTH);
            LogManager.add('scriptBlacklistMode', entry.element, {
              type: 'SCRIPT_BLACKLIST',
              detail: '命中跨标签重复模式: ' + patternName + ' (出现' + thresholdNum + '次以上, 回溯拦截) - 脚本: ' + contentPreview,
              elementContentIdentifier: ci,
            });
            ResourceCanceller.cancelResourceLoading(entry.element);
            ProcessedElementsCache.markAsProcessed(entry.element);
          }
        }
      }
    },
  };
  CrossScriptPatternTracker.init();


  if (_document.readyState && _document.readyState !== 'loading') {
    try { CrossScriptPatternTracker.reset(); } catch (e) {}
  } else {
    _document.addEventListener('DOMContentLoaded', function () {
      CrossScriptPatternTracker.reset();
    });
  }

  // ======================== 残留容器清理器 ========================
    // 移除被拦截元素的空父容器/残留节点，避免页面留空白块。
  const ResidualCleaner = {
    _scanTimer: null,
    _pendingNodes: [],
    _maxCleanupDepth: 5,
    observer: null,
    _isLazyImage: function (el) {
      if (el.tagName !== 'IMG') return false;
      if (el.loading === 'lazy') return true;
      var lazyAttrs = [
        'data-src', 'data-original', 'data-echo', 'data-lazy-src',
        'data-bg', 'data-srcset', 'data-lazy', 'data-ll-status', 'data-islazy',
      ];
      for (var i = 0; i < lazyAttrs.length; i++) {
        if (el.hasAttribute(lazyAttrs[i])) return true;
      }
      if (el.classList) {
        if (el.classList.contains('lazyload') || el.classList.contains('lazy')) return true;
      }
      if (el.srcset && el.srcset.trim()) return true;
      if (el.parentElement && el.parentElement.tagName === 'PICTURE') return true;
      return false;
    },
    init: function () {
      if (!Utils.isAnyModuleEnabled() || !currentConfig.residualCleanupEnabled) {
        this.stop();
        return;
      }
      this.setupMutationObserver();
      this.initialScan();
      this.startPeriodicScan();
    },
    stop: function () {
      if (this.observer) {
        this.observer.disconnect();
        this.observer = null;
      }
      if (this._scanTimer !== null) {
        _cancelIdleCallback(this._scanTimer);
        this._scanTimer = null;
      }
      this._pendingNodes = [];
    },
    getScanSelectors: function () {
      var selectors = ['div', 'span', 'section', 'aside'];
      if (currentConfig.modules.interceptThirdParty) {
        selectors.push('iframe');
        selectors.push('object');
        selectors.push('embed');
      }
      return selectors.join(', ');
    },
    setupMutationObserver: function () {
      var self = this;
      this.observer = new _MutationObserver(function (ms) {
        for (const m of ms) {
          if (m.type === 'childList') {
            if (m.addedNodes.length > 0) {
              for (const n of m.addedNodes) {
                if (n.nodeType === _Node.ELEMENT_NODE && Utils.isElement(n)) {
                  self._pendingNodes.push(n);
                  self.checkAndCleanup(n);
                }
              }
            }
            if (m.removedNodes.length > 0 && m.target && Utils.isElement(m.target)) self.checkAndCleanup(m.target);
          }
        }
      });
      this.observer.observe(_document.documentElement, { childList: true, subtree: true, attributes: false });
    },
    cleanEmptyParents: function (parent, depth) {
      depth = depth || 0;
      if (depth > this._maxCleanupDepth) return;
      if (
        !parent ||
        parent === _document.body ||
        parent === _document.documentElement ||
        !Utils.isElement(parent) ||
        ProcessedElementsCache.isProcessed(parent)
      )
        return;
      if (this.isStrictEmpty(parent) && Utils.isSuspiciousAdContainer(parent) &&
          !hasReleasedOverlayInTree(parent)) {
        ProcessedElementsCache.markAsProcessed(parent);
        parent.setAttribute('data-adblock-hidden', 'true');
        parent.style.setProperty('display', 'none', 'important');
        this.cleanEmptyParents(parent.parentElement, depth + 1);
      }
    },
    isStrictEmpty: function (container) {
      if (!Utils.isElement(container)) return false;
      if (_isSafe(container)) return false;
      if (isWhitelistedOrProtected(container)) return false;
      var hasReal = false;
      for (var i = 0; i < container.childNodes.length; i++) {
        var child = container.childNodes[i];
        if (child.nodeType === _Node.ELEMENT_NODE && ProcessedElementsCache.isProcessed(child)) continue;
        if (child.nodeType === _Node.ELEMENT_NODE && isWhitelistedOrProtected(child)) { hasReal = true; break; }
        if (child.nodeType === _Node.TEXT_NODE) {
          if (child.textContent.trim().length > 1) {
            hasReal = true;
            break;
          }
        } else if (child.nodeType === _Node.ELEMENT_NODE) {
          var el = child;
          var inlineStyle = el.style;
          if (inlineStyle.display === 'none' || inlineStyle.visibility === 'hidden' || inlineStyle.opacity === '0') continue;
          if (el.offsetWidth <= 0 && el.offsetHeight <= 0) continue;
          var s = _getComputedStyle(el);
          if (s.display === 'none' || s.visibility === 'hidden' || s.opacity === '0') continue;
          if (el.tagName === 'IMG') {
            if (this._isLazyImage(el)) {
              hasReal = true;
              break;
            }
            var imgSrc = el.getAttribute('src') || el.getAttribute('data-src') || '';
            var isDataPlaceholder = imgSrc.startsWith('data:') && imgSrc.length < CONFIG.LAZY_PLACEHOLDER_MAX_LEN;
            if (imgSrc && !isDataPlaceholder) {
              hasReal = true;
              break;
            }
            if ((el.naturalWidth <= 5 && el.naturalHeight <= 5) || (el.offsetWidth <= 5 && el.offsetHeight <= 5)) continue;
          }
          if (el.offsetWidth > CONFIG.CONTAINER_MIN_VISIBLE && el.offsetHeight > CONFIG.CONTAINER_MIN_VISIBLE) {
            if (el.tagName === 'A') {
              var hasLink = false;
              for (var j = 0; j < el.childNodes.length; j++) {
                var c = el.childNodes[j];
                if (c.nodeType === _Node.TEXT_NODE && c.textContent.trim().length > 0) {
                  hasLink = true;
                  break;
                }
                if (c.nodeType === _Node.ELEMENT_NODE) {
                  if (c.tagName === 'IMG' && (c.naturalWidth > 5 || this._isLazyImage(c))) {
                    hasLink = true;
                    break;
                  }
                  if (c.offsetWidth > CONFIG.CONTAINER_MIN_VISIBLE && c.offsetHeight > CONFIG.CONTAINER_MIN_VISIBLE && c.tagName !== 'BR' && c.tagName !== 'HR' && c.tagName !== 'A') {
                    hasLink = true;
                    break;
                  }
                }
              }
              if (!hasLink) continue;
            }
            hasReal = true;
            break;
          }
        }
      }
      return !hasReal;
    },
    checkAndCleanup: function (element) {
      if (!element || !Utils.isElement(element) || ProcessedElementsCache.isProcessed(element) || element === _document.body || element === _document.documentElement) return;
      if (isWhitelistedOrProtected(element) || hasWhitelistedContentInTree(element)) return;


      var w = element.offsetWidth;
      var h = element.offsetHeight;
      if (w > 0 && w < CONFIG.RESIDUAL_MIN_WIDTH && h > 0 && h < CONFIG.RESIDUAL_MIN_HEIGHT) return;
      if (!currentConfig.residualCleanupEnabled) return;
      if (hasReleasedOverlayInTree(element)) {
        ProcessedElementsCache.markAsProcessed(element);
        return;
      }
      if (this.isStrictEmpty(element)) {
        var s = _getComputedStyle(element);
        var isFH = s.height !== 'auto' && parseFloat(s.height) > CONFIG.FIXED_HEIGHT_THRESHOLD;
        var isHZ = parseInt(s.zIndex) > CONFIG.ZINDEX_HIDE_THRESHOLD;
        var isAF = s.position === 'absolute' || s.position === 'fixed';
        if (isFH || isAF || isHZ || Utils.isSuspiciousAdContainer(element)) {
          ProcessedElementsCache.markAsProcessed(element);
          this.cleanupContainer(element, isAF || isHZ);
        }
      }
    },
    cleanupContainer: function (container, forceHide) {
      forceHide = forceHide || false;
      if (!container || !Utils.isElement(container) || !container.isConnected) return;
      if (forceHide) {
        container.style.setProperty('display', 'none', 'important');
        container.style.setProperty('visibility', 'hidden', 'important');
        container.style.setProperty('pointer-events', 'none', 'important');
        container.style.setProperty('height', '0px', 'important');
        container.style.setProperty('overflow', 'hidden', 'important');
        var p = container.parentElement;
        while (p && p !== _document.body && p !== _document.documentElement) {
          if (!Utils.isElement(p)) break;
          p.style.setProperty('pointer-events', 'none', 'important');
          if (Array.from(p.childNodes).some(function (c) {
            return ((c.nodeType === _Node.ELEMENT_NODE && !ProcessedElementsCache.isProcessed(c)) || (c.nodeType === _Node.TEXT_NODE && c.textContent.trim().length > 0));
          })) break;
          p = p.parentElement;
        }
        ProcessedElementsCache.markAsProcessed(container);
      } else {
        container.setAttribute('data-adblock-hidden', 'true');
        container.style.setProperty('display', 'none', 'important');
        ProcessedElementsCache.markAsProcessed(container);
        this.cleanEmptyParents(container.parentElement);
      }
    },
    initialScan: function () {
      var self = this;
      var allElements = _document.querySelectorAll(this.getScanSelectors());
      var len = allElements.length;
      if (len === 0) return;
      var index = 0;
      var toR = [];
      var toH = [];
      var BATCH_SIZE = 150;
      var URGENT_BATCH = 30;
      function flushDOM() {
        toR.forEach(function (el) {
          var p = el.parentElement;
          el.remove();
          self.cleanEmptyParents(p);
        });
        toH.forEach(function (el) {
          el.style.setProperty('display', 'none', 'important');
          el.style.setProperty('height', '0px', 'important');
          el.style.setProperty('overflow', 'hidden', 'important');
        });
        toR = [];
        toH = [];
      }
      function processRange(start, end, deadline) {
        // 绝对帧预算: 不依赖 timeRemaining(无 requestIdleCallback 的环境该值恒为 50,
        // 会让整批元素连续同步判定); 返回实际处理到的位置, 未处理的不被跳过
        var _t0 = performance.now();
        var last = start;
        for (var i = start; i < end; i++) {
          var el = allElements[i];
          if (!el || !Utils.isElement(el) || ProcessedElementsCache.isProcessed(el) || el === _document.body || el === _document.documentElement) continue;
          var w = el.offsetWidth;
          var h = el.offsetHeight;
          if (w > 0 && w < CONFIG.RESIDUAL_MIN_WIDTH && h > 0 && h < CONFIG.RESIDUAL_MIN_HEIGHT) continue;
          if (self.isStrictEmpty(el) && !hasReleasedOverlayInTree(el)) {
            var s = _getComputedStyle(el);
            var isFH = s.height !== 'auto' && parseFloat(s.height) > CONFIG.FIXED_HEIGHT_THRESHOLD;
            var isHZ = parseInt(s.zIndex) > CONFIG.ZINDEX_HIDE_THRESHOLD;
            var isAF = s.position === 'absolute' || s.position === 'fixed';
            if (isFH || isAF || isHZ || Utils.isSuspiciousAdContainer(el)) {
              ProcessedElementsCache.markAsProcessed(el);
              if (isAF || isHZ) toH.push(el);
              else toR.push(el);
            }
          }
          last = i + 1;
          if (performance.now() - _t0 > 8) break;
        }
        return last;
      }

      index = processRange(0, URGENT_BATCH, null);

      function processBatch(deadline) {
        var batchEnd = Math.min(index + BATCH_SIZE, len);
        index = processRange(index, batchEnd, deadline);
        if (index >= len) {
          flushDOM();
          return;
        }
        _requestIdleCallback(processBatch);
      }
      if (index < len) {
        _requestIdleCallback(processBatch);
      } else {
        flushDOM();
      }
    },
    startPeriodicScan: function () {
      var self = this;
      var last = 0;
      var loop = function (dl) {
        if (!currentConfig.residualCleanupEnabled) return;
        var now = Date.now();
        // 后台标签页降频纯补扫(Chrome 对隐藏页定时器本就限流, 这里显式再加一道保险)
        if (now - last > CONFIG.IDLE_SCAN_INTERVAL * (_document.visibilityState === 'hidden' ? 3 : 1) && dl.timeRemaining() > 5) {
          var cnt = 0;
          var batch = self._pendingNodes.splice(0, CONFIG.BATCH_SIZE_CLEANUP);
          for (var i = 0; i < batch.length && dl.timeRemaining() > 5 && cnt < CONFIG.BATCH_SIZE_CLEANUP; i++) {
            var el = batch[i];
            if (!el || !Utils.isElement(el) || !el.isConnected) continue;
            self.checkAndCleanup(el);
            cnt++;
          }
          if (self._pendingNodes.length > 500) {
            self._pendingNodes = self._pendingNodes.filter(function(n) {
              return n && n.isConnected;
            });
            if (self._pendingNodes.length > 800) {
              self._pendingNodes = self._pendingNodes.slice(-500);
            }
          }
          if (cnt > 0) last = now;
        }
        self._scanTimer = _requestIdleCallback(loop);
      };
      this._scanTimer = _requestIdleCallback(loop);
    },
  };

  // ======================== 覆盖层拦截器 ========================
    // 核心模块之一：检测并隐藏页面覆盖层广告（fixed/sticky 弹层、贴边条幅、注入伪元素广告、
    // data: 内联图广告、站点预留广告位容器）。检测规则见 isOverlayElement；
    // 隐藏后支持反隐藏对抗（属性监听 + 周期复查）；拦截日志可加白放行。

  function _isScrollableContainer(el, cstyle) {
    if (!el) return false;
    try {
      var s = cstyle || _getComputedStyle(el);
      var oy = String(s.overflowY || '');
      if (oy === 'auto' || oy === 'scroll' || oy === 'overlay') return true;
      var o = String(s.overflow || '');
      var parts = o.split(/\s+/);
      for (var i = 0; i < parts.length; i++) {
        if (parts[i] === 'auto' || parts[i] === 'scroll') return true;
      }
    } catch(e) {}
    return false;
  }


  function _decodeHtmlEntities(s) {
    if (!s || typeof s !== 'string') return s || '';
    try {
      return s
        .replace(/&#(\d+);/g, function (m, n) { return String.fromCharCode(parseInt(n, 10)); })
        .replace(/&#x([0-9a-f]+);/gi, function (m, n) { return String.fromCharCode(parseInt(n, 16)); })

        .replace(/&sol;/g, '/')
        .replace(/&colon;/g, ':')
        .replace(/&period;/g, '.')
        .replace(/&quest;/g, '?')
        .replace(/&num;/g, '#')
        .replace(/&equals;/g, '=')
        .replace(/&semi;/g, ';')
        .replace(/&comma;/g, ',')
        .replace(/&ast;/g, '*')
        .replace(/&bsol;/g, '\\')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&nbsp;/gi, '\u00a0');
    } catch(e) { return s; }
  }

  const OverlayInterceptor = {
    _enabled: false,
    _observer: null,
    _processedSet: new WeakSet(),
    _hideClass: '_uh',
    _periodicTimer: null,
    _hiddenElementsMap: null,
    _locTracker: null,
    _parentTracker: null,
    _locationSterile: null,
    _STERILIZE_THRESHOLD: 3,
    // 读写分相: 批量判定期间(_flushChecks)不为 null —— 布局类隐藏写(隐藏类/内联三件套/
    // 灭菌 display)先缓存到 _styleWriteQueue, 批尾统一落写; 记账/属性标记/日记照旧即时
    // 执行, 判定谓词不动, 消除"逐元素读布局→写隐藏→再读布局"的强制回流
    _styleWriteQueue: null,
    _deferHideSet: null,
    _styleCache: null,
    _sterilizedByLoc: null,
    _overlayWriteHook: null,
    _pendingFsRecheck: null,
    _visResumeHandler: null,
    _resumeScan: false,      // 回前台标记: 下一轮周期补扫立即执行并重建快照
    _coveredChildren: null,
    init: function () {
      currentConfig.modules.overlayIntercept ? this.enable() : this.disable();
    },

    _computeOverlayCI: function (el) {
      if (!el || !Utils.isElement(el)) return null;
      var ci = Utils.getContentIdentifier(el);
      if (ci) return ci;
      var tagInfo = _overlayTagIdent(el);
      var contentPreview = Utils.truncateString(el.textContent || '', 100);
      return 'OVERLAY_' + generateContentHash('overlayIntercept:' + tagInfo + ':' + contentPreview);
    },

    enable: function () {
      if (this._enabled) return;
      this._enabled = true;
      this._hiddenElementsMap = new _Map();
      // 【隐藏记录表】记下"被我们隐藏的元素 + 对应的白名单键"，两个用途：
      // ① 用户加白后从这里恢复显示；② 广告脚本偷偷取消隐藏时知道该盯着谁。
      this._locTracker = new _Map();
      this._parentTracker = new WeakMap();
      this._locationSterile = new _Set();
      this._sterilizedByLoc = new _Map();
      this._styleCache = new WeakMap();
      this._repeatKeys = new _Set();
      // 已知广告结构键集合（锁死）: 判定为广告的实例登记结构键,
      // 后续重建的同结构实例在 MO 微任务同步隐藏, 不依赖 rAF 队列
      this._knownAdKeys = new _Set();
      // 被覆盖容器隐藏过的媒体子元素(容器内 IMG/iframe 等): 它们随容器一并不可见后,
      // 再被单独隐藏时只隐藏、各自不去记一条日记（降噪开启时, 合并重复日志）。
      this._coveredChildren = new WeakSet();


      this._installWriteHook();
      this.setupMutationObserver();
      // 启动即挂载滚动位置监听（尽早开始记录用户滚动位置, 供锁定后恢复使用）
      try { ScrollLockGuard.init(); } catch(e) { _debugCatch(e, "ScrollLockGuard.init"); }
      if (thirdPartyModule && thirdPartyModule.domHooker) {
        thirdPartyModule.domHooker.enableOverlayCheck();
      }
      // 全屏 src iframe 的"页面无正文无标题"判定可能因正文晚加载而误杀播放器
      // (document-start 时 body 尚空)。正文就绪后自动复查: 现在有正文/标题 → 恢复显示,
      // 真劫持页（始终无正文）保持隐藏。用户也可直接加白日志条目立即恢复。
      this._pendingFsRecheck = [];
      this.initialScan();
      this.restoreWhitelistedElements();
      var _doFsRecheck = function () {
        try {
          if (!OverlayInterceptor._enabled) return;
          var _pr = OverlayInterceptor._pendingFsRecheck;
          if (!_pr || !_pr.length) return;
          var _bTxtR = (_document.body ? (_document.body.textContent || '') : '').replace(/\s+/g, ' ').trim();
          var _hasC = _bTxtR.length > 30;
          if (!_hasC) { try { _hasC = _document.querySelectorAll('img, a, video').length > 3; } catch(e) {} }
          var _tLenR = (_document.title || '').trim().length;
          if (!_hasC && _tLenR < 5) return;   // 仍是空页（真劫持页） → 保持隐藏
          for (var i = 0; i < _pr.length; i++) {
            var _el = _pr[i];
            if (!_el) continue;
            try {
              if (_el.isConnected) {
                restoreNeutralizedElement(_el);
                if (OverlayInterceptor._hiddenElementsMap) OverlayInterceptor._hiddenElementsMap.delete(_el);
                if (OverlayInterceptor._processedSet) OverlayInterceptor._processedSet.delete(_el);
                _el.setAttribute('data-ow', 'true');   // 恢复后标记放行, 后续路径跳过
              }
            } catch (e) {}
          }
          OverlayInterceptor._pendingFsRecheck = [];
        } catch (e) {}
      };
      this._fsRecheckTimer = _setTimeout(_doFsRecheck, 2000);
      var _dclHandler = function () {
        try { _clearTimeout(OverlayInterceptor._fsRecheckTimer); } catch(e) {}
        OverlayInterceptor._fsRecheckTimer = _setTimeout(_doFsRecheck, 300);
      };
      this._fsRecheckDcl = _dclHandler;
      // 解析已结束(晚注入档)时 DCL 不会再触发, 直接用 300ms 快复查, 全屏误杀尽早恢复
      if (_document.readyState && _document.readyState !== 'loading') {
        _dclHandler();
      } else {
        try { _document.addEventListener('DOMContentLoaded', _dclHandler, { once: true }); } catch (e) {}
      }
      this.startPeriodicScan();
      // 标签页切回快速恢复: 后台标签页 rAF 完全暂停, 期间广告重建的待检元素
      // 在队列积压, 回前台第一帧才处理——用户会看到"广告先出现一帧再被隐藏";
      // 回前台瞬间同步排空队列(visibilitychange 在渲染前派发, 无可见窗口)
      var _visSelf = this;
      this._visResumeHandler = function () {
        try {
          if (_document.visibilityState !== 'visible') return;
          // 回前台必补一次: 立刻排空积压队列, 并让下一轮周期补扫立即执行+重建快照
          _visSelf._resumeScan = true;
          if (_visSelf._pendingChecks && _visSelf._pendingChecks.length) _visSelf._flushChecks();
        } catch(e) { _debugCatch(e, "visResume"); }
      };
      try { _document.addEventListener('visibilitychange', this._visResumeHandler); } catch(e) {}
    },


    _installWriteHook: function () {
      // 覆盖层专属 document.write 钩子：拦截用 document.write 注入的远程广告脚本
      // （第三方 src / 黑名单 src / 启发式内联判定）；只有当剥离脚本后页面没有正文时才整段丢弃。
      // 拦截会记日志（OVERLAY_WRITE_BLOCKED），可加白放行。
      if (this._overlayWriteHook) return;
      this._overlayWriteHook = function (args, type) {
        // 【覆盖层专属】document.write 广告注入拦截：
        // 广告脚本常用 document.write 塞进"远程广告脚本/广告HTML"。这里在写入前先检查内容——
        // ① 白名单命中 → 放行；② 是第三方脚本（非本站）且像广告 → 阻止写入并记日志；
        // ③ 注入的 HTML 里只有广告、没有正文 → 整段丢弃。拦截记录在日志面板，可加白。
        // 页面已加白放行(OVERLAY_FULLSCREEN_AD 页面键) → 不拦截任何 write 注入
        try { if (RedirectBlocker._isPageReleased()) return; } catch(e) {}
        var c = Array.prototype.join.call(args, '');
        if (typeof c !== 'string' || c.length === 0) return;
        var blockedAny = false;
        try {
          // 统一检测(与动态脚本钩子同口径, 含黑名单 src/启发式内联)
          var _det2 = _detectDangerousWriteContent(c);
          blockedAny = _det2.thirdParty || _det2.srcBlacklisted || _det2.dangerInline;
          if (blockedAny) {


            var _cNorm = c.replace(/([?&][A-Za-z_0-9]+)=([^&\s"']+)/g, '$1=X');
            var _ciNorm = 'OVERLAY_WRITE_BLOCKED:' + generateContentHash(_cNorm);
            if (currentConfig.whitelist.has(_ciNorm) ||
                currentConfig.whitelist.has('DOCUMENT_WRITE_HASH: ' + generateContentHash(_cNorm)) ||
                currentConfig.whitelist.has('DOCUMENT_WRITE_HASH: ' + generateContentHash(c))) return;


            var _stripped = c.replace(/<script[\s\S]*?<\/script>/gi, '');
            var _plain = _decodeHtmlEntities(_stripped).replace(/<[^>]*>/g, '')
              .replace(/[\s\u00a0\u200b\u200c\u200d\ufeff]+/g, '');
            if (_plain.length === 0) {


              try {
                var _srcUrl = extractFirstUrl(c) || c;
                LogManager.add('overlayIntercept', null, {
                  type: 'OVERLAY_WRITE_BLOCKED',
                  detail: '覆盖层拦截(document.write注入广告脚本): ' + Utils.truncateString(_srcUrl, CONFIG.LOG_DETAIL_LENGTH),
                  elementContentIdentifier: _ciNorm,
                });
              } catch(e) { _debugCatch(e, "overlayWriteHook log"); }
              return false;
            }
            // 页面整页重写拦截: 页面加载完成后, 广告站可能用 document.write 写入
            // 一整份 <!DOCTYPE html>…<body> 文档。现代浏览器遇到这种写入会先清空
            // 当前页面, 等于把整页偷换成广告页。这里只拦"加载完成后"的整页写入,
            // 页面正常构建期间(readyState=loading)的写入不受影响。
            try {
              var _rs = _document.readyState;
              if (_rs === 'complete' || _rs === 'interactive') {
                var _cL = c.toLowerCase();
                if ((_cL.indexOf('<!doctype html') !== -1 || _cL.indexOf('<html') !== -1) && _cL.indexOf('<body') !== -1) {
                  var _ciRW = 'OVERLAY_PAGE_REWRITE:' + generateContentHash(c.replace(/\s+/g, '').replace(/[0-9]{6,}/g, 'N').slice(0, 4000));
                  if (!currentConfig.whitelist.has(_ciRW)) {
                    try {
                      LogManager.add('overlayIntercept', null, {
                        type: 'OVERLAY_PAGE_REWRITE',
                        detail: '覆盖层拦截(页面整页重写): ' + Utils.truncateString(extractFirstUrl(c) || 'document.write(完整HTML)', CONFIG.LOG_DETAIL_LENGTH),
                        elementContentIdentifier: _ciRW,
                      });
                    } catch(e) { _debugCatch(e, "rewrite log"); }
                    return false;  // 阻止整页重写（保留当前文档）
                  }
                }
              }
            } catch(e) { _debugCatch(e, "rewrite check"); }
          }
        } catch(e) { _debugCatch(e, "overlayWriteHook"); }
      };
      try { WriteHookManager.addHook(this._overlayWriteHook); } catch(e) {}
    },
    disable: function () {
      if (!this._enabled) return;
      this._enabled = false;
      // 清理正文复查的定时器与监听（模块关闭后保持静止）
      if (this._fsRecheckTimer) { try { _clearTimeout(this._fsRecheckTimer); } catch(e) {} this._fsRecheckTimer = null; }
      if (this._fsRecheckDcl) { try { _document.removeEventListener('DOMContentLoaded', this._fsRecheckDcl); } catch(e) {} this._fsRecheckDcl = null; }
      if (this._visResumeHandler) {
        try { _document.removeEventListener('visibilitychange', this._visResumeHandler); } catch(e) {}
        this._visResumeHandler = null;
      }
      this._pendingFsRecheck = [];

      this._pendingChecks = [];
      this._pendingScheduled = false;
      if (this._domObserverCallback) {
        DomObserver.unsubscribe(this._domObserverCallback);
        this._domObserverCallback = null;
      }
      if (this._observer) { this._observer.disconnect(); this._observer = null; }
      if (thirdPartyModule && thirdPartyModule.domHooker) {
        thirdPartyModule.domHooker.disableOverlayCheck();
      }
      this.stopPeriodicScan();

      if (this._overlayWriteHook) {
        try { WriteHookManager.removeHook(this._overlayWriteHook); } catch(e) {}
        this._overlayWriteHook = null;
      }
      var cls = this._hideClass;
      // 先恢复隐藏表里的元素(同步路径用内联样式隐藏, 只去类名会残留 display:none)
      try {
        if (this._hiddenElementsMap) {
          this._hiddenElementsMap.forEach(function (ci, el) {
            try { restoreNeutralizedElement(el); } catch(e) {}
          });
        }
      } catch(e) {}
      try {
        Array.from(_document.querySelectorAll('.' + cls)).forEach(function (el) { el.classList.remove(cls); });
      } catch(e) { _debugCatch(e, "this._hideClass"); }


      // 停用滚动解锁守卫(恢复被改动的内联 overflow, 移除滚动监听)
      try { ScrollLockGuard.disable(); } catch(e) { _debugCatch(e, "ScrollLockGuard.disable"); }
      this._processedSet = new WeakSet();
      // 【已处理集合】记录"已经检查过/处理过"的元素，防止同一个元素被重复处理
      // （DOM 变化监听会多次触发，没有它就会重复隐藏/重复记日志）。
      this._repeatKeys = null;
      if (this._hiddenElementsMap) this._hiddenElementsMap.clear();
      this._locTracker = null;
      this._parentTracker = null;
      this._locationSterile = null;
      this._sterilizedByLoc = null;
      this._styleCache = null;
      this._knownAdKeys = null;
      this._coveredChildren = null;
    },
    setupMutationObserver: function () {
      var self = this;

      this._pendingChecks = [];
      this._pendingScheduled = false;
      this._uhRehideMap = new WeakMap();
      this._domObserverCallback = function (ms) {
        for (var mi = 0; mi < ms.length; mi++) {
          var m = ms[mi];
          if (m.type === 'childList' && m.addedNodes.length > 0) {
            for (var ni = 0; ni < m.addedNodes.length; ni++) {
              var n = m.addedNodes[ni];
              if (n.nodeType === 1) {
                // 已知广告锁死: 结构键已判定为广告的重建实例在 MO 微任务同步隐藏
                // (后台标签页 rAF 暂停时微任务照常, 重建广告不入队不等帧, 回前台不可见)
                if (self._knownAdKeys && self._knownAdKeys.size > 0) {
                  var _lk = self._getKnownAdKey(n);
                  if (_lk && self._knownAdKeys.has(_lk)) {
                    self._fastLockHide(n, _lk);
                    continue;
                  }
                }
                self._enqueueCheck(n);
              }
            }
          } else if (m.type === 'attributes' && m.target && m.target.nodeType === 1) {
            // iframe 属性后置注入: 广告脚本常先插入空 iframe, 再通过 setAttribute 写入
            // srcdoc/src/style 注入广告内容。插入那一刻检测不到内容,
            // 所以这些属性一变就要重新检测(比如重新做全屏 iframe 判定)。
            if (m.target.tagName === 'IFRAME' &&
                (m.attributeName === 'srcdoc' || m.attributeName === 'src' || m.attributeName === 'style')) {
              if (!self._processedSet.has(m.target)) self._enqueueCheck(m.target);
            }
            // img 同理: 先插入空图再赋 src(或懒加载), src 一变就要重新检测几何;
            // 且图片此时多半未加载完（0×0）, 用 load/error 事件在拿到真实尺寸后立即快速重检,
            // 不必等 3 秒一次的周期扫描（刷新后广告能快速隐藏）。
            if (m.target.tagName === 'IMG' && m.attributeName === 'src') {
              if (!self._processedSet.has(m.target)) {
                self._enqueueCheck(m.target);
                try {
                  var _imgT = m.target;
                  var _imgOnce = function () {
                    try {
                      if (!self._processedSet.has(_imgT) && _imgT.isConnected) self._enqueueCheck(_imgT);
                    } catch(e) {}
                  };
                  if (_imgT.complete) {
                    _imgOnce();
                  } else if (_imgT.addEventListener) {
                    _imgT.addEventListener('load', _imgOnce);
                    _imgT.addEventListener('error', _imgOnce);
                    _setTimeout(_imgOnce, 1500);
                  }
                } catch(e) {}
              }
            }

            var _t = m.target;
            if (self._processedSet.has(_t) && self._hiddenElementsMap && self._hiddenElementsMap.has(_t)) {
              try {
                // 已加白/受保护的覆盖层跳过重新隐藏（加白后属性变化保持放行态）
                if (isOverlayWhitelistedForElement(_t) || isWhitelistedOrProtected(_t)) {
                  self._hiddenElementsMap.delete(_t);
                  continue;
                }
                var _now2 = Date.now();
                var _lastRehide = self._uhRehideMap ? self._uhRehideMap.get(_t) : 0;
                if (_lastRehide && _now2 - _lastRehide < 1000) continue;
                if (!_t.classList || !_t.classList.contains(self._hideClass)) {
                  if (self._uhRehideMap) self._uhRehideMap.set(_t, _now2);
                  _t.classList.add(self._hideClass);
                }
              } catch(e) {}
            }

            // body/html 属性变化: 交给滚动解锁守卫复查（15秒窗口内持续对抗样式表/内联的滚动锁定）
            try { ScrollLockGuard.apply(); } catch(e) {}
          }
        }
      };
      DomObserver.subscribe(this._domObserverCallback);
    },
    _enqueueCheck: function (el) {
      // 【检测队列】DOM 变化频繁时不能每一下都全量扫描（会卡），把待检元素排队，
      // 空闲时（节流）批量检查——既不错过广告，又不拖慢页面。
      var self = this;
      if (!this._pendingChecks) this._pendingChecks = [];
      if (this._pendingChecks.length >= 300) return;
      this._pendingChecks.push(el);
      if (!this._pendingScheduled) {
        this._pendingScheduled = true;
        _requestAnimationFrame(function () { self._flushChecks(); });
      }
    },


    _flushChecks: function () {
      this._pendingScheduled = false;
      if (!this._enabled) { this._pendingChecks = []; return; }
      // 一次性排空完整队列: 重建型覆盖层广告（如周期性重插的底部横幅）依赖
      // 当批全部判定完成, 分帧处理会让尾部元素滞后可见造成闪烁;
      // 判定本身走批量/周期兜底, 主线程占用由整体调用节奏控制。
      var batch = this._pendingChecks;
      this._pendingChecks = [];
      // 读写分相: 先整批跑完判定（只读布局）, 批尾统一落写队列里的隐藏样式 ——
      // 判定谓词与记账不变; 中途异常也要把已决定的隐藏写完(finally 兜底);
      // 队列已存在（未落写的上一批）则续用, 不清空
      if (!this._styleWriteQueue) this._styleWriteQueue = [];
      if (!this._deferHideSet) { try { this._deferHideSet = new Set(); } catch (e) { this._deferHideSet = null; } }
      try {
        for (var i = 0; i < batch.length; i++) {
          var el = batch[i];
          if (el && el.isConnected && !this._processedSet.has(el)) {
            try {
              this.checkAndHandle(el);
            } catch(e) { _debugCatch(e, "flushChecks item"); }
          }
        }
      } finally {
        var q = this._styleWriteQueue;
        this._styleWriteQueue = null;
        this._deferHideSet = null;
        for (var w = 0; w < q.length; w++) {
          var it = q[w];
          try {
            if (!it || !it.el || !it.el.isConnected) continue;
            if (it.t === 'cls') {
              it.el.classList.add(this._hideClass);
            } else if (it.t === 'inline') {
              it.el.style.setProperty('display', 'none', 'important');
              it.el.style.setProperty('visibility', 'hidden', 'important');
              it.el.style.setProperty('pointer-events', 'none', 'important');
            }
          } catch (eW) {}
        }
      }
    },
    isOverlayElement: function (el) {
      // 覆盖层判定核心（全部为通用特征，无域名/类名硬编码）。规则顺序：
      // ① 超高 z-index(fixed/absolute) ② 全屏遮挡 ③ 第三方 iframe 弹层 ④ z≥100 空内容容器
      // ⑤ 全宽+背景色 ⑥ 极低透明度小元素 ⑦ data: 内联背景图广告 ⑧ 贴边条幅(fixed/sticky)
      // ⑨ 贴顶/贴底大容器广告位([120px,50vh)+z>0) ⑩ 背景图贴边条 ⑪ 图片浮层
      // 滚动容器豁免：近全屏可滚动容器不判覆盖层（防误杀滚动区域）。
      if (!el || el.nodeType !== 1 || !Utils.isElement(el)) return false;
      if (Utils.isUIElement(el)) return false;
      if (this._processedSet.has(el)) return false;
      if (_isSafe(el)) return false;
      if (el === _document.body || el === _document.documentElement) return false;
      var w = el.offsetWidth, h = el.offsetHeight;
      if (w < 30 && h < 30) {

        var hasClickAttr = el.onclick || el.ontouchend || el.getAttribute('onclick') || el.getAttribute('ontouchend');
        var inlinePos = (el.style && el.style.position) || '';

        if (el.tagName === 'IMG' && inlinePos === 'fixed') return true;

        if (el.tagName === 'IMG') {
          var imgText = ((el.getAttribute('alt')||'')+' '+(el.getAttribute('title')||'')+' '+(el.src||'')).toLowerCase();
          if (/close|dismiss|取消|删除|delete|cancel|×/i.test(imgText)) return true;
        }

        if (el.tagName === 'SPAN' || el.tagName === 'I' || el.tagName === 'BUTTON' || el.tagName === 'A' || el.tagName === 'B') {
          var txt = (el.textContent || el.innerHTML || '').trim();
          if (/[×✕✖Ⅹ✖]/.test(txt) || /^close$/i.test(txt)) return true;
        }

        if (hasClickAttr) return true;
        var classOrId = ((el.className||'')+' '+(el.id||'')).toLowerCase();
        if (/close|dismiss|btn-close|modal-close|x-btn|ad-close/.test(classOrId)) return true;

        if (inlinePos === 'fixed' || inlinePos === 'absolute') {
          // 内联 z-index 超高直接判定（高频路径, 广告元素普遍内联写死层级）, 免去计算样式/回流
          try {
            var _izI = parseInt((el.style && el.style.zIndex) || '');
            if (!isNaN(_izI) && _izI > 1000000) return true;
            var _cSt = _getComputedStyle(el);
            var _cOp = parseFloat(_cSt.opacity);
            var _cZ = parseInt(_cSt.zIndex);
            if (!isNaN(_cOp) && _cOp < 0.5) return true;
            if (!isNaN(_cZ) && _cZ > 1000000) return true;
          } catch (e) { return true; }
        }

        return false;
      }

      var style;
      if (this._styleCache) {
        style = this._styleCache.get(el);
      }
      if (!style) {
        try { style = _getComputedStyle(el); } catch (e) { return false; }
        if (this._styleCache) {
          try { this._styleCache.set(el, style); } catch (e) {}
        }
      }
      var pos = style.position;
      // 内容流中的孤立广告图(通用几何规则, 无类名/ID硬编码):
      // 移动端小说/视频页常在正文与导航/列表之间注入横幅广告图——元素(IMG或最多3层包裹的
      // 容器, 允许单层 <a> 链接, 自动跳过残留的 SCRIPT/STYLE 等非渲染节点)位于文档流
      // (static/relative/absolute 非fixed)中、无文字或文字极短（如"广告"）, 内含恰好一个
      // <img>, 且图片几何满足任一广告特征:
      //   a) 图片宽 ≥ 80% 视口宽（整宽横幅）
      //   b) 宽高比 ≥ 2.5:1(横幅广告比例, 如 750×120 / 600×90)
      //   c) 图片来源为第三方域名（非本站资源）
      // 站内链接包裹的题图/封面（链接指向本站）一律放行, 避免误杀正文配图;
      // 同源图必须"整宽 + 明显横幅比例（≥3:1）"才判广告（避开 16:9 正文配图）。
      if ((pos === 'static' || pos === 'relative' || pos === 'absolute') && el.offsetWidth >= 120 && el.offsetHeight >= 40) {
        var _imgWrap = el;
        var _depthI = 0;
        while (_imgWrap && _depthI < 3 && _imgWrap.tagName !== 'IMG') {
          if ((_imgWrap.textContent || '').trim().length > 6) { _imgWrap = null; break; }
          var _kids = [];
          for (var _ki = 0; _ki < _imgWrap.children.length; _ki++) {
            var _kc = _imgWrap.children[_ki];
            if (_kc.tagName !== 'SCRIPT' && _kc.tagName !== 'STYLE' && _kc.tagName !== 'LINK' && _kc.tagName !== 'META') _kids.push(_kc);
          }
          if (_kids.length === 1) _imgWrap = _kids[0];
          else { _imgWrap = null; break; }
          _depthI++;
        }
        if (_imgWrap && _imgWrap.tagName === 'IMG') {
          var _iw = _imgWrap.offsetWidth || el.offsetWidth;
          var _ih = _imgWrap.offsetHeight || el.offsetHeight;
          var _ivw = _globals.innerWidth || _document.documentElement.clientWidth;
          var _ivh = _globals.innerHeight || _document.documentElement.clientHeight;
          if (_iw >= 120 && _iw <= _ivw * 1.2 && _ih >= 40 && _ih <= _ivh * 0.6) {
            var _imgSrc = _imgWrap.src || '';
            var _thirdParty = !!(_imgSrc && Utils.isThirdParty(_imgSrc));
            var _wideBanner = _iw >= _ivw * 0.8;
            var _bannerRatio = _ih > 0 && (_iw / _ih) >= 2.5;
            var _adHit = false;
            if (_thirdParty) {
              _adHit = _iw >= _ivw * 0.4 || _bannerRatio || _wideBanner;
            } else {
              _adHit = _wideBanner && _ih > 0 && (_iw / _ih) >= 3;
            }
            if (_adHit) {
              var _imgLinkHost = null;
              if (el.closest) {
                try {
                  var _imgA = el.closest('a');
                  if (_imgA && _imgA.href) _imgLinkHost = new _URL(_imgA.href, _location.href).hostname;
                } catch(e) {}
              }
              if (_imgLinkHost !== _location.hostname) return true;
            }
          }
        }
      }
      // 严格模式: 正文流直接插入的带图广告容器
      // static/relative/absolute + 宽≥50%视口 + 高≥40 + 文字≤6 +
      // (背景图 url 或非占位 <img>) + 宽高比≥2 → 判覆盖层;
      // 近方形（宽高比<2）或多文字的正常内容一律放行
      if (currentConfig.overlayStrictMode && (pos === 'static' || pos === 'relative' || pos === 'absolute')) {
        var _bl1Vw = _globals.innerWidth || _document.documentElement.clientWidth;
        if (el.offsetWidth >= _bl1Vw * 0.5 && el.offsetHeight >= 40 && (el.textContent || '').trim().length <= 6) {
          var _bgiB1 = '';
          try {
            var _bgiB1v = style.backgroundImage;
            if (_bgiB1v && _bgiB1v.indexOf('url(') !== -1) _bgiB1 = String(_bgiB1v);
          } catch (e) {}
          var _imgB1 = null;
          if (el.querySelector) { try { _imgB1 = el.querySelector('img'); } catch (e) {} }
          var _hasRealImgB1 = false;
          if (_imgB1) {
            var _imwB1 = _imgB1.offsetWidth || el.offsetWidth, _imhB1 = _imgB1.offsetHeight || el.offsetHeight;
            _hasRealImgB1 = !(_imwB1 <= 5 && _imhB1 <= 5);  // 非 1×1 占位
          }
          if (_bgiB1 !== '' || _hasRealImgB1) {
            if (el.offsetHeight > 0 && (el.offsetWidth / el.offsetHeight) >= 2) return true;
          }
        }
      }
      if (pos === 'static') return false;


      var _scrollExempt = false;
      if (pos === 'fixed' || pos === 'absolute') {
        try {
          // 可滚动容器豁免只保护"移动端全屏 fixed src iframe 播放器"自身(元素必须是带 src 的 IFRAME)。
          // DIV 包裹 iframe 的固定全屏覆盖层(fixed+100%视口+overflow:auto+超高z-index 的广告形态)
          // 不豁免 → 仍按覆盖层隐藏, 避免覆盖层广告常驻页面导致掉帧。
          if (el.tagName === 'IFRAME' && el.getAttribute && el.getAttribute('src')) {
            var _w2 = el.offsetWidth, _h2 = el.offsetHeight;
            var _vw2 = _globals.innerWidth || _document.documentElement.clientWidth;
            var _vh2 = _globals.innerHeight || _document.documentElement.clientHeight;
            if (_isScrollableContainer(el, style) &&
                _vw2 > 0 && _vh2 > 0 && _w2 >= _vw2 * 0.8 && _h2 >= _vh2 * 0.8) {
              _scrollExempt = true;
            }
          }
        } catch(e) { _debugCatch(e, "滚动容器豁免"); }
      }
      w = el.offsetWidth;
      h = el.offsetHeight;
      var vw = _globals.innerWidth || _document.documentElement.clientWidth;
      var vh = _globals.innerHeight || _document.documentElement.clientHeight;
      var z = parseInt(style.zIndex);
      var hasHighZ = !isNaN(z) && z > CONFIG.ZINDEX_HIDE_THRESHOLD;
      var isFixed = pos === 'fixed';
      var isAbs = pos === 'absolute';


      var isStickyBar = pos === 'sticky';
      if (hasHighZ && !_scrollExempt) return true;


      // 严格模式: 带 transform 动画的悬浮层(fixed/absolute)
      // 超高 z/全屏等强特征（已在上方早期返回）已被排除; animationName 非 none 或
      // transform 含位移/矩阵/旋转/缩放 + 尺寸（≥80×40） + 无交互控件 → 判覆盖层
      if (currentConfig.overlayStrictMode && (isFixed || isAbs) && !_scrollExempt) {
        var _animB2 = '';
        try { if (style.animationName && style.animationName !== 'none') _animB2 = String(style.animationName); } catch (e) {}
        var _tfB2 = '';
        try { if (style.transform && style.transform !== 'none') _tfB2 = String(style.transform); } catch (e) {}
        if (_animB2 !== '' || /(?:translate|matrix|rotate|scale)/i.test(_tfB2)) {
          if (w >= 80 && h >= 40) {
            var _interB2 = false;
            if (el.querySelector) {
              try { if (el.querySelector('button, input, textarea, select, form, video, audio')) _interB2 = true; } catch (e) {}
            }
            if (!_interB2) return true;
          }
        }
      }

      // 严格模式: 第三方 iframe 大容器(不限定位; 静态容器前面已早退, 只抓 relative/absolute/fixed/sticky)
      // 宽≥40%视口 高≥40%视口 + 容器文字≤20 + 内含 iframe 且应为第三方资源 → 判覆盖层;
      // 站内 iframe(src 命中放行)或含较多文字的正常嵌入内容一律放行
      if (currentConfig.overlayStrictMode && w >= vw * 0.4 && h >= vh * 0.4 && (el.textContent || '').trim().length <= 20) {
        var _ifB2 = null;
        if (el.querySelector) { try { _ifB2 = el.querySelector('iframe'); } catch (e) {} }
        if (_ifB2) {
          var _srcB2 = _ifB2.src || _ifB2.getAttribute('src') || '';
          if (_srcB2 && shouldBlockResource(_srcB2)) return true;
        }
      }

      if (isFixed && !_scrollExempt && style.backgroundImage && style.backgroundImage.indexOf('data:image') !== -1) {
        if (!isNaN(z) && z > 50) return true;
        try {
          var _dr = el.getBoundingClientRect();
          if ((_dr.top <= 6 || _dr.bottom >= vh - 6) && (_dr.width >= 120 || _dr.height >= 60)) return true;
        } catch(e) {}
      }
      if (isFixed && w >= vw * 0.5 && h >= vh * 0.5 && !_scrollExempt) return true;
      var hasThirdPartyIframe = false;


      if (currentConfig.modules.interceptThirdParty || currentConfig.modules.overlayIntercept) {
        var iframe = el.querySelector('iframe');
        if (iframe) {
          var src = iframe.src;
          if (src && shouldBlockResource(src)) hasThirdPartyIframe = true;
        }
      }
      if (hasThirdPartyIframe && (isFixed || isAbs) && (w >= vw * 0.3 || h >= vh * 0.3) && !_scrollExempt) {


        var _ifOk = true;
        if (!currentConfig.modules.interceptThirdParty) {
          var _cover = w >= vw * 0.5 && h >= vh * 0.5;
          var _edge3 = false;
          try {
            var _er3 = el.getBoundingClientRect();
            _edge3 = (_er3.bottom >= vh - 6 && _er3.height < vh * 0.5) || (_er3.top <= 6 && _er3.bottom < vh * 0.5);
          } catch(e) {}
          _ifOk = _cover || _edge3;
        }
        if (_ifOk) return true;
      }
      if ((isFixed || isAbs) && !isNaN(z) && z >= 100) {
        var hasVisibleContent = false;
        for (var ci = 0; ci < el.childNodes.length; ci++) {
          var c = el.childNodes[ci];
          if (c.nodeType === _Node.TEXT_NODE && c.textContent.trim().length > 0) { hasVisibleContent = true; break; }
          if (c.nodeType === _Node.ELEMENT_NODE) {
            if (c.tagName === 'IMG' && c.offsetWidth > 5 && c.offsetHeight > 5) { hasVisibleContent = true; break; }
            if (c.offsetWidth > 5 && c.offsetHeight > 5 && c.tagName !== 'BR' && c.tagName !== 'HR') { hasVisibleContent = true; break; }
          }
        }
        if (!hasVisibleContent && !_scrollExempt) return true;
      }
      if (isFixed && !_scrollExempt && (w >= vw * 0.8 || h >= vh * 0.8)) {
        var bg = style.backgroundColor;
        if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') return true;
      }

      if ((isFixed || isAbs) && w < 100 && h < 100) {
        _cOp = parseFloat(style.opacity);
        if (_cOp < 0.1 && !isNaN(z) && z >= 1) return true;
      }
      // 透明点击格群: 移动端广告链常用"底部网格透明空格"做点击劫持(fixed 空格+近透明+
      // 数十个成网格分布, 单格中小尺寸)。单格的层级/透明度特征易被变体绕开(降 z/调透明度),
      // 故以"同形态群体"为主特征: 视口内同时存在 ≥5 个同特征空格才整群判定;
      // 近透明阈值放宽到 0.25 专补 <0.1 判定之外的变体带, 群体+空内容+中小尺寸三重
      // 约束下正常骨架屏（文档流/不透明/非群体）不会命中。
      if ((isFixed || isAbs) && w >= 24 && w <= 160 && h >= 24 && h <= 160 && !_scrollExempt) {
        var _tgOp = parseFloat(style.opacity);
        if (!isNaN(_tgOp) && _tgOp <= 0.25) {
          var _tgText = (el.textContent || '').trim();
          if (_tgText.length <= 2) {
            try {
              var _tgR = el.getBoundingClientRect();
              var _tgVh = _globals.innerHeight || _document.documentElement.clientHeight;
              var _tgInVp = _tgR.width > 0 && _tgR.height > 0 && _tgR.top < _tgVh && _tgR.bottom > 0;
              var _tgZone = _tgR.top >= _tgVh * 0.4 || _tgR.bottom >= _tgVh - 8 || _tgR.top <= 8;
              if (_tgInVp && _tgZone && this._countTransparentGridPeers(el, _tgOp) >= 5) return true;
            } catch (e) {}
          }
        }
      }


      if (isFixed || isStickyBar) {
        try {
          var _er = el.getBoundingClientRect();
          var _edge = (_er.bottom >= vh - 6 && _er.height < vh * 0.5) || (_er.top <= 6 && _er.bottom < vh * 0.5);
          // 左右贴边（侧边栏/左右粘性广告）: 宽度 < 50% 视口才算贴边条
          var _edgeSide = (_er.left <= 6 && _er.width < vw * 0.5) || (_er.right >= vw - 6 && _er.width < vw * 0.5);
          var _etg = el.tagName, _erole = el.getAttribute && el.getAttribute('role');
          var _ecls = (el.className && typeof el.className === 'string') ? el.className : '';
          var _semanticNav = (_etg === 'NAV' || _etg === 'HEADER' || _etg === 'FOOTER') ||
            (_erole && /navigation|banner|contentinfo/i.test(_erole)) ||
            (/(^|[\s_-])(header|nav|menu|toolbar|topbar|navbar|site-head|masthead|head-wrap)([\s_-]|$)/i.test(_ecls));
          if (!_semanticNav) {


            var _zBig = parseInt(style.zIndex);
            var _bigHit = !isNaN(_zBig) && _zBig > 0 && w >= vw * 0.9 &&
              _er.height >= 120 && _er.height < vh * 0.5 &&
              (_er.top <= 6 || (_er.bottom >= vh - 6 && _er.height < vh * 0.5));
            if (_bigHit) return true;


            var _bgImg = '';
            try {
              var _bgi = style ? style.backgroundImage : '';
              if (_bgi && _bgi.indexOf('url(') !== -1) _bgImg = String(_bgi);
            } catch(e) {}
            if (_bgImg && _edge && w >= vw * 0.9 && _er.height >= 100 && _er.height < vh * 0.5) return true;
            if (_bgImg && _edgeSide && w >= 120 && w < vw * 0.5 && _er.height >= 100 && _er.height < vh * 0.5) return true;
            var _etxt = (el.textContent || '').trim();


              // 贴边广告图: 裸 <img> 也计入(移动端常见贴底/贴顶/贴边的 fixed 广告图)
              var _eimg = el.tagName === 'IMG' || (el.querySelector
                ? (el.querySelector('img, iframe') !== null || el.tagName === 'IFRAME')
                : el.tagName === 'IFRAME');
              var _topBar = _er.top <= 6;


              var _anim = '';
              try {
                var _animName = style ? style.animationName : '';
                if (_animName && _animName !== 'none') _anim = String(_animName);
              } catch(e) {}
              if (_eimg && (_edge || _edgeSide) && ((_topBar && (_etxt.length <= 60 || _anim !== '')) || (!_topBar && (_etxt === '' || _etxt.length <= 25)))) {


                if (isStickyBar) {
                  var _sz = parseInt(style.zIndex);
                  if (isNaN(_sz) || _sz <= 0) return false;
                }
                return true;
              }
            }
        } catch(e) { _debugCatch(e, "贴边条幅检测"); }
      }

      // 角落/中部浮动广告（几何判定, 无文本依赖）: fixed + 非贴边 + z>50 + 中等尺寸 + 无交互控件 → 广告浮层
      if (isFixed && !_scrollExempt) {
        try {
          var _erC = el.getBoundingClientRect();
          var _edgeC = (_erC.bottom >= vh - 6 && _erC.height < vh * 0.5) || (_erC.top <= 6 && _erC.bottom < vh * 0.5)
            || (_erC.left <= 6 && _erC.width < vw * 0.5) || (_erC.right >= vw - 6 && _erC.width < vw * 0.5);
          if (!_edgeC) {
            var _zC = parseInt(style.zIndex);
            if (!isNaN(_zC) && _zC > 50 && _erC.width >= 120 && _erC.width <= vw * 0.5
                && _erC.height >= 80 && _erC.height <= vh * 0.6) {
              // 交互豁免: 聊天窗（输入框）/表单/播放器/按钮型浮层(如Cookie面板)不拦
              var _interactive = false;
              if (el.querySelector) {
                try {
                  if (el.querySelector('input, textarea, select, form, video, audio, button')) _interactive = true;
                } catch (e) {}
              }
              if (!_interactive) return true;
            }
          }
        } catch (e) {}
      }

      // 浮动广告图（通用几何规则）: fixed/absolute + 非贴边 + 无文字（或极短） + 内含/本身为 <img>
      // + 中等以上尺寸（宽 120~视口宽, 高 30~60%视口高） + 无交互控件 → 广告浮层。
      // 覆盖"整宽浮动图/窄高浮动图"等角落规则够不着的形态（移动端常见）。
      if ((isFixed || isAbs) && !_scrollExempt && w >= 120 && w <= vw * 1.1 && h >= 30 && h <= vh * 0.6) {
        try {
          var _erF = el.getBoundingClientRect();
          var _edgeF = (_erF.bottom >= vh - 6 && _erF.height < vh * 0.5) || (_erF.top <= 6 && _erF.bottom < vh * 0.5)
            || (_erF.left <= 6 && _erF.width < vw * 0.5) || (_erF.right >= vw - 6 && _erF.width < vw * 0.5);
          if (!_edgeF) {
            var _txtF = (el.textContent || '').trim();
            if (_txtF.length <= 6) {
              var _hasImgF = el.tagName === 'IMG' || (el.querySelector && el.querySelector('img') !== null);
              if (_hasImgF) {
                var _interF = false;
                if (el.querySelector) {
                  try {
                    if (el.querySelector('input, textarea, select, form, video, audio, button')) _interF = true;
                  } catch (e) {}
                }
                if (!_interF) return true;
              }
            }
          }
        } catch (e) {}
      }


      if (isFixed && !_scrollExempt && w >= vw * 0.3 && h >= 80 && h <= vh * 0.7) {
        var _ptxt = (el.textContent || '').trim();
        if (_ptxt.length === 0) {
          var _hasMedia = el.querySelector ? el.querySelector('video, iframe, audio, canvas') !== null : false;
          var _pimg = el.querySelector ? el.querySelector('img') !== null : false;
          if (_pimg && !_hasMedia) {
            var _zi3 = parseInt(style.zIndex);
            var _fHit = false;
            if (!isNaN(_zi3) && _zi3 > 50) {
              _fHit = true;
            } else if (isNaN(_zi3)) {

              try {
                var _er2 = el.getBoundingClientRect();
                var _edge2 = (_er2.bottom >= vh - 6 && _er2.height < vh * 0.5) || (_er2.top <= 6 && _er2.bottom < vh * 0.5);
                var _op2 = parseFloat(style.opacity);
                if (_edge2 || (!isNaN(_op2) && _op2 < 0.5)) _fHit = true;
              } catch(e) {}
            }
            if (_fHit) return true;
          }
        }
      }
      return false;
    },
    _getKnownAdKey: function (el) {
      // 已知广告结构键(与 hideElement 的日记键同公式): 同结构重建的实例键不变,
      // 用于 MO 微任务同步锁死（后台标签页广告重建也能即时隐藏）
      if (!el || !_isElementLike(el)) return null;
      try {
        var _k = _overlayContentKey(el) || Utils.getContentIdentifier(el);
        if (_k) return _k;
        var _ti = _overlayTagIdent(el);
        return 'OVERLAY_' + generateContentHash('overlayIntercept:' + _ti + ':' + Utils.truncateString(el.textContent || '', 100));
      } catch(e) { return null; }
    },
    _fastLockHide: function (el, key) {
      // 已知广告实例的同步锁死（廉价, 无布局读取）: 白名单优先, 其余直接隐藏
      if (!el || !_isElementLike(el)) return;
      if (this._processedSet.has(el)) return;
      if (isOverlayWhitelistedForElement(el)) {
        this._processedSet.add(el);
        el.setAttribute('data-ow', 'true');
        restoreNeutralizedElement(el);
        return;
      }
      // 子树保护: 容器内含已放行元素时不锁死容器（防连坐隐藏）
      if (hasReleasedOverlayInTree(el)) {
        this._processedSet.add(el);
        return;
      }
      el.classList.add(this._hideClass);
      this._processedSet.add(el);
      ProcessedElementsCache.markAsProcessed(el);
      if (this._hiddenElementsMap) this._hiddenElementsMap.set(el, key || this._getKnownAdKey(el));
      try { ScrollLockGuard.armForElement(el); } catch(e) { _debugCatch(e, "lockHide arm"); }
      // 锁死隐藏同样记日记（键与常规路径同公式）, 但套用与 hideElement 相同的
      // 位置级降噪闸门: 同一位置只记首条, 后续重建/漂移实例静默;
      // 加白动作经 resetLocationMemory 清零计数后, 未命中的新变体才会再记一条,
      // 兼顾"漂移变体可加白"与"注入型站点不刷屏"
      try {
        var _lkEl = key || this._getKnownAdKey(el);
        var _lkParent = el.parentElement;
        var _lkLoc = this._getLocationId(el);
        var _lkPos = _lkLoc || (_lkParent ? '_p_' + generateContentHash(_lkParent.tagName + (_lkParent.id || '') + (_lkParent.className || '')) : '');
        var _lkGate = currentConfig.logNoiseReduction !== false && this._repeatKeys && _lkPos && this._repeatKeys.has(_lkPos);
        if (!_lkGate) {
          var _lkDispPre = _overlaySlotPreSlots(el);
          LogManager.add('overlayIntercept', el, {
            type: 'OVERLAY',
            detail: '覆盖层拦截(结构锁死): ' + (_overlaySlotDisplay(el, _lkDispPre) || el.tagName) + ' - ' + Utils.truncateString(el.textContent || '', 100),
            elementContentIdentifier: _lkEl || '',
            altContentIdentifiers: _lkDispPre ? _overlayBackupKeys(el, _lkDispPre) : _overlayBackupKeys(el),
          });
          if (this._repeatKeys && _lkPos) this._repeatKeys.add(_lkPos);
          if (currentConfig.logNoiseReduction !== false) this._markCoveredChildren(el);
        }
      } catch(e) { _debugCatch(e, "lockHide log"); }
    },
    _getLocationId: function (el) {


      if (!el || !el.parentElement) return null;
      var p = el.parentElement, gp = p.parentElement;
      if (!gp) return null;
      var children = Array.from(gp.children);
      var idx = children.indexOf(p);
      if (idx === -1) return null;
      var _gid = _normAnchorId(gp.id || '');
      return gp.tagName + (_gid ? '#' + _gid : '') + '_c' + idx;
    },
    _isInsideSterilizedParent: function (el) {
      if (!el || !this._locTracker) return false;
      var node = el.parentElement;
      while (node && node !== _document.documentElement) {
        if (node.nodeType === 1) {
          if (node.getAttribute && node.getAttribute('data-sterilized') === 'true') { if (isOverlayWhitelistedForElement(el)) return false; return true; }
          var locId = this._getLocationId({parentElement: node});
          if (locId && this._locationSterile && this._locationSterile.has(locId)) { if (isOverlayWhitelistedForElement(el)) return false; return true; }
        }
        node = node.parentElement;
      }
      return false;
    },


    _hideTriggerChild: function (triggerChild) {
      if (!triggerChild || !_isElementLike(triggerChild)) return;
      var _tcTag = (triggerChild.tagName || '').toLowerCase();
      if (_tcTag === 'video' || _tcTag === 'audio' || _tcTag === 'iframe' || _tcTag === 'embed') {
        this._applyInlineHide(triggerChild);
      } else {
        this._applyHideClass(triggerChild);
      }
    },
    // 隐藏类写入口（读写分相感知）: 批量判定期间缓存, 其余路径即时生效
    _applyHideClass: function (el) {
      if (!el) return;
      if (this._styleWriteQueue) {
        this._styleWriteQueue.push({ el: el, t: 'cls' });
        if (this._deferHideSet) { try { this._deferHideSet.add(el); } catch (e) {} }
      } else {
        try { el.classList.add(this._hideClass); } catch (e) {}
      }
    },
    // 内联三件套隐藏写入口（读写分相感知）: 批量判定期间缓存, 其余路径即时生效
    _applyInlineHide: function (el) {
      if (!el || !el.style) return;
      if (this._styleWriteQueue) {
        this._styleWriteQueue.push({ el: el, t: 'inline' });
        if (this._deferHideSet) { try { this._deferHideSet.add(el); } catch (e) {} }
      } else {
        try {
          el.style.setProperty('display', 'none', 'important');
          el.style.setProperty('visibility', 'hidden', 'important');
          el.style.setProperty('pointer-events', 'none', 'important');
        } catch (e) {}
      }
    },
    _sterilizeParent: function (parent, triggerChild) {
      // 灭菌前守卫走统一白名单判定(稳定键/IFRAME_SRC/OVERLAY_/全屏键), 加白后跳过灭菌
      if (isOverlayWhitelistedForElement(parent) || isOverlayWhitelistedForElement(triggerChild)) {
        if (triggerChild && _isElementLike(triggerChild)) { this._applyHideClass(triggerChild); this._processedSet.add(triggerChild); ProcessedElementsCache.markAsProcessed(triggerChild); }
        return;
      }


      try {
        var _ps = _getComputedStyle(parent);
        var _ppos = _ps.position;
        var _pText = (parent.textContent || '').trim();
        var _pMedia = parent.querySelector ? parent.querySelector('video, iframe, audio, canvas') !== null : false;
        var _pScroll = _isScrollableContainer(parent, _ps);
        if ((_ppos !== 'fixed' && _ppos !== 'absolute') || _pText.length > 200 || _pMedia || _pScroll) {

          this._hideTriggerChild(triggerChild);
          if (triggerChild && _isElementLike(triggerChild)) {
            this._processedSet.add(triggerChild);
            ProcessedElementsCache.markAsProcessed(triggerChild);
          }

          try { if (parent.setAttribute) parent.setAttribute('data-sterilized', 'declined'); } catch(e) {}
          return;
        }
      } catch(e) {   }
      this._processedSet.add(parent);
      ProcessedElementsCache.markAsProcessed(parent);
      parent.setAttribute('data-sterilized', 'true');
      this._applyInlineHide(parent);
      // 容器灭活同样可能伴随滚动锁定, 触发守卫
      try { ScrollLockGuard.armForElement(parent); } catch(e) { _debugCatch(e, "sterilize arm"); }
      var tagInfo = _overlayTagIdent(parent);
      // 灭活日记键用稳定槽位公式（命名/松散链）, 容器内广告内容逐次变化也不影响加白;
      // 槽位不可用时退回标签+文本兜底键, 保证日记始终可算
      var _sterileSlots = null;
      try { _sterileSlots = _overlayStableSlots(parent); } catch(e) {}
      var _sterileCI = (_sterileSlots && _sterileSlots[0])
        ? 'OVERLAY_' + generateContentHash('overlayIntercept:' + _sterileSlots[0])
        : 'OVERLAY_' + generateContentHash('overlayIntercept:' + tagInfo + ':' + Utils.truncateString(parent.textContent || '', 100));
      var _sterileBaks = [];
      if (_sterileSlots) {
        for (var _stb = 1; _stb < _sterileSlots.length; _stb++) {
          if (!_sterileSlots[_stb] || _sterileSlots[_stb] === _sterileSlots[0]) continue;
          var _sbk = 'OVERLAY_' + generateContentHash('overlayIntercept:' + _sterileSlots[_stb]);
          if (_sterileBaks.indexOf(_sbk) === -1) _sterileBaks.push(_sbk);
        }
      }
      LogManager.add('overlayIntercept', parent, {
        type: 'OVERLAY_STERILIZED',
        detail: '重复插入超过' + this._STERILIZE_THRESHOLD + '次，容器已温和灭活: ' + tagInfo,
        elementContentIdentifier: _sterileCI,
        altContentIdentifiers: _sterileBaks,
      });
    },
    _isAtSterilizedLocation: function (el) {
      // 顽固广告位判定：同一位置反复冒出来的广告容器，直接把它的父容器隐藏
      // （display:none），让广告彻底无处安放。
      if (!el || !this._locationSterile || this._locationSterile.size === 0) return false;
      var locId = this._getLocationId(el);
      return locId ? this._locationSterile.has(locId) : false;
    },
    _isInsideAdBlockUI: function(el) {
      if (!el) return false;
      var node = el;
      while (node && node !== _document.documentElement) {
        if (node.nodeType === 1) {
          if (_isSafe(node)) return true;
          if (node.id === 'sc' && node.getAttribute('data-role') === 'settings-container') return true;
          if (node.classList && (node.classList.contains('mask') || node.classList.contains('panel'))) return true;
        }
        node = node.parentElement || node.parentNode;
      }
      return false;
    },
    _countTransparentGridPeers: function (el, selfOp) {
      // 透明点击格群体计数: 倒序扫 body 直挂子元素(点击格注入普遍挂 body 尾部), 统计与当前格
      // 同形态(fixed/absolute + 近透明 + 中小空格)的数量, 含自身, ≥5 即成群。500ms 结果缓存,
      // 同批格子只扫一次; 早退凑满即停, 不做全量遍历。
      try {
        var _now = Date.now();
        if (this._tgPeerCache !== null && this._tgPeerCache !== undefined && _now - this._tgPeerCacheTs <= 500) return this._tgPeerCache;
        var _cnt = 1;
        var _kids = _document.body ? _document.body.children : [];
        for (var i = _kids.length - 1; i >= 0 && i >= _kids.length - 400; i--) {
          var k = _kids[i];
          if (!k || k.nodeType !== 1 || k === el) continue;
          if (Utils.isUIElement(k) || this._processedSet.has(k) || _isSafe(k)) continue;
          var ks = this._styleCache ? this._styleCache.get(k) : null;
          if (!ks) { try { ks = _getComputedStyle(k); if (this._styleCache && ks) this._styleCache.set(k, ks); } catch (e2) { continue; } }
          if (!ks) continue;
          if (ks.position !== 'fixed' && ks.position !== 'absolute') continue;
          var kop = parseFloat(ks.opacity);
          if (isNaN(kop) || kop > 0.25 || Math.abs(kop - selfOp) > 0.15) continue;
          var kw = k.offsetWidth, kh = k.offsetHeight;
          if (kw < 24 || kw > 160 || kh < 24 || kh > 160) continue;
          if ((k.textContent || '').trim().length > 2) continue;
          _cnt++;
          if (_cnt >= 5) break;
        }
        this._tgPeerCache = _cnt;
        this._tgPeerCacheTs = _now;
        return _cnt;
      } catch (e) { return 0; }
    },
    checkAndHandle: function (el) {
      // 【单元素检测入口】覆盖层拦截的核心入口：判断一个元素是不是广告覆盖层。
      // 顺序：白名单/保护放行 → 全屏 iframe 广告（移除） → 超高 z 弹层 → 贴边条幅 →
      // 空容器广告位 → 伪元素广告…判定通过就隐藏/移除，全部走日志可加白。      if (!el || el.nodeType !== 1 || !Utils.isElement(el)) return;
      if (Utils.isUIElement(el)) return;
      if (this._processedSet.has(el)) return;
      if (_isSafe(el)) return;
      if (this._isInsideAdBlockUI(el)) {
        this._processedSet.add(el);
        return;
      }
      // 全屏 iframe 广告检测: 广告站/劫持脚本常注入一个占满整页的 iframe
      // (srcdoc 或 src, 常带 sandbox 且无 allow-same-origin, 页面脚本读不到它内部),
      // 盖住页面原有内容。这里只能靠"全屏 + 定位 + 页面其他内容"来推断是否广告:
      //   · 仅拦截 fixed/absolute 定位的 iframe(真覆盖层)——文档流中的全屏播放器
      //     iframe(移动端视频页常见形态, 非 fixed)不做全屏拦截, 避免误杀播放器;
      //   · srcdoc 全屏 → 正常网站嵌播放器用 src 不用 srcdoc, 基本可断定是广告, 隐藏;
      //   · src 全屏 + 页面有正文 → 广告盖在正文上, 隐藏 iframe 后正文保留;
      //   · src 全屏 + 页面无正文无标题 → 疑似广告页本身, 同样隐藏。
      // 属性后置注入的 iframe 由 attributes 监听重新触发本检测; 隐藏后重建也会再走这里。
      if (el.tagName === 'IFRAME' && el.getAttribute) {
        try {
          var _fsd = (el.getAttribute('srcdoc') || '').toLowerCase();
          var _fsrc = el.getAttribute('src') || '';
          if (!_fsd && !_fsrc) { /* 空 iframe: 等属性注入后由 attributes 监听触发 */ }
          else {
            // 定位检查: 只有 fixed/absolute(真覆盖层)才可能是全屏广告 iframe
            // 严格模式（覆盖层拦截）: 不要求定位, 任意全屏 iframe 都按覆盖层广告处理
            var _fsPos = !!currentConfig.overlayStrictMode;
            if (!_fsPos) {
              try {
                var _fsSt = (el.getAttribute('style') || '').toLowerCase();
                if (_fsSt.indexOf('position:fixed') !== -1 || _fsSt.indexOf('position:absolute') !== -1) _fsPos = true;
                else {
                  var _fsCs = _getComputedStyle(el);
                  if (_fsCs && (_fsCs.position === 'fixed' || _fsCs.position === 'absolute')) _fsPos = true;
                }
              } catch(e) {}
            }
            var _isFs = false;
            var _wA = el.getAttribute('width'), _hA = el.getAttribute('height');
            if (_fsPos && _wA === '100%' && _hA === '100%') _isFs = true;
            if (!_isFs) {
              var _stA = (el.getAttribute('style') || '').toLowerCase();
              if (_fsPos && (_stA.indexOf('100vw') !== -1 || _stA.indexOf('100vh') !== -1)) _isFs = true;
            }
            if (!_isFs) {
              var _vwF = _globals.innerWidth || _document.documentElement.clientWidth;
              var _vhF = _globals.innerHeight || _document.documentElement.clientHeight;
              var _rF = el.getBoundingClientRect();
              if (_fsPos && _vwF > 0 && _vhF > 0 && _rF.width >= _vwF * 0.9 && _rF.height >= _vhF * 0.9) _isFs = true;
            }
            if (_isFs) {
              // 白名单键统一用"当前页面地址"：地址稳定，用户加白"这个页面"即可放行。
              // 广告 iframe 的内容每次都不一样（广告域名随机），不能拿来当白名单键。
              var _pgKey = 'OVERLAY_FULLSCREEN_AD:' + generateContentHash(((_location && _location.href) || '').split('#')[0]);
              var _sdKey = _fsd || _fsrc;
              if (_sdKey.length > 204800) _sdKey = _sdKey.slice(0, 204800);
              var _ciF = 'OVERLAY_FULLSCREEN_AD:' + generateContentHash(_sdKey.replace(/\s+/g, '').replace(/[0-9]{6,}/g, 'N').slice(0, 4000));
              // 元素级/URL级白名单优先(用户配置的 URL/关键词白名单对全屏 iframe 同样生效)
              // 任一白名单键命中 → 完全放行（页面键/内容键/日记 IFRAME_SRC 键/关键词白名单全部生效）
              if (isOverlayWhitelistedForElement(el)) {
                this._processedSet.add(el);
                el.setAttribute('data-ow', 'true');
                // 若已被同步路径提前隐藏, 恢复显示（否则加白后播放器仍卡住）
                restoreNeutralizedElement(el);
                return;
              }
              // 日志场景: 只客观描述"检测到的状态 + 采取的动作", 不武断断言是广告页
              // (若 iframe 实际是页面内容, 加白对应条目即可恢复, 见下方统一后缀)
              var _lgScene = '覆盖层拦截(疑似全屏广告iframe): srcdoc全屏iframe, 已隐藏';
              if (!_fsd) {
                // src 型全屏 iframe: 默认仅当"页面无正文且无标题"(劫持页特征)才拦。
                // 页面有正文或标题 → 正常播放器/嵌入内容(移动端视频页播放器常为
                // fixed 全屏覆盖式 src iframe), 一律放行, 避免刷新后误杀播放器。
                // 严格模式（覆盖层拦截）: 页面有正文也拦。
                var _bodyTxt = '';
                try { _bodyTxt = (_document.body ? (_document.body.textContent || '') : '').replace(/\s+/g, ' ').trim(); } catch(e) {}
                var _hasOther = _bodyTxt.length > 30;
                if (!_hasOther) { try { _hasOther = _document.querySelectorAll('img, a, video').length > 3; } catch(e) {} }
                if (_hasOther) {
                  if (!currentConfig.overlayStrictMode) { this._processedSet.add(el); return; }  // 页面有正文 → 正常页面内容, 放行
                  _lgScene = '覆盖层拦截(严格模式-疑似全屏广告iframe): src全屏iframe且页面有正文, 已隐藏该iframe';
                } else {
                  var _tLen = (_document.title || '').trim().length;
                  if (_tLen >= 5) { this._processedSet.add(el); return; }  // 页面有标题 → 放行
                  _lgScene = '覆盖层拦截(疑似全屏广告iframe): src全屏iframe且页面无正文无标题, 已隐藏该iframe';
                }
              }
                            // 可逆处理: 不 remove, 用隐藏类(_uh)隐藏 + 记录 _hiddenElementsMap → 加白即可恢复显示
              this._applyHideClass(el);
              el.setAttribute('data-ow', 'true');
              if (this._hiddenElementsMap) this._hiddenElementsMap.set(el, _pgKey);
              this._processedSet.add(el);
              // src 型全屏 iframe 的"无正文无标题"判定可能因正文晚加载误杀播放器 →
              // 登记待复查, 正文就绪后由 enable 挂的复查定时器自动恢复显示(srcdoc 型广告不复查)
              if (!_fsd && this._pendingFsRecheck) this._pendingFsRecheck.push(el);
            if (ProcessedElementsCache && ProcessedElementsCache.markAsProcessed) ProcessedElementsCache.markAsProcessed(el);
            try {
              LogManager.add('overlayIntercept', null, {
                type: 'OVERLAY_FULLSCREEN_AD',
                detail: _lgScene + '; 若该iframe实际是页面内容(如加载缓慢/正文在其内部), 加白此条目即可恢复显示',
                elementContentIdentifier: _pgKey,
              });
            } catch(e) { _debugCatch(e, "fullscreenAd log"); }
            // 全屏广告 iframe 常伴随 html/body 滚动锁定（样式表注入）, 隐藏后触发滚动解锁
            try { ScrollLockGuard.armForElement(el); } catch(e) { _debugCatch(e, "fullscreenAd arm"); }
            return;
            }
          }
        } catch(e) { _debugCatch(e, "fullscreenAd check"); }
      }

      var _inlineFastTrack = false;
      try {
        var _is = el.style;
        if (_is) {
          var _p = (_is.position || '').toLowerCase();
          if (_p === 'fixed' || _p === 'absolute') {
            var _zi = parseInt(_is.zIndex);
            var _sw = _is.width, _sh = _is.height;
            var _fs = (_sw === '100%' || _sw === '100vw') && (_sh === '100%' || _sh === '100vh');
            if ((!isNaN(_zi) && _zi > CONFIG.ZINDEX_HIDE_THRESHOLD) || (_p === 'fixed' && _fs)) {
              _inlineFastTrack = true;
            }
          }
        }
      } catch(e) { _debugCatch(e, "}"); }
      if (_inlineFastTrack) {
        if (isWhitelistedOrProtected(el)) { this._processedSet.add(el); el.setAttribute('data-ow','true'); restoreNeutralizedElement(el); return; }
        if (this.isOverlayElement(el)) { this.hideElement(el); return; }

      }
      if (isWhitelistedOrProtected(el)) { this._processedSet.add(el); el.setAttribute('data-ow','true'); restoreNeutralizedElement(el); return; }

      if (this._isAtSterilizedLocation(el)) {
        // 统一白名单判定(认稳定键/IFRAME_SRC/OVERLAY_/全屏键): 灭菌位置同样受加白放行
        if (isOverlayWhitelistedForElement(el)) { this._processedSet.add(el); el.setAttribute('data-ow','true'); return; }

        var _sLoc = this._getLocationId(el);
        var _sContainer = _sLoc && this._sterilizedByLoc ? this._sterilizedByLoc.get(_sLoc) : null;
        var _sValid = false;
        if (_sContainer && _sContainer.isConnected) {
          try {
            // 批量判定期间容器隐藏写还在队列里（读写分相）, 已入队即视为已隐藏
            if (_getComputedStyle(_sContainer).display === 'none' || (this._deferHideSet && this._deferHideSet.has(_sContainer))) _sValid = true;
          } catch(e) {}
        }
        if (_sValid) { this._processedSet.add(el); return; }
        if (this._locationSterile) this._locationSterile.delete(_sLoc);
        if (this._sterilizedByLoc) this._sterilizedByLoc.delete(_sLoc);

      }
      if (this._isInsideSterilizedParent(el)) {
        if (isWhitelistedOrProtected(el)) { this._processedSet.add(el); el.setAttribute('data-ow','true'); return; }

        var _spNode = el.parentElement, _spValid = false;
        while (_spNode && _spNode !== _document.documentElement) {
          if (_spNode.getAttribute && _spNode.getAttribute('data-sterilized') === 'true') {
            if (_spNode.isConnected) _spValid = true;
            break;
          }
          _spNode = _spNode.parentElement;
        }
        if (_spValid) { this._processedSet.add(el); return; }

        if (_spNode && _spNode.getAttribute) _spNode.removeAttribute('data-sterilized');
      }
      if (el.getAttribute && el.getAttribute('data-ow') === 'true') {
        this._processedSet.add(el);
        return;
      }
      var overlayCi = el.getAttribute && el.getAttribute('data-oci');
      if (overlayCi && currentConfig.whitelist.has(overlayCi)) {
        this._processedSet.add(el);
        restoreNeutralizedElement(el);
        return;
      }
      if (Whitelisting.isElementWhitelisted(el)) {
        this._processedSet.add(el);
        restoreNeutralizedElement(el);
        return;
      }
      if (!overlayCi) {
        var computedOverlayCi = this._computeOverlayCI(el);
        if (computedOverlayCi && currentConfig.whitelist.has(computedOverlayCi)) {
          this._processedSet.add(el);
          el.setAttribute('data-ow', 'true');
          restoreNeutralizedElement(el);
          return;
        }
      }
      if (currentConfig.keywordWhitelist.size > 0) {
        var kr = getKeywordWhitelistRegex();
        if (kr) {
          var sc = el.textContent || '';
          var src = el.src || el.href || el.action || el.data || el.getAttribute('data-src') || '';
          var className = el.className && typeof el.className === 'string' ? el.className : '';
          var elId = el.id || '';
          var allAttrs = '';
          if (el.attributes) {
            for (var ai = 0; ai < el.attributes.length; ai++) {
              allAttrs += el.attributes[ai].value + ' ';
            }
          }
          var combinedText = sc + ' ' + src + ' ' + className + ' ' + elId + ' ' + allAttrs;
          if (kr.test(combinedText)) {
            this._processedSet.add(el);
            el.setAttribute('data-ow', 'true');
            restoreNeutralizedElement(el);
            return;
          }
        }
      }
      if (this.isOverlayElement(el)) {
        this.hideElement(el);
        return;
      }
      if (el.querySelectorAll) {


        var _deepHint = false;
        try {
          _deepHint = el.querySelector('[style*="fixed"],[style*="absolute"],[style*="z-index"]') !== null;
        } catch(e) {}
        var children = _deepHint ? el.querySelectorAll('div, iframe, section, aside, a, span, article, main, img') : el.children;
        var _childLimit = Math.min(children.length, 30);
        for (var i = 0; i < _childLimit; i++) {
          var child = children[i];
          if (!child) continue;
          if (this._processedSet.has(child)) continue;
          if (Whitelisting.isElementWhitelisted(child)) {
            this._processedSet.add(child);
            continue;
          }
          var childOverlayCi = child.getAttribute && child.getAttribute('data-oci');
          if (childOverlayCi && currentConfig.whitelist.has(childOverlayCi)) {
            this._processedSet.add(child);
            continue;
          }
          var childComputedCi = this._computeOverlayCI(child);
          if (childComputedCi && currentConfig.whitelist.has(childComputedCi)) {
            this._processedSet.add(child);
            child.setAttribute('data-ow', 'true');
            continue;
          }
          if (currentConfig.keywordWhitelist.size > 0) {
            var kr2 = getKeywordWhitelistRegex();
            if (kr2) {
              var csc = child.textContent || '';
              var csrc = child.src || child.href || child.action || child.data || child.getAttribute('data-src') || '';
              var cClass = child.className && typeof child.className === 'string' ? child.className : '';
              var cId = child.id || '';
              if (kr2.test(csc + ' ' + csrc + ' ' + cClass + ' ' + cId)) {
                this._processedSet.add(child);
                child.setAttribute('data-ow', 'true');
                continue;
              }
            }
          }
          if (this.isOverlayElement(child)) this.hideElement(child);
        }
      }
    },
    _markCoveredChildren: function (el) {
      // 容器覆盖层被隐藏后, 其内部媒体子元素(IMG/iframe/video 等)随容器一并不可见;
      // 把它们记入 _coveredChildren, 后续这些子元素再被单独隐藏时只隐藏、各自不去记日记
      // (仅降噪开启时由调用方触发, 只影响记日志, 不动拦截/隐藏行为)。
      if (!el || !el.querySelectorAll || !this._coveredChildren) return;
      try {
        var _list = el.querySelectorAll('img, iframe, video, audio, embed, object');
        for (var _mi = 0; _mi < _list.length; _mi++) this._coveredChildren.add(_list[_mi]);
      } catch(e) {}
    },
    hideElement: function (el) {
      // 隐藏广告元素：加隐藏类(_uh) + 记录日志 + 白名单优先；同容器重复插入只隐藏不重复记日志。
      if (!el || this._processedSet.has(el)) return;
      // 统一白名单判定: 任一日记键(页面键/内容键/IFRAME_SRC/OVERLAY哈希/关键词)命中即完全放行
      if (isOverlayWhitelistedForElement(el)) {
        this._processedSet.add(el);
        el.setAttribute('data-ow', 'true');
        restoreNeutralizedElement(el);
        return;
      }
      // 子树保护: 容器内含已放行元素（加白恢复/用户标记）时不隐藏容器,
      // 防止放行的广告随所在容器一并被连坐隐藏
      if (hasReleasedOverlayInTree(el)) {
        this._processedSet.add(el);
        return;
      }


      // 隐藏覆盖层广告后统一交给滚动解锁守卫: 解除 html/body 的 overflow 锁定 + 恢复滚动位置。
      // (所有隐藏路径含同步 appendChild 钩子都汇入这里, 由 ScrollLockGuard 统一兜底)
      try { ScrollLockGuard.armForElement(el); } catch(e) { _debugCatch(e, "hideElement arm"); }

      var parent = el.parentElement;
      var canSterilize = parent && parent !== _document.body && parent !== _document.documentElement
        && !_isSafe(parent) && !this._processedSet.has(parent);
      if (!canSterilize) {   }


      var hitThreshold = false;
      var locId = this._getLocationId(el);


      if (parent && canSterilize && this._parentTracker) {
        var pt = this._parentTracker.get(parent);
        if (!pt) { this._parentTracker.set(parent, { count: 1 }); }
        else { pt.count++; if (pt.count >= this._STERILIZE_THRESHOLD) hitThreshold = true; }
      }

      if (locId && canSterilize && this._locTracker) {
        var lt = this._locTracker.get(locId);
        if (!lt) { this._locTracker.set(locId, { count: 1 }); }
        else { lt.count++; if (lt.count >= this._STERILIZE_THRESHOLD) hitThreshold = true; }
      }


      // 日记去重键用"元素自身内容标识"(ci): 按父容器/位置算时, 同一父容器下
      // 多个不同广告会互相顶掉日记（只留第一条）, 其余无法加白; 每个不同广告各自记一条,
      // 同一广告重复插入（内容相同）仍只记一条, 加白后所有路径都能放行。
      var ci = null;
      try {
        // 稳定键优先(IFRAME_SRC 去参 / OVERLAY_ 结构哈希): 刷新后依然可加白
        ci = _overlayContentKey(el);
        if (!ci) {
          var tagInfo = _overlayTagIdent(el);
          var contentPreview = Utils.truncateString(el.textContent || '', 100);
          ci = 'OVERLAY_' + generateContentHash('overlayIntercept:' + tagInfo + ':' + contentPreview);
        }
      } catch(e) {}
      // 拦截日记降噪（默认开）: 按"位置"去重(locId/父容器),
      // 同一位置第一次插入记日记, 之后的重复插入（即使内容不同）静默隐藏, 不刷屏;
      // 关闭后每次拦截都记日记。
      var logKey = locId || (parent ? '_p_' + generateContentHash(parent.tagName + (parent.id||'') + (parent.className||'')) : '');
      var isRepeat = currentConfig.logNoiseReduction !== false && this._repeatKeys && logKey ? this._repeatKeys.has(logKey) : false;

      if (hitThreshold) {

        if (parent && parent.getAttribute && parent.getAttribute('data-sterilized') === 'declined') {
          this._hideTriggerChild(el);
          this._processedSet.add(el);
          ProcessedElementsCache.markAsProcessed(el);
          return;
        }
        this._locationSterile.add(locId || '_' + Date.now());

        if (locId && parent && this._sterilizedByLoc) this._sterilizedByLoc.set(locId, parent);
        if (parent) {
          this._sterilizeParent(parent, el);
        }

        // 灭菌路径同样登记隐藏表(否则加白后 restore 找不到元素)
        if (ci) this._hiddenElementsMap.set(el, ci);
        this._applyHideClass(el);
        this._processedSet.add(el);
        ProcessedElementsCache.markAsProcessed(el);
        return;
      }


      // 白名单优先（降噪去重同样先查白名单）: 同位置重复插入(isRepeat)时同样先查白名单,
      // 加白后无论插入多少次都能恢复放行
      if (ci) {
        // 多钥匙匹配: 主键/去名备钥/身份备钥任一命中即放行
        if (_overlayKeyMatches(el, currentConfig.whitelist)) {
          this._processedSet.add(el);
          el.setAttribute('data-oci', ci);
          el.setAttribute('data-ow', 'true');
          // 若已被同步路径提前隐藏, 恢复显示（否则加白后仍卡住）
          restoreNeutralizedElement(el);
          return;
        }

        if (currentConfig.keywordWhitelist.size > 0) {
          var kr = getKeywordWhitelistRegex();
          if (kr) {
            var sc = el.textContent || '';
            var src = el.src || el.href || el.action || el.data || el.getAttribute('data-src') || '';
            if ((sc && kr.test(sc)) || (src && kr.test(src))) {
              this._processedSet.add(el);
              if (ci) el.setAttribute('data-oci', ci);
              el.setAttribute('data-ow', 'true');
              restoreNeutralizedElement(el);
              return;
            }
          }
        }
      }

      this._applyHideClass(el);
      this._processedSet.add(el);
      ProcessedElementsCache.markAsProcessed(el);
      if (ci) this._hiddenElementsMap.set(el, ci);
      // 登记已知广告结构键: 后续同结构重建实例由 MO 微任务同步锁死(见 _domObserverCallback)
      if (ci && this._knownAdKeys) this._knownAdKeys.add(ci);
      // 容器覆盖层隐藏后记下内部媒体子元素: 子元素随容器一并不可见, 再被单独隐藏只隐藏不记日记
      if (currentConfig.logNoiseReduction !== false) this._markCoveredChildren(el);

      if (this._repeatKeys) this._repeatKeys.add(logKey);
      var _skipChildLog = !!(this._coveredChildren && this._coveredChildren.has(el));
      if (!isRepeat && !_skipChildLog) {
        // 日志带尺寸/位置信息, 便于在拦截日志中识别并加白;
        // 显示名用结构槽位短标识(去随机 id/类名), 与备钥组共用一次槽位遍历
        var _detRect = '';
        try {
          var _dr2 = el.getBoundingClientRect();
          _detRect = ' (' + Math.round(_dr2.width) + 'x' + Math.round(_dr2.height) + '@' + Math.round(_dr2.left) + ',' + Math.round(_dr2.top) + ')';
        } catch (e) {}
        var _dispPre = _overlaySlotPreSlots(el);
        var detail = '覆盖层拦截: ' + (_overlaySlotDisplay(el, _dispPre) || el.tagName) + _detRect + ' - ' + Utils.truncateString(el.textContent||'',100);
        LogManager.add('overlayIntercept', el, {
          type: 'OVERLAY',
          detail: detail,
          elementContentIdentifier: ci || '',
          altContentIdentifiers: _dispPre ? _overlayBackupKeys(el, _dispPre) : _overlayBackupKeys(el),
        });
      }
    },
    // 放行连带解放: 容器/槽位被放行时, 其子树内所有带隐藏类的元素一并解除隐藏,
    // 且整棵子树打上保护标记 —— 各拦截路径（同步钩子/周期扫描/锁死）都会跳过,
    // 用户"放行这个位置"的预期即整个位置内没有任何东西被拦
    _releaseDescendants: function (el) {
      try {
        if (!el || !el.querySelectorAll) return;
        var hid = el.querySelectorAll('._uh');
        for (var i = 0; i < hid.length; i++) {
          var d = hid[i];
          d.classList.remove(this._hideClass);
          var ds = d.style;
          if (ds) {
            ds.removeProperty('display');
            ds.removeProperty('visibility');
            ds.removeProperty('opacity');
            ds.removeProperty('pointer-events');
            ds.removeProperty('height');
            ds.removeProperty('overflow');
          }
          d.setAttribute('data-ow', 'true');
          if (this._hiddenElementsMap) this._hiddenElementsMap.delete(d);
        }
        var all = el.querySelectorAll('*');
        for (var j = 0; j < all.length; j++) {
          try { all[j].setAttribute('data-slot-protected', 'true'); } catch (e) {}
        }
      } catch (e) { _debugCatch(e, "releaseDescendants"); }
    },
    restoreWhitelistedElements: function () {
      var self = this;
      // ============ DOM 全量扫描恢复(不依赖 _hiddenElementsMap) ============
      // 四种"加白后恢复不到"的失效场景由这张兜底网覆盖:
      //   ① 同步路径降噪静默隐藏(无日志键可加, 但元素带 _uh 类仍在 DOM → 扫描算稳定键命中白名单即恢复);
      //   ② map 被 disable/整页重写清空（元素脱离隐藏表 → 扫描照样恢复）;
      //   ③ 元素被广告脚本重建(新节点不在 map → 扫描按稳定键命中);
      //   ④ 容器被残留清理隐藏(data-adblock-hidden, 自身无日记 → 子树含放行元素即整容器恢复)。
      // 扫描范围: ._uh 隐藏类元素 + [data-sterilized] 灭菌容器 + [data-adblock-hidden] 清理容器;
      // 限量防性能; 已在 map 的交给下方逻辑处理避免重复。
      try {
        var _scanList = [];
        try {
          var _uhList = _document.querySelectorAll('._uh');
          for (var _ui = 0; _ui < _uhList.length && _ui < 100; _ui++) _scanList.push(_uhList[_ui]);
        } catch (e) {}
        try {
          var _stList2 = _document.querySelectorAll('[data-sterilized="true"]');
          for (var _si2 = 0; _si2 < _stList2.length && _si2 < 50; _si2++) _scanList.push(_stList2[_si2]);
        } catch (e) {}
        try {
          var _rhList = _document.querySelectorAll('[data-adblock-hidden="true"]');
          for (var _ri4 = 0; _ri4 < _rhList.length && _ri4 < 50; _ri4++) _scanList.push(_rhList[_ri4]);
        } catch (e) {}
        for (var _sc = 0; _sc < _scanList.length; _sc++) {
          var _se = _scanList[_sc];
          try {
            if (!_se || !_se.isConnected || !_se.getAttribute || !_se.style) continue;
            if (this._hiddenElementsMap && this._hiddenElementsMap.has(_se)) continue;   // 下方逻辑处理, 防重复
            var _hitWl = false;
            // 多钥匙匹配: 主键(结构槽位/身份/IFRAME_SRC) + 备钥组（去名槽位/松散链）/身份备钥任一命中即恢复
            try { if (_overlayKeyMatches(_se, currentConfig.whitelist)) _hitWl = true; } catch(e) {}
            if (!_hitWl) {
              // 残留清理隐藏的容器自身没有日记键: 子树内任一元素已放行 → 整容器恢复
              if (_se.getAttribute('data-adblock-hidden') === 'true' && hasReleasedOverlayInTree(_se)) _hitWl = true;
            }
            if (!_hitWl) {
              var _fsK = _getFullscreenAdKeys(_se);
              for (var _fk2 = 0; _fk2 < _fsK.length; _fk2++) {
                if (_fsK[_fk2] && currentConfig.whitelist.has(_fsK[_fk2])) { _hitWl = true; break; }
              }
            }
            if (!_hitWl && _se.tagName === 'IFRAME') {
              var _es2 = _se.src || '';
              if (_es2 && urlCache.isWhitelisted(_es2, currentConfig.thirdPartyWhitelist)) _hitWl = true;
            }
            if (!_hitWl) {
              // 灭菌容器键: 与 _sterilizeParent 同公式（稳定槽位主键 + 备钥组）,
              // 标签+文本兜底键一并参与匹配
              var _sti3 = _overlayTagIdent(_se);
              var _sk3 = 'OVERLAY_' + generateContentHash('overlayIntercept:' + _sti3 + ':' + Utils.truncateString(_se.textContent || '', 100));
              if (currentConfig.whitelist.has(_sk3)) { _hitWl = true; }
              if (!_hitWl) {
                try {
                  var _stSlots = _overlayStableSlots(_se);
                  if (_stSlots && _stSlots[0]) {
                    var _skMain = 'OVERLAY_' + generateContentHash('overlayIntercept:' + _stSlots[0]);
                    if (currentConfig.whitelist.has(_skMain)) _hitWl = true;
                    for (var _skb = 1; !_hitWl && _stSlots[_skb]; _skb++) {
                      if (_stSlots[_skb] === _stSlots[0]) continue;
                      if (currentConfig.whitelist.has('OVERLAY_' + generateContentHash('overlayIntercept:' + _stSlots[_skb]))) _hitWl = true;
                    }
                  }
                } catch(e) {}
              }
            }
            if (_hitWl) {
              _se.classList.remove(this._hideClass);
              _se.style.removeProperty('display');
              _se.style.removeProperty('visibility');
              _se.style.removeProperty('opacity');
              _se.style.removeProperty('pointer-events');
              _se.style.removeProperty('height');
              _se.style.removeProperty('overflow');
              _se.style.removeProperty('transform');
              _se.setAttribute('data-ow', 'true');
              markSlotProtected(_se);
              this._releaseDescendants(_se);
              if (_se.getAttribute('data-sterilized') === 'true') _se.removeAttribute('data-sterilized');
              if (_se.getAttribute('data-adblock-hidden') === 'true') _se.removeAttribute('data-adblock-hidden');
              if (this._hiddenElementsMap) this._hiddenElementsMap.delete(_se);
              var _p3 = _se.parentElement, _up3 = 8;
              while (_p3 && _p3 !== _document.body && _p3 !== _document.documentElement && _up3-- > 0) {
                try {
                  _p3.classList.remove(this._hideClass);
                  _p3.style.removeProperty('display');
                  _p3.style.removeProperty('visibility');
                  _p3.style.removeProperty('pointer-events');
                  _p3.style.removeProperty('height');
                  _p3.style.removeProperty('overflow');
                  _p3.style.removeProperty('transform');
                  if (_p3.getAttribute && _p3.getAttribute('data-sterilized') === 'true') _p3.removeAttribute('data-sterilized');
                  if (_p3.getAttribute && _p3.getAttribute('data-adblock-hidden') === 'true') _p3.removeAttribute('data-adblock-hidden');
                } catch (e) {}
                _p3 = _p3.parentElement;
              }
            }
          } catch (e) {}
        }
      } catch (e) {}

      // iframe 沙箱恢复: 已沙箱化的第三方 iframe 在满足放行条件（第三方白名单/日记键/页面放行）
      // 时解除 sandbox——正常第三方嵌入（播放器全屏/登录支付弹窗/地图）不被卡死
      try {
        if (typeof RedirectBlocker !== 'undefined' && RedirectBlocker._iframeSandboxSet && RedirectBlocker._sandboxExempt) {
          var _sbList = _document.querySelectorAll('iframe[sandbox]');
          for (var _sbi = 0; _sbi < _sbList.length; _sbi++) {
            var _sbe = _sbList[_sbi];
            if (!_sbe || !_sbe.isConnected) continue;
            var _sbsrc = _sbe.src || _sbe.getAttribute('src') || '';
            if (RedirectBlocker._sandboxExempt(_sbe, _sbsrc)) RedirectBlocker._restoreIframeSandbox(_sbe);
          }
        }
      } catch(e) {}

      if (!this._hiddenElementsMap || this._hiddenElementsMap.size === 0) return;
      var toRestore = [];
      this._hiddenElementsMap.forEach(function (ci, el) {
        if (typeof el !== 'object' || !el.isConnected) {
          if (typeof el === 'object') self._hiddenElementsMap.delete(el);
          return;
        }
        if (ci && currentConfig.whitelist.has(ci)) {
          toRestore.push(el);
          return;
        }
        // 全屏iframe白名单键（页面键/内容键）同样触发恢复
        var _fsKeys = _getFullscreenAdKeys(el);
        for (var _fk = 0; _fk < _fsKeys.length; _fk++) {
          if (_fsKeys[_fk] && currentConfig.whitelist.has(_fsKeys[_fk])) {
            toRestore.push(el);
            return;
          }
        }
        // iframe 自身命中第三方域名白名单 → 恢复
        if (el.tagName === 'IFRAME') {
          var _esrc = el.src || '';
          if (_esrc && urlCache.isWhitelisted(_esrc, currentConfig.thirdPartyWhitelist)) {
            toRestore.push(el);
            return;
          }
        }
        if (currentConfig.keywordWhitelist.size > 0) {
          var kr = getKeywordWhitelistRegex();
          if (kr) {
            var sc = el.textContent || '';
            var src = el.src || el.href || '';
            if ((sc && kr.test(sc)) || (src && kr.test(src))) {
              toRestore.push(el);
              return;
            }
          }
        }
        if (el.querySelector) {
          var iframes = el.querySelectorAll('iframe');
          for (var i = 0; i < iframes.length; i++) {
            var iframeSrc = iframes[i].src;
            if (iframeSrc && urlCache.isWhitelisted(iframeSrc, currentConfig.thirdPartyWhitelist)) {
              toRestore.push(el);
              return;
            }
          }
        }
      });
      toRestore.forEach(function (el) {
        el.classList.remove(self._hideClass);
        var s = el.style;
        if (s) { s.removeProperty('display'); s.removeProperty('visibility'); s.removeProperty('opacity'); s.removeProperty('pointer-events'); s.removeProperty('height'); s.removeProperty('overflow'); }
        el.setAttribute('data-ow', 'true');
        markSlotProtected(el);
        self._releaseDescendants(el);
        self._hiddenElementsMap.delete(el);
        var parent = el.parentElement, maxUp = 8;
        while (parent && parent !== _document.body && parent !== _document.documentElement && maxUp-- > 0) {
          var ps = parent.style;
          if (ps) { ps.removeProperty('display'); ps.removeProperty('visibility'); ps.removeProperty('pointer-events'); ps.removeProperty('height'); ps.removeProperty('overflow'); }
          parent.classList.remove(self._hideClass);
          if (parent.getAttribute && parent.getAttribute('data-sterilized') === 'true') parent.removeAttribute('data-sterilized');
          if (parent.getAttribute && parent.getAttribute('data-adblock-hidden') === 'true') parent.removeAttribute('data-adblock-hidden');
          parent = parent.parentElement;
        }
      });
      // 灭菌容器恢复: 用户加白了"容器灭活"日志键(_sterileCI, 与 _sterilizeParent 同公式)后,
      // 解除 data-sterilized 容器的 display:none, 让其中的正常内容（播放器等）重新显示
      try {
        var _stList = _document.querySelectorAll('[data-sterilized="true"]');
        for (var _si = 0; _si < _stList.length; _si++) {
          var _st = _stList[_si];
          try {
            if (!_st.isConnected || !_st.getAttribute || !_st.style) continue;
            var _sti = _st.tagName + (_st.id ? '#' + _st.id : '') +
              (_st.className ? '.' + String(_st.className).split(/\s+/).filter(function(c){return c;}).join('.') : '');
            var _hitSt = currentConfig.whitelist.has('OVERLAY_' + generateContentHash('overlayIntercept:' + _sti + ':' + Utils.truncateString(_st.textContent || '', 100)));
            if (!_hitSt) {
              // 与 _sterilizeParent 同公式: 稳定槽位主键 + 备钥组任一命中即恢复
              try {
                var _stSlots2 = _overlayStableSlots(_st);
                if (_stSlots2 && _stSlots2[0]) {
                  if (currentConfig.whitelist.has('OVERLAY_' + generateContentHash('overlayIntercept:' + _stSlots2[0]))) _hitSt = true;
                  for (var _skb2 = 1; !_hitSt && _stSlots2[_skb2]; _skb2++) {
                    if (_stSlots2[_skb2] === _stSlots2[0]) continue;
                    if (currentConfig.whitelist.has('OVERLAY_' + generateContentHash('overlayIntercept:' + _stSlots2[_skb2]))) _hitSt = true;
                  }
                }
              } catch (e) {}
            }
            if (_hitSt) {
              _st.style.removeProperty('display');
              _st.removeAttribute('data-sterilized');
              _st.setAttribute('data-ow', 'true');
              markSlotProtected(_st);
              this._releaseDescendants(_st);
            }
          } catch (e) {}
        }
      } catch (e) {}
    },


    _neutralizeInjectedOverlay: function () {
      // 处理用伪元素(:before/:after)画的广告: 固定定位 + 超高 z-index + 背景图/图片内容。
      // 特征检查只作用于"被删规则自身的块内容", 整表其他位置的特征不参与判定:
      // 规则体内须同时含图片内容(content:url(/background-image:) 与定位特征
      // (fixed/sticky/absolute 或超高 z-index); 定位/层级写在宿主元素内联或计算样式时
      // 以宿主样式作为补充证据。已加白的规则不剥离; 已记录剥离的规则在后续扫描中按白名单键
      // 恢复回原位置。拦截记日志(OVERLAY_INJECTED_STYLE), 白名单键 = 规则内容哈希（刷新后依然有效）。
      // 注入动画(@keyframes transform/opacity 淡入/滑入)与伪元素规则同机制剥离并记日志
      // (OVERLAY_INJECTED_KEYFRAMES), 加白后按剥离时记录的偏移插回样式表恢复。
      // 页面已加白放行 → 不做任何样式剥离
      try { if (RedirectBlocker._isPageReleased()) return; } catch(e) {}
      try {
        if (!this._injectStyleFp) this._injectStyleFp = new WeakMap();
        if (!this._strippedStyleRules) this._strippedStyleRules = new WeakMap();
        if (!this._strippedKeyframes) this._strippedKeyframes = new WeakMap();
        var sts = _document.querySelectorAll('style');
        for (var si = 0; si < sts.length; si++) {
          var stEl = sts[si];
          var css = stEl.textContent || '';
          var _domCss = css;
          var prev = this._injectStyleFp.get(stEl);
          var strippedMap = this._strippedStyleRules.get(stEl);
          // 恢复: 已加白的被删规则按剥离时记录的位置插回样式表
          if (strippedMap && strippedMap.size > 0 && currentConfig.whitelist.size > 0) {
            var _restores = [];
            var _rkList = Array.from(strippedMap.keys());
            for (var rki = 0; rki < _rkList.length; rki++) {
              if (currentConfig.whitelist.has(_rkList[rki])) {
                _restores.push(strippedMap.get(_rkList[rki]));
                strippedMap.delete(_rkList[rki]);
              }
            }
            if (_restores.length) {
              _restores.sort(function (a, b) { return a.offset - b.offset; });
              for (var rsi = 0; rsi < _restores.length; rsi++) {
                var _ins = _restores[rsi];
                var _pos = Math.min(_ins.offset, css.length);
                // 样式表被页面并发修改时偏移可能失准: 插入点前不是规则边界时追加到末尾
                var _preC = _pos > 0 ? css.charAt(_pos - 1) : '';
                if (_preC && '{};'.indexOf(_preC) === -1 && _preC !== ' ' && _preC !== '\n' && _preC !== '\r' && _preC !== '\t') _pos = css.length;
                css = css.slice(0, _pos) + _ins.orig + css.slice(_pos);
              }
            }
          }
// 已加白的关键帧按剥离时记录的偏移插回样式表
          var _kfMapSt = this._strippedKeyframes.get(stEl);
          if (_kfMapSt && _kfMapSt.size > 0 && currentConfig.whitelist.size > 0) {
            var _kfRestores = [];
            var _kfKeys = Array.from(_kfMapSt.keys());
            for (var kfi = 0; kfi < _kfKeys.length; kfi++) {
              if (currentConfig.whitelist.has(_kfKeys[kfi])) {
                _kfRestores.push(_kfMapSt.get(_kfKeys[kfi]));
                _kfMapSt.delete(_kfKeys[kfi]);
              }
            }
            if (_kfRestores.length) {
              _kfRestores.sort(function (a, b) { return a.offset - b.offset; });
              for (var krs = 0; krs < _kfRestores.length; krs++) {
                var _kfIns = _kfRestores[krs];
                var _kfPos = Math.min(_kfIns.offset, css.length);
                css = css.slice(0, _kfPos) + _kfIns.orig + css.slice(_kfPos);
              }
            }
          }
          if (prev === css) continue;
          var ncss = css;
          var removals = [];
          // 逐个伪元素规则独立检查: 规则自身须含图片内容; 定位/层级证据取规则体或宿主样式
          var _ruleRe = /\.([A-Za-z_][A-Za-z0-9_-]*)(?::[a-z-]+)*::?(?:before|after)[^{}]*\{[^}]*\}/gi;
          var _rm;
          while ((_rm = _ruleRe.exec(css)) !== null) {
            var _rule = _rm[0];
            var _cls = _rm[1];
            var _rl = _rule.toLowerCase();
            if (!/content\s*:\s*url\(|background-image\s*:/.test(_rl)) continue;
            var _hasPos = _rl.indexOf('position:fixed') !== -1 || _rl.indexOf('position:sticky') !== -1 || _rl.indexOf('position:absolute') !== -1;
            var _hasHighZ = _rl.indexOf('z-index:2147483') !== -1;
            if (!_hasPos && !_hasHighZ) {
              // 定位/层级也可能只写在宿主元素的样式里（内联或样式表）, 规则文本中没有 → 查宿主
              try {
                var _hostChk = _document.querySelector('.' + _cls);
                if (_hostChk && _hostChk.getAttribute) {
                  var _hstChk = String(_hostChk.getAttribute('style') || '').toLowerCase();
                  if (_hstChk.indexOf('position:fixed') !== -1 || _hstChk.indexOf('position:sticky') !== -1 || _hstChk.indexOf('position:absolute') !== -1) _hasPos = true;
                  if (_hstChk.indexOf('z-index:2147483') !== -1) _hasHighZ = true;
                  if (!_hasPos && !_hasHighZ) {
                    var _hcs = _getComputedStyle(_hostChk);
                    if (_hcs) {
                      if (_hcs.position === 'fixed' || _hcs.position === 'sticky' || _hcs.position === 'absolute') _hasPos = true;
                      if (parseInt(_hcs.zIndex, 10) >= 2147483000) _hasHighZ = true;
                    }
                  }
                }
              } catch(e) {}
              if (!_hasPos && !_hasHighZ) continue;
            }
            var _normRule = _rule.toLowerCase().replace(new RegExp('\\.' + _cls, 'gi'), '.x');
            var _ciInject = 'OVERLAY_INJECTED_STYLE:' + generateContentHash(_normRule);
            if (currentConfig.whitelist.has(_ciInject)) continue;
            removals.push({ index: _rm.index, len: _rule.length, rule: _rule, cls: _cls, key: _ciInject });
          }
// 剥离"危险关键帧"(淡入/滑入动画): 覆盖层脚本用 @keyframes+transform/opacity
          // 让广告从透明/屏幕外进入, 静态帧快扫会漏。判定=关键帧体含 transform/opacity,
          // 且被本表"覆盖层信号规则"(fixed/sticky/absolute、z-index 4位以上、100% 尺寸)
          // 通过 animation/animation-name 引用; 普通页面入场动画（无覆盖层信号的引用规则）
          // 不受影响。
          var kfRemovals = [];
          try {
            var _kfNameRe = /@keyframes\s+([A-Za-z_][A-Za-z0-9_-]*)/gi;
            var _kfMatch;
            while ((_kfMatch = _kfNameRe.exec(css)) !== null) {
              var _kfName = _kfMatch[1];
              // 花括号配平取完整关键帧块(from/to 多层大括号)
              var _kfEnd = -1;
              var _kfDepth = 0;
              for (var kfp = _kfMatch.index; kfp < css.length; kfp++) {
                var _kc = css.charAt(kfp);
                if (_kc === '{') _kfDepth++;
                else if (_kc === '}') { _kfDepth--; if (_kfDepth === 0) { _kfEnd = kfp + 1; break; } }
              }
              if (_kfEnd === -1) continue;
              var _kfRule = css.slice(_kfMatch.index, _kfEnd);
              var _kfLow = _kfRule.toLowerCase();
              if (_kfLow.indexOf('transform') === -1 && _kfLow.indexOf('opacity') === -1) continue;
              var _kfEsc = _kfName.replace(/[{}.*+?^$()|[\]\\]/g, '\\          if (!removals.length && !kfRemovals.length) {');
              var _refRe = new RegExp('animation(?:-name)?\\s*:\\s*[^;{}]*\\b' + _kfEsc + '\\b', 'i');
              var _kfKey = 'OVERLAY_INJECTED_KEYFRAMES:' + generateContentHash(_kfLow);
              if (currentConfig.whitelist.has(_kfKey)) continue;
              var _danger = false;
              for (var rml = 0; rml < removals.length; rml++) {
                if (_refRe.test(removals[rml].rule)) { _danger = true; break; }
              }
              if (!_danger) {
                var _rFind = /([^{}]*)\{([^{}]*)\}/g;
                var _rfM;
                while ((_rfM = _rFind.exec(css)) !== null) {
                  if (!_refRe.test(_rfM[0])) continue;
                  var _rb = _rfM[2].toLowerCase();
                  if (/position\s*:\s*(fixed|sticky|absolute)|z-index\s*:\s*\d{4,}|(?:^|[;{})\s])(?:width|height|max-width|max-height)\s*:\s*(?:100%|100vw|100vh|100dvw|100dvh)|inset\s*:\s*0/.test(_rb)) { _danger = true; break; }
                }
              }
              if (_danger) kfRemovals.push({ index: _kfMatch.index, len: _kfRule.length, rule: _kfRule, name: _kfName, key: _kfKey });
            }
          } catch (e) { _debugCatch(e, 'neutralize keyframes'); }
          if (!removals.length && !kfRemovals.length) {
            this._injectStyleFp.set(stEl, css);
            if (css !== _domCss) stEl.textContent = css;
            continue;
          }
          // 从后往前剥离, 记录的位置不失效
// 从后往前剥离（规则+关键帧合并）, 记录的位置不失效
          var _allRm = removals.concat(kfRemovals);
          _allRm.sort(function (a, b) { return b.index - a.index; });
          for (var rmi = 0; rmi < _allRm.length; rmi++) {
            var _rmv = _allRm[rmi];
            ncss = ncss.slice(0, _rmv.index) + ncss.slice(_rmv.index + _rmv.len);
          }
          for (var rmi = 0; rmi < removals.length; rmi++) {
            var _rmv = removals[rmi];
            ncss = ncss.slice(0, _rmv.index) + ncss.slice(_rmv.index + _rmv.len);
          }
          if (!strippedMap) { strippedMap = new _Map(); this._strippedStyleRules.set(stEl, strippedMap); }
          for (var rmi2 = 0; rmi2 < removals.length; rmi2++) {
            var _rmv2 = removals[rmi2];
            strippedMap.set(_rmv2.key, { orig: _rmv2.rule, offset: _rmv2.index });
if (kfRemovals.length) {
            if (!_kfMapSt) { _kfMapSt = new _Map(); this._strippedKeyframes.set(stEl, _kfMapSt); }
            for (var kr2 = 0; kr2 < kfRemovals.length; kr2++) {
              var _kfr = kfRemovals[kr2];
              _kfMapSt.set(_kfr.key, { orig: _kfr.rule, offset: _kfr.index });
            }
            for (var kr3 = 0; kr3 < kfRemovals.length; kr3++) {
              var _kfr3 = kfRemovals[kr3];
              try {
                LogManager.add('overlayIntercept', null, {
                  type: 'OVERLAY_INJECTED_KEYFRAMES',
                  detail: '覆盖层拦截(注入动画): @keyframes ' + _kfr3.name,
                  elementContentIdentifier: _kfr3.key,
                });
              } catch(e) { _debugCatch(e, "neutralize kf log"); }
            }
          }
          }
          this._injectStyleFp.set(stEl, ncss);
          stEl.textContent = ncss;
          if (!stEl.textContent.replace(/\s/g, '')) {
            if (stEl.parentNode) stEl.parentNode.removeChild(stEl);
          }
          for (var rmi3 = 0; rmi3 < removals.length; rmi3++) {
            var _rmv3 = removals[rmi3];
            try {
              var _uf = '';
              var _um = _rmv3.rule.match(/url\([^)]*\)/i);
              if (_um) _uf = String(_um[0]).slice(0, 80);
              LogManager.add('overlayIntercept', null, {
                type: 'OVERLAY_INJECTED_STYLE',
                detail: '覆盖层拦截(注入伪元素广告): .' + _rmv3.cls + ' ' + _uf,
                elementContentIdentifier: _rmv3.key,
              });
            } catch(e) { _debugCatch(e, "neutralize log"); }
            // 宿主清理: body/html 上的广告类名与顶部留白、广告脚本埋的元标记
            try {
              var host = _document.querySelector('.' + _rmv3.cls);
              if (host) {
                if (host === _document.body || host === _document.documentElement) {
                  if (host.classList && host.classList.contains(_rmv3.cls)) host.classList.remove(_rmv3.cls);
                  if (host.style) {
                    var pt = host.style.paddingTop;
                    if (pt) {
                      var pv = parseInt(pt, 10);
                      if (!isNaN(pv) && pv > (_globals.innerHeight || 800) * 0.15) {
                        host.style.paddingTop = '';
                      }
                    }
                  }
                }
                var gd = _document.querySelector('meta[name="___gd"]');
                if (gd && gd.parentNode) gd.parentNode.removeChild(gd);
              }
            } catch(e) {}
          }
        }
      } catch (e) { _debugCatch(e, "neutralizeInjectedOverlay"); }
    },
    initialScan: function () {
      var self = this;

      try { self._neutralizeInjectedOverlay(); } catch(e) {}
      try {

        var highRiskSelectors = '[style*=\"fixed\"],[style*=\"absolute\"],[style*=\"z-index\"]';
        try {
          var highRiskEls = _document.querySelectorAll(highRiskSelectors);
          // 帧预算: 页面里 fixed/absolute/z-index 元素可能成百上千, 同步逐个判定会占满主线程;
          // 未处理的部分交给下方 TreeWalker 空闲批次继续, 不漏检
          var _tH = performance.now();
          for (var hi = 0; hi < highRiskEls.length; hi++) {
            var hr = highRiskEls[hi];
            if (!self._processedSet.has(hr) && hr.isConnected) self.checkAndHandle(hr);
            if (performance.now() - _tH > 8) break;
          }
        } catch(e) { _debugCatch(e, "highRiskEls[hi]"); }

        var allElements = [];
        var tw = _document.createTreeWalker(_document.documentElement, 1, null, false);
        while (tw.nextNode()) allElements.push(tw.currentNode);
        var len = allElements.length;
        if (len === 0) return;
        var index = 0;

        var URGENT_BATCH = 50;
        var urgentEnd = Math.min(URGENT_BATCH, len);
        var _tU = performance.now();
        for (; index < urgentEnd; index++) {
          var el = allElements[index];
          if (!self._processedSet.has(el) && el.isConnected) self.checkAndHandle(el);
          // 紧急批同样受帧预算约束: 手机端 getComputedStyle 成本高, 过量同步判定会占满主线程
          if (performance.now() - _tU > 8) break;
        }

        var BATCH_SIZE = 30;
        function processBatch(deadline) {
          var _t0 = performance.now();
          var end = Math.min(index + BATCH_SIZE, len);
          for (; index < end; index++) {
            var el = allElements[index];
            if (!self._processedSet.has(el) && el.isConnected) self.checkAndHandle(el);
            // 绝对帧预算: 不依赖 timeRemaining(无 requestIdleCallback 的环境该值恒为 50,
            // 会让整批元素连续同步判定); 8ms 硬预算保证每批都在一帧内让出
            if (performance.now() - _t0 > 8) break;
          }
          if (index < len) _requestIdleCallback(processBatch);
        }
        if (index < len) _requestIdleCallback(processBatch);
      } catch(e) { _debugCatch(e, "len)"); }
    },
    startPeriodicScan: function () {
      var self = this;
      var last = 0;
      var _timerId = null;
      var _cursor = 0;
      // 全量元素扫描快照: 每 10 秒重建一次, 快照有效期内按游标分批续扫,
      // 避免每 3 秒对全 DOM 重建 querySelectorAll(长页面卡顿主因)
      var _scanSnapshot = null;
      var _scanSnapshotAt = 0;
      var loop = function (dl) {
        if (!self._enabled || !currentConfig.modules.overlayIntercept) return;
        if (self._periodicTimer !== _timerId) return;
        var now = Date.now();
        // 后台标签页降频纯补扫(rAF/idle 本就暂停, 再加一道保险; 锁死路径=MO 微任务不受影响)
        // 回前台(_resumeScan)后第一轮立即补扫并重建快照, 防积压广告滞留在可见窗口
        var _pgHidden = _document.visibilityState === 'hidden';
        var _resume = self._resumeScan === true;
        if ((_resume || now - last > CONFIG.IDLE_SCAN_INTERVAL * (_pgHidden ? 3 : 1)) && dl.timeRemaining() > 2) {
          if (_resume) self._resumeScan = false;


          try { self._neutralizeInjectedOverlay(); } catch(e) {}
          // 周期复查滚动锁定（窗口期内广告脚本反复加锁也能持续解除）
          try { ScrollLockGuard.apply(); } catch(e) {}


          if (self._hiddenElementsMap && self._hiddenElementsMap.size > 0) {
            var _entries = Array.from(self._hiddenElementsMap.entries());
            var _start = self._recheckCursor || 0;
            var _count = 0;
            for (var _ri = 0; _ri < _entries.length && _count < 20; _ri++) {
              var _idx = (_start + _ri) % _entries.length;
              var _pair = _entries[_idx];
              var hel = _pair[0];
              if (typeof hel !== 'object' || !hel) continue;
              _count++;
            try {
              if (isOverlayWhitelistedForElement(hel) || isWhitelistedOrProtected(hel)) {
                self._hiddenElementsMap.delete(hel);
                continue;
              }
              if (hel.isConnected && hel.classList && !hel.classList.contains(self._hideClass)) {
                hel.classList.add(self._hideClass);
              }
            } catch(e) {}
            }
            self._recheckCursor = (_start + _count) % _entries.length;
          }
          var cnt = 0;
          try {


            try {
              var _hot = _document.querySelectorAll('[style*="fixed"],[style*="absolute"],[style*="z-index"]');
              for (var hi = 0; hi < _hot.length && cnt < 10 && dl.timeRemaining() > 2; hi++) {
                hel = _hot[hi];
                if (!self._processedSet.has(hel) && hel.isConnected) {
                  self.checkAndHandle(hel);
                  cnt++;
                }
              }
            } catch(e) { _debugCatch(e, "highPriority scan"); }
            // 全量元素补漏扫描（增量）: 快照 10 秒重建（后台 30 秒）, 期间按游标分批续扫;
            // 回前台(_resume)强制立即重建快照, 保证补扫用的是新 DOM 状态
            if (!_scanSnapshot || _resume || (now - _scanSnapshotAt) > (_pgHidden ? 30000 : 10000)) {
              try {
                _scanSnapshot = _document.querySelectorAll('div, iframe, section, aside, a, span, article, main, img');
                _scanSnapshotAt = now;
                _cursor = 0;
              } catch(e) { _scanSnapshot = null; }
            }
            if (_scanSnapshot) {
              var els = _scanSnapshot;
              var _n = els.length;
              var i = _cursor;
              for (; i < _n && cnt < CONFIG.BATCH_SIZE_CLEANUP && dl.timeRemaining() > 2; i++) {
                var el = els[i];
                if (!self._processedSet.has(el) && el.isConnected) {
                  self.checkAndHandle(el);
                  cnt++;
                }
              }
              _cursor = (i >= _n) ? 0 : i;
            }

          } catch(e) { _debugCatch(e, "cnt++"); }
          if (cnt > 0) last = now;
        }
        if (self._enabled && currentConfig.modules.overlayIntercept) {
          self._periodicTimer = _requestIdleCallback(loop);
          _timerId = self._periodicTimer;
        }
      };
      this._periodicTimer = _requestIdleCallback(loop);
      _timerId = this._periodicTimer;
    },
    stopPeriodicScan: function () {
      if (this._periodicTimer !== null) {
        _cancelIdleCallback(this._periodicTimer);
        this._periodicTimer = null;
      }
    },
    resetLocationMemory: function () {
      // 清空位置级记忆（降噪去重表/灭菌计数/位置指纹）, 保留隐藏表与已知广告键。
      // 加白/配置变更后调用: 同一位置的后续插入重新记日记（漂移变体可被再次加白）,
      // 灭菌计数归零避免放行后的元素继续累计同位置计数
      this._repeatKeys = this._enabled ? new _Set() : null;
      this._locTracker = this._enabled ? new _Map() : null;
      this._parentTracker = this._enabled ? new WeakMap() : null;
      this._locationSterile = this._enabled ? new _Set() : null;
      this._sterilizedByLoc = this._enabled ? new _Map() : null;
    },
  };

  // ======================== XHR 拦截状态记录（WeakMap 防页面检测） ========================
    // 【功能】记录被拦截的 XHR 请求状态（是否已替换/处理）。
    // 【机制】WeakMap 键为 XHR 实例——页面脚本无法遍历拿到这份记录（防对抗）。
    // 【注意】配合下方"资源取消器"使用：状态记录 + 元素移除双管齐下。
  // 用 WeakMap 记下被拦截的 XHR 请求状态，页面脚本无法通过遍历拿到这份记录。
  const _xhrBlockState = new WeakMap();

  // ======================== 资源取消器（移除元素并阻止加载） ========================
    // 移除已拦截的资源元素（script/iframe/img）并阻止其加载（配合占位图）。
  const LightweightCorpseCleaner = {
    cleanAfterRemoval: function(removedElement, savedParent) {
      // 资源被移除后清理其父容器链（空容器/残留节点），避免页面留空白块。
      if (!removedElement || !_isElementLike(removedElement)) return;
      var parent = savedParent || removedElement.parentElement;
      if (!parent) return;
      // 父容器文本量大的（正常内容区）直接跳过, 免去每级 textContent 物化整棵子树
      try { if ((parent.textContent || '').length > 200) return; } catch(e) {}
      var depth = 0;
      var maxDepth = 3;
      while (parent && depth < maxDepth) {
        if (this._isProtectedContainer(parent)) break;
        if (this._isAdCorpse(parent)) {
          this._softHide(parent);

          parent = parent.parentElement;
          depth++;
          if (parent && depth < maxDepth && !this._isProtectedContainer(parent) &&
              this._isEffectivelyEmpty(parent) && this._isAdCorpse(parent)) {
            this._softHide(parent);
          }
          break;
        }
        if (this._hasOtherVisibleContent(parent)) break;
        parent = parent.parentElement;
        depth++;
      }
    },
    _isProtectedContainer: function(el) {
      if (!el || !_isElementLike(el)) return true;
      if (el === _document.documentElement || el === _document.body) return true;
      if (_isSafe(el)) return true;
      if (ProcessedElementsCache.isProcessed(el)) return true;
      if (isWhitelistedOrProtected(el)) return true;
      if (el.getAttribute && el.getAttribute('data-slot-protected') === 'true') return true;
      var tag = el.tagName;
      if (tag === 'MAIN' || tag === 'ARTICLE' || tag === 'NAV' ||
          tag === 'HEADER' || tag === 'FOOTER') {
        var s = el.style;
        if (s && (s.position === 'fixed' || s.position === 'absolute')) return false;
        return true;
      }
      var role = el.getAttribute('role');
      if (role && 'navigation main content banner complementary search dialog alert'.indexOf(role) !== -1) return true;
      if (el.shadowRoot) return true;
      if ((el.textContent || '').trim().length > 200) return true;
      return false;
    },
    _isAdCorpse: function(container) {
      if (!container || !_isElementLike(container)) return false;
      if (!this._isEffectivelyEmpty(container)) return false;
      var is = container.style;
      if (is) {

        try {
          var _ovIn = (is.overflowY || is.overflow || '').toLowerCase();
          if (_ovIn.indexOf('auto') !== -1 || _ovIn.indexOf('scroll') !== -1) return false;
        } catch(e) {}
        var pos = (is.position || '').toLowerCase();
        var zi = parseInt(is.zIndex);
        if ((pos === 'fixed' || pos === 'absolute') && !isNaN(zi) && zi > 10) return true;
        var ov = (is.overflow || '').toLowerCase();
        if ((pos === 'fixed' || pos === 'absolute') && ov === 'hidden') return true;
        var iw = parseInt(is.width), ih = parseInt(is.height);
        if (!isNaN(iw) && !isNaN(ih) && iw > 0 && ih > 0 && this._matchesAdSize(iw, ih)) return true;
      }
      var style;
      try { style = _getComputedStyle(container); } catch (e) { return false; }

      if (_isScrollableContainer(container, style)) return false;
      var position = style.position;
      var zIndex = parseInt(style.zIndex);
      var width = parseFloat(style.width), height = parseFloat(style.height);
      if (position === 'fixed' && !isNaN(zIndex) && zIndex > 10) return true;
      if (position === 'absolute' && !isNaN(zIndex) && zIndex > 10 &&
          !isNaN(width) && width > 0 && !isNaN(height) && height > 0) return true;
      if (position === 'fixed') {
        var vw = _globals.innerWidth || 0, vh = _globals.innerHeight || 0;
        if (vw > 0 && vh > 0 && container.offsetWidth > vw * 0.3 && container.offsetHeight > vh * 0.3) return true;
      }
      if (!isNaN(width) && !isNaN(height) && width > 0 && height > 0 && this._matchesAdSize(width, height)) return true;

      var bg = style.backgroundColor;
      if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent' && position === 'fixed' &&
          !isNaN(width) && width > 100 && !isNaN(height) && height > 100) return true;
      return false;
    },
    _matchesAdSize: function(w, h) {
      var adSizes = [[300,250],[728,90],[160,600],[300,600],[320,50],[320,100],
        [970,90],[970,250],[300,50],[336,280],[120,600],[468,60],
        [250,250],[200,200],[180,150],[125,125],[234,60]];
      for (var i = 0; i < adSizes.length; i++) {
        if (Math.abs(w - adSizes[i][0]) < 10 && Math.abs(h - adSizes[i][1]) < 10) return true;
      }
      return false;
    },
    _isEffectivelyEmpty: function(container) {
      if (!container) return false;
      for (var i = 0; i < container.childNodes.length; i++) {
        var child = container.childNodes[i];
        if (child.nodeType === _Node.TEXT_NODE) {
          if (child.textContent.trim().length > 0) return false;
          continue;
        }
        if (child.nodeType !== _Node.ELEMENT_NODE) continue;
        if (ProcessedElementsCache.isProcessed(child)) continue;

        if (child.tagName === 'SCRIPT' || child.tagName === 'STYLE' ||
            child.tagName === 'LINK' || child.tagName === 'META' ||
            child.tagName === 'NOSCRIPT') continue;
        var cs = child.style;
        if (cs && (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0')) continue;
        if (child.tagName === 'BR' || child.tagName === 'HR') continue;
        if (child.offsetWidth > 0 && child.offsetHeight > 0) {
          if (child.tagName === 'IMG') {
            var src = child.src || child.getAttribute('data-src') || '';
            if (src === TRANSPARENT_PIXEL || (child.offsetWidth <= 1 && child.offsetHeight <= 1)) continue;

            if (ResidualCleaner._isLazyImage && ResidualCleaner._isLazyImage(child)) return false;
            if (src && src.startsWith('data:') && src.length < CONFIG.LAZY_PLACEHOLDER_MAX_LEN) continue;
          }
          return false;
        }
      }
      return true;
    },
    _hasOtherVisibleContent: function(container) {
      if (!container) return false;
      for (var i = 0; i < container.children.length; i++) {
        var child = container.children[i];
        if (ProcessedElementsCache.isProcessed(child)) continue;
        if (_isSafe(child)) continue;
        if (child.offsetWidth > 5 && child.offsetHeight > 5) return true;
      }
      return false;
    },
    _softHide: function(el) {
      if (!el || !_isElementLike(el)) return;
      if (isWhitelistedOrProtected(el) || hasWhitelistedContentInTree(el)) return;
      // 子树内含已加白放行的覆盖层广告 → 容器不软化隐藏（防加白后被连坐）
      if (hasReleasedOverlayInTree(el)) return;
      el.classList.add('_uh');
      el.style.setProperty('display', 'none', 'important');
      el.style.setProperty('pointer-events', 'none', 'important');
      el.style.setProperty('height', '0!important');
      el.style.setProperty('overflow', 'hidden', 'important');
      ProcessedElementsCache.markAsProcessed(el);
    },
  };

  const ResourceCanceller = {
    cancelResourceLoading: function (element) {
      if (!Utils.isElement(element) || ProcessedElementsCache.isProcessed(element)) return;
      // 白名单守卫: 已加白的资源元素一律不取消加载（防任何绕过白名单的调用方）
      if (isWhitelistedOrProtected(element)) return;
      var t = element.tagName;
      if (t === 'IMG') {
        element.removeAttribute('src');
        element.removeAttribute('srcset');
        element.removeAttribute('data-src');
      } else if (t === 'IFRAME') {
        element.removeAttribute('src');
        element.style.display = 'none';
        // 被移除的第三方广告 iframe 常伴随 html/body 滚动锁定, 触发滚动解锁守卫
        try { ScrollLockGuard.armForElement(element); } catch(e) { _debugCatch(e, "cancelResourceLoading arm"); }
      } else if (t === 'SCRIPT') {

        try { element.setAttribute('type', 'text/plain'); } catch(e2) {}
        element.removeAttribute('src');
        element.textContent = '';
      } else if (t === 'LINK') {
        var linkRel = (element.rel || '').toLowerCase();
        if (linkRel === 'stylesheet' || linkRel === 'preload' || linkRel === 'prefetch' || linkRel === 'modulepreload')
          element.removeAttribute('href');
      } else if (t === 'STYLE') element.textContent = '';
      else if (t === 'EMBED') element.removeAttribute('src');
      else if (t === 'OBJECT') element.removeAttribute('data');
      var savedParent = element.parentElement;
      var p = savedParent;
      if (p && p !== _document.body && p !== _document.documentElement && !hasWhitelistedContentInTree(p) && Utils.isContainerEmpty(p, true) && Utils.isSuspiciousAdContainer(p)) ResidualCleaner.checkAndCleanup(p);
      if (element.parentNode) element.parentNode.removeChild(element);
      ProcessedElementsCache.markAsProcessed(element);
      LightweightCorpseCleaner.cleanAfterRemoval(element, savedParent);
    },
  };


  const TAG_HANDLERS = {
    SCRIPT: {
      srcAttr: 'src',
      check: function (el, mk, reason) {
        var ci = Utils.getContentIdentifier(el);
        if (ci && currentConfig.whitelist.has(ci)) return false;
        // 外联移除模块的白名单键为 EXTERNAL_SCRIPT(与日志键同公式),
        // 元素路径检查要与加白键一致, 否则加白后该模块仍拦
        if (mk === 'removeExternalScripts' && el.src && currentConfig.whitelist.has(Utils.externalScriptKey(el.src))) return false;
        if (mk === 'removeExternalScripts' && el.src && Utils.externalScriptStructKey && currentConfig.whitelist.has(Utils.externalScriptStructKey(el.src))) return false;
        LogManager.add(mk, el, reason);
        if (mk === 'removeExternalScripts' || mk === 'scriptBlacklistMode') ResourceCanceller.cancelResourceLoading(el);
        else if (mk === 'removeInlineScripts' && !el.src) ResourceCanceller.cancelResourceLoading(el);
        ProcessedElementsCache.markAsProcessed(el);
        return true;
      },
    },
    IFRAME: {
      srcAttr: 'src',
      check: function (el, mk) {
        if (mk !== 'interceptThirdParty') return false;
        var u = el.src;
        if (u && shouldBlockResource(u)) {
          LogManager.add(mk, el, { type: 'THIRD_PARTY', detail: 'IFRAME: ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH) });
          ResourceCanceller.cancelResourceLoading(el);
          ProcessedElementsCache.markAsProcessed(el);
          return true;
        }
        return false;
      },
    },
    IMG: {
      srcAttr: 'src',
      dataSrcAttr: 'data-src',
      check: function (el, mk) {
        if (mk !== 'interceptThirdParty') return false;
        var u = el.src || el.getAttribute('data-src');
        if (u && shouldBlockResource(u)) {
          LogManager.add(mk, el, { type: 'THIRD_PARTY', detail: 'IMG: ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH) });
          ResourceCanceller.cancelResourceLoading(el);
          ProcessedElementsCache.markAsProcessed(el);
          return true;
        }
        return false;
      },
    },
    LINK: {
      srcAttr: 'href',
      check: function (el, mk) {
        if (mk !== 'interceptThirdParty') return false;
        var u = el.href;
        var rel = (el.getAttribute('rel') || '').toLowerCase();

        var interceptableRels = ['stylesheet', 'preload', 'prefetch', 'modulepreload'];
        if (u && interceptableRels.indexOf(rel) !== -1 && shouldBlockResource(u)) {
          var detailType = rel === 'stylesheet' ? 'LINK' : ('LINK_' + rel.toUpperCase());
          LogManager.add(mk, el, { type: 'THIRD_PARTY', detail: detailType + ': ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH) });
          ResourceCanceller.cancelResourceLoading(el);
          ProcessedElementsCache.markAsProcessed(el);
          return true;
        }
        return false;
      },
    },
    EMBED: {
      srcAttr: 'src',
      check: function (el, mk) {
        if (mk !== 'interceptThirdParty') return false;
        var u = el.src;
        if (u && shouldBlockResource(u)) {
          LogManager.add(mk, el, { type: 'THIRD_PARTY', detail: 'EMBED: ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH) });
          ResourceCanceller.cancelResourceLoading(el);
          ProcessedElementsCache.markAsProcessed(el);
          return true;
        }
        return false;
      },
    },
    OBJECT: {
      srcAttr: 'data',
      check: function (el, mk) {
        if (mk !== 'interceptThirdParty') return false;
        var u = el.data;
        if (u && shouldBlockResource(u)) {
          LogManager.add(mk, el, { type: 'THIRD_PARTY', detail: 'OBJECT: ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH) });
          ResourceCanceller.cancelResourceLoading(el);
          ProcessedElementsCache.markAsProcessed(el);
          return true;
        }
        return false;
      },
    },
    A: {
      srcAttr: 'href',
      check: function (el, mk) {
        if (mk !== 'interceptThirdParty') return false;
        var u = el.href;
        if (u && shouldBlockResource(u)) {
          LogManager.add(mk, el, { type: 'THIRD_PARTY', detail: 'A: ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH) });
          el.href = 'javascript:void(0)';
          ProcessedElementsCache.markAsProcessed(el);
          return true;
        }
        return false;
      },
    },
  };

  // ==================== 显式浏览器原型映射表 ====================

  // 【功能】各标签的浏览器原生原型引用表（HTMLScriptElement/HTMLIFrameElement 等），

  // 【机制】缓存原生原型供 setter 劫持使用（type/src/href 等属性写入时拦截），与全局 _globals 缓存同一思想。
  const TAG_PROTO_MAP = {
    SCRIPT: _globals.HTMLScriptElement ? _globals.HTMLScriptElement.prototype : null,
    IFRAME: _globals.HTMLIFrameElement ? _globals.HTMLIFrameElement.prototype : null,
    IMG: _globals.HTMLImageElement ? _globals.HTMLImageElement.prototype : null,
    LINK: _globals.HTMLLinkElement ? _globals.HTMLLinkElement.prototype : null,
    EMBED: _globals.HTMLEmbedElement ? _globals.HTMLEmbedElement.prototype : null,
    OBJECT: _globals.HTMLObjectElement ? _globals.HTMLObjectElement.prototype : null,
    A: _globals.HTMLAnchorElement ? _globals.HTMLAnchorElement.prototype : null,
  };

  // ======================== 模块基类 ========================
    // 各拦截模块的公共基类：提供启用/停用/检查的通用模板，外加按标签分类的处理表（TAG_HANDLERS）。
  class BaseModule {
    constructor(mk) {
      this.moduleKey = mk;
      this.enabled = false;
      this.observer = null;
    }
    init() {
      currentConfig.modules[this.moduleKey] ? this.enable() : this.disable();
    }
    enable() {
      if (this.enabled) return;
      this.enabled = true;
      this.onEnable();
    }
    disable() {
      if (!this.enabled) return;
      this.enabled = false;
      this.onDisable();
    }
    onEnable() {}
    onDisable() {
      if (this.observer) {
        this.observer.disconnect();
        this.observer = null;
      }
      if (this._domObserverCallback) {
        DomObserver.unsubscribe(this._domObserverCallback);
        this._domObserverCallback = null;
      }
    }
    checkElement(el) {
      if (!Utils.shouldInterceptByModule(el, this.moduleKey)) return false;
      return this._checkElement(el);
    }
    _checkElement(el) {
      throw new Error('_checkElement must be implemented');
    }
  }


  class RemoveInlineScriptsModule extends BaseModule {
    constructor() {
      super('removeInlineScripts');
      this.attributeObserver = null;
    }
    onEnable() {
      var self = this;
      this._domObserverCallback = function (ms) {
        for (const m of ms) {
          for (const n of m.addedNodes) {
            if (n.nodeType === 1) {
              if (currentConfig.inlineScriptStrictMode) self.sanitizeInlineEventAttributes(n);
              if (n.tagName === 'SCRIPT' && !n.src) self.checkElement(n);
              else if (n.querySelectorAll) {
                Array.from(n.querySelectorAll('script:not([src])')).forEach(function (s) { self.checkElement(s); });
              }
            }
          }
        }
      };
      DomObserver.subscribe(this._domObserverCallback);

      Array.from(_document.querySelectorAll('script:not([src])')).forEach(function (s) {
        if (!ProcessedElementsCache.isProcessed(s)) {
          ScriptSyncGuard.interceptAndLog(s);
        }
      });
      if (currentConfig.inlineScriptStrictMode) {
        var twEl = _document.createTreeWalker(_document.documentElement, 1, null, false);
        while (twEl.nextNode()) { self.sanitizeInlineEventAttributes(twEl.currentNode); }
      }
      if (currentConfig.inlineScriptStrictMode) {
        this.attributeObserver = new _MutationObserver(function (ms) {
          for (const m of ms) {
            if (m.type !== 'attributes' || m.target.nodeType !== 1) continue;
            var an = m.attributeName;
            var t = m.target;
            if (an && an.toLowerCase().startsWith('on')) {
              var v = t.getAttribute(an);
              if (v && typeof v === 'string' && v.trim() !== '') {
                var r = { type: '内联事件', detail: '属性: ' + an + '="' + v + '"' };
                if (!Whitelisting.isReasonWhitelisted(r, self.moduleKey)) {
                  LogManager.add(self.moduleKey, t, r);
                  t.removeAttribute(an);
                  ProcessedElementsCache.markAsProcessed(t);
                }
              }
            } else if (['href', 'src', 'action', 'data', 'formaction'].indexOf(an) !== -1) {
              var v2 = t.getAttribute(an);
              if (v2 && typeof v2 === 'string' && v2.trim().toLowerCase().startsWith('javascript:')) {
                var r2 = { type: 'javascript URL', detail: an + '="' + v2 + '"' };
                if (!Whitelisting.isReasonWhitelisted(r2, self.moduleKey)) {
                  LogManager.add(self.moduleKey, t, r2);
                  t.removeAttribute(an);
                  ProcessedElementsCache.markAsProcessed(t);
                }
              }
            }
          }
        });
        this.attributeObserver.observe(_document.documentElement, { attributes: true, subtree: true });
      }
    }
    onDisable() {
      super.onDisable();
      if (this.attributeObserver) {
        this.attributeObserver.disconnect();
        this.attributeObserver = null;
      }
    }
    _checkElement(el) {
      // 内嵌移除仅针对有实际内容的脚本: 无内容（空/未写）的脚本不处理,
      // 避免"先插后设src"的空脚本被当作内嵌脚本移除（此时日志键为空内容退化键, 加白无效）
      if (el.tagName === 'SCRIPT' && !el.src && el.textContent) return TAG_HANDLERS.SCRIPT.check(el, this.moduleKey, {
        type: '内嵌脚本移除',
        detail: '内容: ' + Utils.truncateString(el.textContent, CONFIG.LOG_DETAIL_LENGTH),
        elementContentIdentifier: Utils.getContentIdentifier(el),
      });
      return false;
    }
    sanitizeInlineEventAttributes(el) {
      if (!Utils.isElement(el) || ProcessedElementsCache.isProcessed(el)) return false;
      var mod = false;
      if (el.attributes) {
        for (var i = el.attributes.length - 1; i >= 0; i--) {
          var a = el.attributes[i];
          if (a.name.toLowerCase().startsWith('on') && typeof a.value === 'string' && a.value.trim() !== '') {
            var r = { type: '内联事件', detail: '属性: ' + a.name + '="' + a.value + '"' };
            if (!Whitelisting.isReasonWhitelisted(r, this.moduleKey)) {
              LogManager.add(this.moduleKey, el, r);
              el.removeAttribute(a.name);
              mod = true;
            }
          }
        }
      }
      var _moduleKey = this.moduleKey;
      ['href', 'src', 'action', 'data', 'formaction'].forEach(function (attr) {
        var v = el.getAttribute(attr);
        if (v && typeof v === 'string' && v.trim().toLowerCase().startsWith('javascript:')) {
          var r = { type: 'javascript URL', detail: attr + '="' + v + '"' };
          if (!Whitelisting.isReasonWhitelisted(r, _moduleKey)) {
            LogManager.add('removeInlineScripts', el, r);
            el.removeAttribute(attr);
            mod = true;
          }
        }
      });
      if (mod) ProcessedElementsCache.markAsProcessed(el);
      return mod;
    }
    updateStrictMode() {
      if (this.enabled) {
        this.onDisable();
        this.onEnable();
      }
    }
  }


  class RemoveExternalScriptsModule extends BaseModule {
    constructor() {
      super('removeExternalScripts');
    }
    onEnable() {
      var self = this;
      this._domObserverCallback = function (ms) {
        for (const m of ms) {
          if (m.type === 'childList') {
            for (const n of m.addedNodes) {
              if (n.nodeType === 1) {
                if (n.tagName === 'SCRIPT' && n.src) self.checkElement(n);
                if (n.querySelectorAll) Array.from(n.querySelectorAll('script[src]')).forEach(function (s) {
                  self.checkElement(s);
                });
              }
            }
          } else if (m.type === 'attributes' && m.attributeName === 'src') {
            var el = m.target;
            if (el.tagName === 'SCRIPT' && el.src) self.checkElement(el);
          }
        }
      };
      DomObserver.subscribe(this._domObserverCallback);
      Array.from(_document.querySelectorAll('script[src]')).forEach(function (s) {
        if (!ProcessedElementsCache.isProcessed(s)) {
          ScriptSyncGuard.interceptAndLog(s);
        }
      });
    }
    _checkElement(el) {
      if (el.tagName === 'SCRIPT' && el.src) {
        // 内容检查模式（高级设置→严格模式→「外联脚本」开）: 仅内容命中黑名单的外联脚本拦;
        // 已知坏缓存同步判, 未知的交静态检查管线异步取内容判定
        if (currentConfig.staticScriptContentCheck) {
          var _kStable2 = 'SCRIPT_SRC: ' + Utils.truncateString(_stableSrcKey(el.src), CONFIG.LOG_DETAIL_LENGTH);
          if (currentConfig.whitelist.has(_kStable2)) return false;   // 已知坏日记的加白键放行
          var _badKw2 = ScriptSyncGuard._ssccKnownBadKw(_kStable2, '');
          if (_badKw2) {
            return TAG_HANDLERS.SCRIPT.check(el, this.moduleKey, {
              type: '外联脚本移除(内容黑名单已知坏)',
              detail: (_badKw2 !== '1' ? '关键词: ' + _badKw2 + ' - ' : '') + 'SRC: ' + Utils.truncateString(el.src, CONFIG.LOG_DETAIL_LENGTH),
              elementContentIdentifier: _kStable2,
            });
          }
          ScriptSyncGuard._staticScriptContentCheck(el);
          return false;
        }
        return TAG_HANDLERS.SCRIPT.check(el, this.moduleKey, {
          type: '外联脚本移除',
          detail: 'SRC: ' + Utils.truncateString(el.src, CONFIG.LOG_DETAIL_LENGTH),
          elementContentIdentifier: Utils.externalScriptKey(el.src),
        });
      }
      return false;
    }
  }


  class ScriptBlacklistModeModule extends BaseModule {
    constructor() {
      super('scriptBlacklistMode');
      this.activeBlacklistSet = null;
      this.lastBlacklistHash = '';
      this._plainKeywords = [];
      this._blacklistRegex = null;
    }
    updateActiveBlacklistSet() {
      var h = Array.from(currentConfig.scriptBlacklist).sort().join('|') + '|' + currentConfig.builtinBlacklistEnabled + '|' + Array.from(currentConfig.removedBuiltinKeywords).sort().join('|');
      if (h !== this.lastBlacklistHash) {
        this.lastBlacklistHash = h;
        this.activeBlacklistSet = Utils.getActiveBlacklistSet();
        var keywords = Array.from(this.activeBlacklistSet).filter(function (k) {
          return k && k.length > 0;
        });
        if (keywords.length === 0) {
          this._plainKeywords = [];
          this._blacklistRegex = null;
        } else {
          var plainKeywords = [];
          var regexKeywords = [];
          var hasMetaChars = /[.*+?^${}()|[\]\\]/;
          for (var i = 0; i < keywords.length; i++) {
            if (hasMetaChars.test(keywords[i])) {
              regexKeywords.push(keywords[i]);
            } else {
              plainKeywords.push(keywords[i]);
            }
          }
          this._plainKeywords = plainKeywords;
          if (regexKeywords.length > 0) {
            var escaped = regexKeywords.map(function (k) {
              return k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            });
            try {
              this._blacklistRegex = new RegExp(escaped.join('|'), 'i');
            } catch (e) {
              this._blacklistRegex = null;
            }
          } else {
            this._blacklistRegex = null;
          }
        }
      }
    }
    rebuildBlacklist() {
      this.updateActiveBlacklistSet();
    }
    onEnable() {
      var self = this;
      this.updateActiveBlacklistSet();
      this._domObserverCallback = function (ms) {
        for (const m of ms) {
          for (const n of m.addedNodes) {
            if (n.nodeType === 1) {
              if (n.tagName === 'SCRIPT') self.checkElement(n);
              if (n.querySelectorAll) Array.from(n.querySelectorAll('script')).forEach(function (s) {
                self.checkElement(s);
              });
            }
          }
        }
      };
      DomObserver.subscribe(this._domObserverCallback);
      Array.from(_document.querySelectorAll('script')).forEach(function (s) {
        if (!ProcessedElementsCache.isProcessed(s)) {
          ScriptSyncGuard.interceptAndLog(s);
        }
      });
    }
    _checkElement(el) {
      if (el.tagName !== 'SCRIPT') return false;
      // 统一走 checkScriptSync 判定(与 appendChild/DomObserver 路径同一套检查):
      // 避免同一脚本被查 2~3 次、跨标签计数翻倍加速误杀, 且日志/中性化重复执行。
      var r = ScriptSyncGuard.checkScriptSync(el);
      if (r && r.blocked) {
        var _rCI = r.reason && r.reason.elementContentIdentifier;
        if (!(_rCI && LogManager.loggedContentIdentifiers.has(_rCI))) {
          LogManager.add(r.moduleKey || this.moduleKey, el, r.reason);
        }
        ResourceCanceller.cancelResourceLoading(el);
        ProcessedElementsCache.markAsProcessed(el);
        return true;
      }
      return false;
    }
  }


  class HTMLSanitizer {
    constructor(mk) {
      this.moduleKey = mk;
    }
    filterHTMLString(html) {
      if (typeof html !== 'string') return html;

      if (html.indexOf('<') === -1) return html;

      if (html.length < 30) return html;

      var _h = html;
      if (_h.indexOf('<script') === -1 && _h.indexOf('<SCRIPT') === -1 &&
          _h.indexOf('<iframe') === -1 && _h.indexOf('<IFRAME') === -1 &&
          _h.indexOf('<img') === -1 && _h.indexOf('<IMG') === -1 &&
          _h.indexOf('<link') === -1 && _h.indexOf('<LINK') === -1 &&
          _h.indexOf('<embed') === -1 && _h.indexOf('<EMBED') === -1 &&
          _h.indexOf('<object') === -1 && _h.indexOf('<OBJECT') === -1 &&
          _h.indexOf('<form') === -1 && _h.indexOf('<FORM') === -1 &&
          _h.indexOf('<base') === -1 && _h.indexOf('<BASE') === -1 &&
          _h.indexOf('<a ') === -1 && _h.indexOf('<A ') === -1 &&
          _h.indexOf('<a\t') === -1 && _h.indexOf('<A\t') === -1 &&
          _h.indexOf('<a\n') === -1 && _h.indexOf('<A\n') === -1 &&
          _h.indexOf('<a\r') === -1 && _h.indexOf('<A\r') === -1) return html;

      if (_h.indexOf('src=') === -1 && _h.indexOf("src'") === -1 && _h.indexOf('src"') === -1 &&
          _h.indexOf('href=') === -1 && _h.indexOf("href'") === -1 && _h.indexOf('href"') === -1 &&
          _h.indexOf('data=') === -1 && _h.indexOf('action=') === -1) return html;
      var qr = /<(?:script|link|img|iframe|embed|object|a|form|base)[^>]*(?:src|href|data|action)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/gi;
      var need = false;
      var m;
      while ((m = qr.exec(html)) !== null) {
        if (m[1] || m[2] || m[3]) {
          var u = m[1] || m[2] || m[3];
          if (u && shouldBlockResource(u)) {
            need = true;
            break;
          }
        }
      }
      if (!need) return html;
      try {
        var doc = new _globals.DOMParser().parseFromString(html, 'text/html');
        var self = this;
        Array.from(doc.querySelectorAll('script,link,img,iframe,embed,object,a,form,base')).forEach(function (el) {
          var t = el.tagName.toLowerCase();
          var a;
          if (['script', 'img', 'iframe', 'embed'].indexOf(t) !== -1) a = 'src';
          else if (['link', 'a', 'base'].indexOf(t) !== -1) a = 'href';
          else if (t === 'object') a = 'data';
          else if (t === 'form') a = 'action';
          if (!a) return;
          var u = el.getAttribute(a);
          if (!u) return;
          if (t === 'link') {
            var r = el.getAttribute('rel');
            if (!r || !r.includes('stylesheet')) return;
          }
          if (shouldBlockResource(u)) {
            // HTML 注入消毒日志用 THIRD_PARTY_URL 键(与 shouldBlockResource 同公式), 可加白
            var _injAbs = u;
            try { _injAbs = new _URL(u, _location.href).href; } catch(e) {}
            LogManager.add(self.moduleKey, null, {
              type: 'THIRD_PARTY_HTML_INJECTION',
              detail: '阻止: ' + t.toUpperCase() + ' ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH),
              elementContentIdentifier: 'THIRD_PARTY_URL: ' + Utils.truncateString(_injAbs, CONFIG.LOG_DETAIL_LENGTH)
            });
            if (t === 'img') {
              el.setAttribute(a, TRANSPARENT_PIXEL);
              el.removeAttribute('srcset');
              el.removeAttribute('data-src');
            } else if (t === 'form') el.removeAttribute(a);
            else el.remove();
          }
        });
        return doc.body.innerHTML;
      } catch (e) {
        return html;
      }
    }
  }


  class NetworkInterceptor {
    constructor(mk) {
      this.moduleKey = mk;
      this.restoredFns = [];
    }
    setupNetworkInterception() {
      var self = this;
      try {
        var origFetch = _fetch; _globals.fetch = new _Proxy(_fetch, {
          apply: function (t, ta, a) {
            try {
              var u = typeof a[0] === 'string' ? a[0] : (a[0] && a[0].url) ? a[0].url : undefined;
              if (u && typeof u === 'string') {
                try {
                  u = new _URL(u, _location.href).href;
                } catch (urlErr) { }
              }
              if (u && shouldBlockResource(u)) {
                LogManager.add(self.moduleKey, null, {
                  type: 'THIRD_PARTY',
                  detail: 'FETCH: ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH)
                });
                return Promise.resolve(new Response('', { status: 200, statusText: 'Blocked by AdBlocker', headers: { 'X-AdBlock-Blocked': 'true' } }));
              }
            } catch (innerErr) { }
            return Reflect.apply(t, ta, a);
          },
        });
        this.restoredFns.push(function () {
          try {
            _globals.fetch = origFetch;
          } catch(e) { _debugCatch(e, "this.restoredFns.push(fun"); }
        });
      } catch(e) { _debugCatch(e, "origFetch"); }
      try {
        var oo = _XMLHttpRequest.prototype.open;
        var os = _XMLHttpRequest.prototype.send;
        _XMLHttpRequest.prototype.open = new _Proxy(oo, {
          apply: function (t, ta, a) {
            if (a[1] && shouldBlockResource(a[1])) {
              LogManager.add(self.moduleKey, null, {
                type: 'THIRD_PARTY',
                detail: 'XHR: ' + Utils.truncateString(a[1], CONFIG.LOG_DETAIL_LENGTH)
              });
              _xhrBlockState.set(ta, { blocked: true, url: a[1], async: a[2] !== false });
              try {
                Reflect.apply(t, ta, [a[0] || 'GET', 'about:blank', a[2] !== false]);
              } catch(e) { _debugCatch(e, "blocked"); }
              // 假完成事件在 send 代理单点触发; open 代理仅记录拦截状态并打开 about:blank 占位
              return;
            }
            _xhrBlockState.delete(ta);
            return Reflect.apply(t, ta, a);
          },
        });
        _XMLHttpRequest.prototype.send = new _Proxy(os, {
          apply: function (t, ta, a) {
            var state = _xhrBlockState.get(ta);
            if (state && state.blocked) {
              _xhrBlockState.delete(ta);
              var _fireFake = function () {
                try {
                  Object.defineProperty(ta, 'readyState', { value: 4, writable: false, configurable: true });
                  Object.defineProperty(ta, 'status', { value: 200, writable: false, configurable: true });
                  Object.defineProperty(ta, 'statusText', { value: 'OK', writable: false, configurable: true });
                  Object.defineProperty(ta, 'responseText', { value: '', writable: false, configurable: true });
                  Object.defineProperty(ta, 'response', { value: '', writable: false, configurable: true });
                  if (typeof ta.onreadystatechange === 'function') ta.onreadystatechange();
                  if (typeof ta.onload === 'function') ta.onload();
                  if (typeof ta.addEventListener === 'function') {
                    var evt = { type: 'load', target: ta, currentTarget: ta };
                    ta.dispatchEvent(evt);
                  }
                } catch(e) { _debugCatch(e, "type"); }
              };
              // 同步模式(send 返回前页面就会读取状态): 假完成事件同步触发, 异步模式走定时器
              if (state.async === false) { try { _fireFake(); } catch(e) {} }
              else _setTimeout(_fireFake, 0);
              return;
            }
            return Reflect.apply(t, ta, a);
          },
        });
        this.restoredFns.push(function () {
          try {
            _XMLHttpRequest.prototype.open = oo;
          } catch(e) { _debugCatch(e, "this.restoredFns.push(fun"); }
          try {
            _XMLHttpRequest.prototype.send = os;
          } catch(e) { _debugCatch(e, "_XMLHttpRequest.prototype"); }
        });
      } catch(e) { _debugCatch(e, "});"); }
    }
    stopInterception() {
      this.restoredFns.forEach(function (fn) {
        try {
          fn();
        } catch(e) { _debugCatch(e, "重装恢复函数遍历失败"); }
      });
      this.restoredFns = [];
    }
  }


  class ImageInterceptor {
    constructor(mk) {
      this.moduleKey = mk;
      this.originalImage = null;
      this.trackingPatterns = [
        /pixel/i, /beacon/i, /track/i, /analytics/i, /__utm/i, /gtag/i,
        /\bga\.(?:js|gif|png)\b/i, /ping/i, /\/collect\b/i, /\/stat(istic)?s?\b/i,
        /\/log(ger)?\b/i, /\/metric(s)?\b/i, /\/monitor(ing)?\b/i, /\/report(ing)?\b/i,
        /\/hit(s)?\b/i, /\/event(s)?\b/i, /\/counter\b/i, /\/pageview\b/i, /\/activity\b/i,
        /\/telemetry\b/i, /\/rum\b/i, /\/error_report/i, /\/imp(ression)?s?\b/i,
        /\/click(s|track)?\b/i, /\/conv(ersion)?s?\b/i, /\/ref(erral)?(s)?\b/i,
        /\b(?:1x1|spacer|blank|px)\.(?:gif|png|jpe?g)\b/i,
        /\b(?:tr|trk|ct)\.(?:gif|png|jpe?g)\b/i, /\btag\.(?:js|gif|png)\b/i,
        /\.(?:gif|png|jpe?g)\?.*(?:id|uid|sid|pid|session|visitor|ref|source|campaign)=/i,
        /[?&](?:utm_source|utm_medium|utm_campaign|utm_term|utm_content)=/i,
        /[?&](?:gclid|fbclid|msclkid|dclid|mc_eid)=/i,
        /[?&](?:ref|source|medium|campaign|aff_id|click_id|sid|track_id|tid)=/i,
        /[?&]tid=UA-/i, /[?&]tid=G-/i, /[?&]callback=/i,
        /\bfingerprint/i, /\bclient_id/i,
      ];
    }
    init() {
      var self = this;
      try {
        this.originalImage = _globals.Image;
        var OriginalImage = this.originalImage;
        var trackingPatterns = this.trackingPatterns;
        var compiledTrackingRegex = (function() {
          try {
            return new RegExp(trackingPatterns.map(p => `(?:${p.source})`).join('|'), 'i');
          } catch(e) {
            return null;
          }
        })();
        var isTrackingPixel = function (src) {
          if (!src || typeof src !== 'string') return false;
          return compiledTrackingRegex ? compiledTrackingRegex.test(src) : false;
        };
        var WrappedImage = function () {
          var img;
          if (arguments.length === 2) img = new OriginalImage(arguments[0], arguments[1]);
          else if (arguments.length === 1) img = new OriginalImage(arguments[0]);
          else img = new OriginalImage();
          var srcDescriptor = Object.getOwnPropertyDescriptor(OriginalImage.prototype, 'src');
          if (srcDescriptor && srcDescriptor.set) {
            var originalSrcSet = srcDescriptor.set;
            Object.defineProperty(img, 'src', {
              get: function () {
                return srcDescriptor.get.call(this);
              },
              set: function (v) {
                if (v && typeof v === 'string') {
                  if (isTrackingPixel(v) || shouldBlockResource(v)) {
                    LogManager.add(self.moduleKey, null, {
                      type: 'TRACKING_PIXEL',
                      detail: '拦截追踪像素: ' + Utils.truncateString(v, CONFIG.LOG_DETAIL_LENGTH)
                    });
                    return originalSrcSet.call(this, TRANSPARENT_PIXEL);
                  }
                }
                return originalSrcSet.call(this, v);
              },
              configurable: true,
              enumerable: true,
            });
          }
          return img;
        };
        WrappedImage.prototype = OriginalImage.prototype;
        _globals.Image = WrappedImage;
      } catch(e) { _debugCatch(e, "WrappedImage.prototype"); }
    }
    stop() {
      if (this.originalImage) {
        try {
          _globals.Image = this.originalImage;
        } catch(e) { _debugCatch(e, "this.originalImage"); }
        this.originalImage = null;
      }
    }
  }


  class DOMPrototypeHooker {
    constructor(mk, hs) {
      this.moduleKey = mk;
      this.htmlSanitizer = hs;
      this.restoredFns = [];
      this.observer = null;
      this._applyingElements = new WeakSet();
      this._overlayCheckEnabled = false;
    }
    enableOverlayCheck() {
      this._overlayCheckEnabled = true;
    }
    disableOverlayCheck() {
      this._overlayCheckEnabled = false;
    }
    setupProxyInterception() {
      var self = this;
      var lc = function (el, attr, url, tag) {
        LogManager.add(self.moduleKey, el, {
          type: 'THIRD_PARTY',
          detail: tag + ': ' + Utils.truncateString(url, CONFIG.LOG_DETAIL_LENGTH)
        });
        ResourceCanceller.cancelResourceLoading(el);
        ProcessedElementsCache.markAsProcessed(el);
      };

      try {
        var osa = _Element.prototype.setAttribute;
        _Element.prototype.setAttribute = new _Proxy(osa, {
          apply: function (t, ta, a) {
            if (self._applyingElements.has(ta)) {
              return Reflect.apply(t, ta, a);
            }
            if (ProcessedElementsCache.isProcessed(ta)) {
              return Reflect.apply(t, ta, a);
            }
            var handler = TAG_HANDLERS[ta.tagName];
            if (handler && shouldBlockResource(a[1])) {
              var attrName = a[0] && typeof a[0] === 'string' ? a[0].toLowerCase() : a[0];
              if ((handler.srcAttr && handler.srcAttr === attrName) || (handler.dataSrcAttr && handler.dataSrcAttr === attrName)) {
                lc(ta, a[0], a[1], ta.tagName);
                return;
              }
            }

            if (ta.tagName === 'SCRIPT') {
              attrName = (a[0] && typeof a[0] === 'string') ? a[0].toLowerCase() : '';
              var attrValue = a[1];

              var syncResult = ScriptSyncGuard.checkScriptSync(ta);
              if (syncResult && syncResult.blocked) {
                ScriptSyncGuard.neutralizeScript(ta);
                LogManager.add(syncResult.moduleKey, ta, syncResult.reason);
                return;
              }

              if (attrName === 'src' && attrValue && typeof attrValue === 'string') {
                var pendingResult = ScriptSyncGuard.checkPendingSrc(ta, attrValue);
                if (pendingResult && pendingResult.blocked) {
                  ScriptSyncGuard.neutralizeScript(ta);
                  LogManager.add(pendingResult.moduleKey, ta, pendingResult.reason);
                  return;
                }
              }

              if (attrName === 'type' && attrValue) {
                var activatingTypes = ACTIVATING_TYPES;
                var currentType = (ta.getAttribute('type') || '').toLowerCase().trim();
                var newType = (attrValue + '').toLowerCase().trim();
                var wasInactive = currentType && activatingTypes.indexOf(currentType) === -1;
                var isActivating = activatingTypes.indexOf(newType) !== -1;
                if (wasInactive && isActivating) {
                  var recheckResult = ScriptSyncGuard.checkScriptSync(ta);
                  if (recheckResult && recheckResult.blocked) {
                    ScriptSyncGuard.neutralizeScript(ta);
                    LogManager.add(recheckResult.moduleKey, ta, recheckResult.reason);
                    return;
                  }
                }
              }
            }
            self._applyingElements.add(ta);
            try {
              return Reflect.apply(t, ta, a);
            } finally {
              self._applyingElements.delete(ta);
            }
          },
        });
        this.restoredFns.push(function () {
          try {
            _Element.prototype.setAttribute = osa;
          } catch(e) { _debugCatch(e, "this.restoredFns.push(fun"); }
        });
      } catch(e) { _debugCatch(e, "});"); }
      Object.keys(TAG_HANDLERS).forEach(function(tag) {
        var proto = TAG_PROTO_MAP[tag] || undefined;
        if (!proto) return;
        var sa = TAG_HANDLERS[tag].srcAttr;
        try {
          var desc = Object.getOwnPropertyDescriptor(proto, sa);
          if (desc && desc.set && desc.configurable !== false) {
            var os = desc.set;
            Object.defineProperty(proto, sa, {
              set: new _Proxy(os, {
                apply: function (t, ta, a) {
                  if (self._applyingElements.has(ta)) {
                    return Reflect.apply(t, ta, a);
                  }
                  if (ProcessedElementsCache.isProcessed(ta)) {
                    return Reflect.apply(t, ta, a);
                  }

                  if (ta.tagName === 'SCRIPT') {
                    var syncResult2 = ScriptSyncGuard.checkScriptSync(ta);
                    if (syncResult2 && syncResult2.blocked) {
                      ScriptSyncGuard.neutralizeScript(ta);
                      LogManager.add(syncResult2.moduleKey, ta, syncResult2.reason);
                      return;
                    }

                    if (a[0] && typeof a[0] === 'string') {
                      var pendingResult2 = ScriptSyncGuard.checkPendingSrc(ta, a[0]);
                      if (pendingResult2 && pendingResult2.blocked) {
                        ScriptSyncGuard.neutralizeScript(ta);
                        LogManager.add(pendingResult2.moduleKey, ta, pendingResult2.reason);
                        return;
                      }
                    }
                  }
                  if (shouldBlockResource(a[0])) {
                    lc(ta, sa, a[0], tag);
                    return;
                  }

                  if (currentConfig.modules.blockDynamicScripts && ta.tagName === 'SCRIPT' && DynamicScriptInterceptor.shouldBlockScriptElement(ta, false)) {
                    lc(ta, sa, a[0], tag);
                    return;
                  }
                  self._applyingElements.add(ta);
                  try {
                    return Reflect.apply(t, ta, a);
                  } finally {
                    self._applyingElements.delete(ta);
                  }
                },
              }),
              get: desc.get,
              configurable: true,
              enumerable: desc.enumerable !== undefined ? desc.enumerable : true,
            });
            self.restoredFns.push((function (p, prop, d) {
       return function () {
                try {
                  Object.defineProperty(p, prop, d);
                } catch(e) { _debugCatch(e, "Object.defineProperty(p"); }
              };
            })(proto, sa, desc));
          }
        } catch(e) { _debugCatch(e, "desc))"); }
      });
      // ==================== 劫持 HTMLScriptElement.type setter ====================
      // 【功能】脚本 type 属性写入时拦截：广告脚本常把 type 从 text/plain 改回可执行类型复活。
      // 【机制】写入值若属于"可激活类型"(ACTIVATING_TYPES)且脚本已被标记拦截 → 阻止改写；同时复查脚本内容。

      try {
        var scriptProto = TAG_PROTO_MAP['SCRIPT'];
        if (scriptProto) {
          var typeDesc = Object.getOwnPropertyDescriptor(scriptProto, 'type');
          if (typeDesc && typeDesc.set && typeDesc.configurable !== false) {
            var origTypeSet = typeDesc.set;

            var _c = true;
            try { _c = RedirectBlocker._compat(); } catch(e) {}
            this._descriptorSaved = this._descriptorSaved || [];
            this._descriptorSaved.push({ obj: scriptProto, prop: 'type', desc: typeDesc });

            var activatingTypes = ACTIVATING_TYPES;
            Object.defineProperty(scriptProto, 'type', {
              get: typeDesc.get,
              set: function(v) {
                var currentType = (this.getAttribute('type') || '').toLowerCase().trim();
                var newType = (v || '').toLowerCase().trim();
                var isActivating = activatingTypes.indexOf(newType) !== -1;
                var wasInactive = currentType && activatingTypes.indexOf(currentType) === -1;
                if (wasInactive && isActivating) {

                  var src = this.src || '';
                  var content = this.textContent || '';
                  if (src && typeof shouldBlockResource === 'function' && shouldBlockResource(src)) {
                    LogManager.add('interceptThirdParty', this, {
                      type: 'SCRIPT_TYPE_ACTIVATION',
                      detail: 'type激活(第三方): ' + Utils.truncateString(src, CONFIG.LOG_DETAIL_LENGTH)
                    });
                    return;
                  }
                  if (content && currentConfig.modules.blockDynamicScripts &&
                      typeof DynamicScriptInterceptor.shouldBlockScriptElement === 'function') {
                    if (DynamicScriptInterceptor.shouldBlockScriptElement(this, true)) {
                      return;
                    }
                  }
                }
                return origTypeSet.call(this, v);
              },
              configurable: _c,
              enumerable: true
            });
            this.restoredFns.push((function(p, d) {
              return function() {
                try { Object.defineProperty(p, 'type', d); } catch(e) {}
              };
            })(scriptProto, typeDesc));
          }
        }
      } catch(e) { _debugCatch(e, "typeDesc))"); }
    }
    setupHTMLInterception() {
      var self = this;
      try {
        var ihd = Object.getOwnPropertyDescriptor(_Element.prototype, 'innerHTML');
        if (ihd && ihd.set) {
          var os = ihd.set;
          Object.defineProperty(_Element.prototype, 'innerHTML', {
            set: function (v) {
              return os.call(this, self.htmlSanitizer.filterHTMLString(v));
            },
            get: ihd.get,
            configurable: true,
            enumerable: true
          });
          this.restoredFns.push(function () {
            try {
              Object.defineProperty(_Element.prototype, 'innerHTML', ihd);
            } catch(e) { _debugCatch(e, "this.restoredFns.push(fun"); }
          });
        }
      } catch(e) { _debugCatch(e, "}"); }
      try {
        var oi = _Element.prototype.insertAdjacentHTML;
        _Element.prototype.insertAdjacentHTML = new _Proxy(oi, {
          apply: function (t, ta, a) {
            return Reflect.apply(t, ta, [a[0], self.htmlSanitizer.filterHTMLString(a[1])]);
          }
        });
        this.restoredFns.push(function () {
          try {
            _Element.prototype.insertAdjacentHTML = oi;
          } catch(e) { _debugCatch(e, "this.restoredFns.push(fun"); }
        });
      } catch(e) { _debugCatch(e, "});"); }
    }
    patchAttachShadow() {
      var self = this;
      var proto = _Element.prototype;
      try {
        if (proto.attachShadow && !proto._adblockOriginalAttachShadow) {
          proto._adblockOriginalAttachShadow = proto.attachShadow;
          proto.attachShadow = function (init) {
            var shadow = proto._adblockOriginalAttachShadow.call(this, init);
            self.observeShadowRoot(shadow);
            var ihd = Object.getOwnPropertyDescriptor(shadow, 'innerHTML');
            if (ihd && ihd.set && ihd.configurable) {
              Object.defineProperty(shadow, 'innerHTML', {
                get: typeof ihd.get === 'function' ? function () {
                  return ihd.get.call(this);
                } : undefined,
                set: function (v) {
                  ihd.set.call(this, self.htmlSanitizer.filterHTMLString(v));
                },
                configurable: true,
              });
            }
            return shadow;
          };
          this.restoredFns.push(function () {
            if (proto._adblockOriginalAttachShadow) {
              proto.attachShadow = proto._adblockOriginalAttachShadow;
              delete proto._adblockOriginalAttachShadow;
            }
          });
        }
      } catch(e) { _debugCatch(e, "}"); }
    }
    observeShadowRoot(sr) {
      if (!sr || sr._adblockObserved) return;
      sr._adblockObserved = true;
      var self = this;
      var obs = new _MutationObserver(function (ms) {
        if (!currentConfig.modules.interceptThirdParty && !currentConfig.modules.blockDynamicScripts) return;
        for (const m of ms) {
          for (const n of m.addedNodes) {
            if (n.nodeType !== 1) continue;
            if (ProcessedElementsCache.isProcessed(n)) continue;
            var t = n.tagName;
            if (currentConfig.modules.interceptThirdParty && TAG_HANDLERS[t]) {
              var h = TAG_HANDLERS[t];
              var u = n[h.srcAttr] || n.getAttribute(h.srcAttr) || (h.dataSrcAttr && n.getAttribute(h.dataSrcAttr));
              if (u && shouldBlockResource(u)) {
                LogManager.add(self.moduleKey, n, {
                  type: 'THIRD_PARTY',
                  detail: 'Shadow DOM ' + t + ': ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH)
                });
                ResourceCanceller.cancelResourceLoading(n);
                ProcessedElementsCache.markAsProcessed(n);
              }
            }
            if (n.shadowRoot && currentConfig.modules.interceptThirdParty) self.observeShadowRoot(n.shadowRoot);
            if (currentConfig.modules.blockDynamicScripts && t === 'SCRIPT' && DynamicScriptInterceptor.shouldBlockScriptElement(n, false)) {
              LogManager.add(self.moduleKey, n, {
                type: 'THIRD_PARTY',
                detail: '动态脚本内容检查拦截: ' + Utils.truncateString(n.textContent || n.src, CONFIG.LOG_DETAIL_LENGTH),
              });
              ResourceCanceller.cancelResourceLoading(n);
              ProcessedElementsCache.markAsProcessed(n);
            }
          }
        }
      });
      obs.observe(sr, { childList: true, subtree: true });
      this.restoredFns.push(function () {
        obs.disconnect();
        delete sr._adblockObserved;
      });
    }
    stopInterception() {
      this.restoredFns.forEach(function (fn) {
        try {
          fn();
        } catch(e) { _debugCatch(e, "重装恢复函数遍历失败"); }
      });
      this.restoredFns = [];
      if (this.observer) {
        this.observer.disconnect();
        this.observer = null;
      }
    }
  }


  class ThirdPartyInterceptionModule extends BaseModule {
    constructor() {
      super('interceptThirdParty');
      this.htmlSanitizer = new HTMLSanitizer(this.moduleKey);
      this.networkInterceptor = new NetworkInterceptor(this.moduleKey);
      this.domHooker = new DOMPrototypeHooker(this.moduleKey, this.htmlSanitizer);
      this.imageInterceptor = new ImageInterceptor(this.moduleKey);
    }
    onEnable() {
      this.stopInterception();
      this.domHooker.setupProxyInterception();
      this.networkInterceptor.setupNetworkInterception();
      this.setupMutationFallback();
      this.domHooker.setupHTMLInterception();
      this.domHooker.patchAttachShadow();
      this.scanExistingShadowRoots();
      this.imageInterceptor.init();
      this._syncFunnelHook();
    }
    onDisable() {
      this.stopInterception();
      this.imageInterceptor.stop();
      this._syncFunnelHook();
    }
    // 写入通道清洗器（漏斗）: 开启时把 document.write/writeln 的内容经与 innerHTML
    // 清洗器同源的判定过一遍 —— 剥离其中 src 指向第三方的资源节点(script/img/
    // iframe/embed/link), 站内余量照常写出; 全部剥空才整段阻断。被剥离节点走
    // THIRD_PARTY_HTML_INJECTION 日志 + THIRD_PARTY_URL 加白键, 加白后内容完整写出、
    // 内容完整写出。仅作用于解析期(readyState=loading), 加载完成后的写入由
    // 跳转拦截的 write 钩子按既有规则阻断, 两者不重叠。
    _syncFunnelHook() {
      var want = this.enabled && currentConfig.modules.interceptThirdParty && currentConfig.funnelStrictMode;
      if (want && !this._funnelWriteHook) {
        var self = this;
        this._funnelWriteHook = function (args, type) {
          try {
            if (!currentConfig.modules.interceptThirdParty || !currentConfig.funnelStrictMode) return;
            if (_document.readyState !== 'loading') return;
            try { if (RedirectBlocker._isPageReleased()) return; } catch (e) {}
            var c = Array.prototype.join.call(args, '');
            if (typeof c !== 'string' || c.length < 30 || c.indexOf('<') === -1) return;
            var cleaned = self.htmlSanitizer.filterHTMLString(c);
            if (cleaned !== c) {
              if (!cleaned || !cleaned.replace(/\s/g, '')) return false;
              try { WriteHookManager.originalWrite.apply(_document, [cleaned]); } catch (e2) { return false; }
              return false;
            }
          } catch (e) { _debugCatch(e, "funnelWrite"); }
        };
        WriteHookManager.addHook(this._funnelWriteHook);
      } else if (!want && this._funnelWriteHook) {
        try { WriteHookManager.removeHook(this._funnelWriteHook); } catch (e) {}
        this._funnelWriteHook = null;
      }
    }
    stopInterception() {

      var overlayWasActive = this.domHooker._overlayCheckEnabled &&
                             OverlayInterceptor._enabled &&
                             currentConfig.modules.overlayIntercept;
      this.networkInterceptor.stopInterception();
      this.domHooker.stopInterception();
      if (this._domObserverCallback) {
        DomObserver.unsubscribe(this._domObserverCallback);
        this._domObserverCallback = null;
      }
      this.domHooker._overlayCheckEnabled = false;

      if (overlayWasActive) {
        this.domHooker.enableOverlayCheck();
      }
    }
    scanExistingShadowRoots() {
      var self = this;
      var twEl = _document.createTreeWalker(_document.documentElement, 1, null, false);
      while (twEl.nextNode()) {
        var el = twEl.currentNode;
        if (el.shadowRoot && !el.shadowRoot._adblockObserved) {
          self.domHooker.observeShadowRoot(el.shadowRoot);
        }
      }
    }
    setupMutationFallback() {
      var self = this;
      this._domObserverCallback = function (ms) {
        for (const m of ms) {

          if (m.type === 'attributes') {
            var attrEl = m.target;
            if (!_isElementLike(attrEl) || ProcessedElementsCache.isProcessed(attrEl)) continue;

            if (m.attributeName === 'type' && attrEl.tagName === 'SCRIPT') {
              var currentType = (attrEl.getAttribute('type') || '').toLowerCase().trim();
              var activatingTypes = ACTIVATING_TYPES;
              if (activatingTypes.indexOf(currentType) !== -1) {
                if (attrEl.src && shouldBlockResource(attrEl.src)) {
                  LogManager.add(self.moduleKey, attrEl, {
                    type: 'THIRD_PARTY',
                    detail: 'SCRIPT_TYPE_ACTIVATION: ' + Utils.truncateString(attrEl.src, CONFIG.LOG_DETAIL_LENGTH)
                  });
                  ResourceCanceller.cancelResourceLoading(attrEl);
                  ProcessedElementsCache.markAsProcessed(attrEl);
                } else if (attrEl.textContent && currentConfig.modules.blockDynamicScripts) {
                  DynamicScriptInterceptor.shouldBlockScriptElement(attrEl, false);
                }
              }
            }

            if ((m.attributeName === 'rel' || m.attributeName === 'href') && attrEl.tagName === 'LINK') {
              TAG_HANDLERS.LINK.check(attrEl, self.moduleKey);
            }

            if (m.attributeName === 'src' && TAG_HANDLERS[attrEl.tagName]) {
              TAG_HANDLERS[attrEl.tagName].check(attrEl, self.moduleKey);
            }
            continue;
          }

          for (const n of m.addedNodes) {
            if (n.nodeType !== 1) continue;
            if (ProcessedElementsCache.isProcessed(n)) continue;

            if (n.tagName === 'SCRIPT') {
              var syncResult3 = ScriptSyncGuard.interceptAndLog(n);
              if (syncResult3) continue;
            }
            var t = n.tagName;
            if (TAG_HANDLERS[t]) {
              var h = TAG_HANDLERS[t];
              var u = n[h.srcAttr] || n.getAttribute(h.srcAttr) || (h.dataSrcAttr && n.getAttribute(h.dataSrcAttr));
              if (u && shouldBlockResource(u)) {
                LogManager.add(self.moduleKey, n, {
                  type: 'THIRD_PARTY',
                  detail: t + ': ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH)
                });
                ResourceCanceller.cancelResourceLoading(n);
                ProcessedElementsCache.markAsProcessed(n);
              }
            }

            // 容器内 iframe 的第三方检查: innerHTML/document.write 一次性插入时,
            // MO 的 addedNodes 只含容器(iframe 在子树内不会单独触发检查),
            // 这里补查新插入容器内已有的 iframe[src], 与独立插入路径共用同一条判定
            if (t !== 'SCRIPT' && t !== 'IFRAME' && n.querySelectorAll) {
              var _ifrList = n.querySelectorAll('iframe[src]');
              for (var _ifrI = 0; _ifrI < _ifrList.length; _ifrI++) {
                var _ifrEl = _ifrList[_ifrI];
                if (ProcessedElementsCache.isProcessed(_ifrEl)) continue;
                var _ifrU = _ifrEl.src || _ifrEl.getAttribute('src');
                if (_ifrU && shouldBlockResource(_ifrU)) {
                  LogManager.add(self.moduleKey, _ifrEl, {
                    type: 'THIRD_PARTY',
                    detail: 'IFRAME: ' + Utils.truncateString(_ifrU, CONFIG.LOG_DETAIL_LENGTH)
                  });
                  ResourceCanceller.cancelResourceLoading(_ifrEl);
                  ProcessedElementsCache.markAsProcessed(_ifrEl);
                }
              }
            }

            if (t === 'SCRIPT' && !ProcessedElementsCache.isProcessed(n)) {
              var isModule = (n.getAttribute('type') || '').toLowerCase() === 'module';
              var isAsync = n.hasAttribute('async');
              if ((isModule || isAsync) && n.src && shouldBlockResource(n.src)) {
                LogManager.add(self.moduleKey, n, {
                  type: 'THIRD_PARTY',
                  detail: (isModule ? 'MODULE_SCRIPT' : 'ASYNC_SCRIPT') + ': ' + Utils.truncateString(n.src, CONFIG.LOG_DETAIL_LENGTH)
                });
                ResourceCanceller.cancelResourceLoading(n);
                ProcessedElementsCache.markAsProcessed(n);
              }
            }

            if (t === 'LINK' && !ProcessedElementsCache.isProcessed(n)) {
              var linkRel = (n.getAttribute('rel') || '').toLowerCase();
              var blockedRels = ['preload', 'modulepreload', 'prefetch', 'prerender',
                                 'preconnect', 'dns-prefetch'];
              if (blockedRels.indexOf(linkRel) !== -1) {
                var linkHref = n.getAttribute('href');
                if (linkHref && shouldBlockResource(linkHref)) {
                  LogManager.add(self.moduleKey, n, {
                    type: 'RESOURCE_HINT',
                    detail: 'LINK_' + linkRel.toUpperCase() + ': ' + Utils.truncateString(linkHref, CONFIG.LOG_DETAIL_LENGTH)
                  });
                  n.remove();
                  ProcessedElementsCache.markAsProcessed(n);
                }
              }
            }

            if (currentConfig.modules.blockDynamicScripts && t === 'SCRIPT' && DynamicScriptInterceptor.shouldBlockScriptElement(n, false)) {
              LogManager.add(self.moduleKey, n, {
                type: 'BLOCK_DYNAMIC_SCRIPT',
                detail: '动态脚本: ' + Utils.truncateString(n.textContent || n.src || '', CONFIG.LOG_DETAIL_LENGTH)
              });
              ResourceCanceller.cancelResourceLoading(n);
              ProcessedElementsCache.markAsProcessed(n);
            }
            if (n.shadowRoot) self.domHooker.observeShadowRoot(n.shadowRoot);
          }
        }
      };
      DomObserver.subscribe(this._domObserverCallback);
    }
    updateStrictMode() {
      urlCache.clear();
    }
    updateStrictMethod() {
      if (this.enabled) {
        this.onDisable();
        this.onEnable();
      }
    }
    _checkElement(el) {
      var t = el.tagName;
      if (!TAG_HANDLERS[t]) return false;
      var h = TAG_HANDLERS[t];
      var u = el[h.srcAttr] || el.getAttribute(h.srcAttr) || (h.dataSrcAttr && el.getAttribute(h.dataSrcAttr));
      if (u && shouldBlockResource(u)) {
        LogManager.add(this.moduleKey, el, {
          type: 'THIRD_PARTY',
          detail: t + ': ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH)
        });
        ResourceCanceller.cancelResourceLoading(el);
        ProcessedElementsCache.markAsProcessed(el);
        return true;
      }
      return false;
    }
  }

  // ======================== CSP 管理模块 ========================
    // 可选 CSP 规则注入（默认关闭），用于封锁外部脚本/样式/图片等。
  const CSPModule = {
    init: function () {
      if (currentConfig.modules.manageCSP) this.applyCSP();
    },
    applyCSP: function () {
      // 注入页面 CSP meta（默认关闭）：script-src/style-src/img-src 等规则模板可单独启用。
      if (!currentConfig.modules.manageCSP) return;
      var ex = _document.querySelector('meta[http-equiv="Content-Security-Policy"]');
      if (ex) ex.remove();
      var er = currentConfig.cspRules.filter(function (r) {
        return r.enabled;
      });
      if (er.length === 0) return;
      var dirs = {};
      for (const r of er) {
        var p = r.rule.split(/\s+/);
        var d = p[0];
        var v = p.slice(1);
        if (!dirs[d]) dirs[d] = new _Set();
        v.forEach(function (x) {
          dirs[d].add(x);
        });
      }
      var ps = '';
      for (var d2 in dirs) {
        if (dirs.hasOwnProperty(d2)) ps += d2 + ' ' + Array.from(dirs[d2]).join(' ') + '; ';
      }
      ps = ps.trim();
      if (!ps) return;
      var inject = function () {
        if (_document.head) {
          if (!_document.querySelector('meta[http-equiv="Content-Security-Policy"]')) {
            var m = _document.createElement('meta');
            m.httpEquiv = 'Content-Security-Policy';
            m.content = ps;
            _document.head.appendChild(m);
          }
        } else {
          new _MutationObserver(function () {
            this.disconnect();
            if (_document.head) {
              if (!_document.querySelector('meta[http-equiv="Content-Security-Policy"]')) {
                var m2 = _document.createElement('meta');
                m2.httpEquiv = 'Content-Security-Policy';
                m2.content = ps;
                _document.head.appendChild(m2);
              }
            }
          }).observe(_document.documentElement || _document, { childList: true, subtree: true });
        }
      };
      inject();
    },
    updateRule: function (id, enabled) {
      var r = currentConfig.cspRules.find(function (x) {
        return x.id === id;
      });
      if (r) r.enabled = enabled;
    },
  };

  // ======================== UI 样式定义 ========================
    // 面板 UI_CSS：shadow DOM 内样式（.mask 全屏遮罩 pointer-events:auto，可点击关闭）。
  const UI_CSS = `
    :host {
      --ab-z-index: ${2147483640};
    }
    .mask {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100% !important;
      height: 100% !important;
      background: rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(8px);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.3s ease;
      pointer-events: auto;
      animation: fade-in 0.3s forwards;
    }
    .panel {
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      padding: 16px 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      width: 94vw;
      max-width: 500px;
      font-family: system-ui, -apple-system, sans-serif;
      box-sizing: border-box;
      position: relative;
      animation: scale-in 0.3s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
      max-height: 85vh;
      overflow-y: auto;
      font-size: 14px;
      line-height: 1.4;
    }
    .title {
      margin: 0 0 6px 0;
      font-size: 16px;
      font-weight: 700;
      color: #1a1a1a;
      text-align: center;
      word-break: break-all;
      line-height: 1.3;
      padding: 0 8px;
    }
    .btn-group {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 4px;
    }
    .btn-group button {
      flex: 1 0 calc(50% - 8px);
      min-width: 100px;
    }
    button {
      border: none;
      border-radius: 10px;
      padding: 10px 8px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      transition: all 0.2s;
      background: #f0f2f5;
      color: #444;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 40px;
      touch-action: manipulation;
    }
    button:hover {
      background: #e4e6e9;
      transform: translateY(-1px);
    }
    button:active {
      transform: scale(0.95);
    }
    button.primary {
      background: #007AFF;
      color: #fff;
    }
    button.primary:hover {
      background: #0063cc;
      box-shadow: 0 4px 12px rgba(0, 122, 255, 0.3);
    }
    button.danger {
      background: #ff4d4f;
      color: #fff;
    }
    button.danger:hover {
      background: #d9363e;
      box-shadow: 0 4px 12px rgba(255, 77, 79, 0.3);
    }
    textarea {
      width: 100%;
      height: 140px;
      border: 1px solid #ddd;
      border-radius: 10px;
      padding: 10px;
      font-family: monospace;
      font-size: 12px;
      resize: none;
      box-sizing: border-box;
      outline: none;
      line-height: 1.4;
    }
    textarea:focus {
      border-color: #007AFF;
      box-shadow: 0 0 0 2px rgba(0, 122, 255, 0.1);
    }
    select {
      width: 100%;
      padding: 8px;
      border-radius: 10px;
      border: 1px solid #ddd;
      outline: none;
      font-size: 13px;
    }
    .module-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 8px;
      margin-bottom: 8px;
    }
    .module-switch {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 10px;
      background: #f8f9fa;
      border-radius: 10px;
      border: 1px solid #eee;
      min-width: 0 !important;
      box-sizing: border-box;
    }
    .switch-label {
      font-size: 13px;
      font-weight: 600;
      color: #333;
      display: flex;
      align-items: center;
      gap: 6px;
      min-width: 0 !important;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex: 1 1 0%;
    }
    .info-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px;
      height: 18px;
      background: #007AFF;
      color: white;
      border-radius: 50%;
      font-size: 12px;
      font-weight: bold;
      cursor: pointer;
      margin-left: 4px;
      position: relative;
      flex-shrink: 0;
    }
    .info-icon:hover {
      background: #0056b3;
    }
    .info-tooltip {
      position: fixed;
      background: rgba(0, 0, 0, 0.9);
      color: #fff;
      padding: 12px 16px;
      border-radius: 10px;
      font-size: 13px;
      max-width: 280px;
      min-width: 200px;
      line-height: 1.5;
      white-space: pre-line;
      word-break: break-word;
      z-index: calc(var(--ab-z-index) + 100);
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      pointer-events: auto;
      max-height: 60vh;
      overflow-y: auto;
    }
    .info-tooltip::before {
      content: '';
      position: absolute;
      width: 0;
      height: 0;
      border: 8px solid transparent;
    }
    .info-tooltip.tooltip-bottom::before {
      top: -16px;
      left: 50%;
      transform: translateX(-50%);
      border-bottom-color: rgba(0, 0, 0, 0.9);
    }
    .switch {
      position: relative;
      width: 40px;
      height: 24px;
      flex-shrink: 0;
    }
    .switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      transition: .4s;
      border-radius: 24px;
      touch-action: manipulation;
    }
    .slider:before {
      position: absolute;
      content: "";
      height: 18px;
      width: 18px;
      left: 3px;
      bottom: 3px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    input:checked + .slider {
      background-color: #007AFF;
    }
    input:checked + .slider:before {
      transform: translateX(16px);
    }
    input[type="number"] {
      box-sizing: border-box !important;
      min-width: 0 !important;
      max-width: 60px !important;
      flex-shrink: 0 !important;
      height: 24px !important;
      -webkit-appearance: none;
      -moz-appearance: textfield;
    }
    input[type="number"]::-webkit-inner-spin-button,
    input[type="number"]::-webkit-outer-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .sub-panel {
      max-height: 45vh;
      overflow-y: auto;
      background: #f9f9f9;
      padding: 12px;
      border-radius: 10px;
      border: 1px solid #eee;
    }
    .log-entry {
      margin-bottom: 10px;
      padding: 10px;
      background: #fff;
      border-radius: 8px;
      border-left: 4px solid #007AFF;
      font-size: 12px;
      position: relative;
      min-height: 60px;
    }
    .log-module {
      color: #007AFF;
      font-weight: bold;
      margin-bottom: 3px;
      font-size: 13px;
      padding-right: 60px;
    }
    .log-content {
      color: #666;
      word-break: break-word;
      font-size: 11px;
      max-height: 180px;
      overflow-y: auto;
      white-space: normal;
      line-height: 1.4;
      padding-right: 60px;
      -webkit-user-select: none;
      user-select: none;
      -webkit-touch-callout: none;
    }
    .log-module {
      -webkit-user-select: none;
      user-select: none;
      -webkit-touch-callout: none;
    }
    .whitelist-btn {
      position: absolute;
      top: 50%;
      right: 8px;
      transform: translateY(-50%);
      background: #34C759;
      color: #fff;
      border: none;
      border-radius: 5px;
      padding: 3px 8px;
      font-size: 10px;
      cursor: pointer;
      z-index: 1;
    }
    /* 两个加白按钮(域名/链接)同在右侧时纵向一上一下, 整组相对条目垂直居中不突出 */
    .whitelist-btn-group {
      position: absolute;
      top: 50%;
      right: 8px;
      transform: translateY(-50%);
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 4px;
      z-index: 1;
    }
    .whitelist-btn-group .whitelist-btn {
      position: static;
      transform: none;
    }
    /* 长按复制结果提示, 不接收指针事件(不挡操作) */
    .copy-toast {
      position: fixed;
      left: 50%;
      bottom: 12%;
      transform: translateX(-50%);
      background: rgba(0, 0, 0, 0.75);
      color: #fff;
      font-size: 12px;
      padding: 8px 14px;
      border-radius: 16px;
      z-index: 2147483647;
      pointer-events: none;
      max-width: 70%;
      text-align: center;
    }
    .copy-hint {
      font-size: 10px;
      color: #999;
      text-align: center;
      margin: 0 0 6px;
    }
    .csp-rule {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px;
      background: #fff;
      border-radius: 8px;
      margin-bottom: 6px;
    }
    .csp-name {
      font-size: 12px;
      color: #333;
      max-width: 70%;
    }
    .whitelist-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: nowrap;
      width: 100%;
      padding: 8px;
      background: #fff;
      border-radius: 6px;
      margin-bottom: 5px;
    }
    .whitelist-text {
      font-size: 11px;
      color: #333;
      white-space: pre-wrap;
      word-break: break-all;
      flex: 1 1 auto;
      min-width: 0;
      -webkit-user-select: none;
      user-select: none;
      -webkit-touch-callout: none;
    }
    .whitelist-item button {
      flex-shrink: 0;
      margin-left: 8px;
    }
    .panel::-webkit-scrollbar {
      width: 6px;
    }
    .panel::-webkit-scrollbar-track {
      background: #f1f1f1;
      border-radius: 4px;
    }
    .panel::-webkit-scrollbar-thumb {
      background: #c1c1c1;
      border-radius: 4px;
    }
    .log-entry.whitelisted {
      background-color: #e8f5e8;
    }
    .log-entry.keyword-whitelisted {
      background-color: #e0f0ff;
    }
    .log-entry.blacklisted {
      background-color: #ffe0e0;
    }
    .panel-notice {
      background: #e6f2ff;
      border-left: 4px solid #007AFF;
      padding: 10px 14px;
      margin: 0 4px 6px;
      border-radius: 8px;
      font-size: 13px;
      color: #1a1a1a;
      line-height: 1.5;
      white-space: pre-line;
    }
    .confirm-msg {
      text-align: center;
      font-size: 14px;
      color: #555;
      padding: 16px 8px;
      line-height: 1.6;
      white-space: pre-line;
    }
    @media (max-width: 359px) {
      .panel { padding: 12px 8px; border-radius: 14px; }
      .title { font-size: 15px; }
      .switch-label { font-size: 12px; }
      .module-grid { grid-template-columns: 1fr; }
      .btn-group button { min-height: 36px; font-size: 12px; }
      .log-content { font-size: 10px; }
      .whitelist-text { font-size: 10px; }
      .csp-name { font-size: 11px; }
    }
    @media (min-width: 360px) and (max-width: 400px) {
      .switch-label { font-size: 11px; }
    }
    @media (orientation: landscape) and (max-height: 500px) {
      .btn-group button { flex: 1 0 100%; min-width: 80px; }
      .module-grid { grid-template-columns: repeat(3, 1fr); }
      .panel { max-height: 95vh; padding: 12px 10px; }
      .sub-panel { max-height: 50vh; }
    }
    @media (orientation: landscape) and (max-height: 350px) {
      .module-switch { padding: 4px 8px; }
      .switch-label { font-size: 11px; }
      .btn-group { gap: 4px; }
      .btn-group button { padding: 6px 8px; min-height: 32px; font-size: 11px; }
      .sub-panel { max-height: 40vh; padding: 8px; }
    }
    @media (prefers-color-scheme: dark) {
      .panel { background: #1c1c1e; color: #fff; }
      .title { color: #fff; }
      button { background: #2c2c2e; color: #ccc; }
      button:hover { background: #3a3a3c; }
      textarea { background: #2c2c2e; border-color: #444; color: #eee; }
      select { background: #2c2c2e; border-color: #444; color: #eee; }
      .module-switch { background: #2c2c2e; border-color: #444; }
      .switch-label { color: #eee; }
      .sub-panel { background: #2c2c2e; border-color: #444; }
      .log-entry { background: #1c1c1e; }
      .csp-rule { background: #1c1c1e; }
      .whitelist-item { background: #1c1c1e; }
      .whitelist-text { color: #eee; }
      .panel::-webkit-scrollbar-track { background: #2c2c2e; }
      .panel::-webkit-scrollbar-thumb { background: #555; }
      .log-entry.whitelisted { background-color: #2a4a2a; }
      .log-entry.keyword-whitelisted { background-color: #2a3a5a; }
      .log-entry.blacklisted { background-color: #5a2a2a; }
      .panel-notice { background: #1a2a3a; border-left-color: #3a7aff; color: #cecece; }
      .confirm-msg { color: #ddd; }
      .info-tooltip { background: rgba(255, 255, 255, 0.95); color: #1c1c1e; }
      .info-tooltip.tooltip-bottom::before { border-bottom-color: rgba(255, 255, 255, 0.95); } input[type="number"] {
        background: #2c2c2e;
        color: #eee;
      }
    }
    @keyframes fade-in {
      from {
        background: rgba(0, 0, 0, 0);
        backdrop-filter: blur(0px);
      }
      to {
        background: rgba(0, 0, 0, 0.3);
        backdrop-filter: blur(8px);
      }
    }
    @keyframes scale-in {
      from {
        transform: scale(0.9);
        opacity: 0;
      }
      to {
        transform: scale(1);
        opacity: 1;
      }
    }
  `;

  let panelIdCounter = 0;
  let _scriptMap = null;

  // ======================== 面板管理器（设置界面） ========================
    // 设置面板：模块开关 / 白名单 / 黑名单 / 拦截日志。日志条目可点「加白」放行。
  class PanelManager {
    constructor() {
      this._host = null;
      this._shadow = null;
      this._overlay = null;
      this._panelEl = null;
      this.isAnimating = false;
      this._animLockAt = 0;
    }

    _destroyCurrentPanel() {
      if (this._panelGuard) {
        try { this._panelGuard.disconnect(); } catch (e) {}
        this._panelGuard = null;
      }
      if (this._host) { try { this._host.parentNode.removeChild(this._host); } catch (e) {} this._host = null; }
      this._shadow = null;
      this._overlay = null;
      this._panelEl = null;
      this.isAnimating = false;

      if (activePanels.size > 0) {
        activePanels.clear();
        if (strongBlockingEnabled) disableStrongBlocking();
      }
    }


    _checkIframeBlocking() {
      if (!currentConfig.iframeUIFix) return false;
      if (!isInIframe()) return false;
      try {
        _globals.parent.postMessage({
          type: 'adblock-show-panel',
          source: 'adblock-iframe',
          origin: _location.origin,
          timestamp: Date.now()
        }, _location.ancestorOrigins ? _location.ancestorOrigins[0] : '*');
      } catch (e) {   }
      return true;
    }

    _showIframeHint() {
      if (!this._shadow) this.ensureShadow();
      if (!this._shadow) return;
      var existing = this._shadow.querySelector('.iframe-hint');
      if (existing) existing.remove();
      var hint = _document.createElement('div');
      hint.className = 'iframe-hint';
      hint.style.cssText = 'position:fixed;bottom:20px;left:50%;'
        + 'transform:translateX(-50%);background:rgba(0,0,0,0.85);'
        + 'color:#fff;padding:10px 20px;border-radius:20px;font-size:13px;'
        + 'z-index:999999;pointer-events:auto;'
        + 'max-width:90vw;text-align:center;';
      hint.textContent = '广告拦截器：检测到嵌套框架，已通知主页面显示面板';
      this._shadow.appendChild(hint);
      _setTimeout(function() {
        if (hint.parentNode) {
          hint.style.opacity = '0';
          hint.style.transition = 'opacity 0.3s';
          _setTimeout(function() {
            if (hint.parentNode) hint.remove();
          }, 300);
        }
      }, 2000);
    }

    ensureShadow() {
      // 面板宿主创建：closed Shadow DOM 硬隔离（页面无法访问面板内部）；
      // 防杀机制：宿主被页面 remove → 自动重新挂载；display:none/visibility:hidden/opacity:0 → 自动恢复；
      // 全局样式表注入由宿主初始化时的 inline !important 基础样式压住(见下, 样式表变化不产生 MO 通知)。
      if (this._shadow) return;
      this._destroyCurrentPanel();
      var self = this;
      var host = _document.createElement('div');
      host.style.cssText = 'position:absolute;top:0;left:0;z-index:2147483647;pointer-events:none;';
      host.style.setProperty('z-index', '2147483647', 'important');
      // 样式表注入防护: inline !important 优先级最高(CSS 层叠: inline important > 样式表 important),
      // 页面注入 div[style*="2147483647"]{display:none!important} 类全局样式也无法隐藏面板宿主;
      // 与下方 _panelGuard 的 attributes 恢复(同为 important)形成闭环, 页面任何样式表/内联篡改都会被压回。
      host.style.setProperty('display', 'block', 'important');
      host.style.setProperty('visibility', 'visible', 'important');
      host.style.setProperty('opacity', '1', 'important');
      // 防自拦截: 必须先标记"安全/已处理"再挂载面板宿主,
      // 否则启用覆盖层拦截时, 宿主(absolute + 超高 z-index)会被自己的拦截逻辑
      // 当成覆盖层广告隐藏掉。
      _markSafe(host);
      ProcessedElementsCache.markAsProcessed(host);
      _document.documentElement.appendChild(host);
      this._shadow = host.attachShadow({ mode: 'closed' });
      // 面板防杀: 用 closed Shadow DOM 隔离面板内部, 再用 MutationObserver 盯着宿主,
      // 被页面脚本移除就重新挂载、被设置成隐藏样式就恢复 —— 防止网页把设置面板干掉;
      // 恢复一律写 !important(与初始化基础样式同优先级), 保证恢复结果同样压过页面样式表。
      this._lastReviveAt = 0;
      this._panelGuard = new MutationObserver(function (ms) {
        for (var mi = 0; mi < ms.length; mi++) {
          var m = ms[mi];
          if (m.type === 'childList') {
            var removed = false;
            for (var ri = 0; ri < m.removedNodes.length; ri++) {
              if (m.removedNodes[ri] === host) { removed = true; break; }
            }
            if (removed && host.parentNode !== _document.documentElement && _document.documentElement) {
              // 节流: 页面高频删除时 100ms 内不重复复活（防性能问题）
              var _now = Date.now();
              if (_now - self._lastReviveAt < 100) continue;
              self._lastReviveAt = _now;
              _document.documentElement.appendChild(host);  // 复活（shadow 内容随宿主自动恢复）
            }
          } else if (m.type === 'attributes' && host.style) {
            var dv = host.style.getPropertyValue('display');
            if (dv === 'none') host.style.setProperty('display', 'block', 'important');
            var vv = host.style.getPropertyValue('visibility');
            if (vv === 'hidden' || vv === 'collapse') host.style.setProperty('visibility', 'visible', 'important');
            var ov = host.style.getPropertyValue('opacity');
            if (ov === '0') host.style.setProperty('opacity', '1', 'important');
          }
        }
      });
      try {
        this._panelGuard.observe(_document.documentElement, { childList: true, subtree: false });
        this._panelGuard.observe(host, { attributes: true, attributeFilter: ['style', 'class'] });
      } catch(e) {}
      var style = _document.createElement('style');
      style.textContent = UI_CSS;
      this._shadow.appendChild(style);
      this._host = host;
    }
    showInfoTooltip(infoIcon, message) {
      this.closeInfoTooltip();
      if (!this._shadow) this.ensureShadow();
      if (!this._shadow) return;
      var tooltip = _document.createElement('div');
      tooltip.className = 'info-tooltip';
      tooltip.textContent = message;
      tooltip.style.setProperty('z-index', '2147483647', 'important');
      this._shadow.appendChild(tooltip);
      var iconRect = infoIcon.getBoundingClientRect();
      var tooltipRect = tooltip.getBoundingClientRect();
      var viewportWidth = window.innerWidth;
      var tooltipWidth = tooltipRect.width || 280;
      var left = iconRect.left + iconRect.width / 2 - tooltipWidth / 2;
      var top = iconRect.bottom + CONFIG.TOOLTIP_GAP;
      if (left < 10) left = 10;
      if (left + tooltipWidth > viewportWidth - 10) left = viewportWidth - tooltipWidth - 10;
      // 固定向下展开: 长注释在手机上向上弹出会被面板顶部截断, 统一朝下方显示;
      // 图标贴近屏幕底部时把顶边钳回可视区, 超出部分由提示框自身滚动(60vh 上限)
      tooltip.classList.add('tooltip-bottom');
      var _maxTop = window.innerHeight - Math.min(tooltipRect.height || 100, window.innerHeight * 0.6) - 12;
      if (top > _maxTop) top = Math.max(10, _maxTop);
      tooltip.style.left = left + 'px';
      tooltip.style.top = top + 'px';
      this.activeTooltip = tooltip;
      var self = this;
      var closeHandler = function (e) {
        if (e.target !== tooltip && e.target !== infoIcon && !tooltip.contains(e.target)) {
          self.closeInfoTooltip();
          _document.removeEventListener('click', closeHandler, true);
        }
      };
      // 换新提示前先摘掉旧监听, 避免监听累积
      if (this._tooltipCloseHandler) {
        try { _document.removeEventListener('click', this._tooltipCloseHandler, true); } catch(e) {}
      }
      this._tooltipCloseHandler = closeHandler;
      _setTimeout(function () {
        _document.addEventListener('click', closeHandler, true);
      }, 10);
    }
    closeInfoTooltip() {
      if (this._tooltipCloseHandler) {
        try { _document.removeEventListener('click', this._tooltipCloseHandler, true); } catch(e) {}
        this._tooltipCloseHandler = null;
      }
      if (this.activeTooltip) {
        if (this.activeTooltip.parentNode) {
          this.activeTooltip.parentNode.removeChild(this.activeTooltip);
        }
        this.activeTooltip = null;
      }
    }
    showConfirm(message, onConfirm) {
      var panelManager = this;
      this.createPanel({
        title: '⚠️ 操作确认',
        contentHtml: '<div class="confirm-msg">' + escapeHtml(message) + '</div>',
        buttons: [
          {
            id: 'confirmOk', text: '确认执行', class: 'danger', onclick: function () {
              panelManager.closeCurrentMask();
              if (onConfirm) onConfirm();
            }
          },
          {
            id: 'confirmNo', text: '取消', onclick: function (e, m) {
              if (m && m._closePanel) m._closePanel();
            }
          },
        ],
        hideBackButton: true,
        onBack: function () {},
      });
    }
    closeCurrentMask() {
      var m = this._shadow ? this._shadow.querySelector('.mask') : null;
      if (!m) return;
      var pid = m.getAttribute('data-panel-id');
      if (pid) teardownNavigationBlocking(pid);
      m.remove();
      this.isAnimating = false;
    }

    // ===== 长按复制: 写剪贴板(GM 优先 → Clipboard API → execCommand 兜底) + 面板内 toast 提示 =====
    _panelCopyText(text, mask) {
      var self = this;
      var now = Date.now();
      if (mask && mask._lastCopyAt && now - mask._lastCopyAt < 800) return;
      if (mask) mask._lastCopyAt = now;
      var done = false;
      var finish = function (ok) {
        if (done) return;
        done = true;
        self._showCopyToast(mask, ok ? '已复制' : '复制失败');
      };
      try {
        if (typeof GM_setClipboard === 'function') {
          GM_setClipboard(text);
          finish(true);
          return;
        }
      } catch (e) { _debugCatch(e, 'panelCopy GM'); }
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(function () { finish(true); }, function () { self._execCommandCopy(text, finish); });
          return;
        }
      } catch (e) { _debugCatch(e, 'panelCopy api'); }
      this._execCommandCopy(text, finish);
    }
    _execCommandCopy(text, finish) {
      try {
        var ta = _document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0;';
        _document.body.appendChild(ta);
        ta.select();
        try { ta.setSelectionRange(0, String(text).length); } catch (e1) {}
        var ok = false;
        try { ok = _document.execCommand('copy'); } catch (e2) {}
        try { _document.body.removeChild(ta); } catch (e3) {}
        finish(!!ok);
      } catch (e) { _debugCatch(e, 'panelCopy exec'); finish(false); }
    }
    _showCopyToast(mask, msg) {
      try {
        if (!mask || !mask.parentNode) return;
        var t = _document.createElement('div');
        t.className = 'copy-toast';
        t.textContent = msg;
        mask.appendChild(t);
        _setTimeout(function () { try { if (t.parentNode) t.parentNode.removeChild(t); } catch (e1) {} }, 1200);
      } catch (e) { _debugCatch(e, 'copyToast'); }
    }
    _showListPanel({ title, items, renderItem, clearAction, extraHTML, onBack }) {
      this.closeCurrentMask();
      const self = this;
      const listHtml = items.length === 0
        ? '<div style="text-align:center;color:#999;margin:20px 0;font-size:14px;">列表为空</div>'
        : '<div class="copy-hint">长按内容可复制</div>' + items.map((item, i) => renderItem(item, i)).join('');
      this.createPanel({
        title: title,
        contentHtml: (extraHTML || '') + '<div class="sub-panel">' + listHtml + '</div>',
        buttons: clearAction ? [{ id: clearAction, text: '清空全部', class: 'danger', onclick: null }] : [],
        onBack: onBack || function () { self.showSettings(); },
      // 设置面板入口：模块开关 / 白名单 / 黑名单 / 拦截日志（日志条目可加白）。
      });
    }
    createPanel(options) {

      if (this._checkIframeBlocking()) {
        this._showIframeHint();
        return null;
      }
      if (this.isAnimating) {
        // 保险丝: 动画锁残留超过 1 秒(正常动画 500ms 兜底必复位) → 强制解除,
        // 面板不因动画锁异常残留而永久"点击无反应"
        if (this._animLockAt && Date.now() - this._animLockAt > 1000) {
          this.isAnimating = false;
          this._animLockAt = 0;
        } else {
          return null;
        }
      }
      var title = options.title;
      var contentHtml = options.contentHtml;
      var onClose = options.onClose;
      var onBack = options.onBack;
      var buttons = options.buttons || [];
      var hideBackButton = options.hideBackButton || false;
      var isRootPanel = options.isRootPanel || false;
      this.ensureShadow();
      var panelId = 'panel_' + ++panelIdCounter;
      setupNavigationBlocking(panelId);
      var self = this;
      var mask = _document.createElement('div');
      mask.className = 'mask';
      mask.style.setProperty('z-index', '2147483647', 'important');
      _markSafe(mask);
      mask.setAttribute('data-panel-id', panelId);
      var btnHtml = buttons.map(function (b) {
        return ('<button type="button" data-id="' + b.id + '" class="' + (b.class || '') + '">' + escapeHtml(b.text) + '</button>');
      }).join('');
      var backHtml = hideBackButton ? '' : '<button type="button" data-id="backBtn" class="primary">返回设置</button>';
      mask.innerHTML = [
        '<div class="panel" style="max-width:600px; width:95vw;">',
          '<div class="title">', escapeHtml(title), '</div>',
          contentHtml,
          '<div class="btn-group">', btnHtml, backHtml, '</div>',
        '</div>'
      ].join('');
      var closePanel = function (anim) {
        if (anim === undefined) anim = true;
        if (!mask.parentNode) return;
        teardownNavigationBlocking(panelId);
        var cleanup = function () {
          self.isAnimating = false;
          self.closeInfoTooltip();
          try {
            if (onClose) onClose();
          } catch (err) {
            _debugCatch(err, '面板 onClose 回调异常');
          } finally {
            // finally 保证 mask 一定移除: 杜绝"透明 mask 残留盖住页面/吃掉点击"
            if (mask.parentNode) mask.remove();
          }
        };
        if (anim) {
          self.isAnimating = true;
          self._animLockAt = Date.now();
          var cleaned = false;
          var onTE = function () {
            if (cleaned) return;
            cleaned = true;
            mask.removeEventListener('transitionend', onTE);
            cleanup();
          };
          mask.addEventListener('transitionend', onTE);
          mask.style.opacity = '0';
          _setTimeout(function () {
            if (!cleaned) {
              mask.removeEventListener('transitionend', onTE);
              cleanup();
            }
          }, 500);
        } else {
          cleanup();
        }
      };
      mask._closePanel = closePanel;
      var handleBack = function () {
        if (isRootPanel) return;
        if (onBack) {
          onBack();
        } else {
          closePanel();
          self.showSettings();
        }
      };
      mask.addEventListener('click', function (e) {
        // 面板交互异常隔离: 任一分支抛异常只影响当次点击, 不锁死面板后续交互
        try {
          var path = e.composedPath ? e.composedPath() : (e.path || []);
          var isPanel = path.some(function (el) {
            return Utils.isPanelElement(el);
          });
          if (!isPanel && e.target === mask) {
            handleBack();
            return;
          }
          if (isPanel) {
            if (!e.target.closest('button, input, textarea, select, label, .info-icon, .whitelist-btn, [data-copy-full], [data-copy-sid]')) {
              handleBack();
              return;
            }
          }
          var button = e.target.closest('button');
          if (!button) return;
          var action = button.dataset.action || button.dataset.id;
          if (action === 'backBtn') {
            handleBack();
            return;
          }
          var matched = buttons.find(function (b) {
            return b.id === action;
          });
          if (matched && matched.onclick) {
            matched.onclick(e, mask);
            return;
          }
          self.handlePanelAction(action, button.dataset.index, button, mask, e);
        } catch (err) {
          _debugCatch(err, '面板点击处理异常');
        }
      });
      // ===== 长按复制: 内容块长按(触摸)/右键(桌面)复制全文, 内容区点击不触发返回 =====
      var _lpTimer = null;
      var _lpStart = null;
      var _lpClear = function () {
        if (_lpTimer) { try { _clearTimeout(_lpTimer); } catch (e0) {} _lpTimer = null; }
        _lpStart = null;
      };
      var _lpResolveText = function (el) {
        try {
          if (!el || !el.closest) return null;
          var t = el.closest('[data-copy-full], [data-copy-sid]');
          if (!t) return null;
          var sid = t.getAttribute('data-copy-sid');
          if (sid) {
            var full = (typeof _scriptMap !== 'undefined' && _scriptMap) ? _scriptMap.get(sid) : null;
            if (full) return String(full);
          }
          var v = t.getAttribute('data-copy-full');
          if (v != null && v !== '') return v;
          return t.textContent || '';
        } catch (e1) { return null; }
      };
      var _lpFire = function (el) {
        _lpClear();
        var text = _lpResolveText(el);
        if (!text) return;
        self._panelCopyText(String(text), mask);
      };
      mask.addEventListener('touchstart', function (e) {
        try {
          if (!e.touches || e.touches.length !== 1) return;
          var t = e.target;
          if (!t || !t.closest) return;
          if (t.closest('button, input, textarea, select, label, .info-icon, .slider, .switch')) return;
          if (!t.closest('[data-copy-full], [data-copy-sid]')) return;
          _lpStart = { x: e.touches[0].clientX, y: e.touches[0].clientY };
          _lpTimer = _setTimeout(function () { _lpFire(t); }, 500);
        } catch (e2) { _debugCatch(e2, 'lp touchstart'); }
      }, { passive: true });
      mask.addEventListener('touchmove', function (e) {
        try {
          if (!_lpTimer || !_lpStart || !e.touches || !e.touches.length) return;
          var dx = e.touches[0].clientX - _lpStart.x;
          var dy = e.touches[0].clientY - _lpStart.y;
          if ((dx * dx + dy * dy) > 144) _lpClear();
        } catch (e3) {}
      }, { passive: true });
      mask.addEventListener('touchend', function () { _lpClear(); }, true);
      mask.addEventListener('touchcancel', function () { _lpClear(); }, true);
      mask.addEventListener('contextmenu', function (e) {
        try {
          var t = e.target;
          if (!t || !t.closest) return;
          if (t.closest('button, input, textarea, select, label, .info-icon')) return;
          if (!_lpResolveText(t)) return;
          e.preventDefault();
          _lpFire(t);
        } catch (e4) { _debugCatch(e4, 'lp contextmenu'); }
      });
      mask.addEventListener('change', function (e) {
        // 面板开关异常隔离: 整体 try 保证单次异常不锁死面板;
        // 各模块 init 单独 try 保证一个模块失败不影响其他开关
        try {
        var t = e.target;
        if (t.matches('.module-toggle')) {
          var k = t.dataset.key;
          currentConfig.modules[k] = t.checked;
          ConfigUpdater.saveNow();
          resetAllCachesAndStates();
          // 基础模块（移除内嵌/外联脚本/脚本黑名单/第三方）统一按当前开关重新初始化
          try {
            for (var _mi = 0; _mi < UIController.modules.length; _mi++) {
              if (UIController.modules[_mi].moduleKey === k) { UIController.modules[_mi].init(); break; }
            }
          } catch (err) { _debugCatch(err, k + '.init'); }
          try {
            if (k === 'blockDynamicScripts') {
              t.checked ? DynamicScriptInterceptor.enable() : DynamicScriptInterceptor.disable();
            }
          } catch (err) { _debugCatch(err, 'blockDynamicScripts'); }
          try {
            if (k === 'overlayIntercept') {
              t.checked ? OverlayInterceptor.init() : OverlayInterceptor.disable();
            }
          } catch (err) { _debugCatch(err, 'OverlayInterceptor'); }
          try { if (strongBlockingEnabled) disableStrongBlocking(); } catch (err) { _debugCatch(err, 'disableStrongBlocking'); }
          try {
            if (Utils.isAnyModuleEnabled()) {
              if (currentConfig.residualCleanupEnabled) ResidualCleaner.init();
              else ResidualCleaner.stop();
            } else {
              ResidualCleaner.stop();
            }
          } catch (err) { _debugCatch(err, 'ResidualCleaner'); }
        } else if (t.matches('.csp-toggle')) {
          try {
            CSPModule.updateRule(parseInt(t.dataset.id), t.checked);
            currentConfig.modules.manageCSP = currentConfig.cspRules.some(function (r) { return r.enabled; });
            ConfigUpdater.saveNow();
            _location.reload();
          } catch (err) { _debugCatch(err, 'CSP 规则切换'); }
        } else if (t.matches('.advanced-toggle')) {
          var k2 = t.dataset.key;
          try {
          if (k2 === 'spoofUAEnabled') {
            if (t.checked) {
              if (currentConfig.simplePlatformSpoof) {
                currentConfig.simplePlatformSpoof = false;
                var simpleSpoofToggle = mask.querySelector('.advanced-toggle[data-key="simplePlatformSpoof"]');
                if (simpleSpoofToggle) simpleSpoofToggle.checked = false;
              }
            }
          } else if (k2 === 'simplePlatformSpoof') {
            if (t.checked) {
              if (currentConfig.spoofUAEnabled) {
                currentConfig.spoofUAEnabled = false;
                var uaSpoofToggle = mask.querySelector('.advanced-toggle[data-key="spoofUAEnabled"]');
                if (uaSpoofToggle) uaSpoofToggle.checked = false;
              }
            }
          } else if (k2 === 'heuristicBlacklistEnabled') {
            currentConfig.heuristicBlacklistEnabled = t.checked;
            _heuristicRegexGroups = null;
            ConfigUpdater.saveNow();
            if (currentConfig.modules.scriptBlacklistMode) {
              if (scriptBlacklistModule) scriptBlacklistModule.rebuildBlacklist();
            }
          }
          currentConfig[k2] = t.checked;
          ConfigUpdater.saveNow();
          if (k2 === 'dynamicScriptStrictMode') {
            DynamicScriptInterceptor._callbackCheckCache = new WeakMap();
            DynamicScriptInterceptor.disable();
            DynamicScriptInterceptor.enable();
          } else if (k2 === 'overlayStrictMode') {
            // 覆盖层拦截严格模式: 用新规则重扫已有元素
            if (currentConfig.modules.overlayIntercept) {
              OverlayInterceptor.disable();
              OverlayInterceptor.init();
            }
          }
          if (k2 === 'spoofUAEnabled' || k2 === 'simplePlatformSpoof') {
            UASpoofEngine._layer1Active = false;
            // UA 模拟三层：① 客户端属性伪装（navigator/plugins/触屏事件等）② fetch/XHR GM 代理
            // ③ 页面重写注入（仅"苹果设备模拟"开启时）。
            UASpoofEngine._layer2Active = false;
            // 用户主动切换开关 = 重新尝试重写, 清除该站点上次失败的熔断标记
            try { GM_deleteValue('ab_ua_rewrite_fail_' + _location.hostname); } catch (e) {}
            if (currentConfig.simplePlatformSpoof || currentConfig.spoofUAEnabled) {
              UASpoofEngine.init();
            } else {
              UASpoofEngine.disable();
            }
          }
          if (k2 === 'inlineScriptStrictMode' && inlineScriptsModule) inlineScriptsModule.updateStrictMode();
          if (k2 === 'thirdPartyStrictMode' && thirdPartyModule) thirdPartyModule.updateStrictMode();
          if (k2 === 'thirdPartyStrictMethod' && thirdPartyModule) thirdPartyModule.updateStrictMethod();
          if (k2 === 'funnelStrictMode' && thirdPartyModule) thirdPartyModule._syncFunnelHook();
          if (k2 === 'residualCleanupEnabled') {
            if (Utils.isAnyModuleEnabled() && currentConfig.residualCleanupEnabled) ResidualCleaner.init();
            else ResidualCleaner.stop();
          }
          if (k2 === 'trackingParamsCleanerEnabled') {
            if (!t.checked) {
              URLChangeGuard.stop();
              LinkCleaner.disable();
              NetworkTrackingCleaner.disable();
            } else {
              URLChangeGuard.init();
              LinkCleaner.init();
              NetworkTrackingCleaner.init();
            }
          }
          if (k2 === 'redirectBlockerCompatibilityMode') {
            currentConfig[k2] = t.checked;
            ConfigUpdater.saveNow();
            if (currentConfig.redirectBlockerEnabled) {
              try { RedirectBlocker.disable(); } catch(e) {}
              RedirectBlocker._initialized = false;
              RedirectBlocker.init();
            }
          }
          if (k2 === 'redirectBlockerEnabled') {
            try {
              if (t.checked) RedirectBlocker.init();
              else RedirectBlocker.disable();
            } catch (err) { _debugCatch(err, 'redirectBlockerEnabled'); }
          }
          if (k2 === 'builtinBlacklistEnabled') {
            if (t.checked) currentConfig.removedBuiltinKeywords.clear();
            ConfigUpdater.saveNow();
            if (currentConfig.modules.scriptBlacklistMode && scriptBlacklistModule) scriptBlacklistModule.rebuildBlacklist();
          }
          if (k2 === 'heuristicBlacklistEnabled') {
            if (scriptBlacklistModule) scriptBlacklistModule.rebuildBlacklist();
          }
          } catch (err) { _debugCatch(err, '高级设置应用异常(' + (k2 || '?') + ')'); }
        }
        } catch (err) {
          _debugCatch(err, '面板开关处理异常');
        }
      });
      // 渲染/事件绑定全部完成后才关旧面板: 构建过程中任何异常都不会吞掉旧面板
      this.closeCurrentMask();
      this._shadow.appendChild(mask);
      mask.style.pointerEvents = 'auto';
      mask.querySelector('.panel').style.pointerEvents = 'auto';
      return mask;
    }
    renderLogItem(log, index) {
      var status = getLogWhitelistStatus(log);
      var logEntryClass = 'log-entry' + (status ? ' ' + status : '');
      var isWL = status !== '';
      var domainHint = log.domain ? '<div style="font-size:11px;color:#999;margin-top:4px;">域名: ' + escapeHtml(log.domain) + '</div>' : '';
      var copyVal = String(log.content || '') + (log.domain ? '\n域名: ' + log.domain : '');
      var btns;
      if (log.moduleKey === 'interceptThirdParty') {
        // 第三方资源日志提供两个加白选项: 加白域名（整站放行） / 加白链接(仅该具体 URL 放行, 同域名其他资源照拦)
        var _dmWl = false;
        if (log.domain) {
          var _wlD = /^[a-z][a-z0-9+.-]*:/i.test(log.domain) ? log.domain : 'http://' + log.domain;
          _dmWl = urlCache.isWhitelisted(_wlD, currentConfig.thirdPartyWhitelist);
        }
        var _lkWl = !!log.contentIdentifier && currentConfig.whitelist.has(log.contentIdentifier);
        // 两个加白按钮（域名/链接）纵向一上一下排在条目右侧, 整组垂直居中互不叠盖
        btns = '<div class="whitelist-btn-group">' +
          (log.domain ? '<button type="button" class="whitelist-btn"' + (_dmWl ? ' disabled style="background:#999;"' : '') + ' data-action="whitelistDomain" data-index="' + index + '">' + (_dmWl ? '域名已加白' : '加白域名') + '</button>' : '') +
          '<button type="button" class="whitelist-btn" data-action="whitelistLink" data-index="' + index + '" ' + (_lkWl ? 'disabled style="background:#999;"' : '') + '>' + (_lkWl ? '链接已加白' : '加白链接') + '</button>' +
          '</div>';
      } else {
        btns = '<button type="button" class="whitelist-btn" data-action="whitelistLog" data-index="' + index + '" ' + (isWL ? 'disabled style="background:#999;"' : '') + '>' + (isWL ? '已加白' : '加白') + '</button>';
      }
      return ('<div class="' + logEntryClass + '" data-index="' + index + '" data-copy-full="' + escapeHtml(copyVal) + '">' + btns + '<div class="log-module">' + escapeHtml(log.module) + ' - ' + escapeHtml(log.element) + '</div><div class="log-content">' + escapeHtml(log.content) + '</div>' + domainHint + '</div>');
    }
    handlePanelAction(action, index, button, mask, event) {
      var self = this;
      // 面板按钮动作异常隔离: 任一 case 抛只影响当次点击, 不锁死面板交互
      try {
      switch (action) {
        case 'closePanel':
          // 优先走动画关闭路径(_closePanel, 含 onClose/清理/mask 移除), 无则直接销毁
          if (mask && mask._closePanel) mask._closePanel();
          else self._destroyCurrentPanel();
          break;
        case 'viewLogs':
          self.showLogsPanel();
          break;
        case 'manageCSP':
          self.showCSPPanel();
          break;
        case 'manageDiaryWhitelist':
          self.showDiaryWhitelistPanel();
          break;
        case 'manageThirdParty':
          self.showThirdPartyPanel();
          break;
        case 'manageKeywordWhitelist':
          self.showKeywordWhitelistPanel();
          break;
        case 'manageScriptBlacklist':
          self.showScriptBlacklistPanel();
          break;
        case 'showAdvancedSettings':
          self.showAdvancedSettingsPanel();
          break;
        case 'showParamAdjustment':
          self.showParamAdjustmentPanel();
          break;
        case 'cssBlockMark':
          self.closeCurrentMask();
          try { ElementCssBlocker.startPicking(); } catch (err) {
            _debugCatch(err, 'cssBlockMark');
            try { GM_notification({ text: '标记模式启动失败，请刷新页面重试', title: '广告拦截器' }); } catch (e2) {}
          }
          break;
        case 'cssBlockManage':
          self.showCssBlockRulesPanel();
          break;
        case 'deleteCssRule': {
          var _crules = currentConfig.elementCssRules || [];
          var _cidx = parseInt(index);
          if (!isNaN(_cidx) && _cidx >= 0 && _cidx < _crules.length) {
            _crules.splice(_cidx, 1);
            currentConfig.elementCssRules = _crules;
            ConfigUpdater.saveNow();
            try { ElementCssBlocker.applyCss(); } catch (e2) { _debugCatch(e2, 'deleteCssRule applyCss'); }
            // 规则体检内删除: 留在体检面板原地刷新, 由用户点「返回设置」回二级面板
            if (button && button.getAttribute && button.getAttribute('data-from') === 'audit') self.showCssRuleAuditPanel();
            else self.showCssBlockRulesPanel();
          }
          break;
        }
        case 'clearAllCssRules': {
          currentConfig.elementCssRules = [];
          ConfigUpdater.saveNow();
          try { ElementCssBlocker.applyCss(); } catch (e2) { _debugCatch(e2, 'clearAllCssRules applyCss'); }
          self.showCssBlockRulesPanel();
          break;
        }
        case 'narrowCssRule': {
          // 「仅隐藏所选」回退: 把宽键规则的选择器替换为保存时记录的窄键（物理结构键）
          var _nrules = currentConfig.elementCssRules || [];
          var _nidx = parseInt(index);
          if (!isNaN(_nidx) && _nidx >= 0 && _nidx < _nrules.length) {
            var _nr = _nrules[_nidx];
            if (_nr && _nr.narrowSels && _nr.narrowSels.length) {
              _nr.selectors = _nr.narrowSels;
              delete _nr.narrowSels;
              delete _nr.savedHits;
              ConfigUpdater.saveNow();
              try { ElementCssBlocker.applyCss(); } catch (e3) { _debugCatch(e3, 'narrowCssRule applyCss'); }
            }
            self.showCssBlockRulesPanel();
          }
          break;
        }
        case 'cssRuleAudit':
          self.showCssRuleAuditPanel();
          break;
        case 'auditDowngradeRule': {
          // 规则体检处置: remove/combo 规则一键改为纯隐藏方式（停用移除引擎删除循环）
          var _drules = currentConfig.elementCssRules || [];
          var _didx = parseInt(index);
          if (!isNaN(_didx) && _didx >= 0 && _didx < _drules.length) {
            var _dr = _drules[_didx];
            if (_dr && (_dr.mode === 'remove' || _dr.mode === 'combo')) {
              _dr.mode = 'hidden';
              ConfigUpdater.saveNow();
              try { ElementCssBlocker.applyCss(); } catch (e4) { _debugCatch(e4, 'auditDowngradeRule applyCss'); }
            }
            self.showCssRuleAuditPanel();
          }
          break;
        }
        case 'auditNarrowExtRule': {
          // 规则体检处置: 宽扩展键按实际命中的统一标签收窄基底(* → div 等)
          var _wrules = currentConfig.elementCssRules || [];
          var _widx = parseInt(index);
          var _wtag = button && button.getAttribute ? (button.getAttribute('data-tag') || '') : '';
          if (!isNaN(_widx) && _widx >= 0 && _widx < _wrules.length && _wtag && /^[a-zA-Z][a-zA-Z0-9]*$/.test(_wtag)) {
            var _wr = _wrules[_widx];
            if (_wr && _wr.selectors && _wr.selectors.length) {
              var _wChanged = false;
              for (var _wj = 0; _wj < _wr.selectors.length; _wj++) {
                var _ws = String(_wr.selectors[_wj] || '');
                var _wBase = _ws.replace(/:matches-css(?:-before|-after)?\([^)]*\)/g, '').trim();
                if (_wBase === '*') {
                  _wr.selectors[_wj] = _ws.replace(/^\*/, _wtag);
                  _wChanged = true;
                }
              }
              if (_wChanged) {
                ConfigUpdater.saveNow();
                try { ElementCssBlocker.applyCss(); } catch (e5) { _debugCatch(e5, 'auditNarrowExtRule applyCss'); }
              }
            }
            self.showCssRuleAuditPanel();
          }
          break;
        }
        case 'deleteDiaryItem': {
          // 日记白名单按"加白动作"聚合后, 一行=一组钥匙（精确键+结构键/备钥组）:
          // 删除必须整组删, 否则残留子钥匙会让屏蔽不恢复
          var idx = parseInt(index);
          var _grp = (self._wlGroupItems && idx >= 0 && idx < self._wlGroupItems.length) ? self._wlGroupItems[idx] : null;
          if (_grp && _grp.keys && _grp.keys.length) {
            for (var _gdi = 0; _gdi < _grp.keys.length; _gdi++) {
              currentConfig.whitelist.delete(_grp.keys[_gdi]);
              currentConfig.whitelistDisplayNames.delete(_grp.keys[_gdi]);
            }
            ConfigUpdater.saveNow();
            resetAllCachesAndStates();
            self.showDiaryWhitelistPanel();
          }
          break;
        }
        case 'deleteKeywordItem': {
          var arr2 = Array.from(currentConfig.keywordWhitelist);
          var idx2 = parseInt(index);
          if (!isNaN(idx2) && idx2 >= 0 && idx2 < arr2.length && arr2[idx2]) {
            currentConfig.keywordWhitelist.delete(arr2[idx2]);
            ConfigUpdater.saveNow();
            resetAllCachesAndStates();
            self.showKeywordWhitelistPanel();
          }
          break;
        }
        case 'deleteBlacklistItem': {
          var arr3 = Utils.getActiveBlacklistArray();
          var idx3 = parseInt(index);
          if (!isNaN(idx3) && idx3 >= 0 && idx3 < arr3.length && arr3[idx3]) {
            if (BUILTIN_BLACKLIST_KEYWORDS.indexOf(arr3[idx3]) !== -1) currentConfig.removedBuiltinKeywords.add(arr3[idx3]);
            else currentConfig.scriptBlacklist.delete(arr3[idx3]);
            ConfigUpdater.saveNow();
            if (scriptBlacklistModule) scriptBlacklistModule.rebuildBlacklist();
            resetAllCachesAndStates();
            self.showScriptBlacklistPanel();
          }
          break;
        }
        case 'deleteThirdPartyItem': {
          var wl = currentConfig.thirdPartyWhitelist;
          var idx4 = parseInt(index);
          if (!isNaN(idx4) && idx4 >= 0 && idx4 < wl.length && wl[idx4]) {
            var removedItem = wl[idx4];
            wl.splice(idx4, 1);
            if (removedItem) Whitelisting.removeKeywordsMatchingDomain(removedItem);
            _tpHash = '';
            _tpRegex = null;
            ConfigUpdater.saveNow();
            resetAllCachesAndStates();
            self.showThirdPartyPanel();
          }
          break;
        }
        case 'whitelistLog': {
          // 非第三方资源日志: 加白内容标识键(拦截路径按 Set 键放行)
          var logs = LogManager.logs;
          var idx5 = parseInt(index);
          if (!isNaN(idx5) && idx5 >= 0 && idx5 < logs.length && logs[idx5] && logs[idx5].contentIdentifier) {
            var le = logs[idx5];
            // 白名单条目显示名 = 拦截日记当时的原文（元素标识 + 内容）, 用户在
            // 日记白名单面板里看到的就是日记里那句话, 而不是键哈希
            var _rdName = (le.element ? le.element + ' :: ' : '') + _logDisplayName(le.content);
            if (le.moduleKey === 'scriptBlacklistMode' || le.moduleKey === 'redirectBlocker') {
              // redirectBlocker 与 scriptBlacklistMode 一样: 加白内容标识键(REDIRECT_BLOCK_URL),
              // 并同步加域名; 行为拦截判定按内容键放行
              Whitelisting.add(le.contentIdentifier, _rdName);
              if (le.domain && currentConfig.thirdPartyWhitelist.indexOf(le.domain) === -1) {
                currentConfig.thirdPartyWhitelist.push(le.domain);
                _tpHash = '';
                _tpRegex = null;
              }
              ConfigUpdater.saveNow();
              var logDiv = button.closest('.log-entry');
              if (logDiv) {
                logDiv.classList.add('whitelisted');
                button.disabled = true;
                button.textContent = '已加白';
                button.style.backgroundColor = '#999';
              }
              resetAllCachesAndStates();
              OverlayInterceptor.restoreWhitelistedElements();
              break;
            }
            // 移除外联脚本/拦截动态脚本/覆盖层拦截等日志: 加白内容标识键(EXTERNAL_SCRIPT/EVAL_HASH/
            // OVERLAY_/DOCUMENT_WRITE_HASH 等), 与第三方域名白名单互不干扰;
            // 覆盖层日志同时写入备钥组（去名槽位/松散链）, 锚点名或序号逐次变化时备钥仍能命中放行
            if (!currentConfig.whitelist.has(le.contentIdentifier))
              Whitelisting.add(le.contentIdentifier, _rdName);
            var _bakList = Array.isArray(le.altContentIdentifiers) ? le.altContentIdentifiers : [];
            for (var _bi2 = 0; _bi2 < _bakList.length; _bi2++) {
              if (_bakList[_bi2] && !currentConfig.whitelist.has(_bakList[_bi2]))
                Whitelisting.add(_bakList[_bi2], _rdName);
            }
            // 外联脚本日志额外写"结构稳定键"(剥时间戳/随机子域/随机后缀): 广告 URL 每次刷新
            // 都换, 精确键加白后刷新即失配; 结构键保住跨刷新放行（与覆盖层多钥匙同思路）
            if (le.moduleKey === 'removeExternalScripts' && le.url && Utils.externalScriptStructKey) {
              try {
                var _ssKey = Utils.externalScriptStructKey(le.url);
                if (_ssKey && _ssKey !== le.contentIdentifier && !currentConfig.whitelist.has(_ssKey)) {
                  Whitelisting.add(_ssKey, _rdName);
                }
              } catch(e) { _debugCatch(e, 'wl struct key'); }
            }
            // 加白后从已知广告记忆表移除（锁死机制对该结构停止生效）
            if (OverlayInterceptor._knownAdKeys) OverlayInterceptor._knownAdKeys.delete(le.contentIdentifier);
            ConfigUpdater.saveNow();
            var ld = button.closest('.log-entry');
            if (ld) {
              ld.classList.add('whitelisted');
              button.disabled = true;
              button.textContent = '已加白';
              button.style.backgroundColor = '#999';
            }
            resetAllCachesAndStates();
            OverlayInterceptor.restoreWhitelistedElements();
          }
          break;
        }
        case 'whitelistDomain': {
          // 第三方资源日志: 加白域名（该域名全部第三方资源放行）
          var logsD = LogManager.logs;
          var idxD = parseInt(index);
          if (!isNaN(idxD) && idxD >= 0 && idxD < logsD.length && logsD[idxD] && logsD[idxD].domain) {
            var leD = logsD[idxD];
            var domainsToAdd = new Set();
            if (currentConfig.thirdPartyWhitelist.indexOf(leD.domain) === -1) domainsToAdd.add(leD.domain);
            logsD.forEach(function (e) {
              if (e.domain === leD.domain && currentConfig.thirdPartyWhitelist.indexOf(e.domain) === -1) domainsToAdd.add(e.domain);
            });
            domainsToAdd.forEach(function (d) {
              if (currentConfig.thirdPartyWhitelist.indexOf(d) === -1) currentConfig.thirdPartyWhitelist.push(d);
            });
            _tpHash = '';
            _tpRegex = null;
            ConfigUpdater.saveNow();
            Array.from(mask.querySelectorAll('.log-entry')).forEach(function (div) {
              var btn = div.querySelector('.whitelist-btn');
              if (!btn) return;
              var bi = parseInt(btn.dataset.index);
              if (!isNaN(bi) && logsD[bi] && logsD[bi].domain === leD.domain) {
                div.classList.add('whitelisted');
                btn.disabled = true;
                btn.textContent = '域名已加白';
                btn.style.backgroundColor = '#999';
              }
            });
            resetAllCachesAndStates();
            OverlayInterceptor.restoreWhitelistedElements();
          }
          break;
        }
        case 'whitelistLink': {
          // 第三方资源日志: 加白链接(仅该具体 URL 放行, 同域名其他资源仍被拦截)。
          // 只写 THIRD_PARTY_URL 具体 URL 键(shouldBlockResource 同公式),
          // 不写日志 contentIdentifier(SCRIPT_SRC 等), 避免第三方加白污染外联移除路径
          var logsL = LogManager.logs;
          var idxL = parseInt(index);
          if (!isNaN(idxL) && idxL >= 0 && idxL < logsL.length && logsL[idxL] && logsL[idxL].contentIdentifier) {
            var leL = logsL[idxL];
            var _lkKey = leL.url ? _thirdPartyUrlKey(leL.url) : null;
            if (!_lkKey && leL.contentIdentifier && leL.contentIdentifier.indexOf('THIRD_PARTY_URL: ') === 0) {
              _lkKey = leL.contentIdentifier;   // 日志无 url 字段时的兜底（同公式键）
            }
            if (_lkKey && !currentConfig.whitelist.has(_lkKey))
              Whitelisting.add(_lkKey, _logDisplayName(leL.content));
            // 加白后从已知广告记忆表移除（锁死机制对该结构停止生效）
            if (OverlayInterceptor._knownAdKeys && _lkKey) OverlayInterceptor._knownAdKeys.delete(_lkKey);
            ConfigUpdater.saveNow();
            var ldL = button.closest('.log-entry');
            if (ldL) {
              ldL.classList.add('whitelisted');
              var lb = ldL.querySelector('button[data-action="whitelistLink"]');
              if (lb) {
                lb.disabled = true;
                lb.textContent = '链接已加白';
                lb.style.backgroundColor = '#999';
              }
            }
            resetAllCachesAndStates();
            OverlayInterceptor.restoreWhitelistedElements();
          }
          break;
        }
        case 'addToBlacklist': {
          var sid = button.dataset.sid;
          if (sid && _scriptMap && _scriptMap.has(sid)) {
            currentConfig.scriptBlacklist.add(_scriptMap.get(sid));
            ConfigUpdater.saveNow();
            if (scriptBlacklistModule) scriptBlacklistModule.rebuildBlacklist();
            var ld2 = button.closest('.log-entry');
            if (ld2) {
              var tb = ld2.querySelector('button[data-action="addToBlacklist"]');
              if (tb) {
                tb.disabled = true;
                tb.textContent = '已加黑';
                tb.style.backgroundColor = '#999';
              }
              ld2.classList.add('blacklisted');
            }
          }
          break;
        }
        case 'addKeywordWhitelist': {
          var root = mask || (self._shadow ? self._shadow.querySelector('.mask') : null);
          if (!root) break;
          var inp = root.querySelector('#keywordWhitelistInput');
          if (!inp) break;
          var kw = inp.value.trim();
          if (kw) {
            Whitelisting.addKeyword(kw);
            inp.value = '';
            OverlayInterceptor.restoreWhitelistedElements();
            self.showLogsPanel();
          }
          break;
        }
        case 'addWhitelist': {
          // 【面板加白】用户在日志面板点"加白"按钮的落地流程：
          // 每条日志都带一个"内容标识"（页面地址或内容哈希，稳定不变）。点加白后它被存进 GM 存储；
          // 以后再遇到同样的内容，拦截器会先查白名单、直接放行。
          var inp2 = mask.querySelector('#newWhitelist');
          if (!inp2) break;
          var v = inp2.value.trim();
          if (!v) break;
          v = v.replace(/^https?:\/\//, '');  // 去掉用户输入的 http(s):// 前缀，只存域名
          v = v.replace(/\/+$/, '');          // 去掉末尾多余的斜杠
          v = v.replace(/:\d+$/, '');
          var slashIdx = v.indexOf('/');
          if (slashIdx > 0) v = v.substring(0, slashIdx);
          var hasWildcard = v.indexOf('*') !== -1;
          if (hasWildcard) {
            var wcPattern = /^\*\.[a-zA-Z0-9]([a-zA-Z0-9\-]*\.)+[a-zA-Z]{2,}$/;
            if (!wcPattern.test(v)) break;
          } else {
            var domainPattern = /^[a-zA-Z0-9]([a-zA-Z0-9\-]*\.)+[a-zA-Z]{2,}$/;
            if (!domainPattern.test(v)) break;
          }
          if (currentConfig.thirdPartyWhitelist.indexOf(v) === -1) {
            currentConfig.thirdPartyWhitelist.push(v);
            _tpHash = '';
            _tpRegex = null;
            ConfigUpdater.saveNow();
            inp2.value = '';
            resetAllCachesAndStates();
            self.showThirdPartyPanel();
          }
          break;
        }
        case 'addBlacklist': {
          var inp3 = mask.querySelector('#newBlacklistKeyword');
          if (!inp3) break;
          var kw2 = inp3.value.trim();
          if (kw2) {
            currentConfig.scriptBlacklist.add(kw2);
            ConfigUpdater.saveNow();
            if (scriptBlacklistModule) scriptBlacklistModule.rebuildBlacklist();
            inp3.value = '';
            resetAllCachesAndStates();
            self.showScriptBlacklistPanel();
          }
          break;
        }
        case 'addBlacklistFromDomain': {
          var d = decodeURIComponent(button.dataset.domain);
          if (d) {
            currentConfig.scriptBlacklist.add(d);
            ConfigUpdater.saveNow();
            if (scriptBlacklistModule) scriptBlacklistModule.rebuildBlacklist();
            var ld3 = button.closest('.log-entry');
            if (ld3) {
              var tb2 = ld3.querySelector('button[data-action="addBlacklistFromDomain"]');
              if (tb2) {
                tb2.disabled = true;
                tb2.textContent = '域名已加黑';
                tb2.style.backgroundColor = '#999';
              }
              ld3.classList.add('blacklisted');
            }
          }
          break;
        }
        case 'clearAllDiary': {
          self.showConfirm('确定清空所有日记白名单吗？', function () {
            currentConfig.whitelist.clear();
            currentConfig.whitelistDisplayNames.clear();
            ConfigUpdater.saveNow();
            resetAllCachesAndStates();
            self.showDiaryWhitelistPanel();
          });
          break;
        }
        case 'clearAllKeyword': {
          self.showConfirm('确定清空所有关键词白名单吗？', function () {
            currentConfig.keywordWhitelist.clear();
            ConfigUpdater.saveNow();
            resetAllCachesAndStates();
            self.showKeywordWhitelistPanel();
          });
          break;
        }
        case 'clearAllBlacklist': {
          self.showConfirm('确定清空所有脚本黑名单吗？', function () {
            currentConfig.scriptBlacklist.clear();
            currentConfig.removedBuiltinKeywords.clear();
            ConfigUpdater.saveNow();
            if (scriptBlacklistModule) scriptBlacklistModule.rebuildBlacklist();
            resetAllCachesAndStates();
            self.showScriptBlacklistPanel();
          });
          break;
        }
        case 'clearAllThirdParty': {
          self.showConfirm('确定清空所有第三方白名单吗？', function () {
            currentConfig.thirdPartyWhitelist = [];
            _tpHash = '';
            _tpRegex = null;
            ConfigUpdater.saveNow();
            resetAllCachesAndStates();
            self.showThirdPartyPanel();
          });
          break;
        }
        case 'showScriptList': {
          self.showScriptListPanel();
          break;
        }
        case 'enableCSP': {
          currentConfig.modules.manageCSP = true;
          ConfigUpdater.saveNow();
          _location.reload();
          break;
        }
        case 'disableCSP': {
          currentConfig.modules.manageCSP = false;
          ConfigUpdater.saveNow();
          _location.reload();
          break;
        }
        case 'allOn': {
          currentConfig.cspRules.forEach(function (r) { r.enabled = true; });
          currentConfig.modules.manageCSP = true;
          ConfigUpdater.saveNow();
          _location.reload();
          break;
        }
        case 'allOff': {
          currentConfig.cspRules.forEach(function (r) { r.enabled = false; });
          currentConfig.modules.manageCSP = false;
          ConfigUpdater.saveNow();
          _location.reload();
          break;
        }
        case 'loadMoreLogs': {
          self.loadMoreLogs(mask);
          break;
        }
        case 'loadMoreScripts': {
          self.loadMoreScripts(mask);
          break;
        }
      }
      } catch (err) {
        _debugCatch(err, '面板按钮动作异常');
      }
    }
    showAdvancedSettingsPanel() {
      this.closeCurrentMask();
      var self = this;
      var c = currentConfig;
      var infoMap = {
        redirectBlocker: '启用后，尝试拦截所有跳转到第三方、非同源域名的行为。\n\n若关闭严格模式的第三方域名，则允许同主域的子域名跳转。',
        redirectCompat: '需要配合异源跳转拦截功能，开启：允许其他用户脚本（如网页翻译、重定向净化等）劫持相同的浏览器API。如果其他脚本后加载，可能覆盖本脚本的拦截功能。\n\n关闭：锁定API劫持，确保跳转拦截始终生效。如果同时安装了翻译/重定向净化等脚本，它们可能报错失效。',
        inlineStrict: '严格模式：额外拦截内联事件（如onclick）和javascript:URL，适用于拦截点击弹窗、悬浮广告等。\n宽松模式（默认）：仅移除内嵌脚本内容。',
        externalScriptCheck: '外联脚本内容检查模式。开启后：\n①「拦截外联脚本」从"移除全部外联脚本"变为"仅移除内容命中脚本黑名单关键词的外联脚本"（本站脚本直接取回内容检查，几乎不耗流量；第三方网站脚本也尽量取回内容一起检查），可以开启启发黑名单作进一步检查。\n②「脚本黑名单模式」同时获得检查外联脚本内容的能力。\n同时开启「拦截第三方资源」时，第三方域名的脚本由第三方模块负责拦截，本模块不重复处理。\n关闭时：「拦截外联脚本」恢复为无差别拦截外联脚本（开启「拦截第三方资源」时第三方域名脚本仍归第三方模块管）。\n误拦在拦截日记加白对应条目即可放行；关键词在「脚本黑名单」里增删。',
        dynamicScriptStrict: '拦截动态代码中的危险API调用，若同时开启“启发黑名单”，会对脚本内容进行混淆检测并阻止执行，可能会影响部分正常网页的功能。',
        thirdPartyStrict: '严格模式：拦截所有第三方资源（包括子域名和兄弟域名）。\n宽松模式（默认）：只拦截完全无关的第三方域名（主域名不同）。',
        thirdPartyMethod: '严格劫持方式：在宽松模式基础上，额外劫持 appendChild 方法，拦截动态创建的第三方资源。',
        funnelWrite: '写入拦截（深度拦截）：开启后（需同时开启「拦截第三方资源」模块），网页用 document.write 写入的内容会先经过检查——其中指向第三方域名的 script/img/iframe 等资源节点在落地前被剥离，站内其余内容照常显示；整段都是广告时整体拦下。\n\n被剥离的节点会记入拦截日记，加白对应条目后内容完整显示；也可用「第三方白名单」按域名放行。\n\n附带效果：开启时页面加载初期会对已解析的脚本做一次同步预扫，压缩广告脚本抢跑的窗口。',
        residualCleanup: '清空残留容器：清理有明显广告样式且内容为空的容器。除了via以外，某些浏览器或者某些页面如果有拦截日记，但广告仍然显示，可开启，大概率有用，但会导致其他脚本的面板无法打开。',
        iframeUIFix: '开启后，页面内嵌套的窗口（例如视频播放器）会弹出面板，开启本功能后，重新刷新网页后不会再弹出面板，防止同时出现多个面板。',
        builtinBlacklist: '启用后，脚本黑名单模式将使用内置的广告特征关键词列表进行拦截。关闭则不使用内置列表。',
        spoofUA: '模拟桌面端 UA（含 fetch/XHR 层面的 UA 伪装），尝试绕过服务端的桌面端检测，某些网页在手机端访问时会限流或强制进入移动版，可开启试试。',
        DEBUG: '开启后拦截器运行异常时的详细信息会输出到浏览器控制台（F12 → Console），供排查问题使用。一般用户无需开启。',
        logNoiseReduction: '拦截日记降噪（默认开启）：同一位置（结构槽位）的覆盖层广告第一次出现时记录日记，之后的重复插入（即使内容不同）静默隐藏，不刷屏。\n关闭后：每次拦截都会记录日记，方便观察广告的反复注入，但日志面板会被重复条目刷屏。',
        overlayStrict: '覆盖层拦截严格模式：全屏 iframe 即使不是 fixed/absolute 定位、页面有正文也会拦截，拦截更彻底。\n可能误伤正常的全屏播放器/嵌入内容——拦截会记日记，加白对应条目即可恢复；正文加载后才出现的误伤会自动解除。',
        adLinkClickBlock: '可疑链接阻止：识别"孤立大图"广告链接（一张主图+无可视文字），点击、中键、长按打开都会被切断，防止跳到广告站。支持懒加载图、背景图、多图广告位，并叠加跳转参数、短链、悬浮贴边等广告特征。可能误拦正常大图链接——拦截会记日记，加白即可恢复。',
        heuristicBlacklist: '启用后，拦截动态脚本和脚本黑名单模式将额外使用启发式正则规则进行检测，可拦截多种混淆、动态生成、恶意跳转等脚本模式。',
        trackingParamsCleaner: '启用后，自动清洗网页链接中的追踪参数（如 utm_*、fbclid、gclid 等跟踪标记）。',
      };
      this.createPanel({
        title: '高级设置中心',
        contentHtml: `
          <div class="module-grid" style="margin-bottom:8px;">
            <div class="module-switch"><span class="switch-label">异源跳转拦截 <span class="info-icon" data-info="redirectBlocker">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="redirectBlockerEnabled" ${c.redirectBlockerEnabled ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">跳转拦截兼容 <span class="info-icon" data-info="redirectCompat">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="redirectBlockerCompatibilityMode" ${c.redirectBlockerCompatibilityMode ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">清空残留容器 <span class="info-icon" data-info="residualCleanup">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="residualCleanupEnabled" ${c.residualCleanupEnabled ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">内置黑名单 <span class="info-icon" data-info="builtinBlacklist">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="builtinBlacklistEnabled" ${c.builtinBlacklistEnabled ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">启发黑名单 <span class="info-icon" data-info="heuristicBlacklist">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="heuristicBlacklistEnabled" ${c.heuristicBlacklistEnabled ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">清洗追踪参数 <span class="info-icon" data-info="trackingParamsCleaner">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="trackingParamsCleanerEnabled" ${c.trackingParamsCleanerEnabled ? 'checked' : ''}><span class="slider"></span></label></div>
          </div>
          <div style="font-size:12px;color:#888;margin-bottom:6px;padding-left:4px;">严格模式</div>
          <div class="module-grid" style="margin-bottom:8px;">
            <div class="module-switch"><span class="switch-label">内嵌脚本 <span class="info-icon" data-info="inlineStrict">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="inlineScriptStrictMode" ${c.inlineScriptStrictMode ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">外联脚本 <span class="info-icon" data-info="externalScriptCheck">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="staticScriptContentCheck" ${c.staticScriptContentCheck ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">动态脚本 <span class="info-icon" data-info="dynamicScriptStrict">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="dynamicScriptStrictMode" ${c.dynamicScriptStrictMode ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">第三方域名 <span class="info-icon" data-info="thirdPartyStrict">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="thirdPartyStrictMode" ${c.thirdPartyStrictMode ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">第三方劫持 <span class="info-icon" data-info="thirdPartyMethod">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="thirdPartyStrictMethod" ${c.thirdPartyStrictMethod ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">写入拦截 <span class="info-icon" data-info="funnelWrite">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="funnelStrictMode" ${c.funnelStrictMode ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">覆盖层拦截 <span class="info-icon" data-info="overlayStrict">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="overlayStrictMode" ${c.overlayStrictMode ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">可疑链接阻止 <span class="info-icon" data-info="adLinkClickBlock">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="adLinkClickBlock" ${c.adLinkClickBlock ? 'checked' : ''}><span class="slider"></span></label></div>
          </div>
          <div style="font-size:12px;color:#888;margin-bottom:6px;padding-left:4px;">其他</div>
          <div class="module-grid" style="margin-bottom:8px;">
            <div class="module-switch"><span class="switch-label">避免双重面板 <span class="info-icon" data-info="iframeUIFix">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="iframeUIFix" ${c.iframeUIFix ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">桌面UA模拟 <span class="info-icon" data-info="spoofUA">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="spoofUAEnabled" ${c.spoofUAEnabled ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">调试日志 <span class="info-icon" data-info="DEBUG">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="DEBUG" ${c.DEBUG ? 'checked' : ''}><span class="slider"></span></label></div>
            <div class="module-switch"><span class="switch-label">拦截日记降噪 <span class="info-icon" data-info="logNoiseReduction">!</span></span><label class="switch"><input type="checkbox" class="advanced-toggle" data-key="logNoiseReduction" ${c.logNoiseReduction !== false ? 'checked' : ''}><span class="slider"></span></label></div>
          </div>
        `,
        buttons: [],
        onBack: function () { self.showSettings(); },
      });
      var me = this._shadow.querySelector('.mask:last-child');
      if (me) {
        var panelEl = me.querySelector('.panel');
        if (panelEl) {
          panelEl.addEventListener('click', function (e) {
            var infoIcon = e.target.closest('.info-icon');
            if (infoIcon && infoIcon.dataset.info) {
              e.stopPropagation();
              var message = infoMap[infoIcon.dataset.info] || '点击查看详情';
              self.showInfoTooltip(infoIcon, message);
            }
          });
        }
      }
    }
    showParamAdjustmentPanel() {
      this.closeCurrentMask();
      var self = this;
      var c = currentConfig;

      var commaJoin = function(arr) { return (arr || []).join('，'); };
      var commaSplit = function(str) {
        return (str || '').split(/[,，]/).map(function(s){return s.trim();}).filter(function(s){return s.length > 0;});
      };
      var blacklistStr = commaJoin(c.redirectTitleBlacklistKeywords);
      var whitelistStr = commaJoin(c.redirectTitleWhitelistKeywords);
      var modeBoth = !c.redirectBlockAllEnabled && !c.redirectWhitelistBlockMode;
      var modeBlockAll = c.redirectBlockAllEnabled && !c.redirectWhitelistBlockMode;
      var modeWhitelistBlock = c.redirectWhitelistBlockMode;
      var modeInfoMap = {
        modeBoth: '黑名单+白名单（默认）：黑名单匹配时拦截，白名单匹配时放行。白名单优先级高于黑名单。\n\n都不匹配时不拦截。支持通配符 * 匹配域名。',
        modeBlockAll: '全部拦截：忽略页面标题和域名，所有异源跳转一律拦截。\n\n⚠ 开启后黑名单/白名单均不生效。',
        modeWhitelistBlock: '全部拦截（白名单生效）：默认拦截所有异源跳转，但白名单内的关键词匹配时不拦截。\n\n白名单为空时等于全部拦截。支持通配符 * 匹配域名。\n\n💡 如果你只想放行特定的网站（如银行、支付），推荐使用此模式。',
        crossTagThreshold: '需同时开启「脚本黑名单模式」+「启发黑名单」才能生效。\n\n当相同前缀的函数/变量出现次数达到此值时拦截。默认3，范围1~1000，修改后仅当前域名生效，阈值越小误杀率越高。',
        regexSyntax: '📖 re: 开头表示正则匹配，用于黑/白名单关键词。\n\n例①  re:第[\\d零一二三四五六七八九十百千万亿]+[章节页]\n标题或域名包含「第123章」「第一千五百九十七章」，就会命中黑名单 → 异源跳转拦截器将对这类页面生效，防止页面自动跳转到第三方广告/跟踪链接。\n\n例②  re:(小说|阅读|book|novel|章节|笔趣阁)\n标题包含「小说」「阅读」「book」等词时，异源跳转拦截器生效，拦截这类阅读类页面的第三方跳转。\n\n💡 规则会同时匹配页面标题和当前域名。',
      };
      this.createPanel({
        title: '参数调整',
        contentHtml: `
          <div style="font-size:13px;color:#888;margin-bottom:6px;padding-left:4px;">异源跳转拦截 — 标题/域名辅助方式</div>
          <div class="module-grid" style="margin-bottom:10px;" id="redirectModeGrid">
            <div class="module-switch mode-card" style="padding:6px 10px;cursor:pointer;transition:all .15s;${modeBoth ? 'border-color:#007AFF;background:#e8f2ff;' : ''}">
              <span class="switch-label" style="gap:4px;">
                <span style="width:16px;height:16px;border-radius:50%;border:2px solid ${modeBoth ? '#007AFF' : '#bbb'};display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;${modeBoth ? 'background:#007AFF;border-color:#007AFF;' : ''}">
                  <span style="width:6px;height:6px;border-radius:50%;background:#fff;display:${modeBoth ? 'block' : 'none'};"></span>
                </span>
                <input type="radio" name="redirect-mode" value="both" ${modeBoth ? 'checked' : ''} style="display:none;">
                黑名单+白名单 <span class="info-icon" data-info="modeBoth">!</span>
              </span>
            </div>
            <div class="module-switch mode-card" style="padding:6px 10px;cursor:pointer;transition:all .15s;${modeBlockAll ? 'border-color:#ff3b30;background:#fff0ef;' : ''}">
              <span class="switch-label" style="gap:4px;">
                <span style="width:16px;height:16px;border-radius:50%;border:2px solid ${modeBlockAll ? '#ff3b30' : '#bbb'};display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;${modeBlockAll ? 'background:#ff3b30;border-color:#ff3b30;' : ''}">
                  <span style="width:6px;height:6px;border-radius:50%;background:#fff;display:${modeBlockAll ? 'block' : 'none'};"></span>
                </span>
                <input type="radio" name="redirect-mode" value="blockall" ${modeBlockAll ? 'checked' : ''} style="display:none;">
                全部拦截 <span class="info-icon" data-info="modeBlockAll">!</span>
              </span>
            </div>
            <div class="module-switch mode-card" style="padding:6px 10px;cursor:pointer;transition:all .15s;${modeWhitelistBlock ? 'border-color:#ff9500;background:#fff8e1;' : ''}">
              <span class="switch-label" style="gap:4px;">
                <span style="width:16px;height:16px;border-radius:50%;border:2px solid ${modeWhitelistBlock ? '#ff9500' : '#bbb'};display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;${modeWhitelistBlock ? 'background:#ff9500;border-color:#ff9500;' : ''}">
                  <span style="width:6px;height:6px;border-radius:50%;background:#fff;display:${modeWhitelistBlock ? 'block' : 'none'};"></span>
                </span>
                <input type="radio" name="redirect-mode" value="whitelistblock" ${modeWhitelistBlock ? 'checked' : ''} style="display:none;">
                全部拦截（白名单生效） <span class="info-icon" data-info="modeWhitelistBlock">!</span>
              </span>
            </div>
          </div>
          <div style="font-size:13px;color:#888;margin-bottom:6px;padding-left:4px;margin-top:4px;">黑名单关键词（逗号分隔，re:开头=正则） <span class="info-icon" data-info="regexSyntax">!</span></div>
          <div style="margin-bottom:8px;">
            <textarea id="title-blacklist-textarea" style="width:100%;height:70px;padding:6px 8px;border-radius:8px;border:1px solid #ddd;font-size:12px;resize:vertical;box-sizing:border-box;">${escapeHtml(blacklistStr)}</textarea>
            <div style="display:flex;gap:6px;margin-top:4px;">
              <button type="button" class="danger" data-action="resetTitleBlacklist" style="flex:1;padding:4px;font-size:11px;border-radius:6px;">恢复默认</button>
            </div>
          </div>
          <div style="font-size:13px;color:#888;margin-bottom:6px;padding-left:4px;">白名单关键词（用逗号分隔）</div>
          <div style="margin-bottom:8px;">
            <textarea id="title-whitelist-textarea" style="width:100%;height:70px;padding:6px 8px;border-radius:8px;border:1px solid #ddd;font-size:12px;resize:vertical;box-sizing:border-box;">${escapeHtml(whitelistStr)}</textarea>
            <div style="display:flex;gap:6px;margin-top:4px;">
              <button type="button" class="danger" data-action="resetTitleWhitelist" style="flex:1;padding:4px;font-size:11px;border-radius:6px;">恢复默认</button>
            </div>
          </div>
          <div style="font-size:13px;color:#888;margin-bottom:6px;padding-left:4px;">追踪参数（逗号分隔，支持通配符*：<code>utm_*</code>匹配utm_xxx、<code>*_from</code>匹配xxx_from、<code>*key*</code>匹配包含key）</div>
          <div style="margin-bottom:8px;">
            <textarea id="tracking-params-textarea" style="width:100%;height:100px;padding:6px 8px;border-radius:8px;border:1px solid #ddd;font-size:12px;resize:vertical;box-sizing:border-box;font-family:monospace;">${escapeHtml((c.trackingParamKeys || []).join('，'))}</textarea>
            <div style="display:flex;gap:6px;margin-top:4px;">
              <button type="button" class="danger" data-action="resetTrackingParams" style="flex:1;padding:4px;font-size:11px;border-radius:6px;">恢复默认</button>
            </div>
          </div>
          <div style="margin-top:4px;">
            <div class="module-switch" style="margin-bottom:8px;padding:6px 10px;">
              <span class="switch-label">跨标签重复阈值 <span class="info-icon" data-info="crossTagThreshold">!</span>（当前域名）</span>
              <input type="number" id="crossTagThresholdInput" min="2" max="1000" value="${currentConfig.crossTagPatternThreshold}"
                style="width:60px;padding:0 8px;border-radius:8px;border:1px solid #ddd;outline:none;font-size:13px;text-align:center;box-sizing:border-box;min-width:0;flex-shrink:0;height:24px;">
            </div>
          </div>
        `,
        buttons: [],
        onBack: function () { self.showSettings(); },
      });
      var me = this._shadow.querySelector('.mask:last-child');
      if (me) {
        var panelEl = me.querySelector('.panel');
        if (panelEl) {

          var paramSaveNow = function() {

            var blTa = panelEl.querySelector('#title-blacklist-textarea');
            if (blTa) {
              currentConfig.redirectTitleBlacklistKeywords = commaSplit(blTa.value);
            }
            var wlTa = panelEl.querySelector('#title-whitelist-textarea');
            if (wlTa) {
              currentConfig.redirectTitleWhitelistKeywords = commaSplit(wlTa.value);
            }

            var tpTa = panelEl.querySelector('#tracking-params-textarea');
            if (tpTa) {
              currentConfig.trackingParamKeys = commaSplit(tpTa.value);
              rebuildTrackingParamRegex(currentConfig.trackingParamKeys);
            }

            var selectedMode = panelEl.querySelector('input[name="redirect-mode"]:checked');
            if (selectedMode) {
              var mode = selectedMode.value;
              currentConfig.redirectWhitelistBlockMode = (mode === 'whitelistblock');
              currentConfig.redirectBlockAllEnabled = (mode === 'blockall');
              currentConfig.redirectTitleBlacklistEnabled = (mode === 'both');
              currentConfig.redirectTitleWhitelistEnabled = (mode === 'both' || mode === 'whitelistblock');
            }


            ConfigUpdater.saveNow();
            try {
              GM_setValue('adblock_gl_blacklistKeywords', JSON.stringify(currentConfig.redirectTitleBlacklistKeywords));
              GM_setValue('adblock_gl_whitelistKeywords', JSON.stringify(currentConfig.redirectTitleWhitelistKeywords));
              GM_setValue('adblock_gl_trackingParams', JSON.stringify(currentConfig.trackingParamKeys));
            } catch(e) { _debugCatch(e, "保存全局黑名单配置失败"); }

            if (currentConfig.redirectBlockerEnabled) {
              RedirectBlocker.disable();
              RedirectBlocker._initialized = false;
              RedirectBlocker.init();
            }
          };
          var modeCards = panelEl.querySelectorAll('.mode-card');
          var updateModeVisual = function() {
            for (var ci = 0; ci < modeCards.length; ci++) {
              var card = modeCards[ci];
              var radio = card.querySelector('input[type=\"radio\"]');
              var isChecked = radio ? radio.checked : false;
              var dotOuter = card.querySelector('.switch-label > span');
              var dotInner = dotOuter ? dotOuter.querySelector('span') : null;
              var isBlockAll = radio && radio.value === 'blockall';
              var color = isBlockAll ? '#ff3b30' : '#007AFF';
              card.style.borderColor = isChecked ? color : '';
              card.style.background = isChecked ? (isBlockAll ? '#fff0ef' : '#e8f2ff') : '';
              if (dotOuter) {
                dotOuter.style.borderColor = isChecked ? color : '#bbb';
                dotOuter.style.background = isChecked ? color : '';
              }
              if (dotInner) {
                dotInner.style.display = isChecked ? 'block' : 'none';
              }
            }
          };
          for (var ci = 0; ci < modeCards.length; ci++) {
            modeCards[ci].addEventListener('click', function(e) {
              if (e.target.closest('.info-icon')) return;
              e.stopPropagation();
              var radio = this.querySelector('input[type=\"radio\"]');
              if (radio && !radio.checked) {
                radio.checked = true;
                updateModeVisual();
                paramSaveNow();
              }
            });
          }
          var radios = panelEl.querySelectorAll('input[name=\"redirect-mode\"]');
          for (var ri = 0; ri < radios.length; ri++) {
            radios[ri].addEventListener('change', function() { updateModeVisual(); paramSaveNow(); });
          }
          var saveTimer = null;
          var debouncedSave = function() {
            if (saveTimer) _clearTimeout(saveTimer);
            saveTimer = _setTimeout(paramSaveNow, 400);
          };
          var blTa = panelEl.querySelector('#title-blacklist-textarea');
          var wlTa = panelEl.querySelector('#title-whitelist-textarea');
          if (blTa) blTa.addEventListener('input', debouncedSave);
          if (wlTa) wlTa.addEventListener('input', debouncedSave);
          var tpTa = panelEl.querySelector('#tracking-params-textarea');
          if (tpTa) tpTa.addEventListener('input', debouncedSave);

          var thresholdInput = panelEl.querySelector('#crossTagThresholdInput');
          if (thresholdInput) {
            thresholdInput.addEventListener('change', function(e) {
              var val = parseInt(this.value);
              if (isNaN(val) || val < 1) val = 1;
              if (val > 1000) val = 1000;
              this.value = val;
              currentConfig.crossTagPatternThreshold = val;
              ConfigUpdater.saveNow();
              CrossScriptPatternTracker.reset();
            });
          }
          panelEl.addEventListener('click', function (e) {
            var infoIcon = e.target.closest('.info-icon');
            if (infoIcon && infoIcon.dataset.info) {
              e.stopPropagation();
              var msg = modeInfoMap[infoIcon.dataset.info] || '';
              if (msg) self.showInfoTooltip(infoIcon, msg);
              return;
            }
            var btn = e.target.closest('button');
            if (!btn) return;
            var action = btn.getAttribute('data-action') || '';
            if (action === 'resetTitleBlacklist') {
              currentConfig.redirectTitleBlacklistKeywords = [...DEFAULT_REDIRECT_TITLE_BLACKLIST];
              var ta = panelEl.querySelector('#title-blacklist-textarea');
              if (ta) ta.value = commaJoin(DEFAULT_REDIRECT_TITLE_BLACKLIST);
              paramSaveNow();
              GM_notification({ text: '黑名单已恢复默认', title: '广告拦截器' });
            } else if (action === 'resetTitleWhitelist') {
              currentConfig.redirectTitleWhitelistKeywords = [...DEFAULT_REDIRECT_TITLE_WHITELIST];
              ta = panelEl.querySelector('#title-whitelist-textarea');
              if (ta) ta.value = commaJoin(DEFAULT_REDIRECT_TITLE_WHITELIST);
              paramSaveNow();
              GM_notification({ text: '白名单已恢复默认', title: '广告拦截器' });
            } else if (action === 'resetTrackingParams') {
              currentConfig.trackingParamKeys = [...DEFAULT_TRACKING_PARAMS];
              rebuildTrackingParamRegex(currentConfig.trackingParamKeys);
              ta = panelEl.querySelector('#tracking-params-textarea');
              if (ta) ta.value = commaJoin(DEFAULT_TRACKING_PARAMS);
              paramSaveNow();
              GM_notification({ text: '追踪参数已恢复默认', title: '广告拦截器' });
            }
          });
        }
      }
    }
    showSettings() {
      var self = this;

      if (this._checkIframeBlocking()) {
        this._showIframeHint();
        return;
      }


      var ms = Object.keys(MODULE_NAMES).filter(function (k) {
        // elementCssBlock 只是"删了又重建自动改隐藏"日记的模块显示名, 无对应模块开关
        return k !== 'manageCSP' && k !== 'elementCssBlock';
      }).map(function (k) {
        return '<div class="module-switch"><span class="switch-label">' + escapeHtml(MODULE_NAMES[k]) + '</span><label class="switch"><input type="checkbox" class="module-toggle" data-key="' + k + '" ' + (currentConfig.modules[k] ? 'checked' : '') + '><span class="slider"></span></label></div>';
      }).join('');
      var logCount = LogManager.logs.length;
      this.createPanel({
        title: '🛡️广告拦截设置',
        contentHtml: '<div style="font-size:13px;color:#888;margin-bottom:-6px;padding-left:4px;margin-top:4px;">功能模块:</div><div class="module-grid">' + ms + '</div>',
        buttons: [
          { id: 'cssBlockMark', text: '🎯 标记屏蔽元素', class: '' },
          { id: 'cssBlockManage', text: '📋 CSS屏蔽规则 (' + (currentConfig.elementCssRules || []).length + ')', class: '' },
          { id: 'viewLogs', text: '拦截日志 (' + logCount + ')', class: '' },
          { id: 'manageCSP', text: 'CSP策略管理', class: '' },
          { id: 'manageDiaryWhitelist', text: '日记白名单', class: '' },
          { id: 'manageThirdParty', text: '第三方白名单', class: '' },
          { id: 'manageKeywordWhitelist', text: '关键词白名单', class: '' },
          { id: 'manageScriptBlacklist', text: '脚本黑名单', class: '' },
          { id: 'showAdvancedSettings', text: '高级设置中心', class: '' },
          { id: 'showParamAdjustment', text: '高级设置参数调整', class: '' },
          { id: 'closePanel', text: '返回网页', class: 'primary' },
        ],
        isRootPanel: true,
        hideBackButton: true,
        onClose: function () { self._destroyCurrentPanel(); },
      });
    }
    showDiaryWhitelistPanel() {
      var wl = Array.from(currentConfig.whitelist);
      var displayNames = currentConfig.whitelistDisplayNames;
      var prefixMap = {
        'INLINE_EVENT: ': '内联事件: ',
        'JAVASCRIPT_URL: ': 'JS URL: ',
        'SCRIPT_CONTENT: ': '脚本内容: ',
        'SCRIPT_SRC: ': '脚本SRC: ',
        'EXTERNAL_SCRIPT: ': '外联脚本: ',
        'THIRD_PARTY_URL: ': '第三方链接: ',
        'THIRD_PARTY_DETAIL: ': '第三方资源: ',
        'BLACKLIST: ': '脚本黑名单: ',
        'REDIRECT_BLOCK_URL: ': '跳转拦截: ',
        'LOG_DETAIL: ': '拦截详情: ',
        'EVAL_HASH: ': 'Eval调用: ',
        'FUNCTION_HASH: ': 'Function构造器: ',
        'DOCUMENT_WRITE_HASH: ': 'document.write: ',
        'SETTIMEOUT_HASH: ': 'setTimeout: ',
        'SETINTERVAL_HASH: ': 'setInterval: ',
        'REQUESTANIMATIONFRAME_HASH: ': 'requestAnimationFrame: ',
        'OVERLAY_WRITE_BLOCKED:': '覆盖层拦截(document.write广告): ',
        'OVERLAY_INJECTED_STYLE:': '覆盖层拦截(注入伪元素广告): ',
        'OVERLAY_INJECTED_KEYFRAMES:': '覆盖层拦截(注入动画): ',
        'OVERLAY_FULLSCREEN_AD:': '覆盖层拦截(全屏内联iframe): ',
        'OVERLAY_PAGE_REWRITE:': '覆盖层拦截(页面整页重写): ',
      };
      // 一次加白会把多把钥匙写进白名单（外联=精确+结构键, 覆盖层=主键+备钥组）,
      // 面板按"加白动作"(显示名)聚合成一行, 删除某行=整组删除; 只影响渲染与删除
      // 范围, 白名单 Set 内容与所有放行判定路径不变
      var groups = {};
      var groupOrder = [];
      var unnamed = [];
      for (var _wgi = 0; _wgi < wl.length; _wgi++) {
        var _wk = wl[_wgi];
        var _wn = displayNames.get(_wk);
        if (_wn) {
          if (!groups[_wn]) { groups[_wn] = []; groupOrder.push(_wn); }
          groups[_wn].push(_wk);
        } else {
          unnamed.push(_wk);
        }
      }
      var items = [];
      for (var _go = 0; _go < groupOrder.length; _go++) {
        items.push({ name: groupOrder[_go], keys: groups[groupOrder[_go]] });
      }
      for (var _ui = 0; _ui < unnamed.length; _ui++) {
        items.push({ name: null, keys: [unnamed[_ui]] });
      }
      this._wlGroupItems = items;
      this._showListPanel({
        title: '日记白名单 (' + items.length + '项)',
        items: items,
        renderItem: function (item, i) {
          if (item.name) {
            var typeLabel = '';
            var _k0 = item.keys[0];
            for (var prefix in prefixMap) {
              if (prefixMap.hasOwnProperty(prefix) && _k0.startsWith(prefix)) {
                typeLabel = prefixMap[prefix];
                break;
              }
            }
            // 一行=一个加白动作, 内部保留整组多钥匙（精确+结构/备钥）, 展示不暴露
            // "（N项）"字眼, 整组删除语义不变
            return '<div class="whitelist-item" data-index="' + i + '" data-copy-full="' + escapeHtml(typeLabel + item.name) + '">'
                + '<span class="whitelist-text">' + escapeHtml(typeLabel + item.name) + '</span>'
                + '<button type="button" class="danger" data-action="deleteDiaryItem" data-index="' + i + '" style="padding:4px 8px;font-size:10px;border-radius:6px;">删除</button>'
                + '</div>';
          }
          var display = item.keys[0];
          for (prefix in prefixMap) {
            if (prefixMap.hasOwnProperty(prefix) && display.startsWith(prefix)) {
              display = prefixMap[prefix] + item.keys[0].substring(prefix.length);
              break;
            }
          }
          return '<div class="whitelist-item" data-index="' + i + '" data-copy-full="' + escapeHtml(display) + '">'
              + '<span class="whitelist-text">' + escapeHtml(display) + '</span>'
              + '<button type="button" class="danger" data-action="deleteDiaryItem" data-index="' + i + '" style="padding:4px 8px;font-size:10px;border-radius:6px;">删除</button>'
              + '</div>';
        },
        deleteAction: 'deleteDiaryItem',
        clearAction: 'clearAllDiary',
      });
    }
    showCssBlockRulesPanel() {
      var self = this;
      var rules = currentConfig.elementCssRules || [];
      this._showListPanel({
        title: 'CSS屏蔽规则 (' + rules.length + '项)',
        items: rules,
        extraHTML: '<div style="margin-bottom:8px;"><button type="button" data-action="cssRuleAudit" class="primary" style="width:100%;padding:8px 0;border:none;border-radius:8px;background:#007AFF;color:#fff;font-size:13px;font-weight:600;">🩺 规则体检</button></div>',
        renderItem: function (r, i) {
          // 计数与卡片预览同款: 原生走 querySelectorAll, 扩展走扩展引擎 query, Set 去重;
          // 再并入"命中该规则槽位指纹锁"的隐藏元素（重建变体名不匹配静态选择器, 由槽位锁引擎兜底）
          var info = ElementCssBlocker._cssRuleCountInfo(r);
          var cnt = info.total, extN = info.ext, removedN = info.removed;
          var selPrev = escapeHtml(String((r.selectors && r.selectors[0]) || '').slice(0, 100));
          var _modeTxt = ({ remove: '移除', combo: '组合', family: '同类', domain: '域名' })[r.mode] || '隐藏';
          var _isRem = r.mode === 'remove' || r.mode === 'combo';
          var cntTxt = cnt < 0
            ? '<span style="color:#d32f2f;font-size:10px;">计数失败</span>'
            : '<span style="color:#34c759;font-size:10px;">命中 ' + cnt + ' 个' +
              (extN > 0 ? ' <span style="color:#007AFF;">· 扩展引擎命中 ' + extN + '</span>' : '') +
              (_isRem ? ' <span style="color:#ff9500;">· 已移除 <b>' + removedN + '</b> 个</span>' : '') +
              '</span>';
          var _churnTxt = (ElementCssBlocker._churnHideMap && ElementCssBlocker._churnHideMap[r.id])
            ? ' <span style="color:#ff9500;font-size:10px;">· 本页已自动改为隐藏</span>' : '';
          var _narrowBtn = (r.savedHits > 1 && r.narrowSels && r.narrowSels.length)
            ? '<button type="button" data-action="narrowCssRule" data-index="' + i + '" style="padding:4px 8px;font-size:10px;border-radius:6px;border:none;background:#007AFF;color:#fff;">仅隐藏所选</button>'
            : '';
          return '<div class="whitelist-item" data-index="' + i + '" data-copy-full="' + escapeHtml((r.selectors || []).join('\n')) + '">' +
            '<span class="whitelist-text"><b>' + escapeHtml(r.label || '元素') + '</b>' +
            ' <span style="color:#007AFF;font-size:10px;">[' + _modeTxt + ']</span>' +
            ' <span style="font-size:10px;">' + cntTxt + _churnTxt + '</span>' +
            '<div style="font-family:monospace;font-size:10px;color:#999;word-break:break-all;">' + selPrev + '</div></span>' +
            _narrowBtn +
            '<button type="button" class="danger" data-action="deleteCssRule" data-index="' + i + '" style="padding:4px 8px;font-size:10px;border-radius:6px;">删除</button>' +
            '</div>';
        },
        deleteAction: 'deleteCssRule',
        clearAction: 'clearAllCssRules',
        onBack: function () { self.showSettings(); },
      });
    }
    // 规则体检: 三类健康度问题一屏列出, 每条带一键处置 ——
    // ① 零命中规则(类名/ID 轮换后失配的失效键, 可删) ② remove/combo 规则正处
    // 移除规则删了又重建循环（可一键改隐藏） ③ 宽扩展键(基底为 * 或裸标签的 :matches-css 规则,
    // 可按实际命中标签收窄)
    showCssRuleAuditPanel() {
      var self = this;
      var rules = currentConfig.elementCssRules || [];
      var _zero = [], _churn = [], _wide = [];
      for (var i = 0; i < rules.length; i++) {
        var r = rules[i];
        if (!r || !r.selectors || !r.selectors.length) continue;
        var info = ElementCssBlocker._cssRuleCountInfo(r);
        var _isRem = r.mode === 'remove' || r.mode === 'combo';
        if (info.total === 0 && !(info.removed > 0)) _zero.push(i);
        if (_isRem && ElementCssBlocker._churnHideMap && ElementCssBlocker._churnHideMap[r.id]) _churn.push(i);
        for (var j = 0; j < r.selectors.length; j++) {
          var s = String(r.selectors[j] || '');
          if (!_cssIsExtSelector(s)) continue;
          var base = s.replace(/:matches-css(?:-before|-after)?\([^)]*\)/g, '').trim();
          if (base === '*' || /^[a-zA-Z]+$/.test(base)) { _wide.push(i); break; }
        }
      }
      var _sec = function (title, color, idxList, renderRow) {
        var html = '<div style="margin:10px 0 4px;font-size:12px;font-weight:600;color:' + color + ';">' + title + '（' + idxList.length + '）</div>';
        if (!idxList.length) {
          return html + '<div style="font-size:11px;color:#999;margin-bottom:6px;">无</div>';
        }
        for (var k = 0; k < idxList.length; k++) {
          var rr = rules[idxList[k]];
          html += '<div class="whitelist-item" data-index="' + idxList[k] + '" data-copy-full="' + escapeHtml(String(rr.selectors[0] || '')) + '"><span class="whitelist-text"><b style="font-size:11px;">' + escapeHtml((rr.label || rr.id || '规则').slice(0, 40)) + '</b>' +
            '<div style="font-family:monospace;font-size:9px;color:#999;word-break:break-all;">' + escapeHtml(String(rr.selectors[0] || '').slice(0, 90)) + '</div></span>' +
            renderRow(idxList[k], rr) + '</div>';
        }
        return html;
      };
      var _downgradeBtn = function (idx) {
        return '<button type="button" data-action="auditDowngradeRule" data-index="' + idx + '" style="padding:4px 8px;font-size:10px;border-radius:6px;border:none;background:#ff9500;color:#fff;">改为隐藏</button>';
      };
      var _narrowBtnHtml = function (idx, rr) {
        var s = String(rr.selectors[0] || '');
        var base = s.replace(/:matches-css(?:-before|-after)?\([^)]*\)/g, '').trim();
        var tag = null;
        try {
          var hits = (typeof _ExtCss !== 'undefined' && _ExtCss) ? _ExtCss.query(s) : [];
          if (hits.length) {
            tag = (hits[0].tagName || '').toLowerCase();
            for (var h = 1; h < Math.min(hits.length, 20); h++) {
              if ((hits[h].tagName || '').toLowerCase() !== tag) { tag = null; break; }
            }
          }
        } catch (e) {}
        if (tag && base === '*') {
          return '<button type="button" data-action="auditNarrowExtRule" data-index="' + idx + '" data-tag="' + tag + '" style="padding:4px 8px;font-size:10px;border-radius:6px;border:none;background:#007AFF;color:#fff;">收窄为 ' + escapeHtml(tag) + '</button>';
        }
        return '<button type="button" data-action="deleteCssRule" data-from="audit" data-index="' + idx + '" style="padding:4px 8px;font-size:10px;border-radius:6px;">删除</button>';
      };
      var contentHtml =
        _sec('零命中规则（类名/ID 已轮换失配）', '#ff9500', _zero, function (idx) {
          return '<button type="button" class="danger" data-action="deleteCssRule" data-from="audit" data-index="' + idx + '" style="padding:4px 8px;font-size:10px;border-radius:6px;">删除</button>';
        }) +
        _sec('删了又重建的移除规则（本页已自动改为隐藏）', '#d32f2f', _churn, _downgradeBtn) +
        _sec('宽扩展键（基底为 * 或裸标签）', '#8e8e93', _wide, _narrowBtnHtml);
      this.createPanel({
        title: '规则体检',
        contentHtml: '<div class="sub-panel">' + contentHtml + '</div>',
        buttons: [],
        onBack: function () { self.showCssBlockRulesPanel(); },
      });
    }
    showKeywordWhitelistPanel() {
      var kws = Array.from(currentConfig.keywordWhitelist);
      this._showListPanel({
        title: '关键词白名单 (' + kws.length + '项)',
        items: kws,
        renderItem: function (kw, i) {
          return '<div class="whitelist-item" data-index="' + i + '" data-copy-full="' + escapeHtml(kw) + '"><span class="whitelist-text">' + escapeHtml(kw) + '</span><button type="button" class="danger" data-action="deleteKeywordItem" data-index="' + i + '" style="padding:4px 8px;font-size:10px;border-radius:6px;">删除</button></div>';
        },
        deleteAction: 'deleteKeywordItem',
        clearAction: 'clearAllKeyword',
      });
    }
    showScriptBlacklistPanel() {
      var self = this;
      var bl = Utils.getActiveBlacklistArray();
      var listHtml = bl.length === 0
        ? '<div style="text-align:center;color:#999;margin:20px 0;font-size:14px;">列表为空</div>'
        : '<div class="copy-hint">长按内容可复制</div>' + bl.map(function (kw, i) {
          return '<div class="whitelist-item" data-index="' + i + '" data-copy-full="' + escapeHtml(kw) + '"><span class="whitelist-text">' + escapeHtml(kw) + '</span><button type="button" class="danger" data-action="deleteBlacklistItem" data-index="' + i + '" style="padding:4px 8px;font-size:10px;border-radius:6px;">删除</button></div>';
        }).join('');
      var contentHtml = '<div class="sub-panel">' + listHtml + '</div>' +
        '<div style="display:flex;gap:8px;margin:10px 0;"><input type="text" id="newBlacklistKeyword" placeholder="输入关键词或脚本内容..." style="flex:1;padding:8px;border-radius:8px;border:1px solid #ddd;outline:none;font-size:13px;"><button type="button" data-id="addBlacklist" class="primary" style="padding:8px 16px;">添加</button></div>' +
        '<div style="display:flex;gap:8px;"><button type="button" data-action="clearAllBlacklist" class="danger" style="flex:1;">清空全部</button><button type="button" data-id="showScriptList" class="primary" style="flex:1;">显示所有脚本</button></div>';
      this.createPanel({
        title: '脚本黑名单 (' + bl.length + '项)',
        contentHtml: contentHtml,
        buttons: [],
        onBack: function () { self.showSettings(); },
      });
      var selfPanel = this;
      _setTimeout(function () {
        var me = selfPanel._shadow && selfPanel._shadow.querySelector('.mask:last-child');
        if (!me) return;
        var inp = me.querySelector('#newBlacklistKeyword');
        if (inp) {
          inp.focus();
          inp.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
              var b = me.querySelector('[data-id="addBlacklist"]');
              if (b) b.click();
            }
          });
        }
      }, 0);
    }
    showScriptListPanel() {
      this.closeCurrentMask();
      var self = this;
      var scripts = Array.from(_document.scripts);
      _scriptMap = new Map();
      var items = scripts.map(function (s, i) {
        var sContent = s.src || s.textContent;
        var sid = generateContentHash(sContent);
        _scriptMap.set(sid, sContent);
        return {
          index: i + 1,
          isExternal: !!s.src,
          content: Utils.truncateString(s.src ? s.src : s.textContent, CONFIG.LOG_DETAIL_LENGTH),
          script: s,
          sid: sid
        };
      });
      var bls = Utils.getActiveBlacklistSet();
      var initial = items.slice(0, CONFIG.PAGE_SIZE);
      var renderItem = function (item) {
        var sContent = item.isExternal ? item.script.src : item.script.textContent;
        var isBL = bls.has(sContent);
        var domainHint = '', extractBtn = '', isDBL = false, domainEnc = '';
        if (item.isExternal && item.script.src) {
          try {
            var d = new _URL(item.script.src, _location.href).hostname;
            if (d) {
              domainHint = '<div style="font-size:11px;color:#999;margin-top:4px;">域名: ' + escapeHtml(d) + '</div>';
              isDBL = bls.has(d);
              domainEnc = encodeURIComponent(d);
              extractBtn = '<button type="button" data-action="addBlacklistFromDomain" data-domain="' + domainEnc + '" data-index="' + item.index + '" style="position:absolute;top:8px;right:80px;background:' + (isDBL ? '#999' : '#FF9500') + ';color:#fff;border:none;border-radius:5px;padding:3px 8px;font-size:10px;cursor:pointer;z-index:1;" ' + (isDBL ? 'disabled' : '') + '>' + (isDBL ? '域名已加黑' : '加黑域名') + '</button>';
            }
          } catch(e) { _debugCatch(e, "domainEnc"); }
        }
        var cls = 'log-entry' + (isBL || isDBL ? ' blacklisted' : '');
        return ('<div class="' + cls + '" data-copy-sid="' + item.sid + '" style="border-left-color:' + (item.isExternal ? '#FF3B30' : '#007AFF') + ';position:relative;"><div class="log-module">脚本 #' + item.index + ' - ' + (item.isExternal ? '外联' : '内嵌') + '</div><div class="log-content" style="max-height:none;white-space:pre-wrap;word-break:break-all;padding-right:150px;">' + escapeHtml(item.content) + '</div>' + domainHint + extractBtn + '<button type="button" data-action="addToBlacklist" data-sid="' + item.sid + '" data-index="' + item.index + '" style="position:absolute;top:8px;right:8px;background:' + (isBL ? '#999' : '#FF3B30') + ';color:#fff;border:none;border-radius:5px;padding:3px 8px;font-size:10px;cursor:pointer;z-index:1;" ' + (isBL ? 'disabled' : '') + '>' + (isBL ? '已加黑' : '加黑') + '</button></div>');
      };
      this.createPanel({
        title: '当前网页脚本列表 (共' + scripts.length + '个)',
        contentHtml: '<div style="margin-bottom:10px;font-size:13px;color:#666;text-align:center;">点击「加黑」将整个脚本内容添加到脚本黑名单；「加黑域名」将脚本域名加入黑名单；长按脚本可复制全文</div><div class="sub-panel" style="max-height:60vh;" data-panel="scriptList">' + initial.map(renderItem).join('') + '</div>' + (items.length > CONFIG.PAGE_SIZE ? '<button type="button" data-id="loadMoreScripts" class="primary" style="width:100%;margin-top:8px;">加载更多 (' + CONFIG.PAGE_SIZE + '/' + items.length + ')</button>' : ''),
        buttons: [],
        onBack: function () { self.showScriptBlacklistPanel(); },
      });
    }
    loadMoreScripts(mask) {
      var scripts = Array.from(_document.scripts);
      var bls = Utils.getActiveBlacklistSet();
      var container = mask.querySelector('[data-panel="scriptList"]');
      var btn = mask.querySelector('[data-id="loadMoreScripts"]');
      if (!container || !scripts.length) return;
      var cur = container.children.length;
      if (cur >= scripts.length) {
        if (btn) btn.remove();
        return;
      }
      if (!_scriptMap) _scriptMap = new Map();
      var batch = scripts.slice(cur, cur + CONFIG.PAGE_SIZE);
      var htmlBatch = batch.map(function (s, idx) {
        var ri = cur + idx + 1;
        var sContent = s.src || s.textContent;
        if (!_scriptMap.has(generateContentHash(sContent))) {
          _scriptMap.set(generateContentHash(sContent), sContent);
        }
        var isExt = !!s.src;
        var content = Utils.truncateString(isExt ? s.src : s.textContent, CONFIG.LOG_DETAIL_LENGTH);
        var isBL = bls.has(sContent);
        var domainHint = '', extractBtn = '', isDBL = false;
        if (isExt && s.src) {
          try {
            var d = new _URL(s.src, _location.href).hostname;
            if (d) {
              domainHint = '<div style="font-size:11px;color:#999;margin-top:4px;">域名: ' + escapeHtml(d) + '</div>';
              isDBL = bls.has(d);
              extractBtn = '<button type="button" data-action="addBlacklistFromDomain" data-domain="' + encodeURIComponent(d) + '" data-index="' + ri + '" style="position:absolute;top:8px;right:80px;background:' + (isDBL ? '#999' : '#FF9500') + ';color:#fff;border:none;border-radius:5px;padding:3px 8px;font-size:10px;cursor:pointer;z-index:1;" ' + (isDBL ? 'disabled' : '') + '>' + (isDBL ? '域名已加黑' : '加黑域名') + '</button>';
            }
          } catch(e) { _debugCatch(e, "isDBL"); }
        }
        var cls = 'log-entry' + (isBL || isDBL ? ' blacklisted' : '');
        return '<div class="' + cls + '" data-copy-sid="' + generateContentHash(sContent) + '" style="border-left-color:' + (isExt ? '#FF3B30' : '#007AFF') + ';position:relative;"><div class="log-module">脚本 #' + ri + ' - ' + (isExt ? '外联' : '内嵌') + '</div><div class="log-content" style="max-height:none;white-space:pre-wrap;word-break:break-all;padding-right:150px;">' + escapeHtml(content) + '</div>' + domainHint + extractBtn + '<button type="button" data-action="addToBlacklist" data-sid="' + generateContentHash(sContent) + '" data-index="' + ri + '" style="position:absolute;top:8px;right:8px;background:' + (isBL ? '#999' : '#FF3B30') + ';color:#fff;border:none;border-radius:5px;padding:3px 8px;font-size:10px;cursor:pointer;z-index:1;" ' + (isBL ? 'disabled' : '') + '>' + (isBL ? '已加黑' : '加黑') + '</button></div>';
      }).join('');
      var tmp = _document.createElement('div');
      tmp.innerHTML = htmlBatch;
      var frag = _document.createDocumentFragment();
      while (tmp.firstChild) frag.appendChild(tmp.firstChild);
      container.appendChild(frag);
      var nc = container.children.length;
      if (nc >= scripts.length) {
        if (btn) btn.remove();
      } else if (btn) {
        btn.textContent = '加载更多 (' + nc + '/' + scripts.length + ')';
      }
    }
    showLogsPanel() {
      this.closeCurrentMask();
      var self = this;
      var logs = LogManager.logs;
      var initial = logs.slice(0, CONFIG.PAGE_SIZE);
      this.createPanel({
        title: '拦截日志 (' + logs.length + '条)',
        contentHtml: '<div style="margin-bottom:10px;font-size:13px;color:#666;text-align:center;">关键词加白（添加关键词，该资源加入白名单放行）:</div><div style="display:flex;gap:8px;margin-bottom:15px;"><input type="text" id="keywordWhitelistInput" placeholder="输入关键词，如: abc" style="flex:1;padding:8px;border-radius:8px;border:1px solid #ddd;outline:none;font-size:13px;"><button type="button" data-id="addKeywordWhitelist" class="primary" style="padding:8px 16px;">添加</button></div><div class="copy-hint">长按日志内容可复制</div><div class="sub-panel" data-panel="logList">' + initial.map(function (l, i) { return self.renderLogItem(l, i); }).join('') + '</div>' + (logs.length > CONFIG.PAGE_SIZE ? '<button type="button" data-id="loadMoreLogs" class="primary" style="width:100%;margin-top:8px;">加载更多 (' + CONFIG.PAGE_SIZE + '/' + logs.length + ')</button>' : ''),
        buttons: [],
        onBack: function () { self.showSettings(); },
      });
      _setTimeout(function () {
        var me = self._shadow && self._shadow.querySelector('.mask:last-child');
        if (!me) return;
        var inp = me.querySelector('#keywordWhitelistInput');
        if (inp) {
          inp.focus();
          inp.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
              var b = me.querySelector('[data-id="addKeywordWhitelist"]');
              if (b) b.click();
            }
          });
        }
      }, 0);
    }
    loadMoreLogs(mask) {
      var self = this;
      var logs = LogManager.logs;
      var container = mask.querySelector('[data-panel="logList"]');
      var btn = mask.querySelector('[data-id="loadMoreLogs"]');
      var cur = container.children.length;
      if (cur >= logs.length) {
        if (btn) btn.remove();
        return;
      }
      var batch = logs.slice(cur, cur + CONFIG.PAGE_SIZE);
      var htmlBatch = batch.map(function (l, i) {
        return self.renderLogItem(l, cur + i);
      }).join('');
      var tmp = _document.createElement('div');
      tmp.innerHTML = htmlBatch;
      var frag = _document.createDocumentFragment();
      while (tmp.firstChild) frag.appendChild(tmp.firstChild);
      container.appendChild(frag);
      var nc = container.children.length;
      if (nc >= logs.length) {
        if (btn) btn.remove();
      } else if (btn) {
        btn.textContent = '加载更多 (' + nc + '/' + logs.length + ')';
      }
    }
    showCSPPanel() {
      this.closeCurrentMask();
      var self = this;
      var rulesHtml = currentConfig.cspRules.map(function (r) {
        return ('<div class="csp-rule"><span class="csp-name">' + escapeHtml(r.name) + '</span><label class="switch"><input type="checkbox" class="csp-toggle" data-id="' + r.id + '" ' + (r.enabled ? 'checked' : '') + '><span class="slider"></span></label></div>');
      }).join('');
      this.createPanel({
        title: 'CSP策略管理',
        contentHtml: '<div style="margin-bottom:10px;font-size:13px;color:#666;text-align:center;">当前状态: ' + (currentConfig.modules.manageCSP ? '✅已启用' : '❌已禁用') + '</div><div class="sub-panel">' + rulesHtml + '</div><div class="btn-group"><button type="button" data-id="enableCSP" ' + (currentConfig.modules.manageCSP ? 'disabled' : '') + '>启用CSP</button><button type="button" data-id="disableCSP" ' + (!currentConfig.modules.manageCSP ? 'disabled' : '') + '>禁用CSP</button></div><div class="btn-group"><button type="button" data-id="allOn">全部开启</button><button type="button" data-id="allOff">全部关闭</button></div>',
        buttons: [],
        onBack: function () { self.showSettings(); },
      });
    }
    showThirdPartyPanel() {
      var self = this;
      var wl = currentConfig.thirdPartyWhitelist;
      var extraHTML = '<div style="display:flex;gap:8px;margin-bottom:10px;">'
        + '<input type="text" id="newWhitelist" placeholder="域名(如 example.com) 或通配符(如 *.example.com)" '
        + 'style="flex:1;padding:8px;border-radius:8px;border:1px solid #ddd;outline:none;font-size:13px;">'
        + '<button type="button" data-id="addWhitelist" class="primary" style="padding:8px 16px;">添加</button></div>'
        + '<div style="font-size:11px;color:#999;margin-bottom:8px;padding-left:4px;">'
        + '💡 输入完整域名精确匹配，或使用 *.example.com 通配符匹配所有子域名</div>';
      this._showListPanel({
        title: '第三方白名单 (' + wl.length + '项)',
        items: wl,
        renderItem: function (item, i) {
          return '<div class="whitelist-item" data-index="' + i + '" data-copy-full="' + escapeHtml(item) + '"><span class="whitelist-text">' + escapeHtml(item) + '</span><button type="button" class="danger" data-action="deleteThirdPartyItem" data-index="' + i + '" style="padding:4px 8px;font-size:10px;border-radius:6px;">删除</button></div>';
        },
        deleteAction: 'deleteThirdPartyItem',
        clearAction: 'clearAllThirdParty',
        extraHTML: extraHTML,
      });
      _setTimeout(function () {
        var me = self._shadow && self._shadow.querySelector('.mask:last-child');
        if (!me) return;
        var inp = me.querySelector('#newWhitelist');
        if (inp) {
          inp.focus();
          inp.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
              var b = me.querySelector('[data-id="addWhitelist"]');
              if (b) b.click();
            }
          });
        }
      }, 0);
    }
  }

  // ======================== 中央调度器（批量处理元素） ========================
    // 批量元素处理的时间切片调度（requestIdleCallback），避免长页面卡顿。
  class CentralScheduler {
    constructor(modules) {
      this.modules = modules;
      this.elementCheckCache = new WeakSet();
    }
    shouldProcessElement(el) {
      return (
        Utils.isElement(el) &&
        !this.elementCheckCache.has(el) &&
        !ProcessedElementsCache.isProcessed(el) &&
        !Utils.isParentProcessed(el) &&
        !_isSafe(el)
      );
    }
    processElement(el) {
      if (!this.shouldProcessElement(el)) return false;
      this.elementCheckCache.add(el);
      for (var i = 0; i < this.modules.length; i++) {
        var m = this.modules[i];
        if (m.enabled && m.checkElement(el)) {
          ProcessedElementsCache.markAsProcessed(el);
          return true;
        }
      }
      return false;
    }
    clearCache() {
      this.elementCheckCache = new WeakSet();
      urlCache.clear();
    }
  }

  // ======================== 全局变量与初始化 ========================
    // UIController：模块状态同步 / 启动入口（safeInit 在 documentElement 就绪后调用）。
  let inlineScriptsModule = null;
  let thirdPartyModule = null;
  let scriptBlacklistModule = null;
  let centralScheduler = null;


  var _safeInitMO = null;
  var _reinitGuard = false;


  function registerAllMenuCommands() {
    // 【菜单注册】向油猴注册设置面板/开关/清空白名单等菜单命令；
    // 面板首次打开时才初始化 UI（懒加载）。
    if (menuCommandsRegistered) return;
    menuCommandsRegistered = true;
    var ensureUI = function (callback) {
      if (!UIController.uiInitialized) UIController.init();
      callback();
    };
    GM_registerMenuCommand('1 ⚙️ 广告拦截设置面板', function () {
      ensureUI(function () {
        if (!UIController.panelManager) {
          GM_notification({ text: '面板初始化失败，请刷新页面重试', title: '广告拦截器' });
          return;
        }
        UIController.panelManager.showSettings();
      });
    });
    GM_registerMenuCommand(
      '2 🍎 苹果设备模拟 ' + (currentConfig.simplePlatformSpoof ? '✅ 已启用' : '❌ 已禁用'),
      function () {
        currentConfig.simplePlatformSpoof = !currentConfig.simplePlatformSpoof;
        if (currentConfig.simplePlatformSpoof) {
          currentConfig.spoofUAEnabled = false;
        }
        ConfigUpdater.saveNow();
        GM_notification({
          text: '平台模拟已' + (currentConfig.simplePlatformSpoof ? '启用' : '禁用') + '，刷新页面生效',
          title: '广告拦截器'
        });
        _location.reload();
      }
    );

    GM_registerMenuCommand('3 🗑️ 清空所有白名单', function () {
      ensureUI(function () {
        if (!UIController.panelManager) {
          GM_notification({ text: '面板初始化失败，请刷新页面重试', title: '广告拦截器' });
          return;
        }
        // 统一面板内弹窗样式（与日记白名单"清空全部"的确认弹窗一致）
        UIController.panelManager.showConfirm('确定清空当前域名的所有白名单（包括日记白名单、第三方白名单、关键词白名单等）吗？', function () {
          Whitelisting.clearAllWhitelists();
          resetAllCachesAndStates();
          GM_notification({ text: '所有白名单已清空', title: '广告拦截器' });
          _location.reload();
        });
      });
    });
    GM_registerMenuCommand('4 🔄 当前域名重置所有设置', function () {
      ensureUI(function () {
        if (!UIController.panelManager) {
          GM_notification({ text: '面板初始化失败，请刷新页面重试', title: '广告拦截器' });
          return;
        }
        UIController.panelManager.showConfirm('确定重置当前域名的所有设置吗？\n\n这将清空当前域名的所有白名单并关闭所有模块，恢复到初始状态。', function () {
          StorageManager.resetAllSettings();
          resetAllCachesAndStates();
          GM_notification({ text: '当前域名设置已重置', title: '广告拦截器' });
          _location.reload();
        });
      });
    });
    GM_registerMenuCommand('5 ⚠️ 全局重置所有设置', function () {
      ensureUI(function () {
        if (!UIController.panelManager) {
          GM_notification({ text: '面板初始化失败，请刷新页面重试', title: '广告拦截器' });
          return;
        }
        UIController.panelManager.showConfirm('⚠️ 警告：此操作将完全清空本脚本存储的所有配置和数据！\n\n相当于将脚本重新安装，确定要全局重置吗？', function () {
          try {
            var allKeys = GM_listValues();
            for (var i = 0; i < allKeys.length; i++) {
              GM_deleteValue(allKeys[i]);
            }
          } catch(e) { _debugCatch(e, "allKeys.length"); }
          GM_notification({ text: '全局设置已完全清空，正在刷新页面...', title: '广告拦截器' });
          _location.reload();
        });
      });
    });

  }


  const UIController = {
    uiInitialized: false,
    modulesInitialized: false,
    mutationObserver: null,
    batchProcessingQueue: [],
    batchSize: CONFIG.BATCH_SIZE,
    isProcessingBatch: false,
    lastProcessTime: 0,
    emaFrameTime: 16,
    panelManager: null,
    modules: [],
    _lastIframeMessage: 0,
    _iframeMsgHandler: null,


    _setupIframeMessageListener: function() {
      var self = this;
      // 重复挂载（页面重写重建）时先移除旧监听, 避免累积
      if (this._iframeMsgHandler) {
        try { _globals.removeEventListener('message', this._iframeMsgHandler); } catch(e) {}
      }
      this._iframeMsgHandler = function(e) {
        if (!e.data || e.data.source !== 'adblock-iframe') return;
        if (e.data.type !== 'adblock-show-panel') return;
        if (self._lastIframeMessage && Date.now() - self._lastIframeMessage < 1000) return;
        self._lastIframeMessage = Date.now();
        if (!isInIframe() && self.panelManager) {
          self.panelManager.showSettings();
        }
      };
      _globals.addEventListener('message', this._iframeMsgHandler);
    },

    init: function () {
      if (this.uiInitialized) return;
      this.uiInitialized = true;
      this.modulesInitialized = true;
      this.applyInitialModuleStates();
      this.panelManager = new PanelManager();
      this.createModules();
      this.applyModuleSettings();

    },
    startDOMDependent: function () {
      if (this._domStarted) return;
      this._domStarted = true;
      this.setupObservers();
      this.setupResourceScan();
      if (Utils.isAnyModuleEnabled() && currentConfig.residualCleanupEnabled) ResidualCleaner.init();
      else ResidualCleaner.stop();
      OverlayInterceptor.init();
      this._setupIframeMessageListener();
    },
    applyInitialModuleStates: function () {
      // 启动时按存储配置应用各模块开关（与 applyModuleSettings 联动）。
      Object.keys(DEFAULT_MODULE_STATE).forEach(function (k) {
        if (currentConfig.modules[k] === undefined) currentConfig.modules[k] = DEFAULT_MODULE_STATE[k];
      });
    },
    createModules: function () {
      inlineScriptsModule = new RemoveInlineScriptsModule();
      thirdPartyModule = new ThirdPartyInterceptionModule();
      scriptBlacklistModule = new ScriptBlacklistModeModule();
      this.modules = [
        inlineScriptsModule,
        new RemoveExternalScriptsModule(),
        scriptBlacklistModule,
        thirdPartyModule,
      ];
    },
    applyModuleSettings: function () {
      this.modules.forEach(function (m) {
        m.init();
      });
      DynamicScriptInterceptor.init();
      CSPModule.init();
      centralScheduler = new CentralScheduler(this.modules);
    },
    setupObservers: function () {
      if (!Utils.isAnyModuleEnabled()) return;
      var self = this;
      this.mutationObserver = new _MutationObserver(function (ms) {
        for (var i = 0; i < ms.length; i++) {
          var m = ms[i];
          for (var j = 0; j < m.addedNodes.length; j++) {
            var n = m.addedNodes[j];
            if (n.nodeType === _Node.ELEMENT_NODE && !ProcessedElementsCache.isProcessed(n) && !Utils.isParentProcessed(n)) self.addToBatchProcessingQueue(n);
          }
        }
      });
      this.mutationObserver.observe(_document.documentElement, { childList: true, subtree: true });
      this.processExistingElementsBatch();
    },
    setupResourceScan: function () {
      var self = this;
      if (currentConfig.modules.interceptThirdParty) {
        var _run = function () {
          _lateScanTimers.push(_setTimeout(function () {
            self.scanExistingResources();
          }, 1000));
        };

        if (_document.readyState && _document.readyState !== 'loading') {
          _run();
        } else {
          _document.addEventListener('DOMContentLoaded', _run);
        }
      }
    },
    scanExistingResources: function () {
      try {
        Array.from(_document
          .querySelectorAll('script[src], iframe[src], img[src], img[data-src], embed[src], object[data], link[href]'))
          .forEach(function (el) {
            if (ProcessedElementsCache.isProcessed(el) || Utils.isParentProcessed(el)) return;
            var t = el.tagName;
            var u;
            if (t === 'SCRIPT') u = el.src;
            else if (t === 'IFRAME') u = el.src;
            else if (t === 'IMG') u = el.src || el.getAttribute('data-src');
            else if (t === 'EMBED') u = el.src;
            else if (t === 'OBJECT') u = el.data;
            else if (t === 'LINK') u = el.href;
            if (u && shouldBlockResource(u)) {
              var ci = Utils.getContentIdentifier(el);
              if (ci && !currentConfig.whitelist.has(ci)) {
                // 扫描日志用 THIRD_PARTY_URL 键(与 shouldBlockResource 同公式), 可加白
                var _scanAbs = u;
                try { _scanAbs = new _URL(u, _location.href).href; } catch(e) {}
                LogManager.add('interceptThirdParty', el, {
                  type: 'THIRD_PARTY_SCAN',
                  detail: '扫描发现: ' + t + ': ' + Utils.truncateString(u, CONFIG.LOG_DETAIL_LENGTH),
                  elementContentIdentifier: 'THIRD_PARTY_URL: ' + Utils.truncateString(_scanAbs, CONFIG.LOG_DETAIL_LENGTH)
                });
              }
            }
          });
      } catch(e) { _debugCatch(e, "});"); }
    },
    addToBatchProcessingQueue: function (el) {
      if (_isSafe(el)) {
        ProcessedElementsCache.markAsProcessed(el);
        return;
      }
      this.batchProcessingQueue.push(el);
      if (!this.isProcessingBatch) this.processBatch();
    },
    processBatch: function () {
      var self = this;
      if (!centralScheduler) return;
      this.isProcessingBatch = true;
      var bs = this.batchSize;
      var alpha = 0.2;
      // 每帧处理预算(ms): 手机端 getComputedStyle 等重操作累积超过预算即让出主线程,
      // 保证帧率与点击/面板交互响应（批处理不持续占满主线程）
      var _FRAME_BUDGET = 8;
      var chunk = function () {
        var _tStart = performance.now();
        try {
          var now = performance.now();
          if (self.lastProcessTime > 0) {
            self.emaFrameTime = alpha * (now - self.lastProcessTime) + (1 - alpha) * self.emaFrameTime;
            bs = self.emaFrameTime > 16 ? Math.max(5, Math.round(bs * 0.9)) : Math.min(50, Math.round(bs * 1.1));
          }
          self.lastProcessTime = now;
          var batch = self.batchProcessingQueue.splice(0, bs);
          for (var i = 0; i < batch.length; i++) {
            try {
              centralScheduler.processElement(batch[i]);
            } catch (e) {
              _debugCatch(e, 'processBatch.processElement');
            }
            // 帧预算: 超预算立即中断, 未处理元素放回队列头(否则被 splice 出队后丢失=漏拦截),
            // 队列余量由下方统一判断继续调度下一帧
            if (performance.now() - _tStart > _FRAME_BUDGET) {
              self.batchProcessingQueue = batch.slice(i + 1).concat(self.batchProcessingQueue);
              break;
            }
          }
        } catch (e) {
          _debugCatch(e, 'processBatch.chunk');
        }
        // 无论成功/异常/预算中断, 队列有余量继续处理, 否则复位标志
        if (self.batchProcessingQueue.length > 0) _requestAnimationFrame(chunk);
        else self.isProcessingBatch = false;
      };
      _requestAnimationFrame(chunk);
    },
    processExistingElementsBatch: function () {
      var self = this;
      var els = Array.from(
        _document.querySelectorAll('script, iframe, img, a[href], style, link[rel="preload"], link[rel="prefetch"], embed, object, link[href]')
      );
      var twEl = _document.createTreeWalker(_document.documentElement, 1, null, false);
      while (twEl.nextNode()) {
        var el = twEl.currentNode;
        if (el.shadowRoot && !el.shadowRoot._adblockObserved) {
          if (currentConfig.modules.interceptThirdParty && thirdPartyModule && thirdPartyModule.domHooker) {
            thirdPartyModule.domHooker.observeShadowRoot(el.shadowRoot);
          }
          var shadowEls = el.shadowRoot.querySelectorAll('script, iframe, img, a[href], style, link[rel="preload"], link[rel="prefetch"], embed, object, link[href]');
          for (var sei = 0; sei < shadowEls.length; sei++) els.push(shadowEls[sei]);
        }
      }
      var process = function () {
        var batch = els.splice(0, self.batchSize * 2);
        for (var i = 0; i < batch.length; i++) {
          var el = batch[i];
          if (!ProcessedElementsCache.isProcessed(el) && !Utils.isParentProcessed(el)) self.addToBatchProcessingQueue(el);
        }
        if (els.length > 0) _requestIdleCallback(process);
      };
      _requestIdleCallback(process);
    },
  };


  // ======================== 用户脚本自身元素豁免 ========================
    // 【功能】防止用户脚本"自杀"：脚本自身源码含内置黑名单关键词（如 'hm.baidu.com'、'push.js'），
    //        若被自己的拦截逻辑检查，会被判定为广告脚本并中性化+移除（自拦）。
    // 【机制】把自身 <script> 标记为安全+已处理（_markSafe/ProcessedElementsCache），
    //        之后同步钩子/模块初始扫描/fastEarlyScan/DomObserver 任何路径都不会自拦。
    // 【注意】时序关键：必须在模块初始化（applyModuleSettings → 各模块初始扫描）之前执行。
  try {
    var _abSelfEl = _document.currentScript;
    if (!_abSelfEl) {
      var _abSelfScripts = _document.querySelectorAll('script');
      for (var _abi = _abSelfScripts.length - 1; _abi >= 0; _abi--) {
        var _abT = (_abSelfScripts[_abi].textContent || '');
        if (_abT.indexOf('网页广告拦截器') !== -1 && _abT.indexOf('==UserScript==') !== -1) {
          _abSelfEl = _abSelfScripts[_abi];
          break;
        }
      }
    }
    if (_abSelfEl) {
      _markSafe(_abSelfEl);
      ProcessedElementsCache.markAsProcessed(_abSelfEl);
    }
  } catch(e) { _debugCatch(e, "self exempt"); }


  UIController.createModules();
  UIController.applyModuleSettings();

  // ======================== UA 模拟引擎（三层层叠架构） ========================
    // 三层：客户端属性伪装 → fetch/XHR GM 代理 → 页面重写。
  const UASpoofEngine = {
    DESKTOP_UA: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    _layer1Active: false,
    _layer2Active: false,
    _origFetch: null,
    _whitescreenTimer: null,
    // ==================== 第1层：客户端属性伪装 ====================
    // 【功能】客户端属性伪装：navigator/screen/触屏事件等伪装为桌面值，覆盖纯客户端的 UA 检测。
    // 【机制】defineProperty 覆写 userAgent/platform/maxTouchPoints/screen 尺寸等，并向页面注入同款伪装脚本。
    applyLayer1: function () {
      if (this._layer1Active) return;
      this._layer1Active = true;
      var ua = this.DESKTOP_UA;
      try { Object.defineProperty(_globals.navigator, 'platform', { get: function () { return 'MacIntel'; }, configurable: true, enumerable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.navigator, 'userAgent', { get: function () { return ua; }, configurable: true, enumerable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.navigator, 'appVersion', { get: function () { return '5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'; }, configurable: true, enumerable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.navigator, 'maxTouchPoints', { get: function () { return 0; }, configurable: true, enumerable: true }); } catch (e) {}
      try { Object.defineProperty(_globals, 'ontouchstart', { value: undefined, configurable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.screen, 'width', { get: function () { return 1920; }, configurable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.screen, 'height', { get: function () { return 1080; }, configurable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.screen, 'availWidth', { get: function () { return 1920; }, configurable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.screen, 'availHeight', { get: function () { return 1080; }, configurable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.screen, 'colorDepth', { get: function () { return 24; }, configurable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.screen, 'pixelDepth', { get: function () { return 24; }, configurable: true }); } catch (e) {}
      try {
        var origMM = _globals.matchMedia;
        _globals.matchMedia = function (query) {
          if (typeof query === 'string' && query.includes('pointer: coarse')) {
            return { matches: false, media: query, onchange: null, addListener: function () {}, removeListener: function () {}, addEventListener: function () {}, removeEventListener: function () {}, dispatchEvent: function () { return true; } };
          }
          return origMM.apply(this, arguments);
        };
      } catch (e) {}
      this.applyFingerprintSpoof();
      this._injectPageContextSpoof(ua);
    },
    // ==================== 指纹伪装（低风险项）: UA-CH / Plugins / WebGL字符串 / DPR / CPU核数 ====================
    _buildFakePlugins: function () {
      // 伪造桌面 Chrome 默认插件列表(Chrome PDF Plugin / Chrome PDF Viewer / Native Client),
      // 消除"手机端 plugins=0 + 桌面UA"的矛盾; 数组形态兼容 item/namedItem/索引/迭代
      var mkMime = function (type, suffixes, desc, plugin) {
        return {
          type: type, suffixes: suffixes, description: desc, enabledPlugin: plugin,
          __proto__: (typeof _globals.MimeType !== 'undefined') ? _globals.MimeType.prototype : Object.prototype
        };
      };
      var mkPlugin = function (name, filename, desc, mimeList) {
        var plugin = {
          name: name, filename: filename, description: desc,
          __proto__: (typeof _globals.Plugin !== 'undefined') ? _globals.Plugin.prototype : Object.prototype
        };
        var mimes = [];
        for (var i = 0; i < mimeList.length; i++) mimes.push(mkMime(mimeList[i][0], mimeList[i][1], mimeList[i][2], plugin));
        plugin.length = mimes.length;
        plugin.item = function (idx) { return mimes[idx] || null; };
        plugin.namedItem = function (n) {
          for (var j = 0; j < mimes.length; j++) { if (mimes[j].type === n) return mimes[j]; }
          return null;
        };
        for (var k = 0; k < mimes.length; k++) plugin[k] = mimes[k];
        return plugin;
      };
      var p1 = mkPlugin('Chrome PDF Plugin', 'internal-pdf-viewer', 'Portable Document Format', [
        ['application/pdf', 'pdf', 'Portable Document Format'],
        ['text/pdf', 'pdf', 'Portable Document Format']
      ]);
      var p2 = mkPlugin('Chrome PDF Viewer', 'mhjfbmdgcfjbbpaeojofohoefgiehjai', '', [
        ['application/pdf', 'pdf', 'Portable Document Format']
      ]);
      var p3 = mkPlugin('Native Client', 'internal-nacl-plugin', '', [
        ['application/x-nacl', '', 'Native Client Executable'],
        ['application/x-pnacl', '', 'Portable Native Client Executable']
      ]);
      var plugins = [p1, p2, p3];
      var arr = plugins;
      arr.item = function (idx) { return plugins[idx] || null; };
      arr.namedItem = function (n) {
        for (var i = 0; i < plugins.length; i++) { if (plugins[i].name === n) return plugins[i]; }
        return null;
      };
      var mimesAll = [];
      for (var m = 0; m < plugins.length; m++) {
        var mp = plugins[m];
        for (var mi2 = 0; mi2 < mp.length; mi2++) mimesAll.push(mp.item(mi2));
      }
      var mta = mimesAll;
      mta.item = function (idx) { return mimesAll[idx] || null; };
      mta.namedItem = function (n) {
        for (var i = 0; i < mimesAll.length; i++) { if (mimesAll[i].type === n) return mimesAll[i]; }
        return null;
      };
      return { plugins: arr, mimeTypes: mta };
    },
    applyFingerprintSpoof: function () {
      // UA-CH(userAgentData): 部分站点用 navigator.userAgentData.mobile 判断, 需一并伪造
      try {
        if (_globals.navigator.userAgentData) {
          var _uadBrands = [
            { brand: 'Not A(Brand', version: '99' },
            { brand: 'Google Chrome', version: '120' },
            { brand: 'Chromium', version: '120' }
          ];
          var _uad = {
            brands: _uadBrands, mobile: false, platform: 'macOS',
            architecture: 'x86', bitness: '64', model: '',
            platformVersion: '10_15_7', uaFullVersion: '120.0.0.0',
            fullVersionList: _uadBrands,
            getHighEntropyValues: function () {
              return Promise.resolve({
                architecture: 'x86', bitness: '64', model: '', platformVersion: '10_15_7',
                uaFullVersion: '120.0.0.0', fullVersionList: _uadBrands,
                mobile: false, platform: 'macOS', brands: _uadBrands
              });
            },
            toJSON: function () { return { brands: _uadBrands, mobile: false, platform: 'macOS' }; }
          };
          Object.defineProperty(_globals.navigator, 'userAgentData', {
            get: function () { return _uad; }, configurable: true
          });
        }
      } catch (e) {}
      try { Object.defineProperty(_globals.navigator, 'vendor', { get: function () { return 'Google Inc.'; }, configurable: true, enumerable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.navigator, 'hardwareConcurrency', { get: function () { return 8; }, configurable: true }); } catch (e) {}
      try { Object.defineProperty(_globals.navigator, 'deviceMemory', { get: function () { return 8; }, configurable: true }); } catch (e) {}
      try { Object.defineProperty(_globals, 'devicePixelRatio', { get: function () { return 1; }, configurable: true }); } catch (e) {}
      // Plugins / MimeTypes 伪造(桌面 Chrome 默认插件集)
      try {
        var _fp = this._buildFakePlugins();
        Object.defineProperty(_globals.navigator, 'plugins', { get: function () { return _fp.plugins; }, configurable: true });
        Object.defineProperty(_globals.navigator, 'mimeTypes', { get: function () { return _fp.mimeTypes; }, configurable: true });
      } catch (e) {}
      // WebGL 厂商/显卡字符串(仅替换 GL_VENDOR/GL_RENDERER/UNMASKED 四个字符串参数, 不影响渲染)
      try {
        var _spoofParam = function (pname) {
          // Mac 桌面 Chrome 的 ANGLE 格式(与 Macintosh UA 自洽; D3D11 属 Windows 专属 API)
          if (pname === 0x1F00) return 'Google Inc. (Apple)';
          if (pname === 0x1F01) return 'ANGLE (Apple, Apple M1, OpenGL 4.1 Metal - 76.3)';
          if (pname === 0x9245) return 'Google Inc. (Apple)';
          if (pname === 0x9246) return 'ANGLE (Apple, Apple M1, OpenGL 4.1 Metal - 76.3)';
          return null;
        };
        var _hookWg = function (ctx) {
          if (!ctx || !ctx.prototype || !ctx.prototype.getParameter) return;
          if (ctx.prototype.getParameter.__abSpoofed) return;
          var orig = ctx.prototype.getParameter;
          var wrapped = function (pname) {
            try {
              var v = _spoofParam(pname);
              if (v !== null) return v;
            } catch (e) {}
            return orig.apply(this, arguments);
          };
          wrapped.__abSpoofed = true;
          ctx.prototype.getParameter = wrapped;
        };
        _hookWg(_globals.WebGLRenderingContext);
        _hookWg(_globals.WebGL2RenderingContext);
      } catch (e) {}
    },
    _injectPageContextSpoof: function (ua) {
      var scriptText = '(function(){'
        + 'try{Object.defineProperty(navigator,"platform",{get:function(){return"MacIntel"},configurable:true,enumerable:true});}catch(e){}'
        + 'try{Object.defineProperty(navigator,"userAgent",{get:function(){return"' + ua.replace(/"/g, '\\"') + '"},configurable:true,enumerable:true});}catch(e){}'
        + 'try{Object.defineProperty(navigator,"maxTouchPoints",{get:function(){return 0},configurable:true,enumerable:true});}catch(e){}'
        + 'try{Object.defineProperty(navigator,"appVersion",{get:function(){return"5.0 (Macintosh)"},configurable:true,enumerable:true});}catch(e){}'
        + 'try{Object.defineProperty(screen,"width",{get:function(){return 1920},configurable:true});}catch(e){}'
        + 'try{Object.defineProperty(screen,"height",{get:function(){return 1080},configurable:true});}catch(e){}'
        + 'try{Object.defineProperty(screen,"availWidth",{get:function(){return 1920},configurable:true});}catch(e){}'
        + 'try{Object.defineProperty(screen,"availHeight",{get:function(){return 1080},configurable:true});}catch(e){}'
        + 'try{var _oMM=matchMedia;matchMedia=function(q){if(typeof q==="string"&&q.includes("pointer: coarse"))return{matches:false,media:q,onchange:null,addListener:function(){},removeListener:function(){},addEventListener:function(){},removeEventListener:function(){},dispatchEvent:function(){return true}};return _oMM.apply(this,arguments)};}catch(e){}'
        + 'try{Object.defineProperty(navigator,"vendor",{get:function(){return"Google Inc."},configurable:true,enumerable:true});}catch(e){}'
        + 'try{Object.defineProperty(navigator,"hardwareConcurrency",{get:function(){return 8},configurable:true});}catch(e){}'
        + 'try{Object.defineProperty(navigator,"deviceMemory",{get:function(){return 8},configurable:true});}catch(e){}'
        + 'try{Object.defineProperty(window,"devicePixelRatio",{get:function(){return 1},configurable:true});}catch(e){}'
        + 'try{if(navigator.userAgentData){var _uad={brands:[{brand:"Not A(Brand",version:"99"},{brand:"Google Chrome",version:"120"},{brand:"Chromium",version:"120"}],mobile:false,platform:"macOS",architecture:"x86",bitness:"64",model:"",platformVersion:"10_15_7",uaFullVersion:"120.0.0.0",fullVersionList:[{brand:"Not A(Brand",version:"99"},{brand:"Google Chrome",version:"120"},{brand:"Chromium",version:"120"}],getHighEntropyValues:function(){return Promise.resolve({architecture:"x86",bitness:"64",model:"",platformVersion:"10_15_7",uaFullVersion:"120.0.0.0",fullVersionList:this.fullVersionList,mobile:false,platform:"macOS",brands:this.brands})},toJSON:function(){return{brands:this.brands,mobile:false,platform:"macOS"}}};Object.defineProperty(navigator,"userAgentData",{get:function(){return _uad},configurable:true});}}catch(e){}'
        + 'try{var _mkM=function(t,s,d,p){return{type:t,suffixes:s,description:d,enabledPlugin:p}};var _p1={name:"Chrome PDF Plugin",filename:"internal-pdf-viewer",description:"Portable Document Format"};var _p2={name:"Chrome PDF Viewer",filename:"mhjfbmdgcfjbbpaeojofohoefgiehjai",description:""};var _p3={name:"Native Client",filename:"internal-nacl-plugin",description:""};var _m1=_mkM("application/pdf","pdf","Portable Document Format",_p1);var _m2=_mkM("text/pdf","pdf","Portable Document Format",_p1);var _m3=_mkM("application/pdf","pdf","Portable Document Format",_p2);var _m4=_mkM("application/x-nacl","","Native Client Executable",_p3);var _m5=_mkM("application/x-pnacl","","Portable Native Client Executable",_p3);_p1.length=2;_p1.item=function(i){return[_m1,_m2][i]||null};_p1.namedItem=function(n){return n==="application/pdf"?_m1:(n==="text/pdf"?_m2:null)};_p2.length=1;_p2.item=function(i){return i===0?_m3:null};_p2.namedItem=function(n){return n==="application/pdf"?_m3:null};_p3.length=2;_p3.item=function(i){return[_m4,_m5][i]||null};_p3.namedItem=function(n){return n==="application/x-nacl"?_m4:(n==="application/x-pnacl"?_m5:null)};var _pl=[_p1,_p2,_p3];_pl.item=function(i){return _pl[i]||null};_pl.namedItem=function(n){return n==="Chrome PDF Plugin"?_p1:(n==="Chrome PDF Viewer"?_p2:(n==="Native Client"?_p3:null))};var _ml=[_m1,_m2,_m3,_m4,_m5];_ml.item=function(i){return _ml[i]||null};_ml.namedItem=function(n){for(var i=0;i<_ml.length;i++){if(_ml[i].type===n)return _ml[i]}return null};Object.defineProperty(navigator,"plugins",{get:function(){return _pl},configurable:true});Object.defineProperty(navigator,"mimeTypes",{get:function(){return _ml},configurable:true});}catch(e){}'
        + 'try{var _sp=function(p){if(p===7936)return"Google Inc. (Apple)";if(p===7937)return"ANGLE (Apple, Apple M1, OpenGL 4.1 Metal - 76.3)";if(p===37445)return"Google Inc. (Apple)";if(p===37446)return"ANGLE (Apple, Apple M1, OpenGL 4.1 Metal - 76.3)";return null};var _hw=function(c){if(!c||!c.prototype||!c.prototype.getParameter||c.prototype.getParameter.__abS){return}var o=c.prototype.getParameter;var w=function(p){var v=_sp(p);if(v!==null)return v;return o.apply(this,arguments)};w.__abS=true;c.prototype.getParameter=w};_hw(WebGLRenderingContext);_hw(WebGL2RenderingContext);}catch(e){}'
        + '})();';
      var script = _document.createElement('script');
      script.setAttribute('data-ab-ua', 'true');
      script.textContent = scriptText;
      try {
        var target = _document.documentElement || _document;
        var first = target.firstChild;
        if (first) target.insertBefore(script, first);
        else target.appendChild(script);
        script.remove();
      } catch (e) {}
    },
    // ==================== 第2层：fetch/XHR GM 代理 ====================
    applyLayer2: function () {
      if (this._layer2Active) return;
      if (typeof GM_xmlhttpRequest === 'undefined') return;
      // 防重复包装: 重建(rebuild)或脚本被重复注入时, fetch 已是本脚本的包装 → 直接复用, 不重复包装
      // (否则每个请求会走 2~3 层 GM 代理, 网络请求翻倍导致卡顿)
      if (_globals.fetch && _globals.fetch.__abUASpoofed) { this._layer2Active = true; return; }
      this._layer2Active = true;
      var self = this;
      // ============ fetch 代理(带安全回退: 复杂请求/失败/4xx → 退回原生, 防页面卡死) ============
      try {
        this._origFetch = _globals.fetch;
        _globals.fetch = function (input, init) {
          var url = null, reqObj = null;
          if (typeof input === 'string') url = input;
          else if (input && typeof input === 'object' && input.url) { url = input.url; reqObj = input; }
          if (!url || url.startsWith('data:') || url.startsWith('blob:')) return self._origFetch.apply(this, arguments);
          // Request 对象带 body / AbortSignal / 非字符串 body → 直接原生, 防止伪造出错
          if (reqObj && reqObj.body != null && typeof reqObj.body !== 'string') return self._origFetch.apply(this, arguments);
          if (init) {
            if (init.signal) return self._origFetch.apply(this, arguments);
            if (init.body != null && typeof init.body !== 'string'
                && !(typeof URLSearchParams !== 'undefined' && init.body instanceof URLSearchParams)
                && !(typeof ArrayBuffer !== 'undefined' && init.body instanceof ArrayBuffer)
                && !(typeof ArrayBuffer !== 'undefined' && ArrayBuffer.isView && ArrayBuffer.isView(init.body))) {
              return self._origFetch.apply(this, arguments);
            }
          }
          var u;
          try { u = new _URL(url, _location.href).href; if (new _URL(u).origin !== _location.origin) return self._origFetch.apply(this, arguments); } catch (e) { return self._origFetch.apply(this, arguments); }
          // 追踪参数清洗: GM 直连请求也剔除追踪参数
          if (currentConfig.trackingParamsCleanerEnabled) {
            try { u = cleanTrackingParams(u); } catch (e) {}
          }
          var method = ((init && init.method) || (reqObj && reqObj.method) || 'GET').toUpperCase();
          var headers = {};
          var hSrc = (init && init.headers) || (reqObj && reqObj.headers);
          if (hSrc) {
            try {
              if (typeof hSrc.forEach === 'function') hSrc.forEach(function (v, k) { headers[k] = v; });
              else if (typeof hSrc === 'object') { for (var k in hSrc) { if (hSrc.hasOwnProperty(k)) headers[k] = hSrc[k]; } }
            } catch (e) {}
          }
          var body = null;
          if (init && init.body != null) { try { body = typeof init.body === 'string' ? init.body : String(init.body); } catch (e) {} }
          return new Promise(function (resolve, reject) {
            var done = false;
            var fallback = function () {
              if (done) return;
              done = true;
              try { self._origFetch.apply(self._origFetch, [input, init]).then(resolve, reject); } catch (e) { reject(e); }
            };
            try {
              GM_xmlhttpRequest({
                method: method, url: u, headers: headers, data: body || undefined,
                timeout: 30000,
                onload: function (response) {
                  if (done) return;
                  done = true;
              // GM 返回 4xx/5xx(如风控/CSRF 拦截页) → 退回原生 fetch, 页面拿到真实结果
              if ((response.status || 0) >= 400) {
                try { self._origFetch.apply(self._origFetch, [input, init]).then(resolve, reject); } catch (e) { reject(e); }
                return;
              }
              // 风控软拦截: 200 但返回小体积 HTML 错误页（接口请求被劫持为验证页） → 退回原生
              try {
                var _ct = String(response.responseHeaders || '').toLowerCase();
                if ((response.responseText || '').length < 2048 && _ct.indexOf('text/html') !== -1 && /^\s*</.test(response.responseText || '')) {
                  try { self._origFetch.apply(self._origFetch, [input, init]).then(resolve, reject); } catch (e2) { reject(e2); }
                  return;
                }
              } catch (e) {}
              var respHeaders = {};
                  try {
                    (response.responseHeaders || '').split('\r\n').forEach(function (line) {
                      var idx = line.indexOf(':');
                      if (idx > 0) respHeaders[line.substring(0, idx).trim().toLowerCase()] = line.substring(idx + 1).trim();
                    });
                  } catch (e) {}
                  resolve(new Response(response.responseText, { status: response.status || 200, statusText: response.statusText || '', headers: new Headers(respHeaders) }));
                },
                onerror: fallback,
                ontimeout: fallback,
                onabort: function () {
                  if (done) return;
                  done = true;
                  var e = new Error('The user aborted a request.');
                  e.name = 'AbortError';
                  reject(e);
                },
              });
            } catch (e) { fallback(); }
          });
        };
        try { _globals.fetch.__abUASpoofed = true; } catch (e) {}
      } catch (e) {}
      // ============ XHR 代理（同步/二进制/进度监听 → 退回原生, 防页面挂起） ============
      try {
        var OrigXHR = _globals.XMLHttpRequest;
        var origOpen = OrigXHR.prototype.open;
        var origSend = OrigXHR.prototype.send;
        var origSRH = OrigXHR.prototype.setRequestHeader;
        var origAbort = OrigXHR.prototype.abort;
        OrigXHR.prototype.open = function (method, url, async) {
          this._ab_method = method; this._ab_url = url; this._ab_headers = {};
          // 追踪参数清洗: GM 直连请求也剔除追踪参数
          if (url && typeof url === 'string' && currentConfig.trackingParamsCleanerEnabled) {
            try { this._ab_url = cleanTrackingParams(url); } catch (e) {}
          }
          this._ab_useGM = false; this._ab_aborted = false;
          if (url && typeof url === 'string') {
            try {
              var u = new _URL(url, _location.href);
              // 同步 XHR 无法用 GM 模拟(GM 只支持异步) → 退回原生
              if (async !== false && u.origin === _location.origin && !url.startsWith('data:') && !url.startsWith('blob:')) {
                this._ab_useGM = true;
              }
            } catch (e) {}
          }
          return origOpen.apply(this, arguments);
        };
        OrigXHR.prototype.setRequestHeader = function (name, value) {
          if (this._ab_useGM) { try { this._ab_headers[name] = value; } catch (e) {} }
          return origSRH.apply(this, arguments);
        };
        OrigXHR.prototype.abort = function () {
          if (this._ab_useGM) this._ab_aborted = true;
          return origAbort.apply(this, arguments);
        };
        OrigXHR.prototype.send = function (body) {
          var xhr = this;
          // 二进制/表单类请求体、非文本 responseType、进度监听、已被 abort → 原生
          if (!this._ab_useGM || this._ab_aborted || typeof GM_xmlhttpRequest === 'undefined') {
            this._ab_useGM = false;
            return origSend.apply(this, arguments);
          }
          try {
            if (body != null && typeof body !== 'string') {
              if (body instanceof _globals.FormData || body instanceof _globals.Blob
                  || (typeof _globals.ArrayBuffer !== 'undefined' && (body instanceof _globals.ArrayBuffer || (_globals.ArrayBuffer.isView && _globals.ArrayBuffer.isView(body))))) {
                this._ab_useGM = false;
                return origSend.apply(this, arguments);
              }
            }
            var rt = this.responseType;
            if (rt && rt !== '' && rt !== 'text') { this._ab_useGM = false; return origSend.apply(this, arguments); }
            if (this.onprogress || this.onloadstart || this.onloadend ||
                (this.upload && (this.upload.onprogress || this.upload.onloadstart || this.upload.onloadend))) {
              this._ab_useGM = false;
              return origSend.apply(this, arguments);
            }
          } catch (e) {}
          var pending = true;
          try {
            GM_xmlhttpRequest({
              method: this._ab_method || 'GET', url: this._ab_url, headers: this._ab_headers || {},
              data: typeof body === 'string' ? body : (body == null ? undefined : String(body)), timeout: 30000,
              onload: function (response) {
                if (!pending || xhr._ab_aborted) return; pending = false;
                // 4xx/5xx 时 GM 响应可能与原生不同(风控/CSRF 页) → 重新走原生 send, 页面拿真实响应
                if ((response.status || 0) >= 400) {
                  xhr._ab_useGM = false;
                  try { origSend.call(xhr, body); } catch (e) {}
                  return;
                }
                // 风控软拦截: 200 但返回小体积 HTML 错误页 → 重新走原生 send
                try {
                  var _ct2 = String(response.responseHeaders || '').toLowerCase();
                  if ((response.responseText || '').length < 2048 && _ct2.indexOf('text/html') !== -1 && /^\s*</.test(response.responseText || '')) {
                    xhr._ab_useGM = false;
                    try { origSend.call(xhr, body); } catch (e) {}
                    return;
                  }
                } catch (e) {}
                try {
                  var rawH = response.responseHeaders || '';
                  Object.defineProperty(xhr, 'readyState', { value: 4, writable: true, configurable: true });
                  Object.defineProperty(xhr, 'status', { value: response.status || 200, writable: true, configurable: true });
                  Object.defineProperty(xhr, 'statusText', { value: response.statusText || '', writable: true, configurable: true });
                  Object.defineProperty(xhr, 'responseText', { value: response.responseText, writable: true, configurable: true });
                  Object.defineProperty(xhr, 'response', { value: response.responseText, writable: true, configurable: true });
                  Object.defineProperty(xhr, 'getAllResponseHeaders', { value: function () { return rawH; }, configurable: true });
                  Object.defineProperty(xhr, 'getResponseHeader', { value: function (n) { var m = rawH.match(new RegExp('^' + String(n).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ':\\s*(.+)$', 'mi')); return m ? m[1] : null; }, configurable: true });
                  var fire = function (t) {
                    try { if (typeof xhr['on' + t] === 'function') xhr['on' + t](); } catch (e3) {}
                    try { xhr.dispatchEvent(new _globals.Event(t)); } catch (e3) {}
                  };
                  try { if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange(); } catch (e3) {}
                  try { xhr.dispatchEvent(new _globals.Event('readystatechange')); } catch (e3) {}
                  fire('load');
                  fire('loadend');
                } catch (e) { _debugCatch(e, 'xhr gm onload'); }
              },
              onerror: function () {
                if (!pending || xhr._ab_aborted) return; pending = false;
                xhr._ab_useGM = false;
                try { origSend.call(xhr, body); } catch (e) {}
              },
              ontimeout: function () {
                if (!pending || xhr._ab_aborted) return; pending = false;
                try { if (typeof xhr.ontimeout === 'function') xhr.ontimeout(); } catch (e) {}
                try { xhr.dispatchEvent(new _globals.Event('timeout')); } catch (e) {}
              },
              onabort: function () {
                if (!pending) return; pending = false;
                try { if (typeof xhr.onabort === 'function') xhr.onabort(); } catch (e) {}
                try { xhr.dispatchEvent(new _globals.Event('abort')); } catch (e) {}
              },
            });
          } catch (e) {
            this._ab_useGM = false;
            return origSend.apply(this, arguments);
          }
        };
      } catch (e) {}
    },
    init: function () {
      if (currentConfig.simplePlatformSpoof) { this.applyLayer1(); return; }
      if (currentConfig.spoofUAEnabled) {
        this.applyLayer1();
        this.applyLayer2();
        return;
      }
    },
    rebuild: function () {
      this._layer1Active = false;
      this._layer2Active = false;
      this.applyLayer1();
      this.applyLayer2();
    },
    disable: function () {
      if (this._origFetch) { try { _globals.fetch = this._origFetch; } catch (e) {} this._origFetch = null; }
      try { if (_globals.fetch && _globals.fetch.__abUASpoofed) delete _globals.fetch.__abUASpoofed; } catch (e) {}
      this._layer1Active = false;
      this._layer2Active = false;
    },
  };

  // ======================== 统一页面重写引擎 ========================
    // 【功能】整页重写（document.open+write 方式）：用于注入 CSP meta / 模拟桌面 UA。
    // 【机制】GM 抓取带目标 UA 的页面 → SPA 空壳判定（命中则放弃，防毁单页应用）→
    //        document.open+write 重建 → rebuildAfterDocWrite 恢复全部钩子；
    //        隐藏样式自愈（写进被写入文档，3 秒自动揭开，杜绝白屏残留）。
    // 【注意】仅 SSR 页面执行；开启「管理CSP」时即使 SPA 也执行（CSP 注入需要此通道）；
    //        任何失败都回退客户端伪装（L1/L2），不会卡死页面。
  // ======================== SPA 空壳 HTML 判定 ========================
    // 服务端只返回 JS 引导壳、正文全靠客户端渲染的页面(常见特征: __INITIAL_STATE__/
    // __NEXT_DATA__/__NUXT__/空 #root/#app + 极少正文)。这类页面做 document.open+write
    // 整页重写只会毁掉 SPA(二次引导竞态/脚本上下文销毁), 而 UA 欺骗靠客户端属性(L1)
    // 已生效——重写零收益纯破坏, 判定命中 → 跳过整页重写(仅保留 L1/L2 客户端伪装)。
  function _isSpaShellHtml(html) {
    if (!html || typeof html !== 'string') return false;
    try {
      var _h = String(html).toLowerCase();
      var _spaMark = /__initial_state__|__next_data__|__nuxt__|\sid="(?:root|app|__nuxt|mount)"|\bdata-reactroot\b|\bdata-v-app\b|__webpack_require__/.test(_h);
      if (!_spaMark) return false;
      // 去掉脚本/样式标签后剩余正文极少 → 典型空壳(SSR 页面正文会很长)
      var _noScript = String(html).replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ');
      var _txt = _noScript.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      return _txt.length < 300;
    } catch (e) {
      return false;
    }
  }

  const PageRewriteEngine = {
    _active: false,

    shouldRewrite: function () {
      var needUA = typeof UASpoofEngine !== 'undefined'
                   && currentConfig.spoofUAEnabled
                   && typeof GM_xmlhttpRequest !== 'undefined';
      var needCSP = currentConfig.modules.manageCSP && typeof GM_xmlhttpRequest !== 'undefined';
      if (!needUA && !needCSP) return false;
      if (isInIframe()) return false;
      // 本页已是整页重写产生的文档(文档内带有我们注入的 meta 标记) → 说明脚本被重新注入,
      // 绝不能再次重写（否则无限重写循环）, 只保留客户端伪装。正常刷新是全新导航、无此标记 → 必然重写,
      // 不设任何时间窗口, 刷新间隔再短也不会误伤
      try {
        if (_document.querySelector('meta[name="ab-rewrite-done"]')) return false;
      } catch (e) {}
      // 备用检测: document.open() 产生的"重注入文档"没有 navigation 性能条目
      try {
        var _navs = _globals.performance && _globals.performance.getEntriesByType
          ? _globals.performance.getEntriesByType('navigation')
          : null;
        if (_navs !== null && _navs.length === 0) return false;
      } catch (e) {}
      try {
        var _p = _location.protocol;
        if (_p === 'about:' || _p === 'data:' || _p === 'javascript:' || _p === 'file:') return false;
      } catch (e) { return false; }
      // 3 分钟内该站点整页重写失败过 → 跳过该次重写（防止"怎么刷新都白屏"的循环）
      try {
        var _lastFail = GM_getValue('ab_ua_rewrite_fail_' + _location.hostname, 0);
        if (_lastFail && (Date.now() - _lastFail) < 3 * 60 * 1000) return false;
      } catch (e) {}
      return true;
    },

    rewrite: function () {
      if (this._active) return;
      if (!this.shouldRewrite()) return;
      this._active = true;
      var needUA = typeof UASpoofEngine !== 'undefined' && currentConfig.spoofUAEnabled;
      var needCSP = currentConfig.modules.manageCSP;
      // 记录页面加载完成时刻（用于晚注入/页面早已加载完时放弃整页替换, 避免清空已渲染页面）
      if (!this._loadHooked) {
        this._loadHooked = true;
        var _markLoad = function () { PageRewriteEngine._pageLoadAt = Date.now(); };
        if (_document.readyState !== 'loading') {
          // 晚注入: 记下注入时刻, 重写限时放行(见 onload 判断)。
          // 有些站点(如 eu68)的 UA 解析脚本在自身加载时一次性缓存 navigator.userAgent,
          // 若它先于本脚本运行, 缓存的就是真实UA, 必须靠整页重写让页面脚本重跑才能纠正显示
          PageRewriteEngine._pageLoadAt = 1;
          PageRewriteEngine._pageLoadLateAt = Date.now();
        } else {
          try { _document.addEventListener('DOMContentLoaded', _markLoad, true); } catch (e) {}
          try { _globals.addEventListener('load', _markLoad, true); } catch (e) {}
        }
      }
      var headers = {};
      if (needUA) headers['User-Agent'] = UASpoofEngine.DESKTOP_UA;
      var cspMeta = '';
      if (needCSP) {
        var er = currentConfig.cspRules.filter(function (r) { return r.enabled; });
        if (er.length > 0) {
          var dirs = {};
          for (var i = 0; i < er.length; i++) {
            var parts = er[i].rule.split(/\s+/);
            var d = parts[0], v = parts.slice(1);
            if (!dirs[d]) dirs[d] = [];
            for (var j = 0; j < v.length; j++) {
              if (dirs[d].indexOf(v[j]) === -1) dirs[d].push(v[j]);
            }
          }
          var ps = '';
          for (var d2 in dirs) {
            if (dirs.hasOwnProperty(d2)) ps += d2 + ' ' + dirs[d2].join(' ') + '; ';
          }
          ps = ps.trim();
          if (ps) cspMeta = '<meta http-equiv="Content-Security-Policy" content="' + ps.replace(/"/g, '&quot;') + '">';
        }
      }
      var self = this;
      var done = false;
      var attempts = 0;
      var markFail = function () {
        try { GM_setValue('ab_ua_rewrite_fail_' + _location.hostname, Date.now()); } catch (e) {}
      };
      var retryOrFallback = function () {
        // 瞬时失败（网络抖动/风控误判等） → 1.5 秒后重试一次（最多 2 次）, 提高单次欺骗成功率
        if (!done && attempts < 2) {
          _setTimeout(doFetch, 1500);
        } else {
          if (!done) { done = true; self._fallback(); }
        }
      };
      // ============ 整页替换（网络抓取成功或缓存命中后统一执行） ============
      // 【功能】用抓取/缓存到的 HTML 重建整个文档（document.open+write）。
      // 【机制】写入前注入隐藏样式（防闪白）与自愈脚本（3 秒自动揭开）、重写标记（防循环）；写入后校验 html/body，失败自动回退。
      var performSwap = function (html) {
        if (done) return;
        done = true;
        try {
          if (cspMeta) {
            var existingCSP = html.match(/<meta[^>]+http-equiv\s*=\s*["\x27]?Content-Security-Policy["\x27]?[^>]*>/i);
            if (existingCSP) html = html.replace(existingCSP[0], cspMeta);
            else {
              var headMatch = html.match(/<head[^>]*>/i);
              var insertPos = headMatch ? html.indexOf(headMatch[0]) + headMatch[0].length : 0;
              html = html.substring(0, insertPos) + '\n' + cspMeta + '\n' + html.substring(insertPos);
            }
          }
          // 把"隐藏页面"样式 + "已重写"标记注入新 HTML 的 <head> 最前面:
          // 样式让整页替换瞬间不闪空白（解析完成后立即移除）; 标记用于识别"重注入文档"(防无限重写循环)
          try {
            var _prwStyle = '<style data-prw="1">html{visibility:hidden!important;}</style>'
              + '<meta name="ab-rewrite-done" content="1">'
              // 自愈: 移除隐藏样式的逻辑写进"被写入的文档自身"(而非依赖重写前 window 的定时器),
              // 即使 document.open() 销毁旧脚本上下文(about:blank 导航), 新文档 3 秒后也会自行揭开,
              // 绝不残留白屏卡死(重型 SPA 整页重写场景的通用防护)
              + '<script data-prw-heal="1">setTimeout(function(){try{var s=document.querySelector("style[data-prw]");if(s)s.remove()}catch(e){}},3000)<\/script>';
            var _headReplaced = html.replace(/<head[^>]*>/i, function (m) { return m + _prwStyle; });
            if (_headReplaced === html) {
              html = html.replace(/<html[^>]*>/i, function (m) { return m + _prwStyle; });
            } else {
              html = _headReplaced;
            }
          } catch (e) {}
          teardownAllBeforeDocWrite();
          _reinitGuard = true;
          var redWH = RedirectBlocker._writeTimingHook;
          if (redWH) WriteHookManager.removeHook(redWH);
          var opened = false;
          try { _document.open(); opened = true; } catch (e) { opened = false; }
          if (!opened) {
            // open 失败: 页面仍完好 → 装回钩子继续使用, 不做重写
            _reinitGuard = false;
            try {
              var hs2 = _document.querySelector('style[data-prw]');
              if (hs2) hs2.remove();
                } catch (e2) {}
                if (redWH) WriteHookManager.addHook(redWH);
                try { rebuildAfterDocWrite(); } catch (e2) {}
                return;
          }
          try { _document.write(html); } catch (e) {}
          try { _document.close(); } catch (e) {}
          // 校验交换结果: 新文档没有 html/body(浏览器忽略了整页写入) → 标记失败并刷新, 不留白屏
          try {
            if (!_document.querySelector('html, body')) {
              markFail();
              try { _location.reload(); } catch (e2) {}
              return;
            }
          } catch (e2) {}
              try { GM_deleteValue('ab_ua_rewrite_fail_' + _location.hostname); } catch (e) {}
              if (redWH) WriteHookManager.addHook(redWH);
              rebuildAfterDocWrite();
          // 兜底: 3 秒后若隐藏样式还残留（理论上不会）, 强制移除, 防止页面一直隐藏
          _setTimeout(function () {
            try {
              var _prwL = _document.querySelector('style[data-prw]');
              if (_prwL) _prwL.remove();
            } catch (e3) {}
          }, 3000);
          // 重写后 25 秒仍未完成解析（页面卡死） → 标记失败并刷新（下次自动跳过重写）
          try {
            var _swapUrl = _location.href;
            _setTimeout(function () {
              try {
                if (_document.readyState === 'loading'
                    && _document.visibilityState !== 'hidden'
                    && _location.href === _swapUrl) {
                  try { GM_setValue('ab_ua_rewrite_fail_' + _location.hostname, Date.now()); } catch (e3) {}
                  try { _location.reload(); } catch (e3) {}
                }
              } catch (e3) {}
            }, 25000);
          } catch (e2) {}
        } catch (e) {
          // open 成功后写失败/close 异常: 页面已被清空 → 标记失败并刷新（下次跳过重写, 不会反复白屏）
          console.warn('[广告拦截器] 页面重写失败:', e.message || e);
          markFail();
          try { _location.reload(); } catch (e2) {}
        }
      };
      // ============ ① 缓存命中: 同一 URL、120 秒内抓取过 → 直接整页替换, 省掉网络等待（刷新近乎零延迟） ============
      // 晚注入超 10 秒视为"页面已被浏览", 不执行整页替换
      if (!(PageRewriteEngine._pageLoadLateAt && (Date.now() - PageRewriteEngine._pageLoadLateAt) > 10000)) {
        try {
          var _cachedTs = GM_getValue('ab_ua_rewrite_cache_ts_' + _location.hostname, 0);
          var _cachedUrl = GM_getValue('ab_ua_rewrite_cache_url_' + _location.hostname, '');
          if (_cachedTs && _cachedUrl === _location.href && (Date.now() - _cachedTs) < 120 * 1000) {
            var _cachedHtml = GM_getValue('ab_ua_rewrite_cache_' + _location.hostname, '');
            if (_cachedHtml && _cachedHtml.length > 200) {
              // 缓存命中后同样先做 SPA 空壳判定, 避免用缓存重写毁掉 SPA 页面。
              // 仅当重写理由是"UA 伪装"且未开"管理CSP"时才跳过——manageCSP 依赖整页重写注入
              // CSP meta, 跳过了会导致 SPA 页面的 CSP 策略失效（脚本/资源拦截漏掉）。
              if (needUA && !needCSP && _isSpaShellHtml(_cachedHtml)) { done = true; self._fallback(); return; }
              performSwap(_cachedHtml);
              return;
            }
          }
        } catch (e) {}
      }
      // ============ ② 网络抓取（首次访问/缓存过期） ============
      var doFetch = function () {
        if (done || attempts >= 2) return;
        attempts++;
        try {
          GM_xmlhttpRequest({
            method: 'GET', url: _location.href, headers: headers,
            timeout: 10000,
            onload: function (response) {
              if (done) return;
              if (!self._active) { done = true; return; }
              // 晚注入: 距注入超过 10 秒（页面已被用户浏览） → 不执行整页替换;
              // 10 秒内仍允许重写——页面脚本会被重新执行, 此时客户端伪装已就位,
              // 缓存在脚本内的真实UA(如 eu68 的解析库)即被纠正为桌面值
              if (PageRewriteEngine._pageLoadLateAt && (Date.now() - PageRewriteEngine._pageLoadLateAt) > 10000) { done = true; self._fallback(); return; }
              var status = response.status || 0;
              if (status < 200 || status >= 400 || !response.responseText) { retryOrFallback(); return; }
              // 被重定向到其他站点（登录页/风控验证页等） → 放弃重写
              if (response.finalUrl) {
                try {
                  var fu = new _URL(response.finalUrl, _location.href);
                  if (fu.hostname !== _location.hostname) { retryOrFallback(); return; }
                } catch (e) { retryOrFallback(); return; }
              }
              var html = response.responseText;
              // 内容不是 HTML(JSON/错误页/验证页等) → 放弃重写
              var probe = String(html).slice(0, 2000).replace(/^\s*(\uFEFF)?/, '').replace(/^<!--[\s\S]*?-->/, '').trim().toLowerCase();
              if (!/^<!doctype|^<html|^<head|^<body/.test(probe)) { retryOrFallback(); return; }
              // SPA 空壳 → 客户端伪装(L1/L2)已就位, 整页重写对 UA 无效且会毁掉 SPA → 放弃重写。
              // 仅当重写理由是"UA 伪装"且未开"管理CSP"时才跳过(理由同上: 不破坏 CSP 注入通道)。
              if (needUA && !needCSP && _isSpaShellHtml(html)) { done = true; self._fallback(); return; }
              // 校验通过 → 写入缓存（中等大小页面才缓存, 防止存储膨胀; 顺带清理过期缓存）
              try {
                if (html.length <= 262144) {
                  GM_setValue('ab_ua_rewrite_cache_' + _location.hostname, html);
                  GM_setValue('ab_ua_rewrite_cache_ts_' + _location.hostname, Date.now());
                  GM_setValue('ab_ua_rewrite_cache_url_' + _location.hostname, _location.href);
                  try {
                    var _allK = GM_listValues();
                    if (_allK && _allK.length > 10) {
                      var _nowTs = Date.now();
                      for (var _ki = 0; _ki < _allK.length; _ki++) {
                        var _kk = _allK[_ki];
                        if (typeof _kk === 'string' && _kk.indexOf('ab_ua_rewrite_cache_ts_') === 0) {
                          var _kv = GM_getValue(_kk, 0);
                          if (_kv && (_nowTs - _kv) > 5 * 60 * 1000) {
                            var _host = _kk.substring('ab_ua_rewrite_cache_ts_'.length);
                            try { GM_deleteValue('ab_ua_rewrite_cache_' + _host); } catch (e2) {}
                            try { GM_deleteValue('ab_ua_rewrite_cache_url_' + _host); } catch (e2) {}
                            try { GM_deleteValue(_kk); } catch (e2) {}
                          }
                        }
                      }
                    }
                  } catch (e2) {}
                }
              } catch (e) {}
              performSwap(html);
            },
            onerror: function () { retryOrFallback(); },
            ontimeout: function () { retryOrFallback(); },
          });
        } catch (e) { retryOrFallback(); }
      };
      doFetch();
    },
    _fallback: function () {
      this._active = false;
      try { var hs = _document.querySelector('style[data-prw]'); if (hs) hs.remove(); } catch (e) {}
      try { UIController.init(); } catch (e) {}
      try { UIController.startDOMDependent(); } catch (e) {}
    },
  };


  UASpoofEngine.init();


  function teardownAllBeforeDocWrite() {
    // 【重写前拆卸】页面重写(document.write 整页重建)之前，先把所有钩子/监听器拆掉，
    // 防止重写过程中钩子误判或重复触发（拆卸→重写→重建 三步走）。

    try {
      if (UIController.mutationObserver) {
        UIController.mutationObserver.disconnect();
        UIController.mutationObserver = null;
      }
    } catch(e) { _debugCatch(e, "UIController.mutationObse"); }


    try {
      if (OverlayInterceptor._observer) {
        OverlayInterceptor._observer.disconnect();
        OverlayInterceptor._observer = null;
      }
      if (OverlayInterceptor._periodicTimer !== null) {
        _cancelIdleCallback(OverlayInterceptor._periodicTimer);
        OverlayInterceptor._periodicTimer = null;
      }

      cancelLateScanTimers();
      if (OverlayInterceptor._domObserverCallback) {
        DomObserver.unsubscribe(OverlayInterceptor._domObserverCallback);
        OverlayInterceptor._domObserverCallback = null;
      }

      if (OverlayInterceptor._overlayWriteHook) {
        try { WriteHookManager.removeHook(OverlayInterceptor._overlayWriteHook); } catch(e) {}
        OverlayInterceptor._overlayWriteHook = null;
      }
    } catch(e) { _debugCatch(e, "OverlayInterceptor._perio"); }

    try { DomObserver.disconnect(); } catch(e) { _debugCatch(e, "DomObserver.disconnect"); }

    UIController._domStarted = false;

    try { URLChangeGuard.stop(); } catch(e) { _debugCatch(e, "URLChangeGuard.stop"); }


    try {
      if (ResidualCleaner.observer) {
        ResidualCleaner.observer.disconnect();
        ResidualCleaner.observer = null;
      }
      if (ResidualCleaner._scanTimer !== null) {
        _cancelIdleCallback(ResidualCleaner._scanTimer);
        ResidualCleaner._scanTimer = null;
      }
      ResidualCleaner._pendingNodes = [];
    } catch(e) { _debugCatch(e, "ResidualCleaner._scanTime"); }


    try {
      if (RedirectBlocker._savedObservers) {
        for (var j = 0; j < RedirectBlocker._savedObservers.length; j++) {
          try { RedirectBlocker._savedObservers[j].disconnect(); } catch (e2) {}
        }
        RedirectBlocker._savedObservers = [];
      }
    } catch(e) { _debugCatch(e, "RedirectBlocker._savedObs"); }


    try {
      if (UIController.modules) {
        for (var mi = 0; mi < UIController.modules.length; mi++) {
          var mod = UIController.modules[mi];
          if (mod && mod.enabled) {
            try { mod.disable(); } catch (e2) {}
          }
        }
      }
    } catch(e) { _debugCatch(e, "}"); }


    try { if (thirdPartyModule && thirdPartyModule.enabled) thirdPartyModule.disable(); } catch (e) {}


    try { DynamicScriptInterceptor.disable(); } catch (e) {}
    try { RedirectBlocker.disable(); } catch (e) {}
    try { LinkCleaner.disable(); } catch (e) {}
    try { NetworkTrackingCleaner.disable(); } catch (e) {}


    UIController.uiInitialized = false;
    UIController.modulesInitialized = false;
    UIController.isProcessingBatch = false;
    UIController.batchProcessingQueue = [];

    OverlayInterceptor._enabled = false;
    OverlayInterceptor._processedSet = new WeakSet();
    OverlayInterceptor._repeatKeys = null;
    OverlayInterceptor._parentTracker = null;
    OverlayInterceptor._locTracker = null;
    OverlayInterceptor._locationSterile = null;
    OverlayInterceptor._sterilizedByLoc = null;
    OverlayInterceptor._styleCache = null;
    if (OverlayInterceptor._hiddenElementsMap) {
      OverlayInterceptor._hiddenElementsMap.clear();
    }
    // 页面重写前停用滚动解锁守卫(重写后按需重新 arm)
    try { ScrollLockGuard.disable(); } catch(e) { _debugCatch(e, "teardown ScrollLockGuard"); }

    DynamicScriptInterceptor._callbackCheckCache = new WeakMap();


    ProcessedElementsCache.clear();
    if (centralScheduler) {
      centralScheduler.clearCache();
      centralScheduler.elementCheckCache = new WeakSet();
    }
    urlCache.clear();


    try { CrossScriptPatternTracker.reset(); } catch (e) {}


    try {
      if (UIController.panelManager) {
        if (UIController.panelManager._host) {
          UIController.panelManager._host.remove();
          UIController.panelManager._host = null;
        }
        UIController.panelManager._shadow = null;
        UIController.panelManager._overlay = null;
        UIController.panelManager._panelEl = null;
        UIController.panelManager.isAnimating = false;
      }
    } catch(e) { _debugCatch(e, "UIController.panelManager"); }


    try {
      if (strongBlockingEnabled) disableStrongBlocking();
      activePanels.clear();
    } catch(e) { _debugCatch(e, "disableStrongBlocking()"); }


    try {
      if (_safeInitMO) {
        _safeInitMO.disconnect();
        _safeInitMO = null;
      }
    } catch(e) { _debugCatch(e, "}"); }
  }


  function rebuildAfterDocWrite() {
    // 【重写后重建】页面重写完成后，把钩子/监听器/模块状态重新装回去，
    // 并重新扫描新页面里的广告（重写后的页面同样是广告的目标）。
      try {

      try {
        var _prw2 = _document.querySelector('style[data-prw]');
        if (_prw2) _prw2.remove();
      } catch(e) {}


      try {
        var s = document.createElement('style');
        s.setAttribute('data-hs', 'true');
        s.textContent = '._uh{visibility:hidden!important;opacity:0!important;pointer-events:none!important}';
        (document.documentElement || document).appendChild(s);
      } catch(e) { _debugCatch(e, "初始隐藏样式注入失败"); }

      try { ElementCssBlocker.applyCss(); } catch(e) { _debugCatch(e, "ElementCssBlocker rebuild"); }


      try { StorageManager.loadConfig(); } catch (e) {}


      try { if (typeof UASpoofEngine !== 'undefined') UASpoofEngine.rebuild(); } catch(e) {}


      try {
        if (currentConfig.redirectBlockerEnabled) {
          RedirectBlocker.disable();
          RedirectBlocker._initialized = false;
          RedirectBlocker.init();
        }
      } catch(e) { _debugCatch(e, "RedirectBlocker._initiali"); }


      try {
        DynamicScriptInterceptor._enabled = false;
        if (currentConfig.modules.blockDynamicScripts) {
          DynamicScriptInterceptor.enable();
        }
      } catch(e) { _debugCatch(e, "DynamicScriptInterceptor."); }


      try {
        if (currentConfig.trackingParamsCleanerEnabled) {
          LinkCleaner.init();
          NetworkTrackingCleaner.init();
        }
      } catch(e) { _debugCatch(e, "LinkCleaner.init()"); }


      try {
        UIController.init();
      } catch (e) {
        try {
          UIController.uiInitialized = false;
          UIController.modulesInitialized = false;
          UIController.init();
        } catch (e2) {
          console.warn('[广告拦截器] UA伪装后重建失败:', e2.message || e2);
        }
      }

      try { UIController.startDOMDependent(); } catch(e) { _debugCatch(e, "startDOMDependent in rebuild"); }

      try {
        if (currentConfig.trackingParamsCleanerEnabled) URLChangeGuard.init();
      } catch(e) { _debugCatch(e, "URLChangeGuard.init in rebuild"); }
    } finally {

      _reinitGuard = false;
    }
  }

  function isInIframe() {
    try {
      return _globals.self !== _globals.top;
    } catch (e) {
      return true;
    }
  }

  // ======================== 晚同步补救扫描（手机端脚本注入晚时的补扫） ========================
    // 页面加载早期被广告抢先注入时的补救扫描（快速早期扫描 + 延迟补扫）。
  var _lateScanState = { index: 0, list: null };
  var _lateScanTimers = [];

  function fastEarlyScanSync() {
    if (!_document.documentElement) return;
    try {
      if (!_lateScanState.list || _lateScanState.index >= _lateScanState.list.length) {
        _lateScanState.list = _document.querySelectorAll('script');
        _lateScanState.index = 0;
      }
      var scripts = _lateScanState.list;
      var handled = 0;
      for (; _lateScanState.index < scripts.length && handled < 500; _lateScanState.index++) {
        var s = scripts[_lateScanState.index];
        if (!s || !s.isConnected) continue;
        if (!ProcessedElementsCache.isProcessed(s)) {
          try {
            ScriptSyncGuard.interceptAndLog(s);
          } catch (e) { _debugCatch(e, "interceptAndLog in sync scan"); }
          handled++;
        }
      }
      if (_lateScanState.index >= scripts.length) {
        _lateScanState.list = null;
      }
    } catch (e) { _debugCatch(e, "fastEarlyScanSync"); }
  }

  function cancelLateScanTimers() {
    while (_lateScanTimers.length) {
      try { _clearTimeout(_lateScanTimers.pop()); } catch (e) {}
    }
    _lateScanState.list = null;
    _lateScanState.index = 0;
  }

  function fastEarlyScan() {
    // 【启动快扫】页面加载瞬间先扫一遍已有的覆盖层/广告元素（不等 DOMContentLoaded），
    // 因为手机端脚本注入晚、广告脚本常常抢先一步把广告渲染出来——先扫先拦。
    if (!_document.documentElement) return;
    var doScan = function() {
      try {
        var scripts = _document.querySelectorAll('script');
        for (var i = 0; i < scripts.length; i++) {
          if (!ProcessedElementsCache.isProcessed(scripts[i])) {
            ScriptSyncGuard.interceptAndLog(scripts[i]);
          }
        }
      } catch(e) { _debugCatch(e, "fastEarlyScan"); }
    };

    if (typeof queueMicrotask === 'function') {
      queueMicrotask(doScan);
    }

    _requestAnimationFrame(function() {
      doScan();
      DomObserver.flushPending();
    });

    _setTimeout(function() {
      doScan();
      DomObserver.flushPending();
    }, 0);
  }

    function safeInit() {
    // 脚本主入口（documentElement 就绪后调用）：快速早期扫描 → startDOMDependent →
    // 各模块 enable（覆盖层/残留清理/脚本拦截等）→ 面板菜单注册。
    if (_document.documentElement) {
      if (_reinitGuard) return true;

      if (typeof PageRewriteEngine !== 'undefined' && PageRewriteEngine.shouldRewrite()) {
        PageRewriteEngine.rewrite();
        return true;
      }

      // 元素CSS屏蔽: document-start 同步注入样式表（页面解析前）, 规则空/开关关时零开销
      try { ElementCssBlocker.applyCss(); } catch (e) { _debugCatch(e, 'ElementCssBlocker boot'); }


      var _lateInject = _document.readyState && _document.readyState !== 'loading';
      if (_lateInject) {
        cancelLateScanTimers();
        fastEarlyScanSync();
        _lateScanTimers.push(_setTimeout(function () { fastEarlyScanSync(); }, 500));
        _lateScanTimers.push(_setTimeout(function () { fastEarlyScanSync(); }, 2000));
      } else {
        // 脚本元素级移除（内嵌/外联）或深度拦截开启时, documentElement 就绪瞬间先做一次
        // 同步脚本预扫, 抢在后续异步扫描之前中性化已解析的脚本, 压缩同步解析脚本的抢跑窗口
        // —— 注入时机较晚的管理器受益最大: head 中已排队未执行的外联脚本被同步移除后,
        // 广告函数未定义, 后续调用块空跑。预扫判定走完整检查链, 各脚本模块照常参与;
        // 触发只绑定元素级移除模块（默认关, 用户显式选择删脚本才付首屏同步成本）。
        if ((currentConfig.modules.interceptThirdParty && currentConfig.funnelStrictMode)
          || currentConfig.modules.removeInlineScripts
          || currentConfig.modules.removeExternalScripts) {
          try { fastEarlyScanSync(); } catch (e) { _debugCatch(e, "sync prescan"); }
        }
        fastEarlyScan();
      }
      UIController.startDOMDependent();
      return true;
    }
    return false;
  }

  if (!safeInit()) {
    _safeInitMO = new _MutationObserver(function () {
      if (safeInit()) {
        if (_safeInitMO) {
          _safeInitMO.disconnect();
          _safeInitMO = null;
        }
      }
    });
    _safeInitMO.observe(_document, { childList: true });
    _document.addEventListener('DOMContentLoaded', function () {
      if (!safeInit()) _setTimeout(safeInit, 100);
    }, { once: true });
    _setTimeout(function () {
      if (!safeInit()) {
        UIController.init();
      }
    }, 5000);
  }
})();
