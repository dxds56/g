// ==UserScript==
// @name ✡️chinesebibleonline.com
// @namespace   ScriptCat
// @description css字体大小 内容屏蔽  id # class .
// @version      220505.21
// @author       You
// @license MIT
// @run-at       document-end


// @include       *.chinesebibleonline.com/*/*/*

// @exclude   *sina*

// @grant       none

// ==/UserScript==

/*body > [href^="固定/批量匹配"]{}无^固定指定
body > embed[id][src]{display:none !important}


m.xsbiquge.la###chaptercontent > p:nth-of-type(1)

www.sudugu.com##a[href="/xianxia/"]


*/


!(function() {
    'use strict';

    // 通过CSS预先隐藏元素，避免闪烁
    var css = `

ARTICLE.page-content,
#content,
#cContent,
.content,
.container,
#mycontent,
div#htmlContent,
DIV#chaptercontent,
DIV.chapter-content,
#txt,DIV.txt,DIV.con,
DIV.txtnav,
DIV.articlecontent,
DIV#novelcontent,
div#nr1,
DIV#Lab_Contents,
DIV#neirong1{background:#fff;color:#000;font-size:23px;line-height: 38px;text-indent: 0em;padding-left: 26px;padding-right:24px;!important;}


div.bookline{background:#fff;color:#000;font-size:23px;line-height: 38px;text-indent: 0em;!important;}

[src="/images/cbo_newlogo.png"]{width:330px !important;height:200px !important;}
DIV#page-toolbar{display:none !important}

DIV.page-d-top{display:none !important}

DIV#footer_mobile{display:none !important}

body>div>a>img{display:none !important}



    `;
    var style = document.createElement('style');
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);



})();

// ==UserScript==
// @name gblfy
// @namespace    https://viayoo.com/
// @version      220505.21
// @description  暴力翻页。
// @author       You
// @license MIT
// @run-at       document-end
// @match        *://*/*
// @grant        none
// ==/UserScript==

/*空白触屏翻页-暴力版*/var fycz=450;/*450即翻页滚动像素值，可按需修改*/document.body.addEventListener("click",function(e){var ecy=e.clientY,sah=window.screen.availHeight/3;if(ecy<sah){window.scrollBy(0,window.innerHeight*0.9)}else if(ecy>sah){window.scrollBy(0,window.innerHeight*0.5)}});