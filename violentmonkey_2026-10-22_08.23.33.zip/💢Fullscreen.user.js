// ==UserScript==
// @name   💢Fullscreen
// @name:zh-CN  💢全屏按钮
// @match  *://*/*
// @include     *
// @run-at       document-end
// @grant        none
// @version      0.2
// @description A simple float button for entering fullscreen.
// @description:zh-CN 一个简单的浮动按钮用于全屏显示网页。
// @noframes
// @license CC0
// ==/UserScript==
'use strict';
//document.body.insertAdjacentHTML("afterbegin",'<div id="b0n" style="background-color: rgb(209, 209, 209,0.01);position: fixed;display: flex;opacity: 0.66;top:-16px !important;right:-16px !important;margin: 1em;z-index: 2147483647" ><svg width="24" height="24"><path d="M7,14L5,14v5h5v-2L7,17v-3zM5,10h2L7,7h3L10,5L5,5v5zM17,17h-3v2h5v-5h-2v3zM14,5v2h3v3h2L19,5h-5z"/></svg></div>');

/*💢💢💢margin: 1em*/


document.body.insertAdjacentHTML("afterbegin",'<div id="b0n" style="color:#27618D;background-color: rgb(209, 209, 209,0);font-weight: 20px;font-size:14px;width:18px;height:18px;line-height:16px;text-align:center;opacity:0.8;background-repeat:background-size:18px 18px; no-repeat;position: fixed;opacity: 0.8; bottom:2px !important;right:16vw !important;z-index: 21" ><img style="max-width:17px;overflow:hidden;"  src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAABYCAYAAABxlTA0AAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAAQfSURBVHic7dxNaFxVFAfw/7mTTB3fhCZD3kupQYooXXVhxVYj6Exai7hw50ZFF+LKRYrQRRclb7otlHZRcK0ggvi1ETSmSYtQ3FgQP3AhrRJDM6kzY74G0+QeN0rTmvfunZl3aXPn/JZz7zs5/Hl5X3PfAEIIIYQQQvQeutcNZGU6KsU284jpbwKWNGGJCEtgffOBfPDd2Nxcy0VfXgQ8HZViAia7LHMZwCVi/qqy2Pgmi74ADwLOKNw7MOiqgj6LWuPDCrDRTS2VVVM+IfDjDHqfo9L1mT3D5W5qScDpHmKtp2ZGShOdFpCAzfqYce5iNHSik413/DEYcHMc3oYG8OJ4rf5lOxt5ETBgf5kGoEjgCKAIwH4A+9r4M6ta4dDRG/WfbDfwJuBOTQ0N7c7lc8+B9QSAcdN8Aq5UavUx2/o9H/BWX0elpxXwGYAodaLW5fGbzUs2NeUkt8XRWv0Kb9JBAD+mTlTqpG1N2YO3MbV36OHcBn0PYHfSHCI+UFlo/GCqJXvwNp6fb/wOojfS5mio12xqScAJxhf+/JwZPyeNE/OTNnUk4HRnUsYO2hSQgFOoW/rTlOHBmTB81Fgjw368U2k2mwCuJY1r2nzEVEMCNvs1cYSTrzL+IwGbLSYNKCUBd4+SA5Y9OAuMZspo0bS5BGzAACeNaYs7YQnYMQnYMQnYMQnYMQnYMQnYMQnYMQnYsdy9buB+995qa/b1oEAElLd+zkD1SK0em7aX7+Qs3b3uwiZcIYQQQgghepX1jUZQDe94T2F1cvF89u34xyrgoBpOEHBu62cMHJeQzYzPIopxeJ7o/+8/EPBCfyVo3ppd+9ZNa36Qp2mOScCOScCOScCOScCOScCOScCOScCOScCOScCOGQNmQuKPBSmiXdm24x9jwIqSV3hr5sFs2/GPeQ8GJQZMkIBNzMdg5kbiGOGxLJvxUVd7MJieQSwnyjTGcPpZ/ZIyXAhUdCDDfrxjDLgZ37gOYD6xgNZWr/X3Kst/b5pJGmGitwfjQTnZJbALmPTllNHCBvIXsmnHP1YBk85/AiTfcID4lYFq+GZWTfnEagH2+uzyWr4c7AHhUMq0l/KVIFwvRxcx2+zqBzV9Yr0u4sF4eK8i+g1An2HqH0x8dlXn30U8v9ZdeztfWyvci9XhUwCdtpzeAtEUWH+hmK8q9Nf+vSLpKe29QsCg4ulwGkDFTTu3rUwuevF6Q3t3YQSm/vzLABbctHPb3Uu1dqq23zJan15uFY4MfMzMxwCEDnoC4M/KoY6eI/x1auHaysCuJ8D0QdYN+abzBzXvzLVW4tqrRDQG4CMAm5l15ZHMTiSFuDSaQ99bID4G4Klu6/myetPJmXrkzEiwvKafVaDDBN7H4FGARhkYJSCwqeHLVYQQQgghhLgv/QMwYw+Zjn59fwAAAABJRU5ErkJggg==" /></div>');


var btn=document.getElementById("b0n");
var reF=document.documentElement.requestFullscreen||document.documentElement.webkitRequestFullscreen;


//btn.id="btnydv";

//btn.innerHTML="ཐིïཋྀ";//

//btn.setAttribute("style","color:#27618D;font-weight: 20px;font-size:12px;width:26px;height:16px;line-height:16px;text-align:center;opacity:0.8;background-color:rgba(0,0,0,0.198);background-image:url();background-position:center;background-repeat:no-repeat;background-size:36px 36px;background-color:rgba(0,0,0,0.0098125);box-shadow:0px 0px 1px rgba(39,97,141,0.008);position:fixed !important;bottom:0px !important;right:20px !important;z-index:9999999999 !important;border-radius:50px !important;");



//
var btnyd1, btnyd2;

    document.addEventListener("touchstart",

    function(e) {

        btnyd1 = e.changedTouches[0].clientY

    });

    document.addEventListener("touchmove",

    function(e) {

       btnyd2 = e.changedTouches[0].clientY;

        if (btnyd2 - btnyd1 > 0) {

            document.getElementById("b0n").style.display = "none"

        } else {

            document.getElementById("b0n").style.display = "block"

        }

    });/*none♥block*/

//
var action=function(){
    reF.call(document.documentElement);

}
btn.onclick=action;