// ==UserScript==
// @name 🛑📵cssold
// @namespace   ScriptCat
// @description css字体大小 内容屏蔽  id # class .
// @version      220505.21
// @author       You
// @license MIT

// @include       *

// @exclude   *qazqazqaz


// @grant        none
// @run-at       document-end


// ==/UserScript==
/*body > [href^="固定/批量匹配"]{}无^固定指定
body > embed[id][src]{display:none !important}

<a href="javascript:addbookcase('85759','45533','第31！！')" style="color:red;">

A[href='javascript'][style='color:red;']


🛑悬浮广告参考
DIV[style='position:fixed;']{display:none !important}
A[href^='javascript']{display:none !important}


p.Readpage:nth-child(4)

m.xsbiquge.la###chaptercontent > p:nth-of-type(1)

www.sudugu.com##a[href="/xianxia/"]


*/


!(function() {
    'use strict';

    // 通过CSS预先隐藏元素，避免闪烁
    var css = `

div.cccvvv{font-size:24px}
a.ln{font-size:17px}
div.cccvvvccc{font-size:17px}
8tml{margin-left: 5px;margin-right:45px}
#content,
#cContent,
.content,
.container,
#mycontent,
div#htmlContent,
DIV#chaptercontent,
DIV.chapter-content,
DIV#TextContent,
#txt,DIV.txt,DIV.con,
DIV.txtnav,
DIV.articlecontent,
ARTICLE#article,
DIV.content.container,
DIV#novelcontent,
div#nr1,
DIV#Lab_Contents,
DIV#neirong1{font-size:24px;line-height: 38px;text-indent: 0em;padding-left: 6px;padding-right:4px}





    `;
    var style = document.createElement('style');
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);



})();

