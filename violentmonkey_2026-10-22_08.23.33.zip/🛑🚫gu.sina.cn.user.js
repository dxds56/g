// ==UserScript==
// @name 🛑🚫gu.sina.cn
// @namespace   ScriptCat
// @description css字体大小 内容屏蔽  id # class .
// @version      220505.21
// @author       You
// @license MIT
// @run-at       document-end


// @include       *sina.*

// @exclude    https://go.itab.link/#

// @grant       none

// ==/UserScript==

/*body > [href^="固定/批量匹配"]{}无^固定指定
body > embed[id][src]{display:none !important}

.com:*.js?v=17$third-party

||stescud.com^$third-party
! 广告网址 stescud.com

m.biquge365.net^$script

m.xsbiquge.la###chaptercontent > p:nth-of-type(1)

www.sudugu.com##a[href="/xianxia/"]

<a href="javascript:addbookcase('85759','45533','第31！！')" style="color:red;">

A[href='javascript'][style='color:red;']



m.xsbiquge.la###chaptercontent > p:nth-of-type(1)

www.sudugu.com##a[href="/xianxia/"]


*/


!(function() {
    'use strict';

    // 通过CSS预先隐藏元素，避免闪烁
    var css = `

#__callup_bottom_new{display:none !important}
div.-long-words.wb-wrap-flex.wb-flex-mid.wb-btn-wrap{display:none !important}
btn-subpage-bottom-callup{display:none !important}
snp-bottom-bar{display:none !important}
DIV#SNP_bottom_bar{display:none !important}

DIV#sft_scroll_banner{display:none !important}

DIV.call-header,DIV#appHeader,DIV.SFA--gold-hot-bar{display:none !important}


    `;
    var style = document.createElement('style');
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);



})();



/*清除悬浮广告元素🏖️🌫️🌋🏞️🏝️🏖️🌅*/


{function r(p,e){'fixed'!=p&&'sticky'!=p||e.parentNode.removeChild(e)}
 for(var x=document.querySelectorAll("*"),i=0;i<x.length;i++){var p=getComputedStyle(x[i]).position;r(p,x[i]);p=getComputedStyle(x[i],":after").getPropertyValue("position");r(p,x[i]);p=getComputedStyle(x[i],":before").getPropertyValue("position");r(p,x[i]);}}
