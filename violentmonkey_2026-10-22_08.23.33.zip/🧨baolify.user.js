// ==UserScript==
// @name 🧨baolify
// @namespace    https://viayoo.com/
// @version      220505.21
// @description  暴力翻页。
// @author       You
// @license MIT
// @run-at       document-end


// exclude    *imgbb.com/*
// exclude    *://*.anotepad.com/*
// exclude    *://*.ibb.co/*
// exclude    *://youtube.iiilab.com/*
// exclude    *://*.baidu.com/*
// exclude    *://*.github.com/*
// exclude    *://*.woozooo.com/*
// exclude    *://*.kekenet.com/*
// exclude    *://*.crxsoso.com/*
// exclude    *://*.viz.com/*
// exclude    *://*.feedspot.com/*
// exclude    *://*.bing.com/*
// exclude    *://*.bing.com/*
// exclude    *.qidian.com/?source=pc_jump*
// exclude    *://*.qianxingkingdommission.org/*
// exclude    *://*.xiaoyakankan.com/*
// exclude    *://*.duckduckgo.com/*
// exclude    *://*.sina.cn/*

//
//
//
// @include      *.twbook*
// @include      *ixdzs*
// @include      *ixdzs8.*
// @include      *.147txt.*
// @include      *22biqu.*
// @include       *.101kanshu.*
// @include      *.qidian.*
// @include      *twkan.*
// @include      *boxnovel.baidu.com/boxnovel/*

// @grant        none
// ==/UserScript==


/*空白触屏翻页-暴力版*/var fycz=450;/*450即翻页滚动像素值，可按需修改*/document.body.addEventListener("click",function(e){var ecy=e.clientY,sah=window.screen.availHeight/3;if(ecy<sah){window.scrollBy(0,window.innerHeight*0.9)}else if(ecy>sah){window.scrollBy(0,325)}});



/*🍎隐藏全屏翻页中间*/

/*🍇翻页*/
{var tetn=document.createElement("div");

tetn.id="tetnyd";

tetn.innerHTML="";//左下

tetn.setAttribute("style","font-size:5px !important;color:#27618D;width:10px !important;height:50vh !important;line-height:50vh !important;text-align:center !important;background-color:rgba(250,250,250,0);box-shadow:inset 0px 0px 2px rgba(39,97,141,0.25);position:fixed !important;bottom:12vh !important;left:0px !important;z-index:9999999999 !important;border-radius:10px 10px 10px 10px !important;");

var tetnyd1, tetnyd2;

    document.addEventListener("touchstart",

    function(e) {

        tetnyd1 = e.changedTouches[0].clientY

    });

    document.addEventListener("touchmove",

    function(e) {

       tetnyd2 = e.changedTouches[0].clientY;

        if (tetnyd2 - tetnyd1 > 0) {

            document.getElementById("tetnyd").style.display = "none"

        } else {

            document.getElementById("tetnyd").style.display = "block"

        }

    });/*none♥block*/

tetn.onclick=function (){window.scrollBy(0,325);};

document.getElementsByTagName("html").item(0).appendChild(tetn);};

{

var Dtetn=document.createElement("div");

Dtetn.id="Dtetnyd";

Dtetn.innerHTML="";//右下♥♥♥♥

Dtetn.setAttribute("style","font-size:5px !important;color:#27618D;width:10px !important;height:50vh !important;line-height:50vh !important;text-align:center !important;background-color:rgba(250,250,250,0);box-shadow:inset 0px 0px 2px rgba(39,97,141,0.25);position:fixed !important;bottom:12vh !important;right:0px !important;z-index:9999999999 !important;border-radius:10px 10px 10px 10px");

var Dtetnyd1, Dtetnyd2;

    document.addEventListener("touchstart",

    function(e) {

        Dtetnyd1 = e.changedTouches[0].clientY

    });

    document.addEventListener("touchmove",

    function(e) {

       Dtetnyd2 = e.changedTouches[0].clientY;

        if (Dtetnyd2 - Dtetnyd1 > 0) {

            document.getElementById("Dtetnyd").style.display = "none"

        } else {

            document.getElementById("Dtetnyd").style.display = "block"

        }

    });/*none♥block*/

Dtetn.onclick=function (){window.scrollBy(0,325);

};

document.getElementsByTagName("html").item(0).appendChild(Dtetn);

};
