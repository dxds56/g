// ==UserScript==
// @name 🛑xbqg77.com
// @namespace   ScriptCat
// @description css字体大小 内容屏蔽  id # class .
// @version      220505.21
// @author       You
// @license MIT
// @run-at       document-end

// @include       *.xbqg77.com/*/*
// @exclude       https://www.xbqg77.com

// @grant       none

// ==/UserScript==

/*body > [href^="固定/批量匹配"]{}无^固定指定
body > embed[id][src]{display:none !important}


m.xsbiquge.la###chaptercontent > p:nth-of-type(1)

www.sudugu.com##a[href="/xianxia/"]


*/


!(function() {
    'use strict';

    // 通过CSS预先隐藏元素，避免闪烁
    var css = `

ARTICLE.page-content,
#content,
#cContent,
.content,
.container,
#mycontent,
div#htmlContent,
DIV#chaptercontent,
DIV.chapter-content,
#txt,DIV.txt,DIV.con,
DIV.txtnav,
DIV.articlecontent,
DIV#novelcontent,
div#nr1,
DIV#Lab_Contents,
DIV#neirong1{font-size:24px;line-height: 38px;text-indent: 0em;padding-left: 15wh;padding-right:14wh;!important;}


DIV.yd_top.yd,DIV.dir{font-size:14px;line-height: 18px;!important;}


DIV#page-toolbar{display:none !important}

DIV.page-d-top{display:none !important}

HEADER.search.container.search-self,DIV.set,DIV.tj_yd.yd{display:none !important}



    `;
    var style = document.createElement('style');
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);

})();
